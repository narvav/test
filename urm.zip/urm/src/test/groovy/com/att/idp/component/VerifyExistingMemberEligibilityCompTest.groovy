package com.att.idp.component

import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.AccountInfoDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetAssociatedMembersDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetProvisionedServicesDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.SubAccountsDBHelper
import com.att.idp.idgraphuserregistrationms.helper.voltage.ProofingEncryptionHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import org.hamcrest.CoreMatchers
import org.spockframework.spring.SpringBean

/**
 * Component test for POST /lsreg/verifyExistingMemberEligibility endpoint.
 *
 * Dependency chain:
 *   LSRegResourceImpl (INTERNAL — real)
 *     ├── VerifyExistingMemberEligibilityRequestValidator (INTERNAL — real)
 *     └── VerifyExistingMemberEligibilityServiceImpl (INTERNAL — real)
 *          └── VerifyExistingMemberEligibilityHelper (INTERNAL — real)
 *               ├── AccountInfoDBHelper (EXTERNAL — mock)
 *               ├── GetProvisionedServicesDBHelper (EXTERNAL — mock)
 *               ├── GetMemberServicesDBHelper (EXTERNAL — mock)
 *               ├── GetAssociatedMembersDBHelper (EXTERNAL — mock)
 *               ├── SubAccountsDBHelper (EXTERNAL — mock)
 *               ├── ProofingEncryptionHelper (EXTERNAL — mock, Voltage)
 *               └── LockoutHelper (INTERNAL — real, has own DB deps)
 */
class VerifyExistingMemberEligibilityCompTest extends CompTestBase {

    private String uri = '/lsreg/verifyExistingMemberEligibility'

    // TECH_DEBT: DUPLICATE — GetMemberServicesDBHelper also mocked in other CTs; consolidate in CompTestBase (Phase 4)
    @SpringBean
    GetMemberServicesDBHelper getMemberServicesDBHelper = Mock()

    @SpringBean
    AccountInfoDBHelper accountInfoDBHelper = Mock()

    @SpringBean
    GetProvisionedServicesDBHelper getProvisionedServicesDBHelper = Mock()

    @SpringBean
    GetAssociatedMembersDBHelper getAssociatedMembersDBHelper = Mock()

    @SpringBean
    SubAccountsDBHelper subAccountsDBHelper = Mock()

    @SpringBean
    ProofingEncryptionHelper proofingEncryptionHelper = Mock()

    private Map<String, String> validHeaders() {
        [
            'Content-Type' : 'application/json',
            'X-ATT-ClientId': 'IDP',
            'idp-trace-id' : 'trace123:trace123:0:0'
        ]
    }

    private String validRequest() {
        '{"userId":"testuser123","domain":"att.net","ban":"VD0015088"}'
    }

    // ========== Validation Error Scenarios ==========
    // NOTE: 'missing idp-trace-id' is not testable at CT level — SDK auto-generates trace IDs via CommonUtil.getTraceId()

    def "missing X-ATT-ClientId returns 400"() {
        given:
        Map<String, String> headers = [
            'Content-Type' : 'application/json',
            'idp-trace-id' : 'trace123:trace123:0:0'
        ]

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .body(validRequest())
                .when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then()
                .body('appStatusCode', CoreMatchers.equalTo('100'))
                .body('appInfo', CoreMatchers.containsString('Missing or invalid X-ATT-ClientId'))
    }

    def "missing ban returns 400"() {
        given:
        def headers = validHeaders()
        String req = '{"userId":"testuser123","domain":"att.net"}'

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .body(req)
                .when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then()
                .body('appStatusCode', CoreMatchers.equalTo('100'))
                .body('appInfo', CoreMatchers.containsString('BAN'))
    }

    def "missing userId returns 400"() {
        given:
        def headers = validHeaders()
        String req = '{"domain":"att.net","ban":"VD0015088"}'

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .body(req)
                .when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then()
                .body('appStatusCode', CoreMatchers.equalTo('100'))
                .body('appInfo', CoreMatchers.containsString('userId'))
    }

    def "userId starting with sbciptv returns 400"() {
        given:
        def headers = validHeaders()
        String req = '{"userId":"sbciptvuser001","domain":"att.net","ban":"VD0015088"}'

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .body(req)
                .when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then()
                .body('appStatusCode', CoreMatchers.equalTo('100'))
                .body('appInfo', CoreMatchers.containsString('userId can NOT start with sbciptv or attaab'))
    }

    def "invalid isExternalCall returns 400"() {
        given:
        def headers = validHeaders()
        String req = '{"userId":"testuser123","domain":"att.net","ban":"VD0015088","isExternalCall":"X"}'

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .body(req)
                .when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then()
                .body('appStatusCode', CoreMatchers.equalTo('100'))
                .body('appInfo', CoreMatchers.containsString('isExternalCall must be one of Y or N'))
    }

    // ========== Success Path ==========
    // TECH_DEBT: MISSING_TEST — success path requires extensive mock setup for VerifyExistingMemberEligibilityHelper (1241 lines)
    // with 7 external dependencies (AccountInfoDBHelper, GetProvisionedServicesDBHelper, GetMemberServicesDBHelper,
    // GetAssociatedMembersDBHelper, SubAccountsDBHelper, ProofingEncryptionHelper, LockoutHelper dependencies).
    // Need dedicated effort to trace the happy-path through the helper and provide correct mock return values.
}
