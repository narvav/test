package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraph.extclient.db.service.TworkitemService
import com.att.idp.idgraph.extclient.yahoo.model.AliasGroup
import com.att.idp.idgraph.extclient.yahoo.model.AliasList
import com.att.idp.idgraph.extclient.yahoo.model.BaseYahooResponse
import com.att.idp.idgraph.extclient.yahoo.model.ChangeAliasesResponse
import com.att.idp.idgraph.extclient.yahoo.model.CreateAccountResponse
import com.att.idp.idgraph.extclient.yahoo.model.DeleteAccountResponse
import com.att.idp.idgraph.extclient.yahoo.model.ErrorGroup
import com.att.idp.idgraph.extclient.yahoo.model.ErrorList
import com.att.idp.idgraph.extclient.yahoo.model.GetAccountAttributesResponse
import com.att.idp.idgraph.extclient.yahoo.model.SetAccountAttributesResponse
import com.att.idp.idgraph.extclient.yahoo.service.YahooService
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetInfoByMaskDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetSlidInfoDBHelper
import com.att.idp.idgraphuserregistrationms.helper.voltage.VoltageEncryptDecryptHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.MPSDefs
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ObjectNode
import spock.lang.Specification
import spock.lang.Unroll

import java.lang.reflect.Field

/**
 * Spock unit tests for YahooSyncOperation covering all branches.
 * Follows IDGraph testing conventions: concrete types, comprehensive assertions, explicit interactions, ending with 0 * _.
 *
 * NOTE: performSync tests use HANDLE+DOMAIN only (no GUID) because the inherited
 * getSlidInfo in SyncOperation routes by domain and would NPE if GUID path taken
 * (domain stays null). DB mock returns CommonErrorMap.makeCategoryMap-structured maps.
 */
class YahooSyncOperationTest extends Specification {

    YahooService yahooService
    TworkitemService tworkitemService
    VoltageEncryptDecryptHelper voltageHelper
    ObjectMapper objectMapper
    GetSlidInfoDBHelper getSlidInfoDBHelper
    GetInfoByMaskDBHelper getInfoByMaskDBHelper
    YahooSyncOperation yahooSyncOperation

    // Helper: set field value via reflection (searches superclasses)
    private static void setField(Object target, String fieldName, Object value) {
        Class<?> type = target.getClass()
        Field field = null
        while (type != null) {
            try {
                field = type.getDeclaredField(fieldName)
                break
            } catch (NoSuchFieldException ignored) {
                type = type.getSuperclass()
            }
        }
        if (field == null) {
            throw new IllegalArgumentException("Field '" + fieldName + "' not found on " + target.getClass().getName())
        }
        field.setAccessible(true)
        field.set(target, value)
    }

    /**
     * Builds a DB response map structured like CommonErrorMap.makeCategoryMap output
     * with additional SLID profile data merged in. getSlidInfo returns this directly
     * when the response has no "slidInfo" key.
     */
    private static HashMap<String, Object> buildSuccessDbResponse(Map<String, Object> profileData) {
        HashMap<String, Object> dbResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        dbResponse.putAll(profileData)
        return dbResponse
    }

    /** Builds a DB "record not found" response — getSlidInfo maps this to ERR_USER_NOT_FOUND. */
    private static HashMap<String, Object> buildNotFoundDbResponse() {
        return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, "Record not found")
    }

    /** Standard performSync input (handle+domain, no guid to avoid NPE in getSlidInfo). */
    private static HashMap<String, Object> buildSyncInput(String callingSystemId = "UST") {
        return [
                (CommonDefs.HANDLE)       : "testuser",
                (CommonDefs.DOMAIN)       : "att.net",
                (CommonDefs.TRANSACTION_ID): "txn1",
                "callingSystemId"         : callingSystemId
        ] as HashMap<String, Object>
    }

    void setup() {
        yahooService = Mock(YahooService)
        tworkitemService = Mock(TworkitemService)
        voltageHelper = Mock(VoltageEncryptDecryptHelper)
        objectMapper = new ObjectMapper()
        getSlidInfoDBHelper = Mock(GetSlidInfoDBHelper)
        getInfoByMaskDBHelper = Mock(GetInfoByMaskDBHelper)

        yahooSyncOperation = new YahooSyncOperation(yahooService, tworkitemService, voltageHelper, objectMapper)
        setField(yahooSyncOperation, 'oGetSlidInfoDBHelper', getSlidInfoDBHelper)
        setField(yahooSyncOperation, 'oGetInfoByMaskDBHelper', getInfoByMaskDBHelper)
    }

    // --- validateInput tests ---

    @Unroll
    def "validateInput should return error when input is #scenarioName"() {
        when: "validateInput is called"
        HashMap<String, Object> result = yahooSyncOperation.validateInput(testInput)

        then: "Result contains invalid data error"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_INVALID_DATA
        result.get(CErrorDefs.COMMON_APP_INFO).toString().contains("null or empty")
        0 * _

        where:
        scenarioName | testInput
        "null"       | null
        "empty"      | [:]
    }

    def "validateInput should return error when handle/domain and guid are all missing"() {
        given: "Input without handle, domain, or guid"
        HashMap<String, Object> input = [(CommonDefs.HANDLE): "", (CommonDefs.DOMAIN): "", (CommonDefs.GUID): ""]

        when: "validateInput is called"
        HashMap<String, Object> result = yahooSyncOperation.validateInput(input)

        then: "Result contains invalid data error"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_INVALID_DATA
        result.get(CErrorDefs.COMMON_APP_INFO).toString().contains("handle/domain or guid")
        0 * _
    }

    def "validateInput should return null when handle and domain are present"() {
        given: "Valid input with handle and domain"
        HashMap<String, Object> input = [(CommonDefs.HANDLE): "testuser", (CommonDefs.DOMAIN): "att.net"]

        when: "validateInput is called"
        HashMap<String, Object> result = yahooSyncOperation.validateInput(input)

        then: "Result is null (no validation error)"
        result == null
        0 * _
    }

    def "validateInput should return null when guid is present"() {
        given: "Valid input with guid only"
        HashMap<String, Object> input = [(CommonDefs.GUID): "some-guid"]

        when: "validateInput is called"
        HashMap<String, Object> result = yahooSyncOperation.validateInput(input)

        then: "Result is null (no validation error)"
        result == null
        0 * _
    }

    // --- checkEligibility tests ---

    @Unroll
    def "checkEligibility should return error when migrationInd=#migInd"() {
        given: "Input with ineligible migrationInd"
        HashMap<String, Object> input = ["migration_ind": migInd, "sor_name": "ATT"]

        when: "checkEligibility is called"
        HashMap<String, Object> result = yahooSyncOperation.checkEligibility(input)

        then: "Result contains invalid data error"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_INVALID_DATA
        result.get(CErrorDefs.COMMON_APP_INFO).toString().contains("migrationInd")
        0 * _

        where:
        migInd | _
        null   | _
        "L"    | _
        "N"    | _
    }

    @Unroll
    def "checkEligibility should return error when sor_name=#sorName"() {
        given: "Input with ineligible sor_name"
        HashMap<String, Object> input = ["migration_ind": "Y", "sor_name": sorName]

        when: "checkEligibility is called"
        HashMap<String, Object> result = yahooSyncOperation.checkEligibility(input)

        then: "Result contains invalid data error"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_INVALID_DATA
        result.get(CErrorDefs.COMMON_APP_INFO).toString().contains("sor_name")
        0 * _

        where:
        sorName | _
        null    | _
        "NONE"  | _
        "COLA"  | _
    }

    def "checkEligibility should return null when user is eligible"() {
        given: "Input with eligible migrationInd and sor_name"
        HashMap<String, Object> input = ["migration_ind": "Y", "sor_name": "ATT"]

        when: "checkEligibility is called"
        HashMap<String, Object> result = yahooSyncOperation.checkEligibility(input)

        then: "Result is null (user is eligible)"
        result == null
        0 * _
    }

    // --- isAccountExists tests ---

    def "isAccountExists should return false when response is null"() {
        expect:
        !yahooSyncOperation.isAccountExists(null)
    }

    def "isAccountExists should return true when resultCode is SUCCESS"() {
        given: "Response with SUCCESS"
        GetAccountAttributesResponse response = new GetAccountAttributesResponse()
        response.setResultCode("SUCCESS")

        expect:
        yahooSyncOperation.isAccountExists(response)
    }

    def "isAccountExists should return false when error list contains 'AccountID does not exist'"() {
        given: "Response with account not exist error"
        GetAccountAttributesResponse response = new GetAccountAttributesResponse()
        response.setResultCode("FAILURE")
        ErrorGroup eg = new ErrorGroup()
        eg.setErrorString("AccountID does not exist")
        ErrorList el = new ErrorList()
        el.setErrorGroups([eg])
        response.setErrorList(el)

        expect:
        !yahooSyncOperation.isAccountExists(response)
    }

    def "isAccountExists should return true when error list has other errors"() {
        given: "Response with non-account-exist error"
        GetAccountAttributesResponse response = new GetAccountAttributesResponse()
        response.setResultCode("FAILURE")
        ErrorGroup eg = new ErrorGroup()
        eg.setErrorString("Some other error")
        ErrorList el = new ErrorList()
        el.setErrorGroups([eg])
        response.setErrorList(el)

        expect:
        yahooSyncOperation.isAccountExists(response)
    }

    // --- compareProfileData tests ---

    def "compareProfileData should return empty map when profiles match"() {
        given: "Matching MPSYS and Yahoo profiles"
        HashMap<String, Object> mpsys = [
                (MPSDefs.DB_FIRST_NAME): "John",
                (MPSDefs.DB_LAST_NAME) : "Doe",
                "gender"               : "M",
                "language"             : "en"
        ]
        GetAccountAttributesResponse yahoo = new GetAccountAttributesResponse()
        yahoo.setGivenName("John")
        yahoo.setFamilyName("Doe")
        yahoo.setGender("M")
        yahoo.setPrimaryLanguage("en")

        when: "compareProfileData is called"
        HashMap<String, Object> diff = yahooSyncOperation.compareProfileData(mpsys, yahoo)

        then: "No differences detected"
        diff.isEmpty()
        0 * _
    }

    def "compareProfileData should detect differences in firstName and lastName"() {
        given: "Different first and last names"
        HashMap<String, Object> mpsys = [
                (MPSDefs.DB_FIRST_NAME): "Jane",
                (MPSDefs.DB_LAST_NAME) : "Smith",
                "gender"               : "F",
                "language"             : "en"
        ]
        GetAccountAttributesResponse yahoo = new GetAccountAttributesResponse()
        yahoo.setGivenName("John")
        yahoo.setFamilyName("Doe")
        yahoo.setGender("F")
        yahoo.setPrimaryLanguage("en")

        when: "compareProfileData is called"
        HashMap<String, Object> diff = yahooSyncOperation.compareProfileData(mpsys, yahoo)

        then: "firstName and lastName differences detected"
        diff.size() == 2
        diff.get("firstName") == "Jane"
        diff.get("lastName") == "Smith"
        0 * _
    }

    // --- compareAliasData tests ---

    def "compareAliasData should return empty map when aliases match"() {
        given: "Matching aliases"
        HashMap<String, Object> mpsys = [
                (MPSDefs.KEY_LINKED_USERS): [
                        [(CommonDefs.HANDLE): "alias1", (CommonDefs.DOMAIN): "att.net"]
                ]
        ]
        GetAccountAttributesResponse yahoo = new GetAccountAttributesResponse()
        AliasGroup ag = new AliasGroup()
        ag.setAlias("alias1@att.net")
        AliasList al = new AliasList()
        al.setAliasGroupList([ag])
        yahoo.setAliasList(al)

        when: "compareAliasData is called"
        Map<String, List<String>> diff = yahooSyncOperation.compareAliasData(mpsys, yahoo)

        then: "No differences"
        diff.isEmpty()
        0 * _
    }

    def "compareAliasData should detect aliases to add and remove"() {
        given: "MPS has alias2, Yahoo has alias1"
        HashMap<String, Object> mpsys = [
                (MPSDefs.KEY_LINKED_USERS): [
                        [(CommonDefs.HANDLE): "alias2", (CommonDefs.DOMAIN): "att.net"]
                ]
        ]
        GetAccountAttributesResponse yahoo = new GetAccountAttributesResponse()
        AliasGroup ag = new AliasGroup()
        ag.setAlias("alias1@att.net")
        AliasList al = new AliasList()
        al.setAliasGroupList([ag])
        yahoo.setAliasList(al)

        when: "compareAliasData is called"
        Map<String, List<String>> diff = yahooSyncOperation.compareAliasData(mpsys, yahoo)

        then: "alias2 should be added, alias1 removed"
        diff.get("addEmailAliases") == ["alias2@att.net"]
        diff.get("removeEmailAliases") == ["alias1@att.net"]
        0 * _
    }

    // --- compareAccountStatus tests ---

    def "compareAccountStatus should return null when yahoo has no account status"() {
        given: "Yahoo response without account status"
        HashMap<String, Object> mpsys = [:]
        GetAccountAttributesResponse yahoo = new GetAccountAttributesResponse()

        when: "compareAccountStatus is called"
        String result = yahooSyncOperation.compareAccountStatus(mpsys, yahoo)

        then: "Null returned"
        result == null
        0 * _
    }

    def "compareAccountStatus should return MPSYS status when different from Yahoo"() {
        given: "Different account statuses"
        HashMap<String, Object> mpsys = [
                (CommonDefs.SERVICES): [
                        "PORTAL": ["serviceType": "PORTAL", "serviceStatus": "SUSPENDED"]
                ]
        ]
        GetAccountAttributesResponse yahoo = new GetAccountAttributesResponse()
        yahoo.setAccountStatus("ENABLED")

        when: "compareAccountStatus is called"
        String result = yahooSyncOperation.compareAccountStatus(mpsys, yahoo)

        then: "MPS status returned"
        result == "SUSPENDED"
        0 * _
    }

    def "compareAccountStatus should return null when statuses match"() {
        given: "Matching account statuses"
        HashMap<String, Object> mpsys = [
                (CommonDefs.SERVICES): [
                        "PORTAL": ["serviceType": "PORTAL", "serviceStatus": "ENABLED"]
                ]
        ]
        GetAccountAttributesResponse yahoo = new GetAccountAttributesResponse()
        yahoo.setAccountStatus("ENABLED")

        when: "compareAccountStatus is called"
        String result = yahooSyncOperation.compareAccountStatus(mpsys, yahoo)

        then: "Null returned (no diff)"
        result == null
        0 * _
    }

    // --- performSync tests ---
    // NOTE: No GUID in inputs — getSlidInfo takes HANDLE path; domain="att.net" routes to getInfoByMask.
    // DB responses use CommonErrorMap.makeCategoryMap for proper structure.
    // getSlidInfo maps ERR_REC_NOT_FOUND (285) → ERR_USER_NOT_FOUND (121).

    def "performSync should return error when input is null"() {
        when: "performSync called with null"
        HashMap<String, Object> result = yahooSyncOperation.performSync(null)

        then: "Error returned"
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_INVALID_DATA
        0 * _
    }

    def "performSync should return error when input is empty"() {
        when: "performSync called with empty map"
        HashMap<String, Object> result = yahooSyncOperation.performSync(new HashMap<String, Object>())

        then: "Error returned"
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_INVALID_DATA
        0 * _
    }

    def "performSync should return user not found when DB returns rec not found and callingSystemId is not DATAMGT"() {
        given: "Valid input and DB returns ERR_REC_NOT_FOUND"
        HashMap<String, Object> input = buildSyncInput("UST")

        when: "performSync is called"
        HashMap<String, Object> result = yahooSyncOperation.performSync(input)

        then: "User not found error returned (getSlidInfo maps REC_NOT_FOUND to USER_NOT_FOUND)"
        1 * getInfoByMaskDBHelper.getInfoByMask(_) >> buildNotFoundDbResponse()
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_USER_NOT_FOUND
        0 * _
    }

    def "performSync should delete Yahoo account when user not found in MPS and callingSystemId is DATAMGT"() {
        given: "Input with DATAMGT callingSystemId and DB returns ERR_REC_NOT_FOUND"
        HashMap<String, Object> input = buildSyncInput("DATAMGT")

        DeleteAccountResponse deleteResponse = new DeleteAccountResponse()
        deleteResponse.setResultCode("SUCCESS")

        when: "performSync is called"
        HashMap<String, Object> result = yahooSyncOperation.performSync(input)

        then: "Yahoo account deleted and success returned"
        1 * getInfoByMaskDBHelper.getInfoByMask(_) >> buildNotFoundDbResponse()
        1 * yahooService.deleteAccount({ ObjectNode node -> node.get("handle").asText() == "testuser" }) >> deleteResponse
        1 * tworkitemService.deleteByStopKeyAndStopValue("stopfield", "yahoostoptestuser@att.net")
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.COMMON_SUCCESS
        0 * _
    }

    def "performSync should return error when eligibility check fails"() {
        given: "Valid input but ineligible user (migrationInd=L)"
        HashMap<String, Object> input = buildSyncInput()

        when: "performSync is called"
        HashMap<String, Object> result = yahooSyncOperation.performSync(input)

        then: "Eligibility error returned"
        1 * getInfoByMaskDBHelper.getInfoByMask(_) >> buildSuccessDbResponse([
                (MPSDefs.DB_FIRST_NAME): "John",
                (MPSDefs.DB_LAST_NAME) : "Doe",
                "migration_ind"        : "L",
                "sor_name"             : "ATT"
        ])
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_INVALID_DATA
        result.get(CErrorDefs.COMMON_APP_INFO).toString().contains("migrationInd")
        0 * _
    }

    def "performSync should create Yahoo account when account does not exist"() {
        given: "Valid input, eligible user, Yahoo account does not exist"
        HashMap<String, Object> input = buildSyncInput()

        GetAccountAttributesResponse queryResponse = new GetAccountAttributesResponse()
        queryResponse.setResultCode("FAILURE")
        ErrorGroup eg = new ErrorGroup()
        eg.setErrorString("AccountID does not exist")
        ErrorList el = new ErrorList()
        el.setErrorGroups([eg])
        queryResponse.setErrorList(el)

        CreateAccountResponse createResponse = new CreateAccountResponse()
        createResponse.setResultCode("SUCCESS")

        when: "performSync is called"
        HashMap<String, Object> result = yahooSyncOperation.performSync(input)

        then: "Account queried, then created"
        1 * getInfoByMaskDBHelper.getInfoByMask(_) >> buildSuccessDbResponse([
                (MPSDefs.DB_FIRST_NAME): "John",
                (MPSDefs.DB_LAST_NAME) : "Doe",
                "migration_ind"        : "Y",
                "sor_name"             : "ATT",
                "gender"               : "M",
                "language"             : "en"
        ])
        1 * yahooService.getAccountAttributes({ ObjectNode node -> node.get("handle").asText() == "testuser" }) >> queryResponse
        1 * yahooService.createAccount({ ObjectNode node ->
            node.get("handle").asText() == "testuser" &&
            node.get("eventname").asText() == "CreateAccount"
        }) >> createResponse
        1 * tworkitemService.deleteByStopKeyAndStopValue("stopfield", "yahoostoptestuser@att.net")
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.COMMON_SUCCESS
        0 * _
    }

    def "performSync should sync profile diffs when account exists and profile differs"() {
        given: "Valid input, eligible user, Yahoo account exists with different profile"
        HashMap<String, Object> input = buildSyncInput()

        GetAccountAttributesResponse queryResponse = new GetAccountAttributesResponse()
        queryResponse.setResultCode("SUCCESS")
        queryResponse.setGivenName("John")
        queryResponse.setFamilyName("Doe")
        queryResponse.setGender("F")
        queryResponse.setPrimaryLanguage("en")

        SetAccountAttributesResponse updateResponse = new SetAccountAttributesResponse()
        updateResponse.setResultCode("SUCCESS")

        when: "performSync is called"
        HashMap<String, Object> result = yahooSyncOperation.performSync(input)

        then: "Profile update sent to Yahoo"
        1 * getInfoByMaskDBHelper.getInfoByMask(_) >> buildSuccessDbResponse([
                (MPSDefs.DB_FIRST_NAME): "Jane",
                (MPSDefs.DB_LAST_NAME) : "Smith",
                "migration_ind"        : "Y",
                "sor_name"             : "ATT",
                "gender"               : "F",
                "language"             : "en"
        ])
        1 * yahooService.getAccountAttributes(_) >> queryResponse
        1 * yahooService.setAccountAttributes(_) >> updateResponse
        1 * tworkitemService.deleteByStopKeyAndStopValue("stopfield", "yahoostoptestuser@att.net")
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.COMMON_SUCCESS
        0 * _
    }

    def "performSync should return success with no changes when profiles match"() {
        given: "Valid input, eligible user, Yahoo account exists with matching profile"
        HashMap<String, Object> input = buildSyncInput()

        GetAccountAttributesResponse queryResponse = new GetAccountAttributesResponse()
        queryResponse.setResultCode("SUCCESS")
        queryResponse.setGivenName("John")
        queryResponse.setFamilyName("Doe")
        queryResponse.setGender("M")
        queryResponse.setPrimaryLanguage("en")

        when: "performSync is called"
        HashMap<String, Object> result = yahooSyncOperation.performSync(input)

        then: "No updates sent, success returned"
        1 * getInfoByMaskDBHelper.getInfoByMask(_) >> buildSuccessDbResponse([
                (MPSDefs.DB_FIRST_NAME): "John",
                (MPSDefs.DB_LAST_NAME) : "Doe",
                "migration_ind"        : "Y",
                "sor_name"             : "ATT",
                "gender"               : "M",
                "language"             : "en"
        ])
        1 * yahooService.getAccountAttributes(_) >> queryResponse
        0 * yahooService.setAccountAttributes(_)
        0 * yahooService.changeAliases(_)
        0 * yahooService.changeAccountStatus(_)
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.COMMON_SUCCESS
        0 * _
    }

    def "performSync should handle exception and return error map"() {
        given: "Valid input but getInfoByMask throws exception"
        HashMap<String, Object> input = buildSyncInput()

        when: "performSync is called"
        HashMap<String, Object> result = yahooSyncOperation.performSync(input)

        then: "Error map returned"
        1 * getInfoByMaskDBHelper.getInfoByMask(_) >> { throw new RuntimeException("DB connection failed") }
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_SYS_APPL
        0 * _
    }

    def "performSync should return error when create account fails"() {
        given: "Valid input, eligible user, account does not exist, create fails"
        HashMap<String, Object> input = buildSyncInput()

        GetAccountAttributesResponse queryResponse = new GetAccountAttributesResponse()
        queryResponse.setResultCode("FAILURE")
        ErrorGroup eg = new ErrorGroup()
        eg.setErrorString("AccountID does not exist")
        ErrorList el = new ErrorList()
        el.setErrorGroups([eg])
        queryResponse.setErrorList(el)

        CreateAccountResponse createResponse = new CreateAccountResponse()
        createResponse.setResultCode("FAILURE")
        createResponse.setAppInfo("Creation failed")

        when: "performSync is called"
        HashMap<String, Object> result = yahooSyncOperation.performSync(input)

        then: "Error returned for failed create"
        1 * getInfoByMaskDBHelper.getInfoByMask(_) >> buildSuccessDbResponse([
                (MPSDefs.DB_FIRST_NAME): "John",
                (MPSDefs.DB_LAST_NAME) : "Doe",
                "migration_ind"        : "Y",
                "sor_name"             : "ATT"
        ])
        1 * yahooService.getAccountAttributes(_) >> queryResponse
        1 * yahooService.createAccount(_) >> createResponse
        0 * tworkitemService.deleteByStopKeyAndStopValue(_, _)
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_SYS_APPL
        0 * _
    }

    def "performSync should return error when profile update fails"() {
        given: "Valid input, eligible user, account exists, profile update fails"
        HashMap<String, Object> input = buildSyncInput()

        GetAccountAttributesResponse queryResponse = new GetAccountAttributesResponse()
        queryResponse.setResultCode("SUCCESS")
        queryResponse.setGivenName("John")
        queryResponse.setFamilyName("Doe")

        SetAccountAttributesResponse updateResponse = new SetAccountAttributesResponse()
        updateResponse.setResultCode("FAILURE")
        updateResponse.setAppInfo("Update failed")

        when: "performSync is called"
        HashMap<String, Object> result = yahooSyncOperation.performSync(input)

        then: "Error returned for failed update"
        1 * getInfoByMaskDBHelper.getInfoByMask(_) >> buildSuccessDbResponse([
                (MPSDefs.DB_FIRST_NAME): "Jane",
                (MPSDefs.DB_LAST_NAME) : "Doe",
                "migration_ind"        : "Y",
                "sor_name"             : "ATT"
        ])
        1 * yahooService.getAccountAttributes(_) >> queryResponse
        1 * yahooService.setAccountAttributes(_) >> updateResponse
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_SYS_APPL
        0 * _
    }

    def "performSync should sync aliases when alias diff detected"() {
        given: "Valid input, eligible user, account exists, alias diff"
        HashMap<String, Object> input = buildSyncInput()

        GetAccountAttributesResponse queryResponse = new GetAccountAttributesResponse()
        queryResponse.setResultCode("SUCCESS")
        queryResponse.setGivenName("John")
        queryResponse.setFamilyName("Doe")
        AliasGroup ag = new AliasGroup()
        ag.setAlias("oldalias@att.net")
        AliasList al = new AliasList()
        al.setAliasGroupList([ag])
        queryResponse.setAliasList(al)

        ChangeAliasesResponse aliasResponse = new ChangeAliasesResponse()
        aliasResponse.setResultCode("SUCCESS")

        when: "performSync is called"
        HashMap<String, Object> result = yahooSyncOperation.performSync(input)

        then: "Alias change sent to Yahoo"
        1 * getInfoByMaskDBHelper.getInfoByMask(_) >> buildSuccessDbResponse([
                (MPSDefs.DB_FIRST_NAME)   : "John",
                (MPSDefs.DB_LAST_NAME)    : "Doe",
                "migration_ind"           : "Y",
                "sor_name"                : "ATT",
                (MPSDefs.KEY_LINKED_USERS): [
                        [(CommonDefs.HANDLE): "newalias", (CommonDefs.DOMAIN): "att.net"]
                ]
        ])
        1 * yahooService.getAccountAttributes(_) >> queryResponse
        1 * yahooService.changeAliases(_) >> aliasResponse
        1 * tworkitemService.deleteByStopKeyAndStopValue("stopfield", "yahoostoptestuser@att.net")
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.COMMON_SUCCESS
        0 * _
    }

    def "performSync should delete Yahoo account when DATAMGT and delete fails"() {
        given: "DATAMGT input, user not found, delete fails"
        HashMap<String, Object> input = buildSyncInput("DATAMGT")

        DeleteAccountResponse deleteResponse = new DeleteAccountResponse()
        deleteResponse.setResultCode("FAILURE")
        deleteResponse.setAppInfo("Delete failed")

        when: "performSync is called"
        HashMap<String, Object> result = yahooSyncOperation.performSync(input)

        then: "Error returned for failed delete"
        1 * getInfoByMaskDBHelper.getInfoByMask(_) >> buildNotFoundDbResponse()
        1 * yahooService.deleteAccount(_) >> deleteResponse
        0 * tworkitemService.deleteByStopKeyAndStopValue(_, _)
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_SYS_APPL
        0 * _
    }

    // --- buildAccountNode tests ---

    def "buildAccountNode should create Map with expected fields"() {
        given: "Input map with transaction details"
        HashMap<String, Object> input = [
                (CommonDefs.TRANSACTION_ID): "txn123",
                "callingSystemId"          : "UST"
        ]

        when: "buildAccountNode is called"
        Map<String, Object> result = yahooSyncOperation.buildAccountNode("testuser", "att.net", input)

        then: "Result has correct values"
        result.get(CommonDefs.HANDLE) == "testuser"
        result.get(CommonDefs.DOMAIN) == "att.net"
        result.get(CommonDefs.TRANSACTION_ID) == "txn123"
        result.get(CommonDefs.CALLING_SYSTEM_ID) == "UST"
        result.get(CommonDefs.EVENTNAME) == "AddMember"
        0 * _
    }

    // --- buildCreateAccountNode tests ---

    def "buildCreateAccountNode should include profile fields"() {
        given: "SLID info and base ObjectNode"
        HashMap<String, Object> slidInfo = [
                (MPSDefs.DB_FULLNAME)  : "John Doe"
        ]
        ObjectNode baseNode = objectMapper.createObjectNode()
        baseNode.put("handle", "testuser")
        baseNode.put("domain", "att.net")

        when: "buildCreateAccountNode is called"
        ObjectNode node = yahooSyncOperation.buildCreateAccountNode(slidInfo, baseNode, "testuser", "att.net")

        then: "Node has create account fields"
        node.get("eventname").asText() == "CreateAccount"
        node.get("transactionName").asText() == "CreateAccount"
        node.get("handle").asText() == "testuser"
        0 * _
    }

    def "buildCreateAccountNode should build node without DOB when birthdate_venc is absent"() {
        given: "SLID info without DOB and base ObjectNode"
        HashMap<String, Object> slidInfo = [
                (MPSDefs.DB_FULLNAME): "John Doe"
        ]
        ObjectNode baseNode = objectMapper.createObjectNode()
        baseNode.put("handle", "testuser")

        when: "buildCreateAccountNode is called"
        ObjectNode node = yahooSyncOperation.buildCreateAccountNode(slidInfo, baseNode, "testuser", "att.net")

        then: "Node created without DOB"
        node.get("eventname").asText() == "CreateAccount"
        node.get("dateOfBirth") == null
        0 * _
    }
}
