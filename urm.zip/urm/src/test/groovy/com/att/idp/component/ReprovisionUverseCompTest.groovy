package com.att.idp.component

import com.att.idp.idgraphuserregistrationms.client.MPSReconnectWrapperSoapHandler
import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.spockframework.spring.SpringBean

import java.sql.SQLException

import static org.hamcrest.Matchers.equalTo

class ReprovisionUverseCompTest extends CompTestBase{

    private String uri = '/userprofile/reprovision/uban'


    SyncUserProfileRequest requestObj = null
    HashMap<String, Object> requestHeader = null
    Map<String, Object> hmResponse = null

    def setup() {

        requestObj = new SyncUserProfileRequest()
        requestObj.transactionName = 'reprovisionUverse'
        requestObj.unvalidatedHandle = 'handle'
        requestObj.ban = '123456789'
        requestObj.agentId = 'xx556'

        requestHeader = new HashMap<String, String>()
        requestHeader['Content-Type'] = 'application/json'
        requestHeader['idp.trace_id'] = '47e8df49d3410d77:e9123acf450013b3:0:0'
        requestHeader['X-ATT-ClientId'] = 'ATLAS-UI'

        hmResponse = new HashMap<String, String>()
        hmResponse[CommonDefs.TRANSACTION_ID] = '47e8df49d3410d77'
        hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
        hmResponse['appInfo'] = 'Success'

    }

    // ========== Success Scenarios ==========

    def "test reprovisionUverse with ATLAS-UI CallingSystemId success case"() {
        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> hmResponse
        0 * _

        and:
        response.statusCode() == 200
        response.then().body("appStatusMsg", equalTo("SUCCESS"))
                .body("appStatusCode", equalTo("0"))
                .body("appInfo", equalTo("Success"))
    }

    def "test reprovisionUverse with DATAMGT CallingSystemId success case"() {
        given:
        requestHeader['X-ATT-ClientId'] = 'DATAMGT'

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> hmResponse
        0 * _

        and:
        response.statusCode() == 200
        response.then().body("appStatusMsg", equalTo("SUCCESS"))
                .body("appStatusCode", equalTo("0"))
                .body("appInfo", equalTo("Success"))
    }

    def "test reprovisionUverse with UST CallingSystemId success case"() {
        given:
        requestHeader['X-ATT-ClientId'] = 'UST'

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> hmResponse
        0 * _

        and:
        response.statusCode() == 200
        response.then().body("appStatusMsg", equalTo("SUCCESS"))
                .body("appStatusCode", equalTo("0"))
                .body("appInfo", equalTo("Success"))
    }

    // ========== Validation Error Scenarios ==========

    def "test reprovisionUverse null CallingSystemId error case"() {
        given:
        requestHeader['X-ATT-ClientId'] = null

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", equalTo("100"))
                .body("appInfo", equalTo("CallingSystemId Not Allowed :: Invalid CallingSystemId"))
    }

    def "test reprovisionUverse missing CallingSystemId error case"() {
        given:
        requestHeader.remove('X-ATT-ClientId')

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", equalTo("100"))
                .body("appInfo", equalTo("Missing or invalid X-ATT-ClientId in request header"))
    }

    def "test reprovisionUverse invalid CallingSystemId error case"() {
        given:
        requestHeader['X-ATT-ClientId'] = 'IDP'

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", equalTo("100"))
                .body("appInfo", equalTo("CallingSystemId Not Allowed :: Invalid CallingSystemId"))
    }

    def "test reprovisionUverse unknown attributes error case"() {
        given:
        requestObj.source = 'YAHOO'
        requestObj.guid = '123456789'
        requestObj.handle = 'handle'
        requestObj.domain = 'domain'
        requestObj.destination = 'destination'

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", equalTo("100"))
                .body("appInfo", equalTo("Invalid Attributes passed in reprovisionUverseRequest : {domain=domain, destination=destination, guid=123456789, handle=handle, source=YAHOO}"))
    }

    def "test reprovisionUverse when ban contains white space"() {
        given:
        requestObj.ban = "             "

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", equalTo("100"))
                .body("appInfo", equalTo("BAN must be numeric"))
    }

    def "test reprovisionUverse when ban contains non-numeric data"() {
        given:
        requestObj.ban = "123svwdf @'/."

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", equalTo("100"))
                .body("appInfo", equalTo("BAN must be numeric"))
    }

    def "test reprovisionUverse when ban not present"() {
        given:
        requestObj.ban = null

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", equalTo("100"))
                .body("appInfo", equalTo("BAN is required in input request."))
    }

    def "test reprovisionUverse when agentId contains white space"() {
        given:
        requestObj.agentId = "     "

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", equalTo("100"))
                .body("appInfo", equalTo("agentId length is invalid"))
    }

    def "test reprovisionUverse when agentId contains more than max length"() {
        given:
        requestObj.agentId = "123svwdf @'/."

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", equalTo("100"))
                .body("appInfo", equalTo("agentId length is invalid"))
    }

    def "test reprovisionUverse when IsExternalCall not contains Y or N"() {
        given:
        requestObj.isExternalCall = 'a'

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", equalTo("100"))
                .body("appInfo", equalTo("IsExternalCall should be Y or N."))
    }

    // ========== Success with IsExternalCall N ==========

    def "test reprovisionUverse with ATLAS-UI CallingSystemId with IsExternalCall as N success case"() {
        given:
        requestObj.isExternalCall = 'N'

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> hmResponse
        0 * _

        and:
        response.statusCode() == 200
        response.then().body("appStatusMsg", equalTo("SUCCESS"))
                .body("appStatusCode", equalTo("0"))
                .body("appInfo", equalTo("Success"))
    }

    def "test reprovisionUverse with DATAMGT CallingSystemId with IsExternalCall as N success case"() {
        given:
        requestHeader['X-ATT-ClientId'] = 'DATAMGT'
        requestObj.isExternalCall = 'N'

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> hmResponse
        0 * _

        and:
        response.statusCode() == 200
        response.then().body("appStatusMsg", equalTo("SUCCESS"))
                .body("appStatusCode", equalTo("0"))
                .body("appInfo", equalTo("Success"))
    }

    def "test reprovisionUverse with UST CallingSystemId with IsExternalCall as N success case"() {
        given:
        requestHeader['X-ATT-ClientId'] = 'UST'
        requestObj.isExternalCall = 'N'

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> hmResponse
        0 * _

        and:
        response.statusCode() == 200
        response.then().body("appStatusMsg", equalTo("SUCCESS"))
                .body("appStatusCode", equalTo("0"))
                .body("appInfo", equalTo("Success"))
    }

    def "test reprovisionUverse with Unknown CallingSystemId with IsExternalCall as N success case"() {
        given:
        requestHeader['X-ATT-ClientId'] = 'Unknown'
        requestObj.isExternalCall = 'N'

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> hmResponse
        0 * _

        and:
        response.statusCode() == 200
        response.then().body("appStatusMsg", equalTo("SUCCESS"))
                .body("appStatusCode", equalTo("0"))
                .body("appInfo", equalTo("Success"))
    }

    // ========== SOAP Error Scenarios ==========

    def "test reprovisionUverse null response from SOAP error case"() {
        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> null
        0 * _

        and:
        response.statusCode() == 500
        response.then().body("appStatusMsg", equalTo("ERR_SYS_APPL"))
                .body("appStatusCode", equalTo("602"))
                .body("appInfo", equalTo("Response from SyncDestinationRILMPS is NULL"))
    }

    def "test reprovisionUverse SQLException response from SOAP error case"() {
        given:
        Exception ex = new SQLException('SQLException thrown')

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> { throw ex }
        0 * _

        and:
        response.statusCode() == 500
        response.then().body("appStatusMsg", equalTo("ERR_DB"))
                .body("appStatusCode", equalTo("304"))
                .body("appInfo", equalTo("Exception :SQLException thrown"))
    }

    def "test reprovisionUverse GeneralException response from SOAP error case"() {
        given:
        Exception ex = new Exception('General Exception thrown')

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> { throw ex }
        0 * _

        and:
        response.statusCode() == 500
        response.then().body("appStatusMsg", equalTo("ERR_SYS_APPL"))
                .body("appStatusCode", equalTo("602"))
                .body("appInfo", equalTo("Exception :General Exception thrown"))
    }

    def "test reprovisionUverse InvalidDataInputException response from SOAP error case"() {
        given:
        Exception ex = new InvalidInputDataException('InvalidInputDataException thrown')

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> { throw ex }
        0 * _

        and:
        response.statusCode() == 500
        response.then().body("appStatusMsg", equalTo("ERR_SYS_APPL"))
                .body("appStatusCode", equalTo("602"))
                .body("appInfo", equalTo("Exception :InvalidInputDataException thrown"))
    }

    def "test reprovisionUverse status code null response from reprovisionUverseHelper error case"() {
        given:
        hmResponse = new HashMap<String, String>()
        hmResponse[MPSDefs.APP_STATUS_CODE] = null

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> hmResponse
        0 * _

        and:
        response.statusCode() == 500
        response.then().body("appStatusMsg", equalTo("ERR_SYS_APPL"))
                .body("appStatusCode", equalTo("602"))
                .body("appInfo", equalTo("Null response from reprovisionUverseHelper.disconnectReconnect"))
    }

    def "test reprovisionUverse ERR_CANNOT_OPERATE response from SOAP error case"() {
        given:
        hmResponse = new HashMap<String, String>()
        hmResponse[MPSDefs.APP_STATUS_CODE] = '231'
        hmResponse[MPSDefs.APP_STATUS_MSG] = 'ERR_CANNOT_OPERATE'
        hmResponse['appInfo'] = 'verifyEnabledServices method failed with Validation error.'

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> hmResponse
        0 * _

        and:
        response.statusCode() == 400
        response.then().body("appStatusMsg", equalTo("ERR_CANNOT_OPERATE"))
                .body("appStatusCode", equalTo("231"))
                .body("appInfo", equalTo("verifyEnabledServices method failed with Validation error."))
    }

    def "test reprovisionUverse ERR_BAN_NOT_FOUND response from SOAP error case"() {
        given:
        hmResponse = new HashMap<String, String>()
        hmResponse[MPSDefs.APP_STATUS_CODE] = '130'
        hmResponse[MPSDefs.APP_STATUS_MSG] = 'BAN_NOT_FOUND'
        hmResponse['appInfo'] = 'BAN not found in MPS'

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> hmResponse
        0 * _

        and:
        response.statusCode() == 404
        response.then().body("appStatusMsg", equalTo("ERR_BAN_NOT_FOUND"))
                .body("appStatusCode", equalTo("130"))
                .body("appInfo", equalTo("BAN not found in MPS"))
    }

    def "test reprovisionUverse ERR_NO_SERVICE response from SOAP error case"() {
        given:
        hmResponse = new HashMap<String, String>()
        hmResponse[MPSDefs.APP_STATUS_CODE] = '149'
        hmResponse[MPSDefs.APP_STATUS_MSG] = 'ERR_NO_SERVICE'
        hmResponse['appInfo'] = 'ERR_NO_SERVICE : Given ban does not have services in MPS'

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> hmResponse
        0 * _

        and:
        response.statusCode() == 400
        response.then().body("appStatusMsg", equalTo("ERR_NO_SERVICE"))
                .body("appStatusCode", equalTo("149"))
                .body("appInfo", equalTo("ERR_NO_SERVICE : Given ban does not have services in MPS"))
    }

    def "test reprovisionUverse ERR_INVALID_DATA response from SOAP error case"() {
        given:
        hmResponse = new HashMap<String, String>()
        hmResponse[MPSDefs.APP_STATUS_CODE] = '100'
        hmResponse[MPSDefs.APP_STATUS_MSG] = 'ERR_INVALID_DATA'
        hmResponse['appInfo'] = 'SchemaValidationStatus = The value ~1234567890~ of element ~ns2:ban~ is not valid.'

        when:
        def response = givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri)

        then:
        1 * oMPSReconnectWrapperSoapHandler.invokeAPI(_) >> hmResponse
        0 * _

        and:
        response.statusCode() == 400
        response.then().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", equalTo("100"))
                .body("appInfo", equalTo("SchemaValidationStatus = The value ~1234567890~ of element ~ns2:ban~ is not valid."))
    }
}