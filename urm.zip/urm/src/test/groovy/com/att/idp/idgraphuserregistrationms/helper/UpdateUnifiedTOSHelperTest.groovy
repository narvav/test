package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.AccountInfoDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetAssociatedMembersDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.idp.idgraphuserregistrationms.integration.MPSYSInternalRestClient
import com.att.idp.idgraphuserregistrationms.queue.message.helpers.UpdateTOSQueueHelper
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.*
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Specification

class UpdateUnifiedTOSHelperTest extends Specification {


    GetAssociatedMembersDBHelper oMPSDBGetAssociatedMembersH=Mock(GetAssociatedMembersDBHelper)

    GetMemberServicesDBHelper oGetMemberServicesDBHelper=Mock(GetMemberServicesDBHelper)

    UpdateTOSQueueHelper oUpdateTOSQueueHelper=Mock(UpdateTOSQueueHelper)
	
	AccountInfoDBHelper oMPSDBAccountInfoH=Mock(AccountInfoDBHelper)

    FeatureManagerHelper featureManager=Mock(FeatureManagerHelper)

    MPSYSInternalRestClient idpRestClient=Mock(MPSYSInternalRestClient)

    def testObj=new UpdateUnifiedTOSHelper();   

    String stTransactionId = null
    Logger logger = null
    HashMap hmResult = null
    HashMap hmInput = CommonUtil.hashMap
    HashMap hmGetAssocMemInp = CommonUtil.hashMap
    ArrayList alRoles = CommonUtil.arrayList

    HashMap hmAssociatedMembers = CommonUtil.hashMap
    ArrayList alAssociatedMembers = CommonUtil.arrayList
    ArrayList alRoles1 = CommonUtil.arrayList
    HashMap hmService = CommonUtil.hashMap
    HashMap hmInstance = CommonUtil.hashMap
    HashMap hmInstanceValue = CommonUtil.hashMap
    HashMap hmAssociatedMember = CommonUtil.hashMap
    HashMap hmRole = CommonUtil.hashMap
    HashMap hmDbusInput = CommonUtil.hashMap
    private HashMap hmMemSvc = CommonUtil.hashMap

    String stAppInfo = null
    String stAppStatusMsg = null
    HashMap resultHashSuccess = null
    HashMap resultHashError = null
    HashMap hmRecordNotFoundErr = CommonUtil.hashMap


    def setup() {
    
        testObj.oMPSDBGetAssociatedMembersH=oMPSDBGetAssociatedMembersH
        testObj.oGetMemberServicesDBHelper=oGetMemberServicesDBHelper
        testObj.oUpdateTOSQueueHelper=oUpdateTOSQueueHelper
        testObj.oMPSDBAccountInfoH=oMPSDBAccountInfoH
        testObj.featureManager=featureManager
        testObj.idpRestClient=idpRestClient
        
        featureManager.isEnabled(_ as String) >> true
    
        logger = LoggerFactory.getLogger('UpdateUnifiedTOS')
        System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')
        stTransactionId = 'tnx001'

        resultHashSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
				CErrorDefs.COMMON_SUCCESS_MSG)
        resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, 'Error Returned')

        hmRecordNotFoundErr = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
				CErrorDefs.ERR_REC_NOT_FOUND)

        hmInput[CommonDefs.TRANSACTION_ID] = stTransactionId
        hmInput[CommonDefs.TRANSACTION_NAME] = 'UpdateUnifiedTOS'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.BAN] = '1234567890'
        hmInput[CommonDefs.AGENT_ID] = '12345'
        hmInput[CommonDefs.SOURCE_IP_ADDRESS] = '10.55.17.56'
        hmInput[CommonDefs.HSIA_TOS_ACCEPTANCE] = CommonDefs.IND_Y
        hmInput[CommonDefs.IPTV_TOS_ACCEPTANCE] = CommonDefs.IND_Y
        hmInput[CommonDefs.E911_TOS_ACCEPTANCE] = CommonDefs.IND_Y
        hmInput[CommonDefs.WDM_TOS_ACCEPTANCE] = CommonDefs.IND_N
        hmInput[CommonDefs.WVM_TOS_ACCEPTANCE] = CommonDefs.IND_N
        hmInput[CommonDefs.IS_EXTERNAL_CALL] = CommonDefs.IND_Y

        alRoles.add(CommonDefs.TYPE_ALL)

        hmGetAssocMemInp[MPSDefs.DB_SOR_INVARIANT_ID1] = '1234567890'
        hmGetAssocMemInp[MPSDefs.DB_SOR_NAME] = MPSDefs.SOR_LS
        hmGetAssocMemInp[MPSDefs.DB_SERVICE_TYPE] = MPSDefs.TITAN_SERVICE
        hmGetAssocMemInp[CommonDefs.QUERY_ROLES_INFO_FLAG] = alRoles
        hmGetAssocMemInp[MPSDefs.QUERY_ONLY_SLIDS_FLAG] = CommonDefs.IND_Y

        hmRole[MPSDefs.DB_ROLE_NAME] = CommonDefs.KEY_ROLE_NAME_OWNER
        alRoles1.add(hmRole)

        hmInstanceValue[CommonDefs.ROLES] = alRoles1
        hmInstanceValue[MPSDefs.DB_SOR_INVARIANT_ID] = '1234567890'

        hmInstance['1234567890'] = hmInstanceValue

        hmService[CommonDefs.TITAN_SERVICE] = hmInstance

        hmAssociatedMember[MPSDefs.SERVICES] = hmService
        hmAssociatedMember[MPSDefs.DB_MEMBER_NAME] = 'donnavd0013772ggttata'

        alAssociatedMembers.add(hmAssociatedMember)

        hmAssociatedMembers[CommonDefs.ASSOCIATED_MEMBERS] = alAssociatedMembers
        hmAssociatedMembers[MPSDefs.APP_STATUS_CODE] = '0'

        hmMemSvc[MPSDefs.DB_MEMBER_NAME] = 'qayma0081031'
        hmMemSvc[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemSvc=CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
				CErrorDefs.COMMON_SUCCESS_MSG)

    }


    def "test update unified t o s helper error empty or null input"() throws Exception {
        given:
        hmResult = testObj.updateUnifiedTOS(null)

        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
        stAppInfo == 'Input Hash is NULL'
    }


    def "test update unified t o s helper error e r r b a n n o t f o u n d"() throws Exception {
        given:
        oMPSDBAccountInfoH.getAccountInfo(_ as String)>> hmRecordNotFoundErr

        hmResult = testObj.updateUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'ERR_BAN_NOT_FOUND'
        stAppInfo == 'ERR_BAN_NOT_FOUND'
    }


    def "test update unified t o s helper error null response from get account info"() throws Exception {
        given:
        oMPSDBAccountInfoH.getAccountInfo(_ as String)>> null

        hmResult = testObj.updateUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'ERR_SYS_APPL'
        stAppInfo == 'Null or empty response MPSDB_AccountInfo_H'
    }


    def "test update unified t o s helper error get account info returns error"() throws Exception {
        given:
        oMPSDBAccountInfoH.getAccountInfo(_ as String)>> resultHashError

        hmResult = testObj.updateUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
        stAppInfo == 'Error Returned'
    }


    def "test update unified t o s helper error null response from get associated members"() throws Exception {

        given:
        oMPSDBAccountInfoH.getAccountInfo(_ as String)>> resultHashSuccess
        oMPSDBGetAssociatedMembersH.getAssociatedMembers(_ as HashMap)>> null

        hmResult = testObj.updateUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'ERR_SYS_APPL'
        stAppInfo == 'Null or empty response MPSDB_GetAssocicatedMembers_H'
    }


    def "test update unified t o s helper error get associated members returns error"() throws Exception {
        given:
        oMPSDBAccountInfoH.getAccountInfo(_ as String)>> resultHashSuccess
        oMPSDBGetAssociatedMembersH.getAssociatedMembers(_ as HashMap)>> resultHashError

        hmResult = testObj.updateUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
        stAppInfo == 'Error Returned'
    }


    def "test update unified t o s helper error null response from update t o s queue helper"() throws Exception {

        given:
        oMPSDBAccountInfoH.getAccountInfo(_ as String)>> resultHashSuccess
        oMPSDBGetAssociatedMembersH.getAssociatedMembers(_ as HashMap)>> hmAssociatedMembers
        idpRestClient.callIDPRestClient(_ as HashMap)>> null
        oGetMemberServicesDBHelper.getMemberServices(_ as HashMap)>> hmMemSvc

        hmResult = testObj.updateUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'ERR_SYS_APPL'
        stAppInfo == 'Null or empty response UpdateTOSQueueHelper'
    }


    def "test update unified t o s helper error update t o s queue helper returns error"() throws Exception {
        given:
		oMPSDBAccountInfoH.getAccountInfo(_ as String)>> resultHashSuccess
        oMPSDBGetAssociatedMembersH.getAssociatedMembers(_ as HashMap)>> hmAssociatedMembers
        idpRestClient.callIDPRestClient(_ as HashMap)>> resultHashError
        oGetMemberServicesDBHelper.getMemberServices(_ as HashMap)>> hmMemSvc

        hmResult = testObj.updateUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
        stAppInfo == 'Error Returned'
    }


    def "test update unified t o s helper success all t o s flags are n in input"() throws Exception {
        given:
        hmInput[CommonDefs.HSIA_TOS_ACCEPTANCE] = CommonDefs.IND_N
        hmInput[CommonDefs.IPTV_TOS_ACCEPTANCE] = CommonDefs.IND_N
        hmInput[CommonDefs.E911_TOS_ACCEPTANCE] = CommonDefs.IND_N
        hmInput[CommonDefs.WDM_TOS_ACCEPTANCE] = CommonDefs.IND_N
        hmInput[CommonDefs.WVM_TOS_ACCEPTANCE] = CommonDefs.IND_N

        oMPSDBAccountInfoH.getAccountInfo(_ as String)>> resultHashSuccess
        oMPSDBGetAssociatedMembersH.getAssociatedMembers(_ as HashMap)>> hmAssociatedMembers
        oGetMemberServicesDBHelper.getMemberServices(_ as HashMap)>> hmMemSvc

        hmResult = testObj.updateUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'SUCCESS'
        stAppInfo == 'Success'
    }


    def "test update unified t o s helper success"() throws Exception {

        given:
        oMPSDBAccountInfoH.getAccountInfo(_ as String)>> resultHashSuccess
        oMPSDBGetAssociatedMembersH.getAssociatedMembers(_ as HashMap)>> hmAssociatedMembers
        idpRestClient.callIDPRestClient(_ as HashMap)>> resultHashSuccess
        oGetMemberServicesDBHelper.getMemberServices(_ as HashMap)>> hmMemSvc
        
        hmResult = testObj.updateUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'SUCCESS'
        stAppInfo == 'SUCCESS'
    }


    def "test update unified t o s helper from null member service"() throws Exception {

        given:
        oMPSDBAccountInfoH.getAccountInfo(_ as String)>> resultHashSuccess
        oMPSDBGetAssociatedMembersH.getAssociatedMembers(_ as HashMap)>> hmAssociatedMembers
        oGetMemberServicesDBHelper.getMemberServices(_ as HashMap)>> null
        hmResult = testObj.updateUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'ERR_SYS_APPL'
        stAppInfo == 'Null or empty response MPSDB_GetMemberServices_H'

    }


    def "test update unified t o s helper for record not found member service"() throws Exception {
        given:
        oMPSDBAccountInfoH.getAccountInfo(_ as String)>> resultHashSuccess
        oMPSDBGetAssociatedMembersH.getAssociatedMembers(_ as HashMap)>> hmAssociatedMembers
        oGetMemberServicesDBHelper.getMemberServices(_ as HashMap)>> resultHashError
		hmResult = testObj.updateUnifiedTOS(hmInput)
		stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
        stAppInfo == 'Error Returned'

    }

    // ==================== MQ FLOW TESTS (Feature Flag Disabled) ====================

    def "test update unified tos helper MQ flow success"() throws Exception {
        given:
        testObj.featureManager = Mock(FeatureManagerHelper) {
            isEnabled(_ as String) >> false
        }
        oMPSDBAccountInfoH.getAccountInfo(_ as String) >> resultHashSuccess
        oMPSDBGetAssociatedMembersH.getAssociatedMembers(_ as HashMap) >> hmAssociatedMembers
        oGetMemberServicesDBHelper.getMemberServices(_ as HashMap) >> hmMemSvc
        oUpdateTOSQueueHelper.sendMessage(_ as HashMap, _ as HashMap) >> resultHashSuccess

        hmResult = testObj.updateUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'SUCCESS'
        stAppInfo == 'SUCCESS'
    }

    def "test update unified tos helper MQ flow null response"() throws Exception {
        given:
        testObj.featureManager = Mock(FeatureManagerHelper) {
            isEnabled(_ as String) >> false
        }
        oMPSDBAccountInfoH.getAccountInfo(_ as String) >> resultHashSuccess
        oMPSDBGetAssociatedMembersH.getAssociatedMembers(_ as HashMap) >> hmAssociatedMembers
        oGetMemberServicesDBHelper.getMemberServices(_ as HashMap) >> hmMemSvc
        oUpdateTOSQueueHelper.sendMessage(_ as HashMap, _ as HashMap) >> null

        hmResult = testObj.updateUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'ERR_SYS_APPL'
        stAppInfo == 'Null or empty response UpdateTOSQueueHelper'
    }

    def "test update unified tos helper MQ flow error response"() throws Exception {
        given:
        testObj.featureManager = Mock(FeatureManagerHelper) {
            isEnabled(_ as String) >> false
        }
        oMPSDBAccountInfoH.getAccountInfo(_ as String) >> resultHashSuccess
        oMPSDBGetAssociatedMembersH.getAssociatedMembers(_ as HashMap) >> hmAssociatedMembers
        oGetMemberServicesDBHelper.getMemberServices(_ as HashMap) >> hmMemSvc
        oUpdateTOSQueueHelper.sendMessage(_ as HashMap, _ as HashMap) >> resultHashError

        hmResult = testObj.updateUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
        stAppInfo == 'Error Returned'
    }

    def "test update unified tos helper MQ flow empty response"() throws Exception {
        given:
        testObj.featureManager = Mock(FeatureManagerHelper) {
            isEnabled(_ as String) >> false
        }
        oMPSDBAccountInfoH.getAccountInfo(_ as String) >> resultHashSuccess
        oMPSDBGetAssociatedMembersH.getAssociatedMembers(_ as HashMap) >> hmAssociatedMembers
        oGetMemberServicesDBHelper.getMemberServices(_ as HashMap) >> hmMemSvc
        oUpdateTOSQueueHelper.sendMessage(_ as HashMap, _ as HashMap) >> new HashMap()

        hmResult = testObj.updateUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'ERR_SYS_APPL'
        stAppInfo == 'Null or empty response UpdateTOSQueueHelper'
    }

}
