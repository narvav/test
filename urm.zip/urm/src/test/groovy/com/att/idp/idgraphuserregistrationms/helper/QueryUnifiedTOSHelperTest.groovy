package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraph.commons.integration.CGRestClientWrapper
import com.att.idp.cgclienthelpers.models.secureAccountProfile.AccountProfileResponse
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.AccountInfoDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetProvisionedServicesDBHelper
import com.att.idp.idgraphuserregistrationms.helper.voltage.VoltageEncryptionHelper
import com.att.mpsys.common.utils.*
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ArrayNode
import com.fasterxml.jackson.databind.node.ObjectNode
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class QueryUnifiedTOSHelperTest extends Specification {

	def testObj = new QueryUnifiedTOSHelper()

    AccountInfoDBHelper getMPSDB_AccountInfo_H = Mock(AccountInfoDBHelper)

    GetProvisionedServicesDBHelper getMPSDB_GetProvisionedServices_H = Mock(GetProvisionedServicesDBHelper)

    GetMemberServicesDBHelper getMPSDB_GetMemberServices_H = Mock(GetMemberServicesDBHelper)

   // QueryProfileProofingInfoHelper oQueryProfileProofingInfo_H = Mock(QueryProfileProofingInfoHelper)

    CGRestClientWrapper restClientObj=Mock(CGRestClientWrapper)

    VoltageEncryptionHelper ve = Mock(VoltageEncryptionHelper)

    Logger log = null
    String stTransactionId = null

    private HashMap hmResult

    private String stAppStatusMsg

    private String stAppInfo

    private HashMap hmInput = CommonUtil.hashMap
    private HashMap hmRecordNotFoundErr = CommonUtil.hashMap
    private HashMap getInfoResp1 = CommonUtil.hashMap
    private HashMap hmAccountInfo = CommonUtil.hashMap
    private ArrayList alQueryResponse = CommonUtil.arrayList
    private HashMap hmAccInfoResponse = CommonUtil.hashMap
    private HashMap hmInstanceValue = CommonUtil.hashMap
    private HashMap hmInstanceValue2 = CommonUtil.hashMap
    private HashMap hmInstance = CommonUtil.hashMap
    private HashMap hmInstance2 = CommonUtil.hashMap
    private HashMap hmservice = CommonUtil.hashMap
    private HashMap hmProvisionResponse = CommonUtil.hashMap
    private HashMap hmservices = CommonUtil.hashMap
    private HashMap hmMemSvc = CommonUtil.hashMap
    HashMap hmCGResponse = CommonUtil.hashMap
    private HashMap<String, Object> hmInvalidDataErr

    private HashMap<String, Object> hmQueryCRMProofingInfo


    def setup() {
    
        testObj.accountInfoDBHelper=getMPSDB_AccountInfo_H
        testObj.getProvisionedServicesDBHelper=getMPSDB_GetProvisionedServices_H
        testObj.getMemberServicesDBHelper=getMPSDB_GetMemberServices_H
        //testObj.queryProfileProofingInfo=oQueryProfileProofingInfo_H
        testObj.cgRestClient=restClientObj
        testObj.ve=ve
        
        log = LoggerFactory.getLogger('QueryUnifiedTOS')
        System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')
        stTransactionId = 'pm675e_0012'

        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryUnifiedTOS'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.BAN] = 'VD0012659'
        hmInput[CommonDefs.SOURCE_IP_ADDRESS] = '2611:1711:4881:3931:2a16:adsf:fe19:7be4'
        hmInput[CommonDefs.AGENT_ID] = '123'
        hmInput[CommonDefs.IS_EXTERNAL_CALL] = 'N'
        hmInput[CommonDefs.TRANSACTION_ID] = stTransactionId

        // Mock data for AccountInfo
        hmAccountInfo[CommonDefs.HSIA_TOS] = CommonDefs.IND_Y
        hmAccountInfo[CommonDefs.IPTV_TOS] = CommonDefs.IND_Y
        hmAccountInfo[CommonDefs.VOIP_TOS] = CommonDefs.IND_Y
        hmAccountInfo['hsia_tos_date'] = '04152014 06:58:58'
        hmAccountInfo['iptv_tos_date'] = '04152014 07:08:26'
        hmAccountInfo['e911_tos_date'] = '04152014 07:08:26'
        alQueryResponse.add(hmAccountInfo)
        hmAccInfoResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAccInfoResponse[CommonDefs.ACCOUNT_INFO_KEY] = alQueryResponse

        // Mock data for Provision services
        hmInstanceValue[MPSDefs.DB_PRODUCT_ID] = '8'
        hmInstance['gdInstance121'] = hmInstanceValue
        hmInstanceValue2[MPSDefs.DB_PRODUCT_ID] = '11'
        hmInstance2['tid0103448'] = hmInstanceValue

        hmservice['HSIA'] = hmInstance
        hmservice['VOIP'] = hmInstance2

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['services'] = hmservice

        // Mock data for GetMemberService
		
		HashMap hmIPTVServiceDetails = new HashMap()
        hmIPTVServiceDetails = new HashMap()
        hmIPTVServiceDetails[MPSDefs.SERVICE_STATUS] = 'Enabled'
        hmIPTVServiceDetails['service_id'] = '9'
        hmIPTVServiceDetails['service_name'] = 'IPTV'
        hmIPTVServiceDetails['instance_id'] = 'tid1231231231231'
        hmIPTVServiceDetails['sor_invariant_id'] = 'LS1CMP0015310'
        HashMap hmIPTVService = new HashMap()
        hmIPTVService['tid1231231231231'] = hmIPTVServiceDetails

        hmservices['UVERSE'] = null
        hmservices[CommonDefs.IPTV_SERVICE] = hmIPTVService

        hmMemSvc['services'] = hmservices
        hmMemSvc['member_name'] = 'sbciptv_5184182'

        hmRecordNotFoundErr = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
				CErrorDefs.ERR_REC_NOT_FOUND)
        hmInvalidDataErr = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, CErrorDefs.ERR_INVALID_DATA)

        hmQueryCRMProofingInfo = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        hmQueryCRMProofingInfo[CommonDefs.DATE_OF_BIRTH] = '01011970'

        // Mock data for CG Response
        HashMap hmEmail = new HashMap()
        HashMap hmAccount = new HashMap()
        HashMap hmContact = new HashMap()
        //HashMap subscriberNumber = new HashMap();

        HashMap hmCBRInfo =  new HashMap()
        hmCBRInfo[CommonDefs.PHONE_NUMBER] = '9149140004'
        ObjectMapper mapper = new ObjectMapper()
        ArrayNode subscriber = mapper.createArrayNode()

        hmEmail['emailAddress'] = 'aaa@aaa.com'
        hmEmail['effectiveDate'] = '2017-08-22Z'

        hmContact[CommonDefs.EMAIL] = hmEmail
        hmContact[CommonDefs.CBR_INFO] = hmCBRInfo
        ObjectNode subscriberNumber = mapper.createObjectNode()
        subscriberNumber.put('subscriberId', '121321113')
        subscriberNumber.put('status', 'A')
        subscriber.add(subscriberNumber)

        hmAccount['contact'] = hmContact
        hmAccount['primaryAccountHolder'] = '123454'

        hmCGResponse['accounts'] = hmAccount
        hmCGResponse['appStatusCode'] = '0'
        hmCGResponse['subscribers'] = subscriber
        hmCGResponse['appInfo'] = 'SUCCESS'

    }


    def "query unified t o s helper null input hash case"() throws Exception {

        given:
        hmResult = testObj.queryUnifiedTOS(null)

        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppInfo == 'Input Hash is NULL'
        stAppStatusMsg == 'ERR_INVALID_DATA'
    }


    def "query unified t o s helper b a n not found error case"() throws Exception {

        given:
        hmInput[CommonDefs.BAN] = '123'
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmRecordNotFoundErr
        hmResult = testObj.queryUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppStatusMsg == 'ERR_BAN_NOT_FOUND'
        stAppInfo == 'Ban not found'

    }

    def "query unified t o s helper accountInfo null ban not found error case"() throws Exception {

        given:
        hmInput[CommonDefs.BAN] = '123';
        HashMap accountInfos = new HashMap();
        ArrayList accountInfo = new ArrayList();
        accountInfo.add(accountInfos);
        hmAccInfoResponse.put(CommonDefs.ACCOUNT_INFO_KEY, accountInfo)
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmAccInfoResponse
        getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmProvisionResponse
        getMPSDB_GetMemberServices_H.getMemberServices(_ as HashMap) >> hmMemSvc
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        when:
        hmResult = testObj.queryUnifiedTOS(hmInput)
        then:
        hmResult['appStatusMsg'] == 'ERR_BAN_NOT_FOUND'
        hmResult['appCategoryCode'] == '4'

    }
    def "query unified t o s helper success"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '123'
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmAccInfoResponse
		getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmProvisionResponse
        getMPSDB_GetMemberServices_H.getMemberServices(_ as HashMap) >> hmMemSvc
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        //oQueryProfileProofingInfo_H.queryCRMProofingInfo(_ as HashMap) >> hmQueryCRMProofingInfo
        when:
        hmResult = testObj.queryUnifiedTOS(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
        hmResult['provisionedServices'] != null
        hmResult['tosFlags'] != null
    }

    def "query unified t o s helper serviceName doesnt start SBCIPTV"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '123'
        hmMemSvc['member_name'] = 'iptv_5184182'
        hmMemSvc['domain_name'] = 'slid.dum'
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmAccInfoResponse
        getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmProvisionResponse
        getMPSDB_GetMemberServices_H.getMemberServices(_ as HashMap) >> hmMemSvc
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        //oQueryProfileProofingInfo_H.queryCRMProofingInfo(_ as HashMap) >> hmQueryCRMProofingInfo
        when:
        hmResult = testObj.queryUnifiedTOS(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
        hmResult['appStatusCode'] == "602"

    }


    def "query unified t o s helper success w d m and w v m"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '123'
        hmAccountInfo[CommonDefs.WVM_TOS] = CommonDefs.IND_Y
        hmAccountInfo['wvm_tos_date'] = '04152014 06:58:58'
        hmAccountInfo[CommonDefs.WDM_TOS] = CommonDefs.IND_Y
        hmAccountInfo['wdm_tos_date'] = '04152014 06:58:58'
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmAccInfoResponse
        getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmProvisionResponse
        getMPSDB_GetMemberServices_H.getMemberServices(_ as HashMap) >> hmMemSvc
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        //oQueryProfileProofingInfo_H.queryCRMProofingInfo(_ as HashMap) >> hmQueryCRMProofingInfo

        when:
        hmResult = testObj.queryUnifiedTOS(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
        hmResult['provisionedServices'] != null
        hmResult['tosFlags'] != null

    }


    def "query unified t o s helper t o s flags value n"() throws Exception {
        given:
        hmAccountInfo.remove(CommonDefs.HSIA_TOS, CommonDefs.IND_Y)
        hmAccountInfo.remove(CommonDefs.IPTV_TOS, CommonDefs.IND_Y)
        hmAccountInfo.remove(CommonDefs.VOIP_TOS, CommonDefs.IND_Y)
        hmInput[CommonDefs.BAN] = '123'
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmAccInfoResponse
        getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmProvisionResponse
        getMPSDB_GetMemberServices_H.getMemberServices(_ as HashMap) >> hmMemSvc
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
       // oQueryProfileProofingInfo_H.queryCRMProofingInfo(_ as HashMap) >> hmQueryCRMProofingInfo

        when:
        hmResult = testObj.queryUnifiedTOS(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
        hmResult['provisionedServices'] != null
        hmResult['tosFlags'] != null

    }


    def "query unified t o s helper null response from acc info err"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '123'
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> null
        hmResult = testObj.queryUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppStatusMsg == 'ERR_SYS_APPL'
        stAppInfo == 'Null or empty response AccountInfoDBHelper'
    }


    def "query unified t o s helper null response from get provision svc err"() throws Exception {
        given:
        hmAccountInfo.remove(CommonDefs.HSIA_TOS, CommonDefs.IND_Y)
        hmAccountInfo.remove(CommonDefs.IPTV_TOS, CommonDefs.IND_Y)
        hmAccountInfo.remove(CommonDefs.VOIP_TOS, CommonDefs.IND_Y)
        hmInput[CommonDefs.BAN] = '123'
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmAccInfoResponse
        getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> null
        hmResult = testObj.queryUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppStatusMsg == 'ERR_SYS_APPL'
        stAppInfo == 'Null or empty response GetProvisionedServicesDBHelper'
    }


    def "query unified t o s helper null response from get member svc err"() throws Exception {
        given:
        hmAccountInfo.remove(CommonDefs.HSIA_TOS, CommonDefs.IND_Y)
        hmAccountInfo.remove(CommonDefs.IPTV_TOS, CommonDefs.IND_Y)
        hmAccountInfo.remove(CommonDefs.VOIP_TOS, CommonDefs.IND_Y)
        hmInput[CommonDefs.BAN] = '123'
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmAccInfoResponse
		getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmProvisionResponse
        getMPSDB_GetMemberServices_H.getMemberServices(_ as HashMap) >> null
        hmResult = testObj.queryUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppStatusMsg == 'ERR_SYS_APPL'
        stAppInfo == 'Null or empty response GetMemberServicesDBHelper'
    }


    def "query unified t o s helper err response from acc info"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '123'
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmInvalidDataErr
        hmResult = testObj.queryUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
        stAppInfo == '100'
    }


    def "query unified t o s helper err response from get provision svc"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '123'
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmAccInfoResponse
		getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmInvalidDataErr
        hmResult = testObj.queryUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
        stAppInfo == '100'
    }


    def "query unified t o s helper err response from get member svc"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '123'
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmAccInfoResponse
        getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmProvisionResponse
        getMPSDB_GetMemberServices_H.getMemberServices(_ as HashMap) >> hmInvalidDataErr
        hmResult = testObj.queryUnifiedTOS(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
        stAppInfo == '100'
    }


    def "query unified t o s helper success check account type and subtype"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '123'
        hmAccountInfo[CommonDefs.WVM_TOS] = CommonDefs.IND_Y
        hmAccountInfo['wvm_tos_date'] = '04152014 06:58:58'
        hmAccountInfo[CommonDefs.WDM_TOS] = CommonDefs.IND_Y
        hmAccountInfo['wdm_tos_date'] = '04152014 06:58:58'
        hmAccountInfo['account_subtype'] = 'S'
        hmAccountInfo['account_type'] = 'R'
        hmAccountInfo['tn_activated'] = 'Y'
        hmAccountInfo['order_due_date'] = '2000-01-01T00:00:00.000Z'
        hmAccountInfo['order_taken_date'] = '2000-01-01T00:00:00.000Z'
        hmAccountInfo['rg_activated'] = 'Y'
        alQueryResponse.add(hmAccountInfo)
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmAccInfoResponse
        getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmProvisionResponse
        getMPSDB_GetMemberServices_H.getMemberServices(_ as HashMap) >> hmMemSvc
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        //oQueryProfileProofingInfo_H.queryCRMProofingInfo(_ as HashMap) >> hmQueryCRMProofingInfo

        when:
        hmResult = testObj.queryUnifiedTOS(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == "SUCCESS"
        hmResult['provisionedServices'] != null
        hmResult['tosFlags'] !=null
        hmResult['accountSubType'] == 'S'
        hmResult['accountType'] == 'R'
        hmResult['tnActivated'] == 'Y'
        hmResult['orderDueDate'] == '2000-01-01T00:00:00.000Z'
        hmResult['orderTakenDate'] == '2000-01-01T00:00:00.000Z'
        hmResult['rgActivated'] == 'Y'


    }


    def "query unified t o s helper null from query c r m proofing"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '123'
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmAccInfoResponse
        getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmProvisionResponse
        getMPSDB_GetMemberServices_H.getMemberServices(_ as HashMap) >> hmMemSvc
       // oQueryProfileProofingInfo_H.queryCRMProofingInfo(_ as HashMap) >> null
        when:
        hmResult = testObj.queryUnifiedTOS(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'

    }


    def "query unified t o s helper successwith i p t vin memberservice data"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '123'
        hmAccountInfo[CommonDefs.WVM_TOS] = CommonDefs.IND_Y
        hmAccountInfo['wvm_tos_date'] = '04152014 06:58:58'
        hmAccountInfo[CommonDefs.WDM_TOS] = CommonDefs.IND_Y
        hmAccountInfo['wdm_tos_date'] = '04152014 06:58:58'
        hmAccountInfo['account_subtype'] = 'S'
        hmAccountInfo['account_type'] = 'R'
        hmAccountInfo['tn_activated'] = 'Y'
        hmAccountInfo['order_due_date'] = '2000-01-01T00:00:00.000Z'
        hmAccountInfo['order_taken_date'] = '2000-01-01T00:00:00.000Z'
        hmAccountInfo['rg_activated'] = 'Y'
        alQueryResponse.add(hmAccountInfo)
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmAccInfoResponse
        
		getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmProvisionResponse
        getMPSDB_GetMemberServices_H.getMemberServices(_ as HashMap) >> hmMemSvc
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse

        // oQueryProfileProofingInfo_H.queryCRMProofingInfo(_ as HashMap) >> hmQueryCRMProofingInfo

        when:
        hmResult = testObj.queryUnifiedTOS(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
        hmResult.containsKey('provisionedServices') == true
        hmResult.containsKey(CommonDefs.MEMBER_SERVICES_KEY) == true
    }


    def "query unified t o s helper successwith no recordin memberservice data"() throws Exception {
        given:
        hmRecordNotFoundErr = CommonErrorMap.makeCategoryMap(MPSDefs.REC_NOT_FOUND_NUM,
                MPSDefs.REC_NOT_FOUND_MSG)
        hmInput[CommonDefs.BAN] = '123'
        hmAccountInfo[CommonDefs.WVM_TOS] = CommonDefs.IND_Y
        hmAccountInfo['wvm_tos_date'] = '04152014 06:58:58'
        hmAccountInfo[CommonDefs.WDM_TOS] = CommonDefs.IND_Y
        hmAccountInfo['wdm_tos_date'] = '04152014 06:58:58'
        hmAccountInfo['account_subtype'] = 'S'
        hmAccountInfo['account_type'] = 'R'
        hmAccountInfo['tn_activated'] = 'Y'
        hmAccountInfo['order_due_date'] = '2000-01-01T00:00:00.000Z'
		hmAccountInfo['order_taken_date'] = '2000-01-01T00:00:00.000Z'
		hmAccountInfo['rg_activated'] = 'Y'
		alQueryResponse.add(hmAccountInfo)
		getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmAccInfoResponse
        getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmProvisionResponse
		getMPSDB_GetMemberServices_H.getMemberServices(_ as HashMap) >> hmRecordNotFoundErr
		//oQueryProfileProofingInfo_H.queryCRMProofingInfo(_ as HashMap) >> hmQueryCRMProofingInfo
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        when:
        hmResult = testObj.queryUnifiedTOS(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
        hmResult.containsKey('provisionedServices') == true
        hmResult.containsKey(CommonDefs.MEMBER_SERVICES_KEY) == false

    }
    def "test CGSyncCall error response"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '123'
        getMPSDB_AccountInfo_H.getAccountInfo('123') >> hmAccInfoResponse
        getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmProvisionResponse
        getMPSDB_GetMemberServices_H.getMemberServices(_ as HashMap) >> hmMemSvc
        hmCGResponse = new HashMap()
        hmCGResponse.put('appStatusCode', '100')
        hmCGResponse.put('appInfo', 'Customer account profile data not found')
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        when:
        hmResult = testObj.queryUnifiedTOS(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
        hmResult['provisionedServices'] != null
        hmResult['tosFlags'] != null
    }

    def "convertDateFormat should correctly format date"() {
        given:
        def queryUnifiedTOSHelper = new QueryUnifiedTOSHelper()
        def inputDate = "0001-01-03"
        def expectedDate = "01030001"

        when:
        def result = queryUnifiedTOSHelper.convertDateFormat(inputDate)

        then:
        result == expectedDate
    }

    def "convertDateFormat should handle invalid date format"() {
        given:
        def queryUnifiedTOSHelper = new QueryUnifiedTOSHelper()
        def invalidDate = "invalid-date"

        when:
        def result = queryUnifiedTOSHelper.convertDateFormat(invalidDate)

        then:
        result == invalidDate
    }

    def "test queryUnifiedTOS handles AccountProfileResponse and decryption"() {
        given:

        def hmInput = new HashMap<>()
        hmInput.put(CommonDefs.BAN, '123')
        AccountProfileResponse accountProfileResponse = new AccountProfileResponse()
        accountProfileResponse.setDateOfBirth('2023-10-25')
        hmCGResponse.put(CommonDefs.CUSTOMER, accountProfileResponse)
        getMPSDB_AccountInfo_H.getAccountInfo(_ as String) >> hmAccInfoResponse
        getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmProvisionResponse
        getMPSDB_GetMemberServices_H.getMemberServices(_ as HashMap) >> hmMemSvc
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        /*def hmDecryptInput = new HashMap<>()
        hmDecryptInput.put('vc_dateOfBirth', '2023-10-25')*/
        def hmDecryptedResponse = new HashMap<>()
        hmDecryptedResponse.put('vc_dateOfBirth', '2023-10-25')
        ve.getEFPEDecryptedValues(_ as HashMap) >> hmDecryptedResponse

        when:
        def result = testObj.queryUnifiedTOS(hmInput)

        then:
        result[CommonDefs.DATE_OF_BIRTH] == '10252023'
    }

    def "test queryUnifiedTOS handles AccountProfileResponse when default cg date is passed"() {
        given:

        def hmInput = new HashMap<>()
        hmInput.put(CommonDefs.BAN, '123')
        AccountProfileResponse accountProfileResponse = new AccountProfileResponse()
        accountProfileResponse.setDateOfBirth('0001-01-03') // one of default cg dob
        hmCGResponse.put(CommonDefs.CUSTOMER, accountProfileResponse)
        getMPSDB_AccountInfo_H.getAccountInfo(_ as String) >> hmAccInfoResponse
        getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmProvisionResponse
        getMPSDB_GetMemberServices_H.getMemberServices(_ as HashMap) >> hmMemSvc
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse

        def hmDecryptedResponse = new HashMap<>()
        hmDecryptedResponse.put('vc_dateOfBirth', '0001-01-03')
        ve.getEFPEDecryptedValues(_ as HashMap) >> hmDecryptedResponse

        when:
        def result = testObj.queryUnifiedTOS(hmInput)

        then:
        result[CommonDefs.DATE_OF_BIRTH] == null
    }

    def "test VoltageEncryptionHelper.getEFPEDecryptedValues() Response is null"() {
        given:

        def hmInput = new HashMap<>()
        hmInput.put(CommonDefs.BAN, '123')
        AccountProfileResponse accountProfileResponse = new AccountProfileResponse()
        accountProfileResponse.setDateOfBirth('2023-10-25')
        hmCGResponse.put(CommonDefs.CUSTOMER, accountProfileResponse)
        getMPSDB_AccountInfo_H.getAccountInfo(_ as String) >> hmAccInfoResponse
        getMPSDB_GetProvisionedServices_H.getProvisionedServices(_ as HashMap) >> hmProvisionResponse
        getMPSDB_GetMemberServices_H.getMemberServices(_ as HashMap) >> hmMemSvc
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        /*def hmDecryptInput = new HashMap<>()
        hmDecryptInput.put('vc_dateOfBirth', '2023-10-25')*/
        def hmDecryptedResponse = null
        ve.getEFPEDecryptedValues(_ as HashMap) >> hmDecryptedResponse

        when:
        def result = testObj.queryUnifiedTOS(hmInput)

        then:
        !result.containsKey("dateOfBirth")
    }
}
