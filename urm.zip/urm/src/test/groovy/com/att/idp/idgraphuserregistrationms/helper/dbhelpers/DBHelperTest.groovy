package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import spock.lang.Specification

import static org.junit.jupiter.api.Assertions.assertEquals

import java.util.ArrayList
import java.util.HashMap
import java.util.List
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import com.att.idp.idgraphuserregistrationms.exceptions.MPSException
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.DBHelper
import com.att.mpsys.common.utils.MPSDefs

class DBHelperTest extends Specification {

    def testObj = new DBHelper()

    JdbcTemplate jdbcTemplate = Mock(JdbcTemplate)
    ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)
    List<Object> objectList = new ArrayList<Object>()

    List alQueryResponse = new ArrayList<Object>()
    String selectStatement


    def setup() {
		testObj.jdbcTemplate=jdbcTemplate
		testObj.errorMetricHandler=errorMetricHandler
        System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')
    }


    def "get domain id success"() throws MPSException {
        given:
        selectStatement = 'SELECT domain_id FROM domain WHERE domain_name = ?'
        String domain_name = 'slid.dum'
        objectList.add(domain_name)

        HashMap domainList = new HashMap()
        domainList[MPSDefs.DB_DOMAIN_ID] = '15'
        alQueryResponse.add(domainList)

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse

        expect:
        int count = testObj.getDomainId(domain_name)
    }


    def "get domain id error"() {
        given:
        selectStatement = 'SELECT domain_id FROM domain WHERE domain_name = ?'
        String domain_name = 'slid.dum'
        objectList.add(domain_name)

        HashMap domainList = new HashMap()
        domainList[MPSDefs.DB_DOMAIN_ID] = null
        alQueryResponse.add(domainList)

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse

        expect:
        try {
			int count = testObj.getDomainId(domain_name)
        } catch (MPSException e) {
			assertEquals('DBHelper::getDomainId::null', e.message)
        }
    }


    def "get sor id success"() throws MPSException {
        given:
        selectStatement = 'SELECT sor_id FROM systemofrecord WHERE sor_name = ?'
        String sor_name = 'NA'
        objectList.add(sor_name)

        HashMap domainList = new HashMap()
        domainList[MPSDefs.DB_SOR_ID] = '17'
        alQueryResponse.add(domainList)

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse

        expect:
        int count = testObj.getSorId(sor_name)
    }


    def "get sor id s error"() {
        given:
        selectStatement = 'SELECT sor_id FROM systemofrecord WHERE sor_name = ?'
        String sor_name = 'NA'
        objectList.add(sor_name)

        HashMap domainList = new HashMap()
        domainList[MPSDefs.DB_SOR_ID] = null
        alQueryResponse.add(domainList)

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse

        expect:
        try {
			int count = testObj.getSorId(sor_name)
        } catch (MPSException e) {
			assertEquals('DBHelper::getSorId::Cannot invoke "Object.toString()" because the return value of "java.util.Map.get(Object)" is null', e.message)
        }
    }


    def "get security question id success"() throws MPSException {
        given:
        selectStatement = 'SELECT security_question_id FROM SecurityQuestion WHERE SUBSTR(TRIM(LOWER(security_question)), 1, 80) = TRIM(LOWER(?))'
        String sSecurityQuestion = 'What is the title of your favorite book?'
        objectList.add(sSecurityQuestion)

        HashMap domainList = new HashMap()
        domainList[MPSDefs.DB_SECURITY_QUESTION_ID] = '27'
        alQueryResponse.add(domainList)

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        int count = testObj.getSecurityQuestionId(sSecurityQuestion)
    }


    def "get security question id more length success"() throws MPSException {
        given:
        selectStatement = 'SELECT security_question_id FROM SecurityQuestion WHERE SUBSTR(TRIM(LOWER(security_question)), 1, 80) = TRIM(LOWER(?))'
        String sSecurityQuestion = 'What is the title of your favorite book? wdns fwebjfbwejfb cdvchEDBEFJWENFC NWWJEEJWDFNCDkfnkwj'
        objectList.add(sSecurityQuestion)

        HashMap domainList = new HashMap()
        domainList[MPSDefs.DB_SECURITY_QUESTION_ID] = '27'
        alQueryResponse.add(domainList)

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        int count = testObj.getSecurityQuestionId(sSecurityQuestion)
    }


    def "get security question id error"() {
        given:
        selectStatement = 'SELECT security_question_id FROM SecurityQuestion WHERE SUBSTR(TRIM(LOWER(security_question)), 1, 80) = TRIM(LOWER(?))'
        String sSecurityQuestion = 'What is the title of your favorite book?'
        objectList.add(sSecurityQuestion)

        HashMap domainList = new HashMap()
        domainList[MPSDefs.DB_SECURITY_QUESTION_ID] = null
        alQueryResponse.add(domainList)

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        try {
			int count = testObj.getSecurityQuestionId(sSecurityQuestion)
        } catch (MPSException e) {
			assertEquals('DBHelper::getSecurityQuestionId::Cannot invoke "Object.toString()" because the return value of "java.util.Map.get(Object)" is null', e.message)
        }
    }


    def "get next id success"() throws MPSException {
        given:
        String sequence = 'group_num_seq'
        selectStatement = 'SELECT ' + sequence + '.NEXTVAL FROM dual'
        HashMap domainList = new HashMap()
        alQueryResponse.add('12345')

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        long count = testObj.nextMemberGroupId
    }


    def "get access id success"() throws MPSException {
        given:
        String accessName = 'group_num_seq'
        selectStatement = 'SELECT access_id FROM networkaccess WHERE access_name = ?'
        objectList.add(accessName)
        HashMap domainList = new HashMap()
        domainList['access_id'] = '5'
        alQueryResponse.add(domainList)

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        long count = testObj.getAccessId(accessName)
    }


    def "get access id error"() {
        given:
        String accessName = 'group_num_seq'
        selectStatement = 'SELECT access_id FROM networkaccess WHERE access_name = ?'

        objectList.add(accessName)

        HashMap domainList = new HashMap()
        domainList['access_id'] = null
        alQueryResponse.add(domainList)

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        try {
			long count = testObj.getAccessId(accessName)
        } catch (MPSException e) {
			assertEquals('DBHelper::getAccessId::Cannot invoke "Object.toString()" because the return value of "java.util.Map.get(Object)" is null', e.message)
        }
    }


    def "get next id error1"() {
        given:
        String sequence = 'group_num_seq'
        selectStatement = 'SELECT ' + sequence + '.NEXTVAL FROM dual'
        HashMap domainList = new HashMap()
        alQueryResponse.add('-1')

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        try {
			long count = testObj.nextMemberGroupId
        } catch (MPSException e) {
			assertEquals('DBHelper::getNextId::Sequence group_num_seq is empty.', e.message)
        }
    }


    def "get next id error"() {
        given:
        String sequence = 'group_num_seq'
        selectStatement = 'SELECT ' + sequence + '.NEXTVAL FROM dual'
        HashMap domainList = new HashMap()
        alQueryResponse.add(null)
        
        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        try {
			long count = testObj.nextMemberId
        } catch (MPSException e) {
			assertEquals('DBHelper::getNextId::Cannot parse null string', e.message)
        }
    }


    def "get service name error"() {

        given:
        selectStatement = 'SELECT service_name FROM service WHERE service_id = ?'
        objectList.add('1')

        HashMap serviceList = new HashMap()
        serviceList['service_name'] = 123232
        alQueryResponse.add(serviceList)

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        try {
			String service_name = testObj.getServiceName('1')
        } catch (MPSException e) {
			assertEquals('DBHelper::getServiceName::class java.lang.Integer cannot be cast to class java.lang.String (java.lang.Integer and java.lang.String are in module java.base of loader \'bootstrap\')',
                    e.message)
        }
    }


    def "get service name success"() throws MPSException {
        given:
        selectStatement = 'SELECT service_name FROM service WHERE service_id = ?'
        HashMap serviceList = new HashMap()
        serviceList['service_name'] = 'DSL'
        alQueryResponse.add(serviceList)

        objectList.add('1')

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        String service_name = testObj.getServiceName('1')

    }


    def "get service id error"() {
        given:
        selectStatement = 'SELECT service_id FROM service WHERE service_name = ?'
        HashMap serviceList = new HashMap()
        serviceList['service_id'] = null
        alQueryResponse.add(serviceList)

        objectList.add('DSL')
        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        try {
			int serviceId = testObj.getServiceId('DSL')
        } catch (MPSException e) {
			assertEquals('DBHelper::getServiceId::Cannot invoke "Object.toString()" because the return value of "java.util.Map.get(Object)" is null', e.message)
        }
    }


    def "get service id success"() throws MPSException {
        given:
        selectStatement = 'SELECT service_id FROM service WHERE service_name = ?'
        HashMap serviceList = new HashMap()
        serviceList['service_id'] = '1'
        alQueryResponse.add(serviceList)

        objectList.add('DSL')

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        int serviceId = testObj.getServiceId('DSL')

    }


    def "get sor name error"() {
        given:
        selectStatement = 'SELECT sor_name FROM systemofrecord WHERE sor_id = ?'
        HashMap serviceList = new HashMap()
        serviceList['sor_name'] = 1122
        alQueryResponse.add(serviceList)

        objectList.add('17')

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        try {
			String sorName = testObj.getSorName('17')
        } catch (MPSException e) {
			assertEquals('DBHelper::getSorName::class java.lang.Integer cannot be cast to class java.lang.String (java.lang.Integer and java.lang.String are in module java.base of loader \'bootstrap\')',
                    e.message)
        }
    }


    def "get sor name success"() throws MPSException {
        given:
        selectStatement = 'SELECT sor_name FROM systemofrecord WHERE sor_id = ?'
        HashMap serviceList = new HashMap()
        serviceList['sor_name'] = 'NA'
        alQueryResponse.add(serviceList)

        objectList.add('17')
        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        String sorName = testObj.getSorName('17')

    }


    def "get access name error"() {
        given:
        selectStatement = 'SELECT access_name FROM networkaccess WHERE access_id = ?'
        HashMap serviceList = new HashMap()
        serviceList['access_name'] = 12323
        alQueryResponse.add(serviceList)

        objectList.add('5')

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        try {
			String sorName = testObj.getAccessName('5')
        } catch (MPSException e) {
			assertEquals('DBHelper::getAccessName::class java.lang.Integer cannot be cast to class java.lang.String (java.lang.Integer and java.lang.String are in module java.base of loader \'bootstrap\')',
                    e.message)
        }
    }


    def "get access name success"() throws MPSException {
        given:
        selectStatement = 'SELECT access_name FROM networkaccess WHERE access_id = ?'
        HashMap serviceList = new HashMap()
        serviceList['access_name'] = 'NA'
        alQueryResponse.add(serviceList)

        objectList.add('5')
        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        String sorName = testObj.getAccessName('5')

    }


    def "get status code error"() {
        given:
        selectStatement = 'SELECT status_code FROM status WHERE status_name = ?'
        HashMap serviceList = new HashMap()
        serviceList['status_code'] = null
        alQueryResponse.add(serviceList)

        objectList.add('5')

        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        try {
			int statusCode = testObj.getStatusCode('5')
        } catch (MPSException e) {
			assertEquals('DBHelper::getStatusCode::Cannot invoke "Object.toString()" because the return value of "java.util.Map.get(Object)" is null', e.message)
        }
    }


    def "get status code success"() throws MPSException {
        given:
        selectStatement = 'SELECT status_code FROM status WHERE status_name = ?'
        HashMap serviceList = new HashMap()
        serviceList['status_code'] = 0
        alQueryResponse.add(serviceList)

        objectList.add('5')
        jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        int statusCode = testObj.getStatusCode('5')

    }


    def "get domain name error"() {
        given:
        selectStatement = 'SELECT domain_name FROM domain WHERE domain_id = ?'
        HashMap serviceList = new HashMap()
		serviceList[MPSDefs.DB_DOMAIN_NAME] = 213214
		alQueryResponse.add(serviceList)

		objectList.add('15')

		jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
        expect:
        try {
            String domainName = testObj.getDomainName('15')
        } catch (MPSException e) {
            assertEquals('DBHelper::getDomainName::class java.lang.Integer cannot be cast to class java.lang.String (java.lang.Integer and java.lang.String are in module java.base of loader \'bootstrap\')',
                    e.message)
        }
    }


    def "get domain name success"() {
		selectStatement = 'SELECT domain_name FROM domain WHERE domain_id = ?'
		HashMap serviceList = new HashMap()
		serviceList[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
		alQueryResponse.add(serviceList)

		objectList.add('15')
		jdbcTemplate.queryForList(_ as String, _)>> alQueryResponse
		String domainName = testObj.getDomainName('15')

	}

}
