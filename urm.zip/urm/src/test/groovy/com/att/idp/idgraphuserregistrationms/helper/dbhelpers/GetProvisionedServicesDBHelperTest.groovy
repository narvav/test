package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import com.att.mpsys.common.utils.PropertyManager
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import spock.lang.Specification
/**
 * 
 * @author kg852c
 *
 */
class GetProvisionedServicesDBHelperTest extends Specification {

    JdbcTemplate jdbcTemplate = Mock(JdbcTemplate)
    ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)

    def testObj = new GetProvisionedServicesDBHelper()

    Logger logger = null
    HashMap hmDBInput = null
    String stAppStatusMsg = null
    List alQueryResponse = CommonUtil.arrayList
    HashMap hmQueryResponse = CommonUtil.hashMap
    List<Object> objectList = CommonUtil.arrayList
    HashMap hmResult = CommonUtil.hashMap

    private static String dateFormat = 'MMDDYYYY HH24:mi:ss'

    private static final String banQuery = ' select ' + 'provservice.provisioned_service_num, provservice.product_id, '+
			"provservice.instance_id,  " + "provservice.service_eligibility, to_char(provservice.create_date, '"+
			dateFormat + "') as create_date, to_char(provservice.last_modified, '" + dateFormat+
			"') as last_modified, provservice.last_modified_by, "+
			"pro.portal_provider, pro.unvalidated_handle , pro.unvalidated_domain , "+
			"pro.provisioned_service_num, provservice.ban, serv.service_name, serv.email_eligible, "+
			"provservice.sor_invariant_id " + "from "+
			"provisionedhsia pro,  provisionedservice provservice, service serv " + "where "+
			"provservice.product_id=serv.service_id (+) AND "+
			"provservice.provisioned_service_num = pro.provisioned_service_num (+) AND " + "provservice.ban = ?";


    def setup() throws Exception {
        PropertyManager.setProperty("MSCONFIG", "EMAIL_ELIGIBLE_PORTAL_PROVIDERS",null);

        testObj.jdbcTemplate=jdbcTemplate
        testObj.errorMetricHandler=errorMetricHandler
		logger = LoggerFactory.getLogger('AddAssociation')

        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')
        hmDBInput = CommonUtil.hashMap
        hmDBInput[MPSDefs.DB_BAN] = '123456'

        hmQueryResponse[MPSDefs.DB_BAN] = '123456'
        hmQueryResponse[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmQueryResponse[MPSDefs.DB_DOMAIN_ID] = '11'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = MPSDefs.IPTV_SERVICE
        hmQueryResponse[MPSDefs.DB_INSTANCE_ID] = '12345'
        hmQueryResponse[MPSDefs.DB_LAST_FOUR_SSN] = '1234'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'Y'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.PENDING
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.PENDING
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID2] = '17'

        alQueryResponse.add(hmQueryResponse)
    }


    def "get provisioned services no b a n error case"() throws Exception {
        given:
        hmDBInput[MPSDefs.DB_BAN] = ''
        hmResult = testObj.getProvisionedServices(hmDBInput)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_EMPTY'
    }


    def "get provisioned services no record found case"() throws Exception {
        given:
        objectList.add('123456')
        jdbcTemplate.queryForList(new String(banQuery), _) >> null
        hmResult = testObj.getProvisionedServices(hmDBInput)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'REC_NOT_FOUND'
    }


    def "get provisioned services no h s i a s u c c e s s case"() throws Exception {
        given:
        objectList.add('123456')
        jdbcTemplate.queryForList(new String(banQuery), _) >> alQueryResponse
        hmResult = testObj.getProvisionedServices(hmDBInput)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'OK'
    }
	
    def "get provisioned services h s i a s u c c e s s with a t t provider case"() throws Exception {
        given:
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = MPSDefs.HSIA_SERVICE
        hmQueryResponse[MPSDefs.DB_PORTAL_PROVIDER] = 'AT&T Yahoo'
        objectList.add('123456')
        jdbcTemplate.queryForList(new String(banQuery), _) >> alQueryResponse
        hmResult = testObj.getProvisionedServices(hmDBInput)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'OK'
    }
	
    def "get provisioned services h s i a s u c c e s s case"() throws Exception {
        given:
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = MPSDefs.HSIA_SERVICE
        objectList.add('123456')
        jdbcTemplate.queryForList(new String(banQuery), _) >> alQueryResponse
        hmResult = testObj.getProvisionedServices(hmDBInput)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'OK'
    }


    def "get provisioned services multiple services s u c c e s s case"() throws Exception {
        given:
        HashMap hmQueryResponse2 = new HashMap()
        hmQueryResponse2[MPSDefs.DB_BAN] = '123456'
        hmQueryResponse2[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmQueryResponse2[MPSDefs.DB_DOMAIN_ID] = '11'
        hmQueryResponse2[MPSDefs.DB_SERVICE_NAME] = MPSDefs.IPTV_SERVICE
        hmQueryResponse2[MPSDefs.DB_INSTANCE_ID] = '12345'
        hmQueryResponse2[MPSDefs.DB_LAST_FOUR_SSN] = '1234'
        hmQueryResponse2[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'Y'
        hmQueryResponse2[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.PENDING
        hmQueryResponse2[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.PENDING
        hmQueryResponse2[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        hmQueryResponse2[MPSDefs.DB_SOR_ID1] = '17'
        hmQueryResponse2[MPSDefs.DB_SOR_INVARIANT_ID1] = '17'
		hmQueryResponse2[MPSDefs.DB_SOR_ID2] = '17'
		hmQueryResponse2[MPSDefs.DB_SOR_INVARIANT_ID2] = '17'

		alQueryResponse.add(hmQueryResponse2)
		objectList.add('123456')
		jdbcTemplate.queryForList(new String(banQuery),_) >> alQueryResponse

		hmResult = testObj.getProvisionedServices(hmDBInput)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]

        then:
        stAppStatusMsg == 'OK'
    }


    def "get provisioned services exception case"() throws Exception {
        given:
        hmDBInput[MPSDefs.DB_BAN] = 12345
        hmResult = testObj.getProvisionedServices(hmDBInput)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_SYS_APPL'
    }

}
