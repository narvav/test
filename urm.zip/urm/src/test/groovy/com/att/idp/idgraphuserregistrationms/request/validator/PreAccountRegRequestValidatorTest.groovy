package com.att.idp.idgraphuserregistrationms.request.validator

import com.att.idp.idgraphuserregistrationms.resource.request.PreAccountRegRequest
import com.att.idp.idgraphuserregistrationms.resource.request.SorInvariantId
import com.att.idp.idgraphuserregistrationms.resource.response.PreAccountRegResponse
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders

class PreAccountRegRequestValidatorTest extends Specification {

	def preAccountRegRequestValidator= new PreAccountRegRequestValidator()

	PreAccountRegRequest preAccountRegRequest = null
	PreAccountRegResponse preAccountRegResponse = null
	HttpHeaders requestHeader = null


	def setup() throws Exception {
		preAccountRegRequest = new PreAccountRegRequest()
		preAccountRegResponse= new PreAccountRegResponse()
		requestHeader= Mock(HttpHeaders)

		preAccountRegRequest.isExternalCall = 'Y'
		preAccountRegRequest.guid = '8761100331'

		SorInvariantId sor = new SorInvariantId()
		sor.sorName = 'LS'
		sor.sorInvariantId = '1234567890123'
		List<SorInvariantId> lstSor = new ArrayList<SorInvariantId>()
		lstSor.add(sor)
		preAccountRegRequest.sorInvariantIdList = lstSor

		//MockitoAnnotations.initMocks(this)
		ReflectionTestUtils.setField(preAccountRegRequestValidator, 'propValidCallersForPreAccountReg',
				'DATAMGT|OPUS')

	}

	def "preaccountreg request validator null req test"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		preAccountRegResponse = preAccountRegRequestValidator.preAccountRegRequestValidator(requestHeader, null)
		then:
		preAccountRegResponse.appInfo == 'Input Request is NULL / Empty.'

	}
	def "test preacctreg null request"() throws Exception {
		given:
		//	requestHeader.getHeaderString('idp-trace-id')>>'null'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		preAccountRegRequest = null
		when:
		preAccountRegResponse = preAccountRegRequestValidator.preAccountRegRequestValidator(requestHeader,
				preAccountRegRequest)
		then:
		preAccountRegResponse.appInfo == 'Missing or Invalid IdpTraceId'
	}
	def "preaccountreg requestunknownattribues"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		Map<String,Object> allUnknownAttributes =new HashMap<>()
		preAccountRegRequest.setUnknownAttributes(allUnknownAttributes)
		allUnknownAttributes.put("test","test")
		when:
		PreAccountRegResponse responseObj = preAccountRegRequestValidator.preAccountRegRequestValidator(requestHeader, preAccountRegRequest)
		then:
		responseObj.appInfo == 'Invalid Attributes passed in PreAccountRegRequest : {test=test}'

	}

	def "test preaccountreg success case"() {
		given:
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'OPUS'
		when:
		preAccountRegResponse = preAccountRegRequestValidator.preAccountRegRequestValidator(requestHeader,
				preAccountRegRequest)
		then:
		preAccountRegResponse == null
	}

	def "test preaccountreg invalid csid error"() throws Exception {

		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>null
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'

		when:
		preAccountRegResponse = preAccountRegRequestValidator.preAccountRegRequestValidator(requestHeader,
				preAccountRegRequest)
		then:
		preAccountRegResponse.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}


	def "test preaccount regcsi error"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>' '
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		preAccountRegResponse = preAccountRegRequestValidator.preAccountRegRequestValidator(requestHeader,
				preAccountRegRequest)
		then:
		preAccountRegResponse.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}

	def "test preaccountreg is external call level"() {
		given:
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		preAccountRegRequest.isExternalCall = 'A'
		when:
		preAccountRegResponse = preAccountRegRequestValidator.preAccountRegRequestValidator(requestHeader,
				preAccountRegRequest)
		then:
		preAccountRegResponse.appInfo == 'isExternalCall must be one of Y or N'
	}


	def "test preaccountreg null guid"() {
		given:
		preAccountRegRequest.guid = null
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'OPUS'
		when:
		preAccountRegResponse = preAccountRegRequestValidator.preAccountRegRequestValidator(requestHeader,
				preAccountRegRequest)
		then:
		preAccountRegResponse.appInfo == 'guid must be present'
	}

	def "test preaccoun reg null list"() {
		given:
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'OPUS'
		preAccountRegRequest.sorInvariantIdList = null
		when:
		preAccountRegResponse = preAccountRegRequestValidator.preAccountRegRequestValidator(requestHeader,
				preAccountRegRequest)
		then:
		preAccountRegResponse.appInfo == 'sorInvariantIdList must be present'
	}

	def "test preaccountreg null sor name"() {

		given:
		SorInvariantId sor = new SorInvariantId()
		//sor.setSorName("LS");
		sor.sorInvariantId = '1234567890123'
		List<SorInvariantId> lstSor = new ArrayList<SorInvariantId>()
		lstSor.add(sor)
		preAccountRegRequest.sorInvariantIdList = lstSor

		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'OPUS'
		when:
		preAccountRegResponse = preAccountRegRequestValidator.preAccountRegRequestValidator(requestHeader,
				preAccountRegRequest)
		then:
		preAccountRegResponse.appInfo == 'sorName is required field in input request'
	}

	def "test preaccountreg null sor invt id"() {

		given:
		SorInvariantId sor = new SorInvariantId()
		sor.sorName = 'LS'
		//sor.setSorInvariantId("1234567890123");
		List<SorInvariantId> lstSor = new ArrayList<SorInvariantId>()
		lstSor.add(sor)
		preAccountRegRequest.sorInvariantIdList = lstSor

		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'OPUS'
		when:
		preAccountRegResponse = preAccountRegRequestValidator.preAccountRegRequestValidator(requestHeader,
				preAccountRegRequest)
		then:
		preAccountRegResponse.appInfo == 'sorInvariantId is required field in input request'
	}

	def "test preaccountreg null sor invariant id in list"() {
		given:
		SorInvariantId sor = new SorInvariantId()
		sor.sorName = 'LS'
		sor.sorInvariantId = null
		List<SorInvariantId> lstSor = new ArrayList<SorInvariantId>()
		lstSor.add(sor)
		preAccountRegRequest.sorInvariantIdList = lstSor

		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'OPUS'
		when:
		preAccountRegResponse = preAccountRegRequestValidator.preAccountRegRequestValidator(requestHeader, preAccountRegRequest)
		then:
		preAccountRegResponse.appInfo == 'sorInvariantId is required field in input request'
	}

	def "test preaccountreg exception handling"() {
		given:
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		preAccountRegRequest = new PreAccountRegRequest()
		preAccountRegRequest.guid = '8761100331'
		preAccountRegRequest.isExternalCall = 'Y'
		SorInvariantId sor = new SorInvariantId()
		sor.sorName = 'LS'
		sor.sorInvariantId = '1234567890123'
		preAccountRegRequest.sorInvariantIdList = [sor]
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'OPUS'

		// Mock the exception
		preAccountRegRequestValidator= Mock(PreAccountRegRequestValidator)
		preAccountRegRequestValidator.preAccountRegRequestValidator(_ as HttpHeaders, _ as PreAccountRegRequest)>>new Exception("Mocked Exception")

		when:
		preAccountRegResponse = preAccountRegRequestValidator.preAccountRegRequestValidator(requestHeader, preAccountRegRequest)

		then:
		thrown(Exception)

	}
}
