package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.helper.RetriggerQARHelper
import com.att.idp.idgraphuserregistrationms.resource.request.RetriggerQARRequest
import com.att.idp.idgraphuserregistrationms.resource.response.RetriggerQARResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.junit.jupiter.api.Assertions
import spock.lang.Specification

import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap


class RetriggerQARServiceImplTest extends Specification {

	def retriggerQARServiceImplObj = new RetriggerQARServiceImpl()

	RetriggerQARHelper retriggerQARHelperObj=Mock(RetriggerQARHelper)

	private RetriggerQARRequest retriggerQARRequest = null
	private RetriggerQARResponse retriggerQARResponse = null

	public MultivaluedMap<String, String> requestHeader = null
	private Map<String, String> headers = new HashMap<>()


	def setup() throws Exception {
		retriggerQARServiceImplObj.retriggerQARHelperObj = retriggerQARHelperObj
		retriggerQARRequest = new RetriggerQARRequest()
		requestHeader = new MultivaluedHashMap<>(headers)

		retriggerQARRequest.callingSystemId = 'IDP'
		retriggerQARRequest.isExternalCall = 'Y'
		retriggerQARRequest.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
		retriggerQARRequest.ban = '876110000'
		retriggerQARRequest.accessId = 'crissyechev74@aatt.net'
		retriggerQARRequest.accountType = 'crissyechev74@aatt.net'
	}

	@SuppressWarnings('unchecked')

	def "test retriggerqar null response"() {
		when:
		retriggerQARResponse = retriggerQARServiceImplObj.retriggerQAR(retriggerQARRequest, requestHeader)
		then:
		retriggerQARResponse.appInfo == 'Null response from retriggerQARHelperObj.retriggerQAR'
		HashMap hmResponse = new HashMap()
		when:
		hmResponse[MPSDefs.APP_STATUS_CODE] = null
		retriggerQARHelperObj.retriggerQAR(_)>>hmResponse
		and:
		retriggerQARResponse = retriggerQARServiceImplObj.retriggerQAR(retriggerQARRequest, requestHeader)
		then:
		retriggerQARResponse.appInfo == 'Null response from retriggerQARHelperObj.retriggerQAR'
	}


	def "test retriggerqar invaliddata excep"() {

		given:
		HashMap hmResponse = new HashMap()
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
		hmResponse['isTransactionRollback'] = 'true'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		retriggerQARHelperObj.retriggerQAR(_ as HashMap)>>hmResponse
		expect:
		InvalidInputDataException excep = Assertions.assertThrows(InvalidInputDataException.class, () -> {
			retriggerQARServiceImplObj.retriggerQAR(retriggerQARRequest, requestHeader)
		})

	}

	@SuppressWarnings('unchecked')

	def "test retriggerqar success"() {

		given:
		HashMap hmResponse = new HashMap()
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['appInfo'] = 'Success'
		hmResponse['ErrorEnum'] = CommonDefs.COMMON_SUCCESS_MSG

		retriggerQARHelperObj.retriggerQAR(_ as HashMap)>>hmResponse
		when:
		retriggerQARResponse = retriggerQARServiceImplObj.retriggerQAR(retriggerQARRequest, requestHeader)

		then:
		retriggerQARResponse.appStatusCode == '0'
	}
}
