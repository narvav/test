package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.helper.PreAccountRegHelper
import com.att.idp.idgraphuserregistrationms.resource.request.PreAccountRegRequest
import com.att.idp.idgraphuserregistrationms.resource.request.SorInvariantId
import com.att.idp.idgraphuserregistrationms.resource.response.PreAccountRegResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.junit.jupiter.api.Assertions
import spock.lang.Specification

import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap


class PreAccountRegServiceImplTest extends Specification {


	def preAccountRegServiceImplObj=new PreAccountRegServiceImpl()

	PreAccountRegHelper preAccountRegHelperObj=Mock(PreAccountRegHelper)

	PreAccountRegResponse preAccountRegResponse = null
	PreAccountRegRequest preAccountRegRequest = null

	public MultivaluedMap<String, String> requestHeader = null
	private Map<String, String> headers = new HashMap<>()


	def setup() throws Exception {
		preAccountRegServiceImplObj.preAccountRegHelper = preAccountRegHelperObj
		preAccountRegRequest = new PreAccountRegRequest()
		requestHeader = new MultivaluedHashMap<>(headers)

		preAccountRegRequest.isExternalCall = 'Y'
		preAccountRegRequest.guid = '1020420061'

		SorInvariantId sor = new SorInvariantId()
		sor.sorName = 'LS'
		sor.sorInvariantId = '1234567687'
		List<SorInvariantId> lstSor = new ArrayList<SorInvariantId>()
		lstSor.add(sor)
		preAccountRegRequest.sorInvariantIdList = lstSor

	}

	@SuppressWarnings('unchecked')

	def "test preaccountreg null response"() {
		when:
		preAccountRegResponse = preAccountRegServiceImplObj.preAccountReg(preAccountRegRequest,
				requestHeader)
		then:
		preAccountRegResponse.appInfo == 'Null response from preAccountRegHelper.preAccountReg'

		HashMap hmResponse = new HashMap()
		when:
		hmResponse[MPSDefs.APP_STATUS_CODE] = null
		//Mockito.doReturn(hmResponse).when(preAccountRegHelperObj).preAccountReg(Mockito.any())
		preAccountRegHelperObj.preAccountReg(_ as HashMap)>>hmResponse
		and:
		preAccountRegResponse = preAccountRegServiceImplObj.preAccountReg(preAccountRegRequest,
				requestHeader)
		then:
		preAccountRegResponse.appInfo == 'Null response from preAccountRegHelper.preAccountReg'
	}


	def "test preaccountreg invaliddataexcep"() {

		given:
		HashMap hmResponse = new HashMap()
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
		hmResponse['isTransactionRollback'] = 'true'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		preAccountRegHelperObj.preAccountReg(_ as HashMap)>>hmResponse
		expect:
		InvalidInputDataException excep = Assertions.assertThrows(InvalidInputDataException.class, () -> {
			preAccountRegServiceImplObj.preAccountReg(preAccountRegRequest, requestHeader)
		})

	}

	@SuppressWarnings('unchecked')
	def "test preaccountreg success"() {

		given:
		HashMap hmResponse = new HashMap()
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['appInfo'] = 'Success'
		hmResponse['ErrorEnum'] = CommonDefs.COMMON_SUCCESS_MSG
		preAccountRegHelperObj.preAccountReg(_ as HashMap)>>hmResponse

		when:
		preAccountRegResponse = preAccountRegServiceImplObj.preAccountReg(preAccountRegRequest,
				requestHeader)
		then:
		preAccountRegResponse.appStatusCode == '0'
	}

}
