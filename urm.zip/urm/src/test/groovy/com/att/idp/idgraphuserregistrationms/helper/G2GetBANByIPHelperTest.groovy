package com.att.idp.idgraphuserregistrationms.helper

import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Ignore
import spock.lang.Specification
import org.springframework.test.util.ReflectionTestUtils

import jakarta.ws.rs.core.Response

class G2GetBANByIPHelperTest extends Specification {

    Map<String, Object> hmInput = new HashMap()
    Map<String, Object> hmResult = null
    Map<String, Object> hmSuccessResponse = new HashMap()
    Map<String, Object> hmErrorResponse = new HashMap()
    Response response = null
    private Logger logger = null
    private String stAppInfo
    HashMap hmResponse = null
    String stAppStatusMsg = null

    def oG2GetBANByIPHelper = new G2GetBANByIPHelper()
    FeatureManagerHelper featureManager = Mock(FeatureManagerHelper)

    def setup(){
        logger = LoggerFactory.getLogger('.getBANByIP.')
        oG2GetBANByIPHelper.featureManager=featureManager
        // System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')

        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'

        hmSuccessResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        hmErrorResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_LENGTH_NUM, 'Error')
        GroovySpy(G2GetBANByIPHelper, global: true)

        ReflectionTestUtils.setField(oG2GetBANByIPHelper, 'propG2RequestElement', 'getbanbyipRequest')
        ReflectionTestUtils.setField(oG2GetBANByIPHelper, 'propG2RequestNamespace', 'http://g2.att.com/g2mpsservice')
        ReflectionTestUtils.setField(oG2GetBANByIPHelper, 'propG2GetBanByIPURL', 'https://g2-lgw-nonprod.test.att.com/aze2st/st/mps/soaplistener/services/G2MPSPort')
        ReflectionTestUtils.setField(oG2GetBANByIPHelper, 'propG2ConnectTimeout', '5000')
        ReflectionTestUtils.setField(oG2GetBANByIPHelper, 'propG2ReadTimeout', '10000')
        ReflectionTestUtils.setField(oG2GetBANByIPHelper, 'propG2SetSoapAction', 'Y')
        ReflectionTestUtils.setField(oG2GetBANByIPHelper, 'propG2GetBanByIPLBURL', 'https://g2-lgw.it.att.com/idns-api-mps/prod/mps/soaplistener/services/G2MPSPort')
        ReflectionTestUtils.setField(oG2GetBANByIPHelper, 'propG2Authorization', 'Y')
        ReflectionTestUtils.setField(oG2GetBANByIPHelper, 'propG2ProxyHost', '1234')
        ReflectionTestUtils.setField(oG2GetBANByIPHelper, 'propG2ProxyPort', '1234')


    }

    def "test g2 get b a n by i p null case"() throws Exception {
        // when hmInput is null
        given:
        featureManager.isEnabled(_)>>false
        hmResult = oG2GetBANByIPHelper.getBANByIP(null)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
        stAppInfo == 'Input Hash is NULL'
    }


    def "test g2 get b a n by i p b a n not found"() throws Exception {

        // when hmInput is populated, respective ban not found
        given:
        featureManager.isEnabled(_)>>true
        hmInput[CommonDefs.IP_ADDRESS] = '2611:1711:4881:3931:2a16:adsf:fe19:7be4'
        hmResult = oG2GetBANByIPHelper.getBANByIP(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppInfo == 'Error Response to SOAP over HTTP call from G2'
    }


    def "test g2 get b a n by i p success"() throws Exception {

        // when hmInput is populated, ban found in G2
        given:
        featureManager.isEnabled(_)>>true
        hmInput[CommonDefs.IP_ADDRESS] = '192.168.1.1'
        hmResult = oG2GetBANByIPHelper.getBANByIP(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        stAppInfo == 'Error Response to SOAP over HTTP call from G2'
    }
}
