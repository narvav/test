package com.att.idp.idgraph.commons.integration

import com.att.idp.http.client.config.RestTemplateBeanFactory
import com.att.idp.idgraph.commons.integration.model.CLMNotificationRequest
import com.att.idp.idgraph.commons.integration.model.CLMNotificationResponse
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.Bean
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.retry.annotation.EnableRetry
import org.springframework.test.context.ContextConfiguration
import org.springframework.test.context.TestPropertySource
import org.springframework.test.context.bean.override.mockito.MockitoBean
import org.springframework.web.client.HttpClientErrorException
import org.springframework.web.client.HttpServerErrorException
import org.springframework.web.client.ResourceAccessException
import org.springframework.web.client.RestTemplate
import spock.lang.Specification
import static org.mockito.Mockito.*

/**
 * Integration test for CLMRestClient to verify retry logic and error handling.
 *
 * This is required since unit tests do not execute the retry logic due to the way Spock handles method calls.
 */
@ContextConfiguration(classes = TestBeans)
@TestPropertySource(properties = [
        'apiclient.rest.ccmulesoft.serverUrl=http://localhost:8080',
        'apiclient.rest.ccmulesoft.endpoint=/api/notify',
        'apiclient.rest.ccmulesoft.clientid=test-client-id',
        'apiclient.rest.ccmulesoft.clientsecret=test-client-secret'
])
class CLMRestClientIntegrationTest extends Specification {

    @EnableRetry
    static class TestBeans {
        @Bean
        static PropertySourcesPlaceholderConfigurer propertyConfigurer() {
            return new PropertySourcesPlaceholderConfigurer()
        }

        @Bean
        CLMRestClient clmRestClient(RestTemplate restTemplate) throws Exception {
            def factory = mock(RestTemplateBeanFactory)
            when(factory.getObject(anyString())).thenReturn(restTemplate)
            return new CLMRestClient(factory)
        }
    }

    @Autowired
    CLMRestClient clmRestClient

    @MockitoBean
    RestTemplate restTemplate

    def outContent
    def originalOut

    def setup() {
        originalOut = System.out
        outContent = new ByteArrayOutputStream()
        System.setOut(new PrintStream(outContent))
    }

    def cleanup() {
        System.setOut(originalOut)
        println(outContent.toString())
    }

    def "should retry 3 times for 5xx errors and return error response"() {
        given:
        def request = CLMNotificationRequest.builder().build()
        def exception = new HttpServerErrorException(status)
        when(restTemplate.postForEntity(anyString(), any(), eq(CLMNotificationResponse.class))).thenThrow(exception)

        when:
        def result = clmRestClient.sendCLMNotification(request)

        then:
        result.statusCode == 610
        outContent.toString().contains("Sending CLM notification, retry count = 2")

        where:
        status << [HttpStatus.INTERNAL_SERVER_ERROR, HttpStatus.BAD_GATEWAY, HttpStatus.SERVICE_UNAVAILABLE]
    }

    def "should not retry 4xx errors and return error response"() {
        given:
        def request = CLMNotificationRequest.builder().build()
        def exception = new HttpClientErrorException(status)
        when(restTemplate.postForEntity(anyString(), any(), eq(CLMNotificationResponse.class))).thenThrow(exception)

        when:
        def result = clmRestClient.sendCLMNotification(request)

        then:
        result.statusCode == 610
        !outContent.toString().contains("Sending CLM notification, retry count = 2")

        where:
        status << [HttpStatus.BAD_REQUEST, HttpStatus.FORBIDDEN, HttpStatus.UNAUTHORIZED]
    }

    def "should not retry for 200 OK response"() {
        given:
        def request = CLMNotificationRequest.builder().build()
        def response = new CLMNotificationResponse(statusCode: 200, statusMessage: "Success")
        def successResponse = new ResponseEntity<>(response, HttpStatus.OK)
        when(restTemplate.postForEntity(anyString(), any(), eq(CLMNotificationResponse.class))).thenReturn(successResponse)

        when:
        def result = clmRestClient.sendCLMNotification(request)

        then:
        result.statusCode == 200
    }

    def "should retry 2 times for 5xx error and succeed on 3rd attempt"() {
        given:
        def request = CLMNotificationRequest.builder().build()
        def exception = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR)
        def response = new CLMNotificationResponse(statusCode: 200, statusMessage: "Success")
        def successResponse = new ResponseEntity<>(response, HttpStatus.OK)
        // First two calls throw 5xx, third call succeeds
        when(restTemplate.postForEntity(anyString(), any(), eq(CLMNotificationResponse.class)))
            .thenThrow(exception)
            .thenReturn(successResponse)

        when:
        def result = clmRestClient.sendCLMNotification(request)

        then:
        result.statusCode == 200
        // Verify total invocations (2 retries, 1 success)
        outContent.toString().contains("Sending CLM notification, retry count = 1")
        !outContent.toString().contains("Sending CLM notification, retry count = 2")
    }

    def "should retry for ResourceAccessException and return error response after max attempts"() {
        given:
        def request = CLMNotificationRequest.builder().build()
        def exception = new ResourceAccessException("Connection timed out")
        when(restTemplate.postForEntity(anyString(), any(), eq(CLMNotificationResponse.class))).thenThrow(exception)

        when:
        def result = clmRestClient.sendCLMNotification(request)

        then:
        result.statusCode == 610
        // Should have retried 3 times (default maxAttempts)
        outContent.toString().contains("Sending CLM notification, retry count = 2")
    }
}
