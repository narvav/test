package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.EmailAppPasswordDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.idp.idgraphuserregistrationms.queue.message.helpers.PublishEventHelper
import com.att.idp.idgraphuserregistrationms.utils.ProfileOrchestrationConstants
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.MPSDefs
import jakarta.ws.rs.core.HttpHeaders
import spock.lang.Specification

class DeleteEmailAppPasswordHelperSpec extends Specification {

    EmailAppPasswordDBHelper mockEmailAppPasswordDBHelper
    GetMemberServicesDBHelper mockGetMemberServicesDBHelper
    PublishEventHelper mockPublishEventHelper
    YahooSMKHelper mockYahooSMKHelper
    HttpHeaders mockHttpHeaders
    DeleteEmailAppPasswordHelper helperUnderTest

    void setup() {
        mockEmailAppPasswordDBHelper = Mock(EmailAppPasswordDBHelper)
        mockGetMemberServicesDBHelper = Mock(GetMemberServicesDBHelper)
        mockPublishEventHelper = Mock(PublishEventHelper)
        mockYahooSMKHelper = Mock(YahooSMKHelper)
        mockHttpHeaders = Mock(HttpHeaders)
        helperUnderTest = new DeleteEmailAppPasswordHelper(mockEmailAppPasswordDBHelper, mockGetMemberServicesDBHelper, mockPublishEventHelper)
        helperUnderTest.yahooSMKHelper = mockYahooSMKHelper
    }

    def "should set DB_MEMBER_NUM from guid and DB_PASSWORD_NAME from passwordName then call deleteEmailAppPwd"() {
        given:
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put("guid", "12345")
        hmInput.put("passwordName", "imap")
        hmInput.put("memberId", "testUser")
        hmInput.put("domain", "att.net")
        hmInput.put(CommonDefs.TRANSACTION_ID, "trace123")
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "IDMPROFILE")

        HashMap deleteResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        HashMap yahooResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success")
        HashMap publishResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success")
        HashMap memberResult = memberResult("12345", "testUser", "att.net")

        when:
        HashMap result = helperUnderTest.deleteEmailAppPassword(hmInput, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices({ HashMap input ->
            input.get(MPSDefs.DB_MEMBER_NUM) == "12345"
        }) >> memberResult
        1 * mockEmailAppPasswordDBHelper.deleteEmailAppPwd({ HashMap input ->
            input.get(MPSDefs.DB_MEMBER_NUM) == "12345" &&
            input.get(MPSDefs.DB_MEMBER_NAME) == "testUser" &&
            input.get(MPSDefs.DB_DOMAIN_NAME) == "att.net" &&
            input.get(MPSDefs.DB_PASSWORD_NAME) == "imap"
        }) >> deleteResult
        1 * mockYahooSMKHelper.deleteApplicationPassword(_) >> yahooResult
        1 * mockPublishEventHelper.publishEvent(_, _, { Map eventPayload ->
            eventPayload.get("mainHashKey") == "testUser"
        }, _) >> publishResult
        0 * _

        and:
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
    }

    def "should not set DB_PASSWORD_NAME when passwordName is absent"() {
        given:
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put("guid", "12345")
        hmInput.put("memberId", "testUser")
        hmInput.put("domain", "att.net")
        hmInput.put(CommonDefs.TRANSACTION_ID, "trace123")
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "IDMPROFILE")

        HashMap deleteResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        HashMap publishResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success")
        HashMap memberResult = memberResult("12345", "testUser", "att.net")

        when:
        HashMap result = helperUnderTest.deleteEmailAppPassword(hmInput, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices({ HashMap input ->
            input.get(MPSDefs.DB_MEMBER_NUM) == "12345"
        }) >> memberResult
        1 * mockEmailAppPasswordDBHelper.deleteEmailAppPwd({ HashMap input ->
            input.get(MPSDefs.DB_MEMBER_NUM) == "12345" &&
            !input.containsKey(MPSDefs.DB_PASSWORD_NAME)
        }) >> deleteResult
        1 * mockPublishEventHelper.publishEvent(_, _, { Map eventPayload ->
            eventPayload.get("mainHashKey") == "testUser"
        }, _) >> publishResult
        0 * _

        and:
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
    }

    def "should resolve member number via getMemberServices and call deleteEmailAppPwd when guid is absent"() {
        given:
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put("memberId", "testUser")
        hmInput.put("domain", "att.net")
        hmInput.put("passwordName", "imap")
        hmInput.put(CommonDefs.TRANSACTION_ID, "trace123")
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "IDMPROFILE")

        HashMap memberResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        memberResult.put(MPSDefs.DB_MEMBER_NUM, "99999")
        memberResult.put(MPSDefs.DB_MEMBER_NAME, "testUser")
        memberResult.put(MPSDefs.DB_DOMAIN_NAME, "att.net")
        memberResult.put(MPSDefs.DB_CONTACT_EMAIL, "testUser@att.net")
        memberResult.put(MPSDefs.DB_ACCOUNT_TYPE, "UVERSE")

        HashMap deleteResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        HashMap yahooResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success")
        HashMap publishResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success")

        when:
        HashMap result = helperUnderTest.deleteEmailAppPassword(hmInput, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices({ HashMap input ->
            input.get(MPSDefs.DB_MEMBER_NAME) == "testUser" &&
            input.get(MPSDefs.DB_DOMAIN_NAME) == "att.net"
        }) >> memberResult
        1 * mockEmailAppPasswordDBHelper.deleteEmailAppPwd({ HashMap input ->
            input.get(MPSDefs.DB_MEMBER_NUM) == "99999" &&
            input.get(MPSDefs.DB_PASSWORD_NAME) == "imap"
        }) >> deleteResult
        1 * mockYahooSMKHelper.deleteApplicationPassword(_) >> yahooResult
        1 * mockPublishEventHelper.publishEvent(_, _, _, _) >> publishResult
        0 * _

        and:
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
    }

    def "should return not-found response when getMemberServices returns null"() {
        given:
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put("memberId", "unknownUser")
        hmInput.put("domain", "att.net")
        String traceId = "trace-notfound"
        hmInput.put("idpTraceId", traceId)

        when:
        HashMap result = helperUnderTest.deleteEmailAppPassword(hmInput, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices(_) >> null
        0 * mockEmailAppPasswordDBHelper.deleteEmailAppPwd(_)
        0 * _

        and:
        result.get(MPSDefs.APP_STATUS_CODE) == "121"
        result.get(CommonDefs.COMMON_APP_INFO) == "User not found"
        result.get(ProfileOrchestrationConstants.IDP_TRACE_ID) == traceId
    }

    def "should return not-found response when getMemberServices result has no DB_MEMBER_NUM"() {
        given:
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put("memberId", "unknownUser")
        hmInput.put("domain", "att.net")
        String traceId = "trace-notfound-2"
        hmInput.put("idpTraceId", traceId)

        HashMap memberResult = new HashMap()

        when:
        HashMap result = helperUnderTest.deleteEmailAppPassword(hmInput, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices(_) >> memberResult
        0 * mockEmailAppPasswordDBHelper.deleteEmailAppPwd(_)
        0 * _

        and:
        result.get(MPSDefs.APP_STATUS_CODE) == "121"
        result.get(ProfileOrchestrationConstants.IDP_TRACE_ID) == traceId
    }

    def "should return not-found response when getMemberServices result has empty string for DB_MEMBER_NUM"() {
        given:
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put("memberId", "unknownUser")
        hmInput.put("domain", "att.net")
        String traceId = "trace-empty-membernum"
        hmInput.put("idpTraceId", traceId)

        HashMap memberResult = new HashMap()
        memberResult.put(MPSDefs.DB_MEMBER_NUM, "")

        when:
        HashMap result = helperUnderTest.deleteEmailAppPassword(hmInput, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices(_) >> memberResult
        0 * mockEmailAppPasswordDBHelper.deleteEmailAppPwd(_)
        0 * _

        and:
        result.get(MPSDefs.APP_STATUS_CODE) == "121"
        result.get(ProfileOrchestrationConstants.IDP_TRACE_ID) == traceId
    }

    def "should treat empty string guid as absent and use memberId/domain path"() {
        given:
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put("guid", "")
        hmInput.put("memberId", "testUser")
        hmInput.put("domain", "att.net")
        hmInput.put("passwordName", "imap")
        hmInput.put(CommonDefs.TRANSACTION_ID, "trace123")
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "IDMPROFILE")

        HashMap memberResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        memberResult.put(MPSDefs.DB_MEMBER_NUM, "55555")
        memberResult.put(MPSDefs.DB_MEMBER_NAME, "testUser")
        memberResult.put(MPSDefs.DB_DOMAIN_NAME, "att.net")
        memberResult.put(MPSDefs.DB_CONTACT_EMAIL, "testUser@att.net")
        memberResult.put(MPSDefs.DB_ACCOUNT_TYPE, "UVERSE")

        HashMap deleteResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        HashMap yahooResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success")
        HashMap publishResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success")

        when:
        HashMap result = helperUnderTest.deleteEmailAppPassword(hmInput, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices(_) >> memberResult
        1 * mockEmailAppPasswordDBHelper.deleteEmailAppPwd({ HashMap input ->
            input.get(MPSDefs.DB_MEMBER_NUM) == "55555"
        }) >> deleteResult
        1 * mockYahooSMKHelper.deleteApplicationPassword(_) >> yahooResult
        1 * mockPublishEventHelper.publishEvent(_, _, _, _) >> publishResult
        0 * _

        and:
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
    }

    def "should return error when deleteEmailAppPwd returns error"() {
        given:
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put("guid", "12345")
        hmInput.put("passwordName", "imap")
        hmInput.put("memberId", "testUser")
        hmInput.put("domain", "att.net")
        hmInput.put(CommonDefs.TRANSACTION_ID, "trace123")
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "IDMPROFILE")

        HashMap deleteResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "DB delete failed")
        HashMap memberResult = memberResult("12345", "testUser", "att.net")

        when:
        HashMap result = helperUnderTest.deleteEmailAppPassword(hmInput, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices({ HashMap input ->
            input.get(MPSDefs.DB_MEMBER_NUM) == "12345"
        }) >> memberResult
        1 * mockEmailAppPasswordDBHelper.deleteEmailAppPwd(_) >> deleteResult
        0 * mockPublishEventHelper.publishEvent(_, _, _, _)
        0 * _

        and:
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_SYS_APPL_NUM)
    }

    def "should bypass error when publishNotificationEvent fails"() {
        given:
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put("guid", "12345")
        hmInput.put("passwordName", "imap")
        hmInput.put("memberId", "testUser")
        hmInput.put("domain", "att.net")
        hmInput.put(CommonDefs.TRANSACTION_ID, "trace123")
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "IDMPROFILE")

        HashMap deleteResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        HashMap yahooResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success")
        HashMap publishResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "Publish failed")
        HashMap memberResult = memberResult("12345", "testUser", "att.net")

        when:
        HashMap result = helperUnderTest.deleteEmailAppPassword(hmInput, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices({ HashMap input ->
            input.get(MPSDefs.DB_MEMBER_NUM) == "12345"
        }) >> memberResult
        1 * mockEmailAppPasswordDBHelper.deleteEmailAppPwd(_) >> deleteResult
        1 * mockYahooSMKHelper.deleteApplicationPassword(_) >> yahooResult
        1 * mockPublishEventHelper.publishEvent(_, _, { Map eventPayload ->
            eventPayload.get("mainHashKey") == "testUser"
        }, _) >> publishResult
        0 * _

        and:
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
    }

    def "should skip notification when suppressEDD is Y"() {
        given:
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put("guid", "12345")
        hmInput.put("passwordName", "imap")
        hmInput.put("memberId", "testUser")
        hmInput.put("domain", "att.net")
        hmInput.put(CommonDefs.TRANSACTION_ID, "trace123")
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "IDMPROFILE")
        hmInput.put("suppressEDD", CommonDefs.IND_Y)

        HashMap deleteResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        HashMap yahooResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success")
        HashMap memberResult = memberResult("12345", "testUser", "att.net")

        when:
        HashMap result = helperUnderTest.deleteEmailAppPassword(hmInput, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices({ HashMap input ->
            input.get(MPSDefs.DB_MEMBER_NUM) == "12345"
        }) >> memberResult
        1 * mockEmailAppPasswordDBHelper.deleteEmailAppPwd(_) >> deleteResult
        1 * mockYahooSMKHelper.deleteApplicationPassword(_) >> yahooResult
        0 * mockPublishEventHelper.publishEvent(_, _, _, _)
        0 * _

        and:
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
    }

    private static HashMap memberResult(String memberNum, String memberName, String domain) {
        HashMap memberResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        memberResult.put(MPSDefs.DB_MEMBER_NUM, memberNum)
        memberResult.put(MPSDefs.DB_MEMBER_NAME, memberName)
        memberResult.put(MPSDefs.DB_DOMAIN_NAME, domain)
        memberResult.put(MPSDefs.DB_CONTACT_EMAIL, memberName + "@" + domain)
        memberResult.put(MPSDefs.DB_ACCOUNT_TYPE, "UVERSE")
        return memberResult
    }

}
