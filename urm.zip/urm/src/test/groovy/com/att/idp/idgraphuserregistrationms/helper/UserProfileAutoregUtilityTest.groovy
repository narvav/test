/**
 * 
 */
package com.att.idp.idgraphuserregistrationms.helper

import spock.lang.Specification

import java.io.IOException
import java.util.ArrayList
import java.util.HashMap
import java.util.Map

import jakarta.ws.rs.core.Response

import org.springframework.test.util.ReflectionTestUtils

import com.att.idp.idgraphuserregistrationms.helper.UserProfileAutoregUtility
import com.att.idp.idgraphuserregistrationms.integration.MPSYSInternalRestClient
import com.att.idp.idgraphuserregistrationms.utils.RILCheckAndEncryptPasswordHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.CommonUtil

import static org.junit.jupiter.api.Assertions.assertEquals

/**
 * @author pragathi.a.baskar
 *
 */
class UserProfileAutoregUtilityTest extends Specification {


    def userProfileAutoregUtilityObj=new UserProfileAutoregUtility();

	RILCheckAndEncryptPasswordHelper oRILCheckAndEncryptPasswordHelper=Mock(RILCheckAndEncryptPasswordHelper)

	MPSYSInternalRestClient internalIDPRestClient=Mock(MPSYSInternalRestClient)

    HashMap hmInput = new HashMap()
    HashMap hmSuccessResponse = new HashMap()
    HashMap hmErrorResponse = new HashMap()

    Response response = null
    HashMap hmCGResponse = new HashMap()
    HashMap hmCheckUserResp = new HashMap()
    private Map hmResult = CommonUtil.hashMap
    String stAppInfo = null


    def setup()
			throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		
        userProfileAutoregUtilityObj.oRILCheckAndEncryptPasswordHelper=oRILCheckAndEncryptPasswordHelper
        userProfileAutoregUtilityObj.internalIDPRestClient=internalIDPRestClient
        hmResult = null

        hmSuccessResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        hmErrorResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_LENGTH_NUM, 'Error')

        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.IS_EXTERNAL_CALL] = 'Y'
        hmInput[CommonDefs.TRANSACTION_NAME] = 'WirelessAutoReg'
        hmInput[CommonDefs.FIRST_NAME] = 'qay'
        hmInput[CommonDefs.LAST_NAME] = 'test'
        hmInput[CommonDefs.GUID] = '121321113'
        hmInput[CommonDefs.CONTACT_EMAIL] = 'qaytest@att.net'
        hmInput['isConnectedCar'] = 'Y'
        hmInput[CommonDefs.SERVICE_NAME] = 'MOBILITY'
        hmInput[CommonDefs.SOR_ID] = '13'
        hmInput[CommonDefs.SOR_INVARIANT_ID] = '2462729299'

        HashMap hmSuggest = new HashMap<>()
        hmSuggest['suggest'] = 'qaydgeurts65718034'
        ArrayList<Map<String, String>> suggestList = new ArrayList()
        suggestList.add(hmSuggest)

        hmCheckUserResp['suggestList'] = suggestList
        hmCheckUserResp['appInfo'] = 'SUCCESS'
        hmCheckUserResp['appStatusCode'] = '0'

        ReflectionTestUtils.setField(userProfileAutoregUtilityObj, 'propRILHRSValidDomains',
                'sbcglobal.net|prodigy.net|wans.net|flash.net|ameritech.net|swbell.net|pacbell.net|nvbell.net|snet.net|attworld.com|att.net|bellsouth.net|portal.att.net|myaccount.bellsouth.net|slid.dum')
        ReflectionTestUtils.setField(userProfileAutoregUtilityObj, 'propAutogenLegalChars',
                'abcdefghijklmnopqrstuvwxyz0123456789.-_@')
    }


    def "test user profile autoreg util success"() throws Exception {

		// when checkUser returns suggestlist and contactEmail domain is att

        given:
        internalIDPRestClient.callIDPRestClient(_ as HashMap)>> hmCheckUserResp
        hmResult = userProfileAutoregUtilityObj.generateAutoGenAccessId(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'

        // when checkUser returns suggestlist and contactEmail domain is not att
        when:
        hmInput[CommonDefs.CONTACT_EMAIL] = 'qaytest@yahoo.com'
        hmResult = userProfileAutoregUtilityObj.generateAutoGenAccessId(hmInput)
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'

        // when contactemail format is not valid, for missing coverage
		// it will set bContactEmailDomainNotFound true
        when:
        hmInput[CommonDefs.CONTACT_EMAIL] = 'qaytest@.com'
        hmResult = userProfileAutoregUtilityObj.generateAutoGenAccessId(hmInput)
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
        //when fn and ln are bad data
        when:
        hmInput[CommonDefs.CONTACT_EMAIL] = 'qaytest@.com'
        hmInput[CommonDefs.FIRST_NAME] = '??'
        hmInput[CommonDefs.LAST_NAME] = '??'
        hmResult = userProfileAutoregUtilityObj.generateAutoGenAccessId(hmInput)
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'

    }

    def "test user profile autoreg util success case2"() throws Exception {
        given:
        internalIDPRestClient.callIDPRestClient(_ as HashMap)>> hmCheckUserResp
        hmInput[CommonDefs.CONTACT_EMAIL] = 'qaytest@.com'
        hmInput[CommonDefs.FIRST_NAME] = '??'
        hmInput[CommonDefs.LAST_NAME] = '??'
        hmResult = userProfileAutoregUtilityObj.generateAutoGenAccessId(hmInput)
        when:
        hmResult = userProfileAutoregUtilityObj.generateAutoGenAccessId(hmInput)
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
    }

    def "test user profile autoreg util success case3"() throws Exception {
        given:
        internalIDPRestClient.callIDPRestClient(_ as HashMap)>> hmCheckUserResp
        hmInput[CommonDefs.CONTACT_EMAIL] = 'qaytest@.com'
        hmInput[CommonDefs.FIRST_NAME] = '??'
        hmInput[CommonDefs.LAST_NAME] = 'ab'
        hmResult = userProfileAutoregUtilityObj.generateAutoGenAccessId(hmInput)
        when:
        hmResult = userProfileAutoregUtilityObj.generateAutoGenAccessId(hmInput)
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
    }
//    def "test user profile autoreg util error"() throws Exception {
//
//		// when null response received from IDP rest client, validSlid not found
//        given:
//        internalIDPRestClient.callIDPRestClient(_ as HashMap)>> null
//        hmResult = userProfileAutoregUtilityObj.generateAutoGenAccessId(hmInput)
//        when:
//        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
//        then:
//        stAppInfo == 'Auto registration aborted'
//
//        // when IDP restClient returns exception
//        when:
//		idpInternalRestClient.callIDPRestClient(_ as HashMap)
//		then:
//		thrown(RuntimeException)
//       // when:
//        hmResult = userProfileAutoregUtilityObj.generateAutoGenAccessId(hmInput)
//		//stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
//       // then:
//       // stAppInfo == 'SYSTEM ERROR'
//    }

    def "test adduser return expected response"() throws Exception {
		Map<String, Object> input = new HashMap<>()
		input['contactEmailRTValidFlag'] = 'Y'
		input[CommonDefs.CONTACT_EMAIL] = 'test@slid.dum'
		input[CommonDefs.FIRST_NAME] = 'Test'
		input[CommonDefs.LAST_NAME] = 'User'
		input[CommonDefs.CALLING_SYSTEM_ID] = 'TestSystem'

        internalIDPRestClient.callIDPRestClient(_ as HashMap)>> hmCheckUserResp
		Map<String, Object> actualResponse = userProfileAutoregUtilityObj.callAddUser(input, 'test@slid.dum')

		assertEquals(hmCheckUserResp, actualResponse)
	}

    def "test invalid contact email format"() {
        given:
        hmInput[CommonDefs.CONTACT_EMAIL] = '@...$%....com'
        when:
        Map<String,Object>  result = userProfileAutoregUtilityObj.generateAutoGenAccessId(hmInput)
        then:
        result[CommonDefs.COMMON_APP_INFO] == "Auto registration aborted"
    }

    def "test callCheckUserIdAvailability return null"() {
        given:
        hmInput[CommonDefs.CONTACT_EMAIL] = 'test@slid.dum'
        internalIDPRestClient.callIDPRestClient(_ as HashMap)>>null
        when:
        def result = userProfileAutoregUtilityObj.callCheckUserIdAvailability(hmInput, "test@slid.dum", "1");
        then:
        result[CommonDefs.COMMON_APP_INFO] == "Null Response returned from MPSYSInternalRestClient.callIDPRestClient()"
    }

    def "test generateAutoGenAccessId handles exception"() {
        given:
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >> new RuntimeException('null')
        when:
        def result = userProfileAutoregUtilityObj.generateAutoGenAccessId(hmInput)
        then:
        result['appStatusMsg']=="ERR_SYS_APPL";;

    }

    /*def "test null or empty response map"() {
        given:
        Map hmResult=null;
       when:
        Map result = userProfileAutoregUtilityObj.generateAutoGenAccessId(hmInput)
        then:
        result['appInfo'] == "Response Map is NULL or EMPTY" //Inside finally block, lines of code never executes

    }*/

    def "test callAddUser returns null response"() {
        given:
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >> null
        when:
        def result = userProfileAutoregUtilityObj.callAddUser(hmInput, "validSLID")
        then:
        result[CommonDefs.COMMON_APP_INFO] == "Null Response returned from MPSYSInternalRestClient.callIDPRestClient()"

    }

    def "test callAddUser returns valid response"() {
        given:
        hmInput.put(CommonDefs.CONTACT_EMAIL, "abc@slid.dum");
        hmInput.put("contactEmailRTValidFlag", "Y");
        def hmResponse = new HashMap()
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmResponse[CommonDefs.COMMON_APP_INFO] = "SUCCESS"
        hmResponse[CommonDefs.COMMON_APP_STATUS_MSG] = "SUCCESS"
        hmResponse[CommonDefs.COMMON_APP_CATEGORY_CODE] = 0
        internalIDPRestClient.callIDPRestClient(_ as Map) >> hmResponse
        when:
        def result = userProfileAutoregUtilityObj.callAddUser(hmInput, "abc@slid.dum")
        then:
        result == hmResponse
    }



}
