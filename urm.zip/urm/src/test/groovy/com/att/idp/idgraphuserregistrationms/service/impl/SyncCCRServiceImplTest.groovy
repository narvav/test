package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.helper.SyncCCRHelper
import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.idp.idgraphuserregistrationms.resource.response.SyncUserProfileResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import jakarta.ws.rs.core.HttpHeaders
import spock.lang.Specification
import spock.lang.Unroll

class SyncCCRServiceImplTest extends Specification {

    SyncCCRHelper syncCCRHelper
    SyncCCRServiceImpl serviceUnderTest
    HttpHeaders headers = Mock(HttpHeaders)

    def setup() {
        syncCCRHelper = Mock(SyncCCRHelper)
        serviceUnderTest = new SyncCCRServiceImpl(syncCCRHelper)
    }

    @Unroll
    def "should return success response for #scenarioName"() {
        given: "A valid request and helper success map"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setIdpTraceId(idpTraceId)
        request.setTransactionName(transactionName)
        request.setHandle(handle)
        request.setDomain(domain)

        Map<String, Object> helperResponse = new HashMap<>()
        helperResponse.put(MPSDefs.APP_STATUS_CODE, appStatusCode)
        helperResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        helperResponse.put(CommonDefs.COMMON_APP_INFO, appInfo)
        // No rollback flag on success

        when: "syncCCR is invoked"
        SyncUserProfileResponse result = serviceUnderTest.syncCCR(request, headers)

        then: "Helper is called with exact request and no other interactions"
        1 * syncCCRHelper.syncCCR({ SyncUserProfileRequest req ->
            req.getIdpTraceId() == idpTraceId &&
            req.getTransactionName() == transactionName &&
            req.getHandle() == handle &&
            req.getDomain() == domain
        }) >> helperResponse
        0 * _

        and: "Result contains expected response attributes"
        result != null
        result.getTransactionName() == transactionName
        result.getAppStatusCode() == CommonDefs.COMMON_SUCCESS
        result.getAppCategoryCode() != null
        result.getAppStatusMsg() != null
        result.getAppInfo() == appInfo
        result.getIdpTraceId() == idpTraceId
        result.getErrors() == null

        where: "Different successful scenarios"
        scenarioName         | idpTraceId     | transactionName                          | handle         | domain     | appStatusCode | appInfo
        "standard success"  | "trace-123"    | "SyncCCR" | "user123"     | "att.com" | "0"          | "Success"
        "reprovision g2"    | "trace-456"    | "SyncCCR" | "member789"   | "att.com" | "0"          | "Updated"
    }

    def "should throw InvalidInputDataException when helper indicates transaction rollback"() {
        given: "A request and helper response with rollback flag and non-success code"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setIdpTraceId("trace-err")
        request.setTransactionName("SyncCCR")
        request.setHandle("userX")
        request.setDomain("att.com")

        Map<String, Object> helperResponse = new HashMap<>()
        helperResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, "0")
        helperResponse.put(CommonDefs.COMMON_APP_INFO, "DB error")
        helperResponse.put("isTransactionRollback", "Y")

        when: "syncCCR is invoked"
        serviceUnderTest.syncCCR(request, headers)

        then: "Helper called and exception thrown"
        1 * syncCCRHelper.syncCCR({ SyncUserProfileRequest req ->
            req.getIdpTraceId() == "trace-err" &&
            req.getTransactionName() ==    "SyncCCR" &&
            req.getHandle() == "userX" &&
            req.getDomain() == "att.com"
        }) >> helperResponse


        and: "Exception details are propagated"
        InvalidInputDataException ex = thrown()

    }

    @Unroll
    def "should handle null or missing APP_STATUS_CODE for #scenarioName"() {
        given: "A request and helper response with null or missing APP_STATUS_CODE"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setIdpTraceId("trace-null")
        request.setTransactionName("SyncCCR")
        request.setHandle("userZ")
        request.setDomain("att.com")
        HttpHeaders headers = Stub(HttpHeaders)

        Map<String, Object> helperResponse = new HashMap<>()
        if (includeStatusCode) {
            helperResponse.put(MPSDefs.APP_STATUS_CODE, null)
        }
        helperResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, includeStatusCode ? null : CommonDefs.COMMON_SUCCESS)
        helperResponse.put(CommonDefs.COMMON_APP_INFO, "Info")

        when: "syncCCR is invoked"
        SyncUserProfileResponse result = serviceUnderTest.syncCCR(request, headers)

        then: "Helper called and service builds response via processHelperResponse"
        1 * syncCCRHelper.syncCCR({ SyncUserProfileRequest req ->
            req.getIdpTraceId() == "trace-null" &&
            req.getTransactionName() ==   "SyncCCR"
                    &&
            req.getHandle() == "userZ" &&
            req.getDomain() == "att.com"
        }) >> helperResponse
        0 * _

        and: "Result is not null and contains app info and trace id"
        result != null
        result.getTransactionName() ==   "SyncCCR"
        result.getAppInfo() != null
        result.getIdpTraceId() == "trace-null"

        where:
        scenarioName            | includeStatusCode
        "missing status code"  | false
        "null status code"     | true
    }

    @Unroll
    def "should return success response for Guid in request  #scenarioName"() {
        given: "A valid request and helper success map"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setIdpTraceId(idpTraceId)
        request.setTransactionName(transactionName)
        request.setGuid("1232432")

        Map<String, Object> helperResponse = new HashMap<>()
        helperResponse.put(MPSDefs.APP_STATUS_CODE, appStatusCode)
        helperResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        helperResponse.put(CommonDefs.COMMON_APP_INFO, appInfo)
        // No rollback flag on success

        when: "syncCCR is invoked"
        SyncUserProfileResponse result = serviceUnderTest.syncCCR(request, headers)

        then: "Helper is called with exact request and no other interactions"
        1 * syncCCRHelper.syncCCR({ SyncUserProfileRequest req ->
            req.getIdpTraceId() == idpTraceId &&
                    req.getTransactionName() == transactionName &&
                    req.getGuid() == guid
        }) >> helperResponse

        and: "Result contains expected response attributes"
        result != null
        result.getTransactionName() == transactionName
        result.getAppStatusCode() == CommonDefs.COMMON_SUCCESS
        result.getAppCategoryCode() != null
        result.getAppStatusMsg() != null
        result.getAppInfo() == appInfo
        result.getIdpTraceId() == idpTraceId
        result.getErrors() == null

        where: "Different successful scenarios"
        scenarioName         | idpTraceId     | transactionName   | guid   | appStatusCode | appInfo
        "standard success"  | "trace-123"    | "SyncCCR" | "1232432"     | "0"   | "Success"
    }
}
