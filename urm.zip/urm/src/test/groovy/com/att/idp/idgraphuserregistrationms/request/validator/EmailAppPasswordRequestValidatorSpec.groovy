package com.att.idp.idgraphuserregistrationms.request.validator

import com.att.idp.idgraphuserregistrationms.resource.response.EmailAppPasswordResponse
import com.att.idp.idgraphuserregistrationms.utils.ProfileOrchestrationConstants
import jakarta.ws.rs.core.HttpHeaders
import spock.lang.Specification
import spock.lang.Unroll

/**
 * Unit tests for EmailAppPasswordRequestValidator class.
 * Tests cover validation of memberId, domain, GUID, and X-ATT-ClientId header.
 */
class EmailAppPasswordRequestValidatorSpec extends Specification {

    EmailAppPasswordRequestValidator emailAppPasswordRequestValidator
    HttpHeaders httpHeaders

    def setup() {
        emailAppPasswordRequestValidator = new EmailAppPasswordRequestValidator()
        httpHeaders = Mock(HttpHeaders)
    }

    @Unroll
    def "emailPasswordReqValidator returns null when valid GUID provided for #scenarioName"() {
        given:
        String memberId = inputMemberId
        String domain = inputDomain
        String guid = inputGuid
        String traceId = "trace-123"

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders)

        then:
        result == null

        where:
        scenarioName                    | inputMemberId | inputDomain   | inputGuid
        "GUID only"                     | null          | null          | "1234512345"
        "GUID with memberId"            | "testMember"  | null          | "1234512345"
        "GUID with domain"              | null          | "testDomain"  | "1234512345"
        "GUID with memberId and domain" | "testMember"  | "testDomain"  | "1234512345"
        "numeric GUID"                  | null          | null          | "123456789"
        "another numeric GUID"          | null          | null          | "9876543210"
    }

    @Unroll
    def "emailPasswordReqValidator returns null when valid memberId and domain provided for #scenarioName"() {
        given:
        String memberId = inputMemberId
        String domain = inputDomain
        String guid = null
        String traceId = "trace-456"

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders)

        then:
        result == null

        where:
        scenarioName          | inputMemberId    | inputDomain
        "standard values"     | "testMember"     | "testDomain"
        "alphanumeric"        | "member123"      | "domain456"
        "with special chars"  | "test.member"    | "test.domain"
        "with hyphen"         | "test-member"    | "test-domain"
        "with underscore"     | "test_member"    | "test_domain"
    }

    def "emailPasswordReqValidator returns error when X-ATT-ClientId header is missing"() {
        given:
        String memberId = "testMember"
        String domain = "testDomain"
        String guid = null
        String traceId = "trace-789"

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        httpHeaders.getHeaderString("X-ATT-ClientId") >> null

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders)

        then:
        result != null
        result.errors != null
    }

    @Unroll
    def "emailPasswordReqValidator returns error when X-ATT-ClientId is invalid for #scenarioName"() {
        given:
        String memberId = "testMember"
        String domain = "testDomain"
        String guid = null
        String traceId = "trace-invalid"

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        httpHeaders.getHeaderString("X-ATT-ClientId") >> invalidClientId

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders)

        then:
        result != null
        result.errors != null

        where:
        scenarioName       | invalidClientId
        "wrong value"      | "INVALID"
        "empty string"     | ""
        "different app"    | "OTHERAPP"
        "lowercase wrong"  | "idmprofiles"
        "partial match"    | "IDM"
    }

    @Unroll
    def "emailPasswordReqValidator accepts X-ATT-ClientId case insensitively for #scenarioName"() {
        given:
        String memberId = "testMember"
        String domain = "testDomain"
        String guid = null
        String traceId = "trace-case"

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        httpHeaders.getHeaderString("X-ATT-ClientId") >> clientIdValue

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders)

        then:
        result == null

        where:
        scenarioName   | clientIdValue
        "uppercase"    | "IDMPROFILE"
        "lowercase"    | "idmprofile"
        "mixed case"   | "IdMpRoFiLe"
        "capital I"    | "Idmprofile"
    }

    def "emailPasswordReqValidator returns error when neither GUID nor memberId/domain provided"() {
        given:
        String memberId = null
        String domain = null
        String guid = null
        String traceId = "trace-missing"

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders)

        then:
        result != null
        result.errors != null
    }

    @Unroll
    def "emailPasswordReqValidator returns error when only #scenarioName provided"() {
        given:
        String memberId = inputMemberId
        String domain = inputDomain
        String guid = null
        String traceId = "trace-partial"

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders)

        then:
        result != null
        result.errors != null

        where:
        scenarioName       | inputMemberId | inputDomain
        "memberId only"    | "testMember"  | null
        "domain only"      | null          | "testDomain"
        "empty memberId"   | ""            | "testDomain"
        "empty domain"     | "testMember"  | ""
        "whitespace guid"  | null          | null
    }

    @Unroll
    def "emailPasswordReqValidator handles whitespace values correctly for #scenarioName"() {
        given:
        String memberId = inputMemberId
        String domain = inputDomain
        String guid = inputGuid
        String traceId = "trace-whitespace"

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders)

        then:
        result != null
        result.errors != null

        where:
        scenarioName                     | inputMemberId | inputDomain   | inputGuid
        "whitespace GUID only"           | null          | null          | "   "
        "empty GUID only"                | null          | null          | ""
        "whitespace memberId"            | "   "         | "testDomain"  | null
        "whitespace domain"              | "testMember"  | "   "         | null
        "both memberId and domain empty" | ""            | ""            | null
    }

    def "emailPasswordReqValidator includes trace ID in error response"() {
        given:
        String memberId = null
        String domain = null
        String guid = null
        String traceId = "unique-trace-id-999"

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders)

        then:
        result != null
        result.idpTraceId == traceId
    }

    def "emailPasswordReqValidator returns error with appStatusCode when validation fails"() {
        given:
        String memberId = null
        String domain = null
        String guid = null
        String traceId = "trace-status"

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders)

        then:
        result != null
        result.appCategoryCode != null
    }

    def "emailPasswordReqValidator validates clientId before checking memberId and domain"() {
        given:
        String memberId = "testMember"
        String domain = "testDomain"
        String guid = null
        String traceId = "trace-order"

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        httpHeaders.getHeaderString("X-ATT-ClientId") >> null

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders)

        then:
        result != null
        result.errors != null
    }

    def "emailPasswordReqValidator returns null for valid GUID even with invalid memberId and domain"() {
        given:
        String memberId = ""
        String domain = ""
        String guid = "1234567890"
        String traceId = "trace-guid-priority"

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders)

        then:
        result == null
    }

    @Unroll
    def "emailPasswordReqValidator returns error when guid is not all numeric for #scenarioName"() {
        given:
        String traceId = "trace-alpha"

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(null, null, inputGuid, httpHeaders)

        then:
        result != null
        result.errors != null

        where:
        scenarioName                | inputGuid
        "letters only"             | "abcdef"
        "alphanumeric guid"        | "guid-12345"
        "uuid with hex letters"    | "a1b2c3d4-e5f6-7890"
        "mixed alpha and numeric"  | "123abc456"
        "uppercase letters"        | "ABCDEF123"
        "hyphen separated numbers" | "1234-5678"
        "guid with spaces"         | "1234 5678"
        "guid with special chars"  | "1234@5678"
    }

    @Unroll
    def "emailPasswordReqValidator returns error when memberId exceeds 127 characters for #scenarioName"() {
        given:
        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> "trace-memberlen"
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(inputMemberId, "att.net", null, httpHeaders)

        then:
        result != null
        result.errors != null

        where:
        scenarioName           | inputMemberId
        "memberId 128 chars"   | "a" * 128
        "memberId 200 chars"   | "b" * 200
    }

    def "emailPasswordReqValidator returns null when memberId is exactly 127 characters"() {
        given:
        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> "trace-memberboundary"
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator("a" * 127, "att.net", null, httpHeaders)

        then:
        result == null
    }

    @Unroll
    def "emailPasswordReqValidator returns error when domain exceeds 30 characters for #scenarioName"() {
        given:
        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> "trace-domainlen"
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator("testMember", inputDomain, null, httpHeaders)

        then:
        result != null
        result.errors != null

        where:
        scenarioName          | inputDomain
        "domain 31 chars"     | "a" * 31
        "domain 50 chars"     | "a" * 50
    }

    def "emailPasswordReqValidator returns null when domain is exactly 30 characters"() {
        given:
        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> "trace-domainboundary"
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator("testMember", "a" * 30, null, httpHeaders)

        then:
        result == null
    }

    @Unroll
    def "emailPasswordReqValidator returns error when guid exceeds 12 characters for #scenarioName"() {
        given:
        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> "trace-guidlen"
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(null, null, inputGuid, httpHeaders)

        then:
        result != null
        result.errors != null

        where:
        scenarioName          | inputGuid
        "guid 13 digits"      | "1" * 13
        "guid 30 digits"      | "1" * 30
    }

    def "emailPasswordReqValidator returns null when guid is exactly 12 numeric characters"() {
        given:
        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> "trace-guidboundary"
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(null, null, "1" * 12, httpHeaders)

        then:
        result == null
    }

    def "emailPasswordReqValidator handles null trace ID gracefully"() {
        given:
        String memberId = null
        String domain = null
        String guid = null

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> null
        httpHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        when:
        EmailAppPasswordResponse result = emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders)

        then:
        result != null
        result.idpTraceId.startsWith("AutoGen_")
    }
}

