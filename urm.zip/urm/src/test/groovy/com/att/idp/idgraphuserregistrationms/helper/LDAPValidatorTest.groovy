package com.att.idp.idgraphuserregistrationms.helper

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import com.att.mpsys.common.utils.PropertyManager
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll

class LDAPValidatorTest extends Specification{
    PropertyManager propertyManager = Mock(PropertyManager)
    def ldapValidator = new LDAPValidator()

    HashMap npOutputHs = CommonUtil.hashMap

    def setup(){
        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')
        npOutputHs['appStatusCode'] =='0'
        PropertyManager.setProperty("MSCONFIG","blockparent-1","#universal_bozo_parent#");

    }
    def "validate should return correct hash map when input is valid"() {
        given:
        HashMap hmInput = new HashMap()
        HashMap mpsData = new HashMap()
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(hmInput, mpsData, log)

        then:
        assert result instanceof HashMap
    }

    def "populate and validate common- data should return correct hash map when input is valid"() {
        given:
        HashMap accessHashMap = new HashMap()
        HashMap inpParam = new HashMap()
        HashMap mpsData = new HashMap()
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.populateAndValidateCommonData(accessHashMap, inpParam, mpsData, log)

        then:
        assert result instanceof HashMap
    }

    def "validate parent should return correct hash map when mpsData is valid"() {
        given:
        HashMap mpsData = new HashMap()
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validateparent(mpsData, log)

        then:
        assert result instanceof HashMap
    }

    def "validate access should return correct hash map when input is valid"() {
        given:
        HashMap accessHashMap = new HashMap()
        HashMap mpsData = new HashMap()
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validateAccess(accessHashMap, mpsData, log)

        then:
        assert result instanceof HashMap
    }

    def "validate dsl should return correct hash map when input is valid"() {
        given:
        HashMap accessHashMap = new HashMap()
        HashMap mpsData = new HashMap()
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validateDSL(accessHashMap, mpsData, log)

        then:
        assert result instanceof HashMap
    }

    def "validate hsia should return correct hash map when input is valid"() {
        given:
        HashMap accessHashMap = new HashMap()
        HashMap mpsData = new HashMap()
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validateHSIA(accessHashMap, mpsData, log)

        then:
        assert result instanceof HashMap
    }

    def "populate and validate dsl specific data should return correct hash map when input is valid"() {
        given:
        HashMap accessHashMap = new HashMap()
        accessHashMap[MPSDefs.DB_CIRCUIT_ID]
        HashMap mpsData = new HashMap()
        mpsData[MPSDefs.DB_SOR_NAME] = 'MO'
        mpsData[MPSDefs.SOR_BLS] = 'N'
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.populateAndValidateDSLSpecificData(accessHashMap, mpsData, log)

        then:
        assert result instanceof HashMap
    }
    def "populate and validate dsl specific data should return correct hash map when input is valid1"() {
        given:
        HashMap accessHashMap = new HashMap()
        accessHashMap[MPSDefs.DB_CIRCUIT_ID]
        HashMap mpsData = new HashMap()
        mpsData[MPSDefs.DB_SOR_NAME] = 'MO'
        mpsData[MPSDefs.SOR_BLS] = 'N'
        mpsData[MPSDefs.SERVICES] = accessHashMap
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.populateAndValidateDSLSpecificData(accessHashMap, mpsData, log)

        then:
        assert result instanceof HashMap
    }

    def "populate and validate static data should return correct hash map when input is valid"() {
        given:
        HashMap accessHashMap = new HashMap()
        HashMap mpsData = new HashMap()
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.populateAndValidateStaticData(accessHashMap, mpsData, log)

        then:
        assert result instanceof HashMap
    }

    def "validate isdn should return correct hash map when input is valid"() {
        given:
        HashMap accessHashMap = new HashMap()
        HashMap mpsData = new HashMap()
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validateISDN(accessHashMap, mpsData, log)

        then:
        assert result instanceof HashMap
    }

    def "validate swh should return correct hash map when input is valid"() {
        given:
        HashMap hostingHashMap = new HashMap()
        hostingHashMap[MPSDefs.DB_MEMBER_STATUS_NAME] = 'Active'
        HashMap mpsData = new HashMap()
        mpsData[MPSDefs.DB_SOR_NAME] = 'MO'
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validateSWH(hostingHashMap, mpsData, log)

        then:
        assert result instanceof HashMap
    }

    def "validate wifi should return correct hash map when input is valid"() {
        given:
        HashMap wifi = new HashMap()
        HashMap mpsData = new HashMap()
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validateWIFI(wifi, mpsData, log)

        then:
        assert result instanceof HashMap
    }

    def "validate  should return member_name missing in the mpsData hashmap"() {
        given:
        HashMap wifi = new HashMap()
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        serviceHash['Active'] = new HashMap<>()
        mpsData[MPSDefs.DB_ACCESS_NAME] = 'Active'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] == 'member_name missing in the mpsData hashmap'
    }
    def "validate  should return domain_name missing in the mpsData hashmap"() {
        given:
        HashMap wifi = new HashMap()
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        serviceHash['Active'] = new HashMap<>()
        mpsData[MPSDefs.DB_ACCESS_NAME] = 'Active'
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] == 'domain_name missing in the mpsData hashmap'
    }

    def "validate  should return parent handle missing in the mpsData hashmap"() {
        given:
        HashMap wifi = new HashMap()
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        serviceHash['Active'] = new HashMap<>()
        mpsData[MPSDefs.DB_ACCESS_NAME] = 'Active'
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] == 'parent handle missing in the mpsData hashmap'
    }

    def "validate  should return full name missing in the mpsData hashmap"() {
        given:
        HashMap wifi = new HashMap()
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        serviceHash['Active'] = new HashMap<>()
        mpsData[MPSDefs.DB_ACCESS_NAME] = 'Active'
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] == 'fullname missing in the mpsData hashmap'
    }


    def "validate  should return wsPhpUrl missing in the inpParam hashmap "() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        serviceHash['Active'] = accessHash
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        mpsData[MPSDefs.DB_ACCESS_NAME] = 'Active'
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'C'

        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] == 'wsPhpUrl missing in the inpParam hashmap'
    }

    def "validate  should return wsPhpHomeDir missing in the inpParam hashmap"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        serviceHash['Active'] = accessHash
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        mpsData[MPSDefs.DB_ACCESS_NAME] = 'Active'
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'C'

        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] == 'wsPhpHomeDir missing in the inpParam hashmap'
    }

    def "validate  should return wsPhpHomeDir missing in the inpParam hashmap1"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        serviceHash['Active'] = accessHash
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        mpsData[MPSDefs.DB_ACCESS_NAME] = 'Active'
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'C'

        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result ['guserid'] =='JohnDoe@att.com'
    }

    def "validate  should return sor_id missing in the mpsData hashmap"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        accessHash[MPSDefs.DIAL_SERVICE] = 'A'
        serviceHash['A'] = accessHash

        mpsData[MPSDefs.DB_ACCESS_NAME] = 'A'
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_PREMIUM_800_IND] = MPSDefs.PREMIUM_800_IND_YES
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'C'

        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] == 'sor_id missing in the mpsData hashmap'
    }


    def "validate  should return group_status or member_status missing in the mpsData hashmap"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        accessHash[MPSDefs.DIAL_SERVICE] = 'A'
        serviceHash['A'] = accessHash

        mpsData[MPSDefs.DB_ACCESS_NAME] = 'A'
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_SOR_NAME] = 'LS'
        mpsData[MPSDefs.DB_PREMIUM_800_IND] = MPSDefs.PREMIUM_800_IND_YES
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'C'

        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] == 'group_status or member_status missing in the mpsData hashmap'
    }



    def "validate  should return SOR is BLS, access_name is one of [A,1544,I,I2] and network_profile_name is missing in MPS db"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        accessHash[MPSDefs.DIAL_SERVICE] = 'A'
        accessHash[MPSDefs.SERVICE_STATUS] = 'Enabled'
        serviceHash['A'] = accessHash

        mpsData[MPSDefs.DB_ACCESS_NAME] = 'A'
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_SOR_NAME] = 'BLS'
        mpsData[MPSDefs.DB_PREMIUM_800_IND] = MPSDefs.PREMIUM_800_IND_YES
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'C'
        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] == 'SOR is BLS, access_name is one of [A,1544,I,I2] and network_profile_name is missing in MPS db'
    }

    def "validate  should return roaming_block_ind missing in the wifi HashMap"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        HashMap hostingHash = new HashMap()
        HashMap wifiHash = new HashMap()
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        accessHash[MPSDefs.DB_NETWORK_PROFILE_NAME] = 'network'
        accessHash[MPSDefs.DIAL_SERVICE] = 'A'
        accessHash[MPSDefs.SERVICE_STATUS] = 'Enabled'
        serviceHash['A'] = accessHash
        hostingHash[MPSDefs.DB_MEMBER_STATUS_NAME] =MPSDefs.ENABLED
        serviceHash[MPSDefs.SWH_SERVICE] = hostingHash
        wifiHash[MPSDefs.DB_WIFI_SERVICE_TYPE] = 'installation'
        serviceHash[MPSDefs.WIFI_SERVICE] = wifiHash

        mpsData[MPSDefs.DB_ACCESS_NAME] = 'A'
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_SOR_NAME] = 'BLS'
        mpsData[MPSDefs.DB_PREMIUM_800_IND] = MPSDefs.PREMIUM_800_IND_YES
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'C'
        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] == 'roaming_block_ind missing in the wifi HashMap'
    }

    def "validate  should return success scenario"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        HashMap hostingHash = new HashMap()
        HashMap wifiHash = new HashMap()
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        accessHash[MPSDefs.DB_NETWORK_PROFILE_NAME] = 'network'
        accessHash[MPSDefs.DIAL_SERVICE] = 'A'
        accessHash[MPSDefs.SERVICE_STATUS] = 'Enabled'
        serviceHash['A'] = accessHash
        hostingHash[MPSDefs.DB_MEMBER_STATUS_NAME] =MPSDefs.ENABLED
        serviceHash[MPSDefs.SWH_SERVICE] = hostingHash
        wifiHash[MPSDefs.DB_WIFI_SERVICE_TYPE] = 'installation'
        wifiHash['roaming_block_ind'] = 'true'
        wifiHash[MPSDefs.DB_MEMBER_STATUS_CODE] = 'true'
        wifiHash[MPSDefs.DB_GROUP_STATUS_CODE] = 'true'
        serviceHash[MPSDefs.WIFI_SERVICE] = wifiHash

        mpsData[MPSDefs.DB_ACCESS_NAME] = 'A'
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_SOR_NAME] = 'BLS'
        mpsData[MPSDefs.DB_PREMIUM_800_IND] = MPSDefs.PREMIUM_800_IND_YES
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'C'
        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result ['guserid'] =='JohnDoe@att.com'
    }

    def "validate  should return circuit_id missing in the accessHashMap"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        HashMap hostingHash = new HashMap()
        HashMap wifiHash = new HashMap()
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        accessHash[MPSDefs.DB_NETWORK_PROFILE_NAME] = 'network'
        accessHash[MPSDefs.DIAL_SERVICE] = '1544'
        accessHash[MPSDefs.SERVICE_STATUS] = 'Enabled'
        serviceHash['1544'] = accessHash
        serviceHash['A'] = accessHash
        hostingHash[MPSDefs.DB_MEMBER_STATUS_NAME] =MPSDefs.ENABLED
        serviceHash[MPSDefs.SWH_SERVICE] = hostingHash
        wifiHash[MPSDefs.DB_WIFI_SERVICE_TYPE] = 'installation'
        wifiHash['roaming_block_ind'] = 'true'
        wifiHash[MPSDefs.DB_MEMBER_STATUS_CODE] = 'true'
        wifiHash[MPSDefs.DB_GROUP_STATUS_CODE] = 'true'
        serviceHash[MPSDefs.WIFI_SERVICE] = wifiHash

        mpsData[MPSDefs.DB_ACCESS_NAME] =MPSDefs.DSL_SERVICE
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_SOR_NAME] = 'LS'
        mpsData[MPSDefs.DB_PREMIUM_800_IND] = MPSDefs.PREMIUM_800_IND_YES
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'C'
        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] =='circuit_id missing in the accessHashMap'
    }

    def "validate  should return virtual_path missing in the accessHashMap"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        HashMap hostingHash = new HashMap()
        HashMap wifiHash = new HashMap()
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        accessHash[MPSDefs.DB_CIRCUIT_ID] = 'circuit'
        accessHash[MPSDefs.DB_NETWORK_PROFILE_NAME] = 'network'
        accessHash[MPSDefs.DIAL_SERVICE] = '1544'
        accessHash[MPSDefs.SERVICE_STATUS] = 'Enabled'
        serviceHash['1544'] = accessHash
        serviceHash['A'] = accessHash
        hostingHash[MPSDefs.DB_MEMBER_STATUS_NAME] =MPSDefs.ENABLED
        serviceHash[MPSDefs.SWH_SERVICE] = hostingHash
        wifiHash[MPSDefs.DB_WIFI_SERVICE_TYPE] = 'installation'
        wifiHash['roaming_block_ind'] = 'true'
        wifiHash[MPSDefs.DB_MEMBER_STATUS_CODE] = 'true'
        wifiHash[MPSDefs.DB_GROUP_STATUS_CODE] = 'true'
        serviceHash[MPSDefs.WIFI_SERVICE] = wifiHash

        mpsData[MPSDefs.DB_ACCESS_NAME] =MPSDefs.DSL_SERVICE
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_SOR_NAME] = 'LS'
        mpsData[MPSDefs.DB_PREMIUM_800_IND] = MPSDefs.PREMIUM_800_IND_YES
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'C'
        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] =='virtual_path missing in the accessHashMap'
    }

    def "validate  should return virtual_circuit missing in the accessHashMap"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        HashMap hostingHash = new HashMap()
        HashMap wifiHash = new HashMap()
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        accessHash[MPSDefs.DB_CIRCUIT_ID] = 'circuit'
        accessHash[MPSDefs.DB_VIRTUAL_PATH] = 'path'
        accessHash[MPSDefs.DB_NETWORK_PROFILE_NAME] = 'network'
        accessHash[MPSDefs.DIAL_SERVICE] = '1544'
        accessHash[MPSDefs.SERVICE_STATUS] = 'Enabled'
        serviceHash['1544'] = accessHash
        serviceHash['A'] = accessHash
        hostingHash[MPSDefs.DB_MEMBER_STATUS_NAME] =MPSDefs.ENABLED
        serviceHash[MPSDefs.SWH_SERVICE] = hostingHash
        wifiHash[MPSDefs.DB_WIFI_SERVICE_TYPE] = 'installation'
        wifiHash['roaming_block_ind'] = 'true'
        wifiHash[MPSDefs.DB_MEMBER_STATUS_CODE] = 'true'
        wifiHash[MPSDefs.DB_GROUP_STATUS_CODE] = 'true'
        serviceHash[MPSDefs.WIFI_SERVICE] = wifiHash

        mpsData[MPSDefs.DB_ACCESS_NAME] =MPSDefs.DSL_SERVICE
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_SOR_NAME] = 'LS'
        mpsData[MPSDefs.DB_PREMIUM_800_IND] = MPSDefs.PREMIUM_800_IND_YES
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'C'
        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] =='virtual_circuit missing in the accessHashMap'
    }

    def "validate  should return protocol_type missing from the accessHashMap"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        HashMap hostingHash = new HashMap()
        HashMap wifiHash = new HashMap()
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        accessHash[MPSDefs.DB_CIRCUIT_ID] = 'circuit'
        accessHash[MPSDefs.DB_VIRTUAL_PATH] = 'path'
        accessHash[MPSDefs.DB_VIRTUAL_CIRCUIT] = 'virtual circuit'
        accessHash[MPSDefs.DB_NETWORK_PROFILE_NAME] = 'network'
        accessHash[MPSDefs.DIAL_SERVICE] = '1544'
        accessHash[MPSDefs.SERVICE_STATUS] = 'Enabled'
        serviceHash['1544'] = accessHash
        serviceHash['A'] = accessHash
        hostingHash[MPSDefs.DB_MEMBER_STATUS_NAME] =MPSDefs.ENABLED
        serviceHash[MPSDefs.SWH_SERVICE] = hostingHash
        wifiHash[MPSDefs.DB_WIFI_SERVICE_TYPE] = 'installation'
        wifiHash['roaming_block_ind'] = 'true'
        wifiHash[MPSDefs.DB_MEMBER_STATUS_CODE] = 'true'
        wifiHash[MPSDefs.DB_GROUP_STATUS_CODE] = 'true'
        serviceHash[MPSDefs.WIFI_SERVICE] = wifiHash

        mpsData[MPSDefs.DB_ACCESS_NAME] =MPSDefs.DSL_SERVICE
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_SOR_NAME] = 'LS'
        mpsData[MPSDefs.DB_PREMIUM_800_IND] = MPSDefs.PREMIUM_800_IND_YES
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'C'
        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] =='protocol_type missing from the accessHashMap'
    }

    def "validate  should return incoming_burst missing from the accessHashMap"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        HashMap hostingHash = new HashMap()
        HashMap wifiHash = new HashMap()
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        accessHash[MPSDefs.DB_CIRCUIT_ID] = 'circuit'
        accessHash[MPSDefs.DB_VIRTUAL_PATH] = 'path'
        accessHash[MPSDefs.DB_VIRTUAL_CIRCUIT] = 'virtual circuit'
        accessHash[MPSDefs.DB_PROTOCOL_TYPE] = 'https'
        accessHash[MPSDefs.DB_NETWORK_PROFILE_NAME] = 'network'
        accessHash[MPSDefs.DIAL_SERVICE] = '1544'
        accessHash[MPSDefs.SERVICE_STATUS] = 'Enabled'
        serviceHash['1544'] = accessHash
        serviceHash['A'] = accessHash
        hostingHash[MPSDefs.DB_MEMBER_STATUS_NAME] =MPSDefs.ENABLED
        serviceHash[MPSDefs.SWH_SERVICE] = hostingHash
        wifiHash[MPSDefs.DB_WIFI_SERVICE_TYPE] = 'installation'
        wifiHash['roaming_block_ind'] = 'true'
        wifiHash[MPSDefs.DB_MEMBER_STATUS_CODE] = 'true'
        wifiHash[MPSDefs.DB_GROUP_STATUS_CODE] = 'true'
        serviceHash[MPSDefs.WIFI_SERVICE] = wifiHash

        mpsData[MPSDefs.DB_ACCESS_NAME] =MPSDefs.DSL_SERVICE
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_SOR_NAME] = 'LS'
        mpsData[MPSDefs.DB_PREMIUM_800_IND] = MPSDefs.PREMIUM_800_IND_YES
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'C'
        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] =='incoming_burst missing from the accessHashMap'
    }

    def "validate  should return incoming_burst missing from the accessHashMaps"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        HashMap hostingHash = new HashMap()
        HashMap wifiHash = new HashMap()
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        accessHash[MPSDefs.DB_CIRCUIT_ID] = 'circuit'
        accessHash[MPSDefs.DB_VIRTUAL_PATH] = 'path'
        accessHash[MPSDefs.DB_VIRTUAL_CIRCUIT] = 'virtual circuit'
        accessHash[MPSDefs.DB_PROTOCOL_TYPE] = 'https'
        accessHash[MPSDefs.DB_NETWORK_PROFILE_NAME] = 'network'
        accessHash[MPSDefs.DIAL_SERVICE] = '1544'
        accessHash[MPSDefs.SERVICE_STATUS] = 'Enabled'
        serviceHash['1544'] = accessHash
        serviceHash['A'] = accessHash
        hostingHash[MPSDefs.DB_MEMBER_STATUS_NAME] =MPSDefs.ENABLED
        serviceHash[MPSDefs.SWH_SERVICE] = hostingHash
        wifiHash[MPSDefs.DB_WIFI_SERVICE_TYPE] = 'installation'
        wifiHash['roaming_block_ind'] = 'true'
        wifiHash[MPSDefs.DB_MEMBER_STATUS_CODE] = 'true'
        wifiHash[MPSDefs.DB_GROUP_STATUS_CODE] = 'true'
        serviceHash[MPSDefs.WIFI_SERVICE] = wifiHash

        mpsData[MPSDefs.DB_ACCESS_NAME] =MPSDefs.DSL_SERVICE
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_SOR_NAME] = 'LS'
        mpsData[MPSDefs.DB_PREMIUM_800_IND] = MPSDefs.PREMIUM_800_IND_YES
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'C'
        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] =='incoming_burst missing from the accessHashMap'
    }
    def "validate  should return incoming_limit missing from the accessHashMap"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        HashMap hostingHash = new HashMap()
        HashMap wifiHash = new HashMap()
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        accessHash[MPSDefs.DB_CIRCUIT_ID] = 'circuit'
        accessHash[MPSDefs.DB_VIRTUAL_PATH] = 'path'
        accessHash[MPSDefs.DB_VIRTUAL_CIRCUIT] = 'virtual circuit'
        accessHash[MPSDefs.DB_PROTOCOL_TYPE] = 'https'

        accessHash[MPSDefs.DB_INCOMING_BURST] = 'https'

        accessHash[MPSDefs.DB_NETWORK_PROFILE_NAME] = 'network'
        accessHash[MPSDefs.DIAL_SERVICE] = '1544'
        accessHash[MPSDefs.SERVICE_STATUS] = 'Enabled'
        serviceHash['1544'] = accessHash
        serviceHash['A'] = accessHash
        hostingHash[MPSDefs.DB_MEMBER_STATUS_NAME] =MPSDefs.ENABLED
        serviceHash[MPSDefs.SWH_SERVICE] = hostingHash
        wifiHash[MPSDefs.DB_WIFI_SERVICE_TYPE] = 'installation'
        wifiHash['roaming_block_ind'] = 'true'
        wifiHash[MPSDefs.DB_MEMBER_STATUS_CODE] = 'true'
        wifiHash[MPSDefs.DB_GROUP_STATUS_CODE] = 'true'
        serviceHash[MPSDefs.WIFI_SERVICE] = wifiHash

        mpsData[MPSDefs.DB_ACCESS_NAME] =MPSDefs.DSL_SERVICE
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_SOR_NAME] = 'LS'
        mpsData[MPSDefs.DB_PREMIUM_800_IND] = MPSDefs.PREMIUM_800_IND_YES
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'C'
        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result['appInfo'] =='incoming_limit missing from the accessHashMap'
    }


    def "validate  should return ProofingEncryption_H.getDecryptedValues() returned error"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        HashMap hostingHash = new HashMap()
        HashMap wifiHash = new HashMap()
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        accessHash[MPSDefs.DB_CIRCUIT_ID] = 'circuit'
        accessHash[MPSDefs.DB_VIRTUAL_PATH] = 'path'
        accessHash[MPSDefs.DB_INCOMING_LIMIT] = '24'
        accessHash[MPSDefs.DB_VIRTUAL_CIRCUIT] = 'virtual circuit'
        accessHash[MPSDefs.DB_PROTOCOL_TYPE] = 'https'
        accessHash[MPSDefs.DB_OUTGOING_LIMIT] = '2024'
        accessHash[MPSDefs.DB_OUTGOING_BURST] = 'outgoing'

        accessHash[MPSDefs.DB_INCOMING_BURST] = 'https'

        accessHash[MPSDefs.DB_NETWORK_PROFILE_NAME] = 'network'
        accessHash[MPSDefs.DIAL_SERVICE] = '1544'
        accessHash[MPSDefs.SERVICE_STATUS] = 'Enabled'
        accessHash[MPSDefs.DB_DSLAM_TYPE] = MPSDefs.DEFAULT_DSLAM_TYPE
        serviceHash['1544'] = accessHash
        serviceHash['A'] = accessHash
        hostingHash[MPSDefs.DB_MEMBER_STATUS_NAME] =MPSDefs.ENABLED
        serviceHash[MPSDefs.SWH_SERVICE] = hostingHash
        wifiHash[MPSDefs.DB_WIFI_SERVICE_TYPE] = 'installation'
        wifiHash['roaming_block_ind'] = 'true'
        wifiHash[MPSDefs.DB_MEMBER_STATUS_CODE] = 'true'
        wifiHash[MPSDefs.DB_GROUP_STATUS_CODE] = 'true'
        serviceHash[MPSDefs.WIFI_SERVICE] = wifiHash

        mpsData[MPSDefs.DB_ACCESS_NAME] =MPSDefs.DSL_SERVICE
        mpsData[MPSDefs.DB_DSL_NET_ENCR_TYPE] = 'A'
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_SOR_NAME] = 'LS'
        mpsData[MPSDefs.DB_PREMIUM_800_IND] = MPSDefs.PREMIUM_800_IND_YES
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)
        HashMap npOutputHs = new HashMap()
        npOutputHs[CommonDefs.COMMON_APP_STATUS_CODE] =='0'


        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result!=null
    }
    def "validate  should return exception"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        HashMap hostingHash = new HashMap()
        HashMap wifiHash = new HashMap()
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        accessHash[MPSDefs.DB_CIRCUIT_ID] = 'circuit'
        accessHash[MPSDefs.DB_VIRTUAL_PATH] = 'path'
        accessHash[MPSDefs.DB_INCOMING_LIMIT] = '24'
        accessHash[MPSDefs.DB_VIRTUAL_CIRCUIT] = 'virtual circuit'
        accessHash[MPSDefs.DB_PROTOCOL_TYPE] = 'https'
        accessHash[MPSDefs.DB_OUTGOING_LIMIT] = '2024'
        accessHash[MPSDefs.DB_OUTGOING_BURST] = 'outgoing'

        accessHash[MPSDefs.DB_INCOMING_BURST] = 'https'

        accessHash[MPSDefs.DB_NETWORK_PROFILE_NAME] = 'network'
        accessHash[MPSDefs.DIAL_SERVICE] = '1544'
        accessHash[MPSDefs.SERVICE_STATUS] = 'Enabled'
        accessHash[MPSDefs.DB_DSLAM_TYPE] = MPSDefs.DEFAULT_DSLAM_TYPE
        serviceHash['1544'] = accessHash
        serviceHash['A'] = accessHash
        hostingHash[MPSDefs.DB_MEMBER_STATUS_NAME] =MPSDefs.ENABLED
        serviceHash[MPSDefs.SWH_SERVICE] = hostingHash
        wifiHash[MPSDefs.DB_WIFI_SERVICE_TYPE] = 'installation'
        wifiHash['roaming_block_ind'] = 'true'
        wifiHash[MPSDefs.DB_MEMBER_STATUS_CODE] = 'true'
        wifiHash[MPSDefs.DB_GROUP_STATUS_CODE] = 'true'
        serviceHash[MPSDefs.WIFI_SERVICE] = wifiHash

        mpsData[MPSDefs.DB_ACCESS_NAME] =MPSDefs.DSL_SERVICE
        mpsData[MPSDefs.DB_DSL_NET_ENCR_TYPE] = 'A'
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_SOR_NAME] = 'LS'
        mpsData[MPSDefs.DB_PREMIUM_800_IND] = MPSDefs.PREMIUM_800_IND_YES
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'P'

        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)

        when:

        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result!=null
    }

    def "validate  should return ban missing in the mpsData hashmap"() {
        given:
        HashMap wifi = new HashMap()
        wifi[MPSDefs.WS_PHPENABLED] ='Y'
        wifi[MPSDefs.WS_PHPURL] ='php@url.com'
        wifi[MPSDefs.WS_PHPHOMEDIR] ='php@url.com'
        HashMap mpsData = new HashMap()
        HashMap serviceHash = new HashMap()
        HashMap accessHash = new HashMap()
        HashMap hostingHash = new HashMap()
        HashMap wifiHash = new HashMap()
        accessHash[MPSDefs.DB_MEMBER_TERMINATE_DATE] = '05-09-2040 12:34:56'
        accessHash[MPSDefs.DB_CIRCUIT_ID] = 'circuit'
        accessHash[MPSDefs.DB_VIRTUAL_PATH] = 'path'
        accessHash[MPSDefs.DB_INCOMING_LIMIT] = '24'
        accessHash[MPSDefs.DB_VIRTUAL_CIRCUIT] = 'virtual circuit'
        accessHash[MPSDefs.DB_PROTOCOL_TYPE] = 'https'
        accessHash[MPSDefs.DB_OUTGOING_LIMIT] = '2024'
        accessHash[MPSDefs.DB_OUTGOING_BURST] = 'outgoing'

        accessHash[MPSDefs.DB_INCOMING_BURST] = 'https'

        accessHash[MPSDefs.DB_NETWORK_PROFILE_NAME] = 'network'
        accessHash[MPSDefs.DIAL_SERVICE] = MPSDefs.HSIA_SERVICE
        accessHash[MPSDefs.SERVICE_STATUS] = 'Enabled'
        accessHash[MPSDefs.DB_DSLAM_TYPE] = MPSDefs.DEFAULT_DSLAM_TYPE
        serviceHash[MPSDefs.HSIA_SERVICE] = accessHash
        serviceHash['A'] = accessHash
        hostingHash[MPSDefs.DB_MEMBER_STATUS_NAME] =MPSDefs.ENABLED
        serviceHash[MPSDefs.SWH_SERVICE] = hostingHash
        wifiHash[MPSDefs.DB_WIFI_SERVICE_TYPE] = 'installation'
        wifiHash['roaming_block_ind'] = 'true'
        wifiHash[MPSDefs.DB_MEMBER_STATUS_CODE] = 'true'
        wifiHash[MPSDefs.DB_GROUP_STATUS_CODE] = 'true'
        serviceHash[MPSDefs.WIFI_SERVICE] = wifiHash

        mpsData[MPSDefs.DB_ACCESS_NAME] =MPSDefs.HSIA_SERVICE
        mpsData[MPSDefs.DB_DSL_NET_ENCR_TYPE] = 'C'
        mpsData[MPSDefs.DB_MEMBER_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        mpsData[MPSDefs.DB_PARENT_NAME] = 'JohnDoe@att.com'
        mpsData[MPSDefs.DB_PARENT_DOMAIN] = 'slid.dum'
        mpsData[MPSDefs.DB_SOR_NAME] = 'LS'
        mpsData[MPSDefs.DB_PREMIUM_800_IND] = MPSDefs.PREMIUM_800_IND_YES
        mpsData[MPSDefs.DB_FULLNAME] = 'JohnDeo'
        mpsData[MPSDefs.DB_PARENT_CHILD_IND] = 'P'

        mpsData[MPSDefs.DB_ACCOUNT_TYPE] = 'consumers'
        mpsData[MPSDefs.DB_MAILHOST] = 'john@gmail.com'
        mpsData[MPSDefs.SERVICES] = serviceHash
        Logger log = LoggerFactory.getLogger(LDAPValidator.class)
        HashMap npOutputHs = new HashMap()
        npOutputHs[CommonDefs.COMMON_APP_STATUS_CODE] =='0'


        when:
        HashMap result = ldapValidator.validate(wifi, mpsData, log)

        then:
        result ['appInfo'] =='ban missing in the mpsData hashmap'
    }

    @Unroll
    def "should populate correct profile attributes for #scenarioName"() {
        given: "A valid mpsData and accessHashMap for #scenarioName"
        HashMap mpsData = new HashMap()
        HashMap accessHashMap = new HashMap()
        HashMap dialServiceHash = new HashMap()
        HashMap servicesHash = new HashMap()
        mpsData.put(MPSDefs.DB_ACCESS_NAME, accessName)
        mpsData.put(MPSDefs.DB_SOR_NAME, sorName)
        mpsData.put(MPSDefs.SERVICES, servicesHash)
        servicesHash.put(accessName, accessHashMap)
        servicesHash.put(MPSDefs.DIAL_SERVICE, dialServiceHash)
        accessHashMap.put(MPSDefs.SERVICE_STATUS, "Enabled")
        accessHashMap.put(MPSDefs.DB_NETWORK_PROFILE_NAME, accessProfile)
        dialServiceHash.put(MPSDefs.DB_NETWORK_PROFILE_NAME, dialProfile)
        Logger log = Mock(Logger)

        when: "validateAccess is called"
        HashMap result = ldapValidator.validateAccess(accessHashMap, mpsData, log)

        then: "Correct profile attributes are set"
        if (accessName == MPSDefs.DIAL_SERVICE) {
            result.get(MPSDefs.G2_DIALPROFILE) == accessProfile
        } else if (accessName == MPSDefs.DSL_SERVICE) {
            result.get(MPSDefs.G2_DSLPROFILE) == accessProfile
            result.get(MPSDefs.G2_DIALPROFILE) == dialProfile
        } else if (accessName == MPSDefs.ISDN_SERVICE || accessName == MPSDefs.ISDN2_SERVICE) {
            result.get(MPSDefs.G2_ISDNPROFILE) == accessProfile
            result.get(MPSDefs.G2_DIALPROFILE) == dialProfile
        }

        and: "Other required attributes are present"
        result.get(MPSDefs.G2_ASSOCIATEDDOMAIN) == sorName
        result.get(MPSDefs.G2_ACCESSENABLED) == CommonDefs.DEFAULT_TRUE
        result.get(MPSDefs.G2_CLASSOFSERVICE) == accessName
        result.get(MPSDefs.G2_ACCOUNTSTATUS) == "Enabled"

        where: "Different accessName and profile scenarios"
        scenarioName         | accessName              | sorName         | accessProfile | dialProfile
        "DIAL service"       | MPSDefs.DIAL_SERVICE    | "BLS"           | "dialProf"    | null
        "DSL service"        | MPSDefs.DSL_SERVICE     | "BLS"           | "dslProf"     | "dialProf"
        "ISDN service"       | MPSDefs.ISDN_SERVICE    | "BLS"           | "isdnProf"    | "dialProf"
        "ISDN2 service"      | MPSDefs.ISDN2_SERVICE   | "BLS"           | "isdn2Prof"   | "dialProf"
    }

}
