package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraphuserregistrationms.client.MPSReconnectWrapperSoapHandler
import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.ril.mpsys.reconnectwrapperrequest.v1.ReconnectWrapperRequest
import spock.lang.Specification

class ReprovisionUverseHelperTest extends Specification {

    def reprovisionUverseHelper = new ReprovisionUverseHelper();
    MPSReconnectWrapperSoapHandler<ReconnectWrapperRequest> mpsReconnectWrapperSoapHandler = Mock()

    def setup() {
        reprovisionUverseHelper.mpsReconnectWrapperSoapHandler = mpsReconnectWrapperSoapHandler
    }

    def "test success"() {
        given:
        SyncUserProfileRequest reprovisionUverseRequest = new SyncUserProfileRequest()
        reprovisionUverseRequest.transactionName = 'ReprovisionUverse'
        reprovisionUverseRequest.callingSystemId = 'ATLAS-UI'
        reprovisionUverseRequest.unvalidatedDomain = 'domain'
        reprovisionUverseRequest.unvalidatedHandle = 'MPS'
        reprovisionUverseRequest.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'

        HashMap<String, Object> hmSoapHelperResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        mpsReconnectWrapperSoapHandler.invokeAPI(_) >> hmSoapHelperResponse
        when:
        Map<String,Object> hmRes = reprovisionUverseHelper.disconnectReconnect(reprovisionUverseRequest)
        then:
        hmRes[CommonDefs.COMMON_APP_CATEGORY_CODE] == '0'
    }


    def "test null result"(){
        given:
        SyncUserProfileRequest reprovisionUverseRequest = new SyncUserProfileRequest()
        reprovisionUverseRequest.transactionName = 'ReprovisionUverse'
        reprovisionUverseRequest.callingSystemId = 'ATLAS-UI'
        reprovisionUverseRequest.unvalidatedDomain = 'domain'
        reprovisionUverseRequest.unvalidatedHandle = 'MPS'
        reprovisionUverseRequest.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
        mpsReconnectWrapperSoapHandler.invokeAPI(_) >> null
        when:
        Map<String,Object> hmRes = reprovisionUverseHelper.disconnectReconnect(reprovisionUverseRequest)
        then:
        hmRes[CommonDefs.COMMON_APP_INFO] == 'Response from SyncDestinationRILMPS is NULL'
    }
}
