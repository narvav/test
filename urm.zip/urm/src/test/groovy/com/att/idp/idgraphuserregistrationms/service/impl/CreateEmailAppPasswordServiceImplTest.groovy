package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.helper.CreateEmailAppPasswordHelper
import com.att.idp.idgraphuserregistrationms.resource.request.CreateEmailAppPasswordRequest
import com.att.idp.idgraphuserregistrationms.resource.response.CreateEmailAppPasswordResponse
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap
import spock.lang.Specification

import java.lang.reflect.Field

class CreateEmailAppPasswordServiceImplTest extends Specification {

	private CreateEmailAppPasswordHelper createEmailAppPasswordHelper
	private CreateEmailAppPasswordServiceImpl serviceUnderTest

	void setup() {
		createEmailAppPasswordHelper = Mock(CreateEmailAppPasswordHelper)
		serviceUnderTest = new CreateEmailAppPasswordServiceImpl()
		setField(serviceUnderTest, "createEmailAppPasswordHelperObj", createEmailAppPasswordHelper)
	}

	def "should pass transaction id and caller id to helper"() {
		given: "a valid request and request headers"
		CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
		request.setGuid("12345")
		request.setPasswordName("imap")
		request.setIdpTraceId("trace123:trace123:0:0")

		MultivaluedMap<String, String> requestHeaders = new MultivaluedHashMap<>()
		requestHeaders.add("X-ATT-ClientId", "IDMPROFILE")

		Map<String, Object> helperResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS")
		helperResponse.put(CommonDefs.PASSWORD, "clear-secret")

		when: "the service delegates to the helper"
		CreateEmailAppPasswordResponse response = serviceUnderTest.createEmailAppPassword(request, requestHeaders)

		then: "the helper receives the derived transaction id and caller id"
		1 * createEmailAppPasswordHelper.createEmailAppPassword({ Map<String, Object> helperInput ->
			helperInput.get(CommonDefs.GUID) == "12345" &&
					helperInput.get(CommonDefs.PASSWORD_NAME) == "imap" &&
					helperInput.get(CommonDefs.TRANSACTION_ID) == "trace123" &&
					helperInput.get(CommonDefs.CALLING_SYSTEM_ID) == "IDMPROFILE"
		}) >> helperResponse
		0 * _

		and: "the service maps the helper response"
		response != null
		response.getIdpTraceId() == "trace123:trace123:0:0"
		response.getPassword() == "clear-secret"
	}

	private static void setField(Object target, String fieldName, Object value) {
		Field field = target.getClass().getDeclaredField(fieldName)
		field.accessible = true
		field.set(target, value)
	}
}

