package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.GlobalConfig
import com.att.idp.QAIntegration.Helpers.ApiHelpers
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Tag
import spock.lang.Unroll

@Slf4j
@Tag("Regression")
@Tag("IdGraphUserRegistrationMs")
@IgnoreIf({ !GlobalConfig.isTestCaseEnabled("RegisterLSUserITSpec") })
class RegisterLSUserITSpec extends TestBase {

    @Unroll
    def "RegisterLSUser negative - #scenario.name"() {
        setup:
        TestBase.setTestName("RegisterLSUser Negative — ${scenario.name}")
        TestBase.logStep("POST ${GlobalConfig.Endpoints.REGISTER_LS_USER} — ${scenario.name}")

        Map<String, Object> payload = [:]
        if (scenario.ban != null) payload.ban = scenario.ban
        if (scenario.memberId != null) payload.memberId = scenario.memberId
        if (scenario.domain != null) payload.domain = scenario.domain

        when: "RegisterLSUser API is called with invalid parameters"
        Response response = ApiHelpers.registerLSUser(payload, "IDP")

        then: "No mock interactions — real HTTP call"
        0 * _

        and: "API returns expected error response"
        def expectedStatuses = scenario.expectedStatus instanceof List ? scenario.expectedStatus : [scenario.expectedStatus]
        assert response.statusCode() in expectedStatuses :
                "Expected HTTP ${expectedStatuses} but got: ${response.statusCode()}"

        where:
        scenario << getNegativeScenarios()
    }

    static List getNegativeScenarios() {
        GlobalConfig.getTestData()?.registerLSUser?.negative ?: []
    }
}
