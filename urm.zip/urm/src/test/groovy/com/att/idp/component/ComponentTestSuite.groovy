package com.att.idp.component

import org.junit.platform.suite.api.SelectClasses
import org.junit.platform.suite.api.Suite
import spock.lang.Specification
/*
 * All the component test classes must be registered in this suite class,
 * otherwise that component test class will be ignored.
 */
@Suite
@SelectClasses([
	UserRegistrationCompTest.class,
	QueryByIPEligibilityCompTest.class,
	RegisterLSUserCompTest.class,
	UpdateUnifiedTOSCompTest.class,
	VerifyExistingMemberEligibilityCompTest.class,
	RetriggerQARCompTest.class,
	WirelessAutoRegCompTest.class,
	AutoGenTempAIDCompTest.class,
	PreAccountRegCompTest.class,
	ReprovisionUverseCompTest.class,
	ValidateAndSyncG2CompTest.class,
    HaloSyncOperationCompTest.class,
		G2SyncOperationCompTest.class,
		SyncUserProfileCompTest.class,
		EmailAppPasswordCompTest.class])
class ComponentTestSuite extends Specification {
}