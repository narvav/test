package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.GlobalConfig
import com.att.idp.QAIntegration.Helpers.ApiHelpers
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Tag
import spock.lang.Unroll

@Slf4j
@Tag("Regression")
@Tag("IdGraphUserRegistrationMs")
@IgnoreIf({ !GlobalConfig.isTestCaseEnabled("EmailAppPasswordITSpec") })
class EmailAppPasswordITSpec extends TestBase {

    @Unroll
    def "EmailAppPassword negative - #scenario.name"() {
        setup:
        TestBase.setTestName("EmailAppPassword Negative — ${scenario.name}")
        String operation = scenario.operation ?: "list"

        when: "EmailAppPassword API is called with invalid parameters"
        Response response

        if (operation == "list") {
            TestBase.logStep("GET ${GlobalConfig.Endpoints.LIST_EMAIL_APP_PASSWORD} — ${scenario.name}")
            response = ApiHelpers.listEmailAppPassword(
                    scenario.memberId as String ?: "",
                    scenario.domain as String ?: "",
                    null, "IDP"
            )
        } else if (operation == "create") {
            TestBase.logStep("POST ${GlobalConfig.Endpoints.CREATE_EMAIL_APP_PASSWORD} — ${scenario.name}")
            Map<String, Object> payload = [:]
            if (scenario.memberId != null) payload.memberId = scenario.memberId
            if (scenario.domain != null) payload.domain = scenario.domain
            if (scenario.applicationName != null) payload.applicationName = scenario.applicationName
            response = ApiHelpers.createEmailAppPassword(payload, "IDP")
        } else {
            TestBase.logStep("DELETE ${GlobalConfig.Endpoints.DELETE_EMAIL_APP_PASSWORD} — ${scenario.name}")
            Map<String, Object> payload = [:]
            if (scenario.memberId != null) payload.memberId = scenario.memberId
            if (scenario.domain != null) payload.domain = scenario.domain
            response = ApiHelpers.deleteEmailAppPassword(payload, "IDP")
        }

        then: "No mock interactions — real HTTP call"
        0 * _

        and: "API returns expected error response"
        def expectedStatuses = scenario.expectedStatus instanceof List ? scenario.expectedStatus : [scenario.expectedStatus]
        assert response.statusCode() in expectedStatuses :
                "Expected HTTP ${expectedStatuses} but got: ${response.statusCode()}"

        where:
        scenario << getNegativeScenarios()
    }

    static List getNegativeScenarios() {
        GlobalConfig.getTestData()?.emailAppPassword?.negative ?: []
    }
}
