package com.att.idp.component

import com.att.idp.idgraphuserregistrationms.client.MPSSyncDestinationSoapHandler
import com.att.idp.idgraph.extclient.haloc.service.HaloCService
import com.att.idp.idgraph.extclient.haloc.model.GetUserResponse
import com.att.idp.idgraph.extclient.model.ExtClientResponse
import com.att.idp.idgraph.extclient.yahoo.service.YahooService
import com.att.idp.idgraph.extclient.yahoo.model.GetAccountAttributesResponse
import com.att.idp.idgraph.extclient.yahoo.model.CreateAccountResponse
import com.att.idp.idgraph.extclient.yahoo.model.SetAccountAttributesResponse
import com.att.idp.idgraph.extclient.db.service.TworkitemService
import com.att.idp.idgraphuserregistrationms.helper.ConsolidatedProfileHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetSlidInfoDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetInfoByMaskDBHelper
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.hamcrest.CoreMatchers
import org.spockframework.spring.SpringBean
import spock.lang.PendingFeature
import org.springframework.dao.DataAccessException
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.transaction.PlatformTransactionManager
import org.springframework.ws.soap.SoapMessage
import org.springframework.ws.soap.client.SoapFaultClientException

import javax.swing.Spring

import static org.hamcrest.Matchers.equalTo

class SyncUserProfileCompTest  extends CompTestBase {

    private String uri = '/userprofile/sync'


    @SpringBean
    PlatformTransactionManager transactionManager = Mock()

    private Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<String, String>()
        headers['Content-Type'] = 'application/json'
        headers['X-ATT-ClientId'] ='IDP'
        headers['idp-trace-id'] = 'cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0'
        return headers
    }

    private String halocReq(String userId, String domain) {
        return '{"userId":"'+userId+'","domain":"'+domain+'","destination":"HALOC","agentId":"ag1"}'
    }

    private GetUserResponse buildHaloAbsent() {
        GetUserResponse r = new GetUserResponse()
        r.setAppStatusCode("0")
        r.setAppStatusMsg("SUCCESS")
        return r
    }
    private GetUserResponse buildHaloPresent(String handle, String domain) {
        GetUserResponse r = new GetUserResponse()
        r.setHandle(handle)
        r.setDomain(domain)
        r.setAppStatusCode("0")
        r.setAppStatusMsg("SUCCESS")
        return r
    }
    private GetUserResponse buildHaloErrMemberNotFound() {
        GetUserResponse r = new GetUserResponse()
        r.setAppStatusCode("121")
        r.setAppStatusMsg("ERR_MEMBER_ID_NOT_FOUND")
        return r
    }
    private ExtClientResponse successResp() {
        ExtClientResponse e = new ExtClientResponse()
        e.setAppStatusCode("0")
        e.setAppInfo("SUCCESS")
        return e
    }
    private HashMap<String,Object> dbSuccess(String handle,String domain, boolean slidDomain=false, boolean includePortal=true) {
        HashMap<String,Object> profile = new HashMap<>()
        profile.put(CErrorDefs.COMMON_APP_STATUS_CODE, "0")
        profile.put(CErrorDefs.COMMON_APP_INFO, "SUCCESS")
        profile.put(MPSDefs.DB_MEMBER_NAME, handle)
        profile.put(MPSDefs.DB_DOMAIN_NAME, domain)
        HashMap<String,Object> services = new HashMap<>()
        if(includePortal){
            HashMap<String,Object> portal = new HashMap<>()
            portal.put(MPSDefs.SERVICE_STATUS, MPSDefs.ENABLED)
            portal.put(MPSDefs.DB_SERVICE_ID, "12")
            portal.put(MPSDefs.DB_SOR_NAME, "BLS")
            services.put("PORTAL", portal)
        }
        profile.put(CommonDefs.SERVICES, services)
        // For SLID domain wrap under slidInfo key
        if(slidDomain){
            HashMap<String,Object> wrapper = new HashMap<>()
            wrapper.put(CErrorDefs.COMMON_APP_STATUS_CODE, "0")
            wrapper.put(CErrorDefs.COMMON_APP_INFO, "SUCCESS")
            wrapper.put("slidInfo", profile)
            return wrapper
        }
        return profile
    }
    private HashMap<String,Object> dbNotFound() {
        HashMap<String,Object> nf = new HashMap<>()
        nf.put(CErrorDefs.COMMON_APP_STATUS_CODE, "121")
        nf.put(CErrorDefs.COMMON_APP_INFO, "User not found with input access id.")
        return nf
    }

    def "wireless auto reg success"() {
        given:
        String req = '{\r\n' + '    "userId": "dgeurts6571@att.net",\r\n' +
        '    "domain": "att.net",\r\n' + '    "destination": "HALOC",\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'
        HashMap hmSoapHelperResponse =  CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        mpsSyncDestinationSoapHandler.invokeAPI(_) >> hmSoapHelperResponse
        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(200)
                .body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
                .body("appStatusCode", CoreMatchers.equalTo("0"))
                .body("appInfo", CoreMatchers.containsString("Success"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    def "wireless auto reg userId invalid input"() {
        given:
        String req = '{\r\n' + '    "userId": "",\r\n' +
                '    "domain": "att.net",\r\n' + '    "destination": "HALOC",\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(400)
                .body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", CoreMatchers.equalTo("100"))
                .body("appInfo", CoreMatchers.containsString("userId length is invalid"))
                .body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_100"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }


    def "wireless auto destination invalid value"() {
        given:
        String req = '{\r\n' + '    "userId": "dgeurts6571@att.net",\r\n' +
                '    "domain": "att.net",\r\n' + '    "destination": "IDP",\r\n' +
                '    "source": "IDP",\r\n' + '    "isExternalCall": "Y",\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'
        HashMap invalidDestinationResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, 'Invalid Sync between Source/Destination')
        mpsSyncDestinationSoapHandler.invokeAPI(_) >> invalidDestinationResponse

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(400)
                .body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", CoreMatchers.equalTo("100"))
                .body("appInfo", CoreMatchers.containsString("Invalid Sync between Source/Destination"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    def "wireless auto destination exception from soap call "() {

        given:
        Exception ex = new Exception(' Exception thrown')
        String req = '{\r\n' + '    "userId": "dgeurts6571@att.net",\r\n' +
                '    "domain": "att.net",\r\n' + '    "destination": "HALOC",\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'
        mpsSyncDestinationSoapHandler.invokeAPI(_) >> { throw ex }
        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(500)
                .assertThat().body("appStatusMsg", equalTo("ERR_SYS_APPL"))
                .assertThat().body("appStatusCode", equalTo("602"))
                 }


    def "wireless auto destination SoapFaultClientException from soap call "() {

        given:

        String req = '{\r\n' + '    "userId": "dgeurts6571@att.net",\r\n' +
                '    "domain": "att.net",\r\n' + '    "destination": "HALOC",\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'
        mpsSyncDestinationSoapHandler.invokeAPI(_) >> { throw new SoapFaultClientException(_ as SoapMessage) }
        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(500)
                .assertThat().body("appStatusMsg", equalTo("ERR_SYS_APPL"))
                .assertThat().body("appStatusCode", equalTo("602"))
    }

    def "haloc add path when halo user absent"() {
        given:
        String reqJson = halocReq("newuser","att.net")
        HashMap slidInfo = readJsonFileToMap("mockResponse/SlidInfo.json") as HashMap
        getInfoByMaskDBHelper.getInfoByMask(_ as HashMap) >> slidInfo
        featureManager.isEnabled(_)>>true
        GetUserResponse haloAbsent = buildHaloAbsent()

        1 * haloCService.getUser(_ as Object) >> haloAbsent
        1 * haloCService.addMember(_ as Object) >> successResp()
        1 * haloCService.updateAliasList(_ as Object) >> successResp()
        0 * getSlidInfoDBHelper.getSlidInfo(_)

        expect:
        givenBaseSpec().headers(getHeaders()).body(reqJson).when().post(uri).then().statusCode(200)
                .body("appStatusCode", CoreMatchers.equalTo("0"))
                .body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
    }

    def "haloc delete path when mps missing halo present"() {
        given:
        String reqJson = halocReq("deluser","att.net")
        featureManager.isEnabled(_)>>true
        // MPS not found
        getInfoByMaskDBHelper.getInfoByMask(_ as HashMap) >> dbNotFound()
        GetUserResponse haloPresent = buildHaloPresent("deluser","att.net")
        1 * haloCService.getUser(_ as Object) >> haloPresent
        1 * haloCService.deleteUser(_ as Object) >> successResp()
        0 * haloCService.addMember(_)

        expect:
        givenBaseSpec().headers(getHeaders()).body(reqJson).when().post(uri).then().statusCode(200)
                .body("appStatusCode", CoreMatchers.equalTo("0"))
    }

    def "haloc both systems missing returns 121"() {
        given:
        String reqJson = halocReq("absentuser","att.net")
        featureManager.isEnabled(_)>>true
        getInfoByMaskDBHelper.getInfoByMask(_ as HashMap) >> dbNotFound()
        GetUserResponse haloAbsent = buildHaloAbsent()
        1 * haloCService.getUser(_ as Object) >> haloAbsent
        0 * haloCService.addMember(_)
        0 * haloCService.deleteUser(_)

        expect:
        givenBaseSpec().headers(getHeaders()).body(reqJson).when().post(uri).then().statusCode(404)
                .body("appStatusCode", CoreMatchers.equalTo("121"))
    }

    def "haloc ghost iptv synthetic success"() {
        given:
        String reqJson = halocReq("sbciptv_999","att.net")
        featureManager.isEnabled(_)>>true
        // MPS success but no IPTV service (services map empty) triggers ghost path when HALO returns member not found.
        getInfoByMaskDBHelper.getInfoByMask(_ as HashMap) >> dbSuccess("sbciptv_999","att.net", false, false)
        GetUserResponse haloErrNotFound = buildHaloErrMemberNotFound()
        2 * haloCService.getUser(_ as Object) >> haloErrNotFound
        0 * haloCService.addMember(_)
        0 * haloCService.deleteUser(_)

        expect:
        givenBaseSpec().headers(getHeaders()).body(reqJson).when().post(uri).then().statusCode(200)
                .body("appStatusCode", CoreMatchers.equalTo("0"))
                .body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
    }

    def "haloc profile and services diff triggers updateMember and updateServiceList"() {
        given:
        featureManager.isEnabled(_)>>true
        String reqJson = halocReq("diffuser","att.net")
        HashMap<String,Object> dbProf = dbSuccess("diffuser","att.net", false, true)
        dbProf.put(MPSDefs.DB_PASSWORD_DIRTY, "Y")
        dbProf.put(MPSDefs.DB_USER_LOCK_LEVEL, "3")
        getInfoByMaskDBHelper.getInfoByMask(_ as HashMap) >> dbProf
        GetUserResponse haloPresent = buildHaloPresent("diffuser","att.net")
        haloPresent.setAppStatusCode("0")
        haloPresent.setAppStatusMsg("SUCCESS")
        haloSyncHelper.compareServiceData(_, _ as HashMap, _, _, _) >> { it[1] }
        haloSyncHelper.hasNonEmptyServices(_) >> true
        1 * haloCService.getUser(_ as Object) >> haloPresent
        1 * haloCService.updateMember(_ as Object) >> successResp()
        1 * haloCService.updateServiceList(_ as Object) >> successResp()
        0 * haloCService.addMember(_)
        0 * haloCService.deleteUser(_)

        expect:
        givenBaseSpec().headers(getHeaders()).body(reqJson).when().post(uri).then().statusCode(200)
                .body("appStatusCode", CoreMatchers.equalTo("0"))
    }

    def "SyncCCR success"() {
        given:
        String req = '{\r\n' + '    "userId": "dgeurts6571@att.net",\r\n' +
                '    "domain": "att.net",\r\n' + '    "destination": "CCR",\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'
        HashMap memberResult =  CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        memberResult.put(MPSDefs.DB_MEMBER_NUM, "12334")
        getMemberServicesDBHelper.getMemberServices(_) >> memberResult
        jdbcTemplate.update(_ as String, _, _) >> 1

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(200)
                .body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
                .body("appStatusCode", CoreMatchers.equalTo("0"))
                .body("appInfo", CoreMatchers.containsString("SUCCESS"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    def "SyncCCR success with guid"() {
        given:
        String req = '{\r\n' + '    "guid": "6571",\r\n' +
                 '   "destination": "CCR",\r\n' +
                ' "syncCCRMemberTables": ["member"],\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'
        HashMap memberResult =  CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        memberResult.put(MPSDefs.DB_MEMBER_NUM, "12334")
        getMemberServicesDBHelper.getMemberServices(_) >> memberResult
        jdbcTemplate.update(_ as String, _, _) >> 1

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(200)
                .body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
                .body("appStatusCode", CoreMatchers.equalTo("0"))
                .body("appInfo", CoreMatchers.containsString("SUCCESS"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    def "SyncCCR success when no record found"() {
        given:
        String req = '{\r\n' + '    "userId": "dgeurts6571@att.net",\r\n' +
                '    "domain": "att.net",\r\n' + '    "destination": "CCR",\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'
        Map<String, Object> expectedSuccess = CommonErrorMap.makeCategoryMap(MPSDefs.REC_NOT_FOUND_NUM, CErrorDefs.ERR_REC_NOT_FOUND_MSG)
        getMemberServicesDBHelper.getMemberServices(_) >> expectedSuccess
        jdbcTemplate.update(_ as String, _, _) >> 1

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(404)
                .body("appStatusMsg", CoreMatchers.equalTo("ERR_USER_NOT_FOUND"))
                .body("appStatusCode", CoreMatchers.equalTo("121"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    def "SyncCCR success when throw error"() {
        given:
        String req = '{\r\n' + '    "userId": "dgeurts6571@att.net",\r\n' +
                '    "domain": "att.net",\r\n' + '    "destination": "CCR",\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'
        getMemberServicesDBHelper.getMemberServices(_) >> {throw new Exception("DB down")}

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(500)
                .body("appStatusMsg", CoreMatchers.equalTo("ERR_SYS_APPL"))
                .body("appStatusCode", CoreMatchers.equalTo("602"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    def "SyncCCR success when db exception thrown"() {
        given:
        String req = '{\r\n' + '    "userId": "dgeurts6571@att.net",\r\n' +
                '    "domain": "att.net",\r\n' + '    "destination": "CCR",\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'

        jdbcTemplate.update(_ as String, _, _) >>  {throw new Exception("DB down"){}}

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(500)
                .body("appStatusMsg", CoreMatchers.equalTo("ERR_SYS_APPL"))
                .body("appStatusCode", CoreMatchers.equalTo("602"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    // ====== SyncCG Tests ======

    def "SyncCG reject when userId and domain provided"() {
        given:
        String req = '{\r\n' + '    "userId": "dgeurts6571@att.net",\r\n' +
                '    "domain": "att.net",\r\n' + '    "destination": "CG",\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(400)
                .body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", CoreMatchers.equalTo("100"))
                .body("appInfo", CoreMatchers.containsString("CG destination only supports ban"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    def "SyncCG Failure with guid"() {
        given:
        String req = '{\r\n' + '    "guid": "6571",\r\n' +
                '    "destination": "CG",\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(400)
                .body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", CoreMatchers.equalTo("100"))
                .body("appInfo", CoreMatchers.containsString("CG destination only supports ban"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    def "SyncCG success with ban"() {
        given:
        String req = '{\r\n' + '    "ban": "0007556",\r\n' +
                '    "destination": "CG",\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'
        HashMap cgResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
         jdbcTemplate.update(_, _, _)>>1;
        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(200)
                .body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
                .body("appStatusCode", CoreMatchers.equalTo("0"))
                .body("appInfo", CoreMatchers.containsString("SUCCESS"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    def "SyncCG reject when ban missing"() {
        given:
        String req = '{\r\n' + '    "destination": "CG",\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(400)
                .body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", CoreMatchers.equalTo("100"))
                .body("appInfo", CoreMatchers.containsString("Either ban, guid OR userId/domain must be present"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    def "SyncCG invalid input missing required field"() {
        given:
        String req = '{\r\n' + '    "ban": "",\r\n' +
                '    "destination": "CG",\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(400)
                .body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", CoreMatchers.equalTo("100"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    def "SyncCG exception ban must be numeric"() {
        given:
        Exception ex = new Exception('Exception thrown from CG')
        String req = '{\r\n' + '    "ban": "VD0007556",\r\n' +
                '    "destination": "CG",\r\n' +
                '    "agentId": "ak1568"\r\n' + '}'

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(400)
                .body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", CoreMatchers.equalTo("100"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    // ====== SyncG2LDAP Tests ======

    def "SyncG2LDAP success with handle and domain"() {
        given:
        String req = '{"userId":"testuser","domain":"att.net","destination":"G2LDAP","agentId":"ag1"}'
        featureManager.isEnabled(_) >> true
        getInfoByMaskDBHelper.getInfoByMask(_ as HashMap) >> dbSuccess("testuser", "portal.att.net")

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(200)
                .body("appStatusCode", CoreMatchers.equalTo("0"))
                .body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    def "SyncG2LDAP success with guid"() {
        given:
        String req = '{"guid":"12345","destination":"G2LDAP","agentId":"ag1"}'
        featureManager.isEnabled(_) >> true
        getInfoByMaskDBHelper.getInfoByMask(_ as HashMap) >> dbSuccess("testuser", "portal.att.net")

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(200)
                .body("appStatusCode", CoreMatchers.equalTo("0"))
                .body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    def "SyncG2LDAP success with ban"() {
        given:
        String req = '{"ban":"1234567","destination":"G2LDAP","agentId":"ag1"}'
        featureManager.isEnabled(_) >> true
        getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> dbSuccess("testuser", "portal.att.net")

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(200)
                .body("appStatusCode", CoreMatchers.equalTo("0"))
                .body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    def "SyncG2LDAP reject when ban provided with YAHOO destination"() {
        given:
        String req = '{"ban":"1234567","destination":"YAHOO","agentId":"ag1"}'

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(400)
                .body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", CoreMatchers.equalTo("100"))
                .body("appInfo", CoreMatchers.containsString("BAN not valid for Sync to YAHOO or HALOC/CCR destinations"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

    def "SyncG2LDAP reject when no identifier provided"() {
        given:
        String req = '{"destination":"G2LDAP","agentId":"ag1"}'

        expect:
        givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(400)
                .body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", CoreMatchers.equalTo("100"))
                .body("appInfo", CoreMatchers.containsString("Either ban, guid OR userId/domain must be present"))
                .body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
    }

}
