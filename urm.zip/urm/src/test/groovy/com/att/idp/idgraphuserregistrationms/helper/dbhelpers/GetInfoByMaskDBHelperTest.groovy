package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import com.att.common.validators.SecurityQuestionValidation
import com.att.common.validators.ServiceValidation
import com.att.common.validators.StatusValidation
import com.att.idp.idgraphuserregistrationms.helper.voltage.ProcessVoltageHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import com.att.mpsys.common.utils.PropertyManager
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import spock.lang.Specification

class GetInfoByMaskDBHelperTest extends Specification {

    def objGetInfoByMaskDBHelper

    JdbcTemplate jdbcTemplate = Mock(JdbcTemplate)
    JdbcTemplate jdbcTemplate1 = Mock(JdbcTemplate)
    ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)

    DBHelper oDBHelper = Mock(DBHelper)

    StatusValidation objStatusValidation = Mock(StatusValidation)

    ProcessVoltageHelper oProcessVoltageHelper = Mock(ProcessVoltageHelper)

    ServiceValidation objServiceValidation = Mock(ServiceValidation)

    SecurityQuestionValidation objSecurityQuestionValidation = Mock(SecurityQuestionValidation)

    EmailAppPasswordDBHelper oEmailAppPasswordDBHelper = Mock(EmailAppPasswordDBHelper)

    GetMemberRolesDBHelper oGetMemberRolesDBHelper = Mock(GetMemberRolesDBHelper)
    FraudLockDBHelper oFraudLockDBHelper = Mock(FraudLockDBHelper)
    MemberServiceAttributeDBHelper oGetMemSvcAttr = Mock(MemberServiceAttributeDBHelper)

    HashMap<String, Object> hmResponse = null
    HashMap<String, Object> hmInput = new HashMap<String, Object>()
    HashMap<String, Object> hmGetInfoInp = new HashMap<String, Object>()
    HashMap<String, Object> hmQueryResponse = CommonUtil.hashMap
    HashMap<String, Object> resultHashSuccess = CommonUtil.hashMap

    List<Object> objectList = null
    List<Object> objectList1 = null
    List<Map<String, Object>> alQueryResponse = new ArrayList()
    List alQueryresponse = new ArrayList()
    List alQueryAllResponse2 = new ArrayList()
    ArrayList alDataMasks = new ArrayList()

    String stAppStatusMsg
    String sFinalQuery = null
    String dynSql
    Logger logger = null

    private static String queryForServiceNotEcommUverse = ''' SELECT portal.portal_provider, memService.instance_id, TO_CHAR(memService.pending_disconnect_date, \''
			+ dateFormat
			+ "') AS pending_disconnect_date, memService.member_num AS memService_member_num, memService.service_id AS service_id, "
			+ " memService.member_status AS member_status_code, memService.group_status AS group_status_code, "
			+ " memService.nickname as service_nickname, "
			+ " memService.default_account, TO_CHAR(memService.date_default_est, '" + dateFormat
			+ "') AS date_default_est, memService.cpni_impacted, TO_CHAR(memService.terminate_date, '" + dateFormat
			+ "') AS terminate_date, TO_CHAR(memService.create_date, '" + dateFormat
			+ "') AS create_date, TO_CHAR(memService.last_modified, '" + dateFormat
			+ "') AS last_modified, memService.last_modified_by AS last_modified_by, memService.sor_id, "
			+ " memService.sor_invariant_id, iptv.portal_svc_provider as portal_svc_provider, " + " servassoc.sor_id1, "
			+ " nvl(servassoc.sor_invariant_id1, '--NULL--') as sor_invariant_id1, " + " servassoc.sor_id2, "
			+ " nvl(servassoc.sor_invariant_id2, '--NULL--') as sor_invariant_id2, "
			+ " servassoc.assigned_by as asso_assigned_by, servassoc.last_modified_by as asso_last_modified_by, "
			+ " TO_CHAR(servassoc.create_date, '" + dateFormat + "') AS asso_create_date, "
			+ " TO_CHAR(servassoc.last_modified, '" + dateFormat
			+ "') AS asso_last_modified, portal.plite_ind, memService.parent_sor_id, memService.parent_sor_invariant_id, "
			+ " memService.uverse_service_ind, memService.owned_by, memService.unification_pending " + ""
			+ " FROM MEMBERSERVICE memService, PORTALUSER portal, IPTVUSER iptv, serviceassociation servassoc "
			+ " WHERE " + " memService.service_id = portal.service_id (+) "
			+ " AND memService.member_num = portal.member_num (+) "
			+ "	AND memService.member_num = iptv.member_num(+) AND memService.service_id = iptv.service_id(+) "
			+ " AND servassoc.sor_id1(+) = memService.sor_id AND servassoc.sor_invariant_id1(+) = memService.sor_invariant_id "
			+ " AND memService.member_num = ? "''';

    private static String queryForServiceEcommUverse = '''' SELECT memService.instance_id, TO_CHAR(memService.pending_disconnect_date, \''
			+ dateFormat
			+ "') AS pending_disconnect_date, memService.member_num AS memService_member_num, memService.service_id AS service_id, "
			+ " memService.member_status AS member_status_code, memService.group_status AS group_status_code, "
			+ " memService.nickname as service_nickname, "
			+ " memService.default_account, TO_CHAR(memService.date_default_est, '" + dateFormat
			+ "') AS date_default_est, memService.cpni_impacted, TO_CHAR(memService.terminate_date, '" + dateFormat
			+ "') AS terminate_date, TO_CHAR(memService.create_date, '" + dateFormat
			+ "') AS create_date, TO_CHAR(memService.last_modified, '" + dateFormat
			+ "') AS last_modified, memService.last_modified_by AS last_modified_by, "
			+ " memService.sor_id, memService.sor_invariant_id, memService.parent_sor_id, memService.parent_sor_invariant_id, "
			+ " memService.uverse_service_ind, memService.owned_by, memService.unification_pending " + ""
			+ " FROM  MEMBERSERVICE memService " + " WHERE " + " memService.member_num = ? "''';

    def setup() {
        PropertyManager.setProperty("MSCONFIG", "GENERIC_PASSWORD_ENCRYPTION_TYPE",null);
        objGetInfoByMaskDBHelper = new GetInfoByMaskDBHelper()
        objGetInfoByMaskDBHelper.jdbcTemplate = jdbcTemplate
        objGetInfoByMaskDBHelper.jdbcTemplate1 = jdbcTemplate1
        objGetInfoByMaskDBHelper.errorMetricHandler = errorMetricHandler
        objGetInfoByMaskDBHelper.oDBHelper = oDBHelper
        objGetInfoByMaskDBHelper.objServiceValidation = objServiceValidation
        objGetInfoByMaskDBHelper.objStatusValidation = objStatusValidation
        objGetInfoByMaskDBHelper.oProcessVoltageHelper = oProcessVoltageHelper
        objGetInfoByMaskDBHelper.oMPSDB_EmailAppPassword_H = oEmailAppPasswordDBHelper
        objGetInfoByMaskDBHelper.oMPSDB_GetMemberRoles_H = oGetMemberRolesDBHelper
        objGetInfoByMaskDBHelper.objSecurityQuestionValidation = objSecurityQuestionValidation
        objGetInfoByMaskDBHelper.oFraudLockDBHelper = oFraudLockDBHelper
        objGetInfoByMaskDBHelper.oGetMemSvcAttr = oGetMemSvcAttr
        logger = LoggerFactory.getLogger('GetInfoByMaskDBHelperTest')

        sFinalQuery = 'SELECT mf.member_num, mf.member_name, mf.contact_email, mf.search_entity, mf.entity_identifier, ms.instance_id as dmctn, mf.role_name, mf.rank FROM ( SELECT m.member_num, m.member_name, m.contact_email, \'TITAN\' search_entity, ms.sor_invariant_id entity_identifier,  sr.role_name, \'1\' rank  FROM member m, memberservice ms, mps_owner.memberservicerole msr, mps_owner.servicerole sr  WHERE m.member_num = ms.member_num and m.parent_child_ind = \'S\' and  ms.member_num = msr.member_num and ms.service_id = msr.service_id and  msr.role_id = sr.role_id and msr.service_id = sr.service_id and  ms.sor_id = msr.sor_id and  ms.sor_invariant_id = msr.sor_invariant_id and  ms.service_id = 33 and ms.sor_id = 6 and ms.sor_invariant_id = ?  UNION SELECT m.member_num, m.member_name, m.contact_email, \'DIRECTVNOW\' search_entity, ms.sor_invariant_id entity_identifier,  \'NA\' role_name,  \'4\' rank  FROM member m, memberservice ms  WHERE m.member_num = ms.member_num and m.parent_child_ind = \'S\' and  ms.service_id = 56 and ms.sor_id = 23 and ms.sor_invariant_id = ?  UNION SELECT m.member_num, m.member_name, m.contact_email, \'CONTACT_EMAIL_ACCESSID\' search_entity, m.member_name entity_identifier,  \'NA\' role_name,  \'5\' rank  FROM member m  WHERE m.parent_child_ind = \'S\' and m.member_name = ? UNION select m.member_num, m.member_name, m.contact_email, \'DMCTN\' search_entity, ms.instance_id entity_identifier,  \'NA\' role_name,  \'6\' rank  from member m, memberservice ms  where m.member_num = ms.member_num and m.parent_child_ind = \'S\' and  ms.service_id = 23 and ms.instance_id = ?  UNION SELECT m.member_num, m.member_name, m.contact_email, \'CONTACT_EMAIL\' search_entity, m.contact_email entity_identifier,  \'NA\' role_name,  \'7\' rank  FROM member m  WHERE m.contact_email is not null and m.member_name <> m.contact_email and m.parent_child_ind = \'S\' and m.contact_email = ?  ) mf, memberservice ms  WHERE  NOT EXISTS (SELECT 1 FROM memberservice msd WHERE mf.member_num = msd.member_num AND msd.service_id in (38,39,45))  AND ms.member_num(+) = mf.member_num  AND ms.service_id(+) = 23  ORDER BY rank, role_name desc '

        alDataMasks.add('AU')
        objectList = new ArrayList<Object>()
        objectList1 = new ArrayList<Object>()
        hmGetInfoInp[MPSDefs.DB_MEMBER_NAME] = 'qay_123'
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmGetInfoInp[MPSDefs.DB_MEMBER_NUM] = '123456'
        hmGetInfoInp[MPSDefs.DB_SLID_MEMBER_NUM] = '732234'
        hmGetInfoInp[MPSDefs.DB_BAN] = '56784'
        hmGetInfoInp[MPSDefs.SOURCE_CALLER] = 'MYWORLD'
        hmGetInfoInp[MPSDefs.QUERY_LINKED_USERS_FLAG] = 'Y'
        hmGetInfoInp[MPSDefs.QUERY_FRAUD_LOCK_FLAG] = 'Y'
        hmGetInfoInp[MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG] = 'Y'

        hmQueryResponse[MPSDefs.DB_MEMBER_NUM] = '22423533'
        hmQueryResponse[MPSDefs.DB_MEMBER_NAME] = 'qaynam'
        hmQueryResponse[MPSDefs.DB_CONTACT_EMAIL] = 'hs2880@att.com'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.RESERVED_STATE
        hmQueryResponse[MPSDefs.DB_BAN] = 'VD00132311'
        hmQueryResponse[MPSDefs.DB_ACCOUNT_TYPE] = 'R'
        hmQueryResponse[MPSDefs.DB_LAST_MEMBER_STATUS_CODE] = 'Enabled'
        hmQueryResponse[MPSDefs.DB_ENC_PASSWORD_VENC] = 'asf343534vdsfgvfsdgdfgf'
        hmQueryResponse[MPSDefs.DB_MD5_PASSWORD_VENC] = 'fdsgfsdgbhtr23456467567'
        hmQueryResponse[MPSDefs.DB_SHA1_PASSWORD_VENC] = 'sdgsrfytryt34645656676'
        hmQueryResponse[MPSDefs.DB_DES3_PASSWORD_VENC] = 'fdhgfhgjhgjh345465'
        hmQueryResponse[MPSDefs.DB_SSHA_PASSWORD_VENC] = 'dfgfhgfhydgtfgh546578t'
        hmQueryResponse[MPSDefs.DB_DOMAIN_ID] = null
        hmQueryResponse[MPSDefs.DB_SOR_NAME] = null
        hmQueryResponse[MPSDefs.DB_ACCESS_ID] = null
        hmQueryResponse[MPSDefs.DB_ACCESS_NAME] = null
        hmQueryResponse[MPSDefs.DB_CREATE_DATE] = null
        hmQueryResponse[MPSDefs.DB_LAST_MODIFIED] = null
        hmQueryResponse[MPSDefs.DB_LAST_MODIFIED_BY] = null
        hmQueryResponse[MPSDefs.DB_PREMIUM_800_IND] = null
        hmQueryResponse[MPSDefs.DB_BULK_BILLING_IND] = null
        hmQueryResponse[MPSDefs.DB_ACCESS_CODE] = null
        hmQueryResponse[MPSDefs.DB_FAILED_AUTH_COUNT] = null
        hmQueryResponse[MPSDefs.DB_PASSWORD_DIRTY] = null
        hmQueryResponse[MPSDefs.DB_CONTACT_EMAIL] = null
        hmQueryResponse[MPSDefs.DB_CONTACT_EMAIL_VALID] = null
        hmQueryResponse[MPSDefs.DB_CREDIT_CHECKED_IND] = null
        hmQueryResponse[MPSDefs.DB_YREG_COMPLETE_IND] = null
        hmQueryResponse[MPSDefs.DB_LOCKOUT_TIMESTAMP] = null
        hmQueryResponse[MPSDefs.DB_LC_FIRSTNAME] = null
        hmQueryResponse[MPSDefs.DB_LC_LASTNAME] = null
        hmQueryResponse[MPSDefs.DB_NICKNAME] = null
        hmQueryResponse[MPSDefs.DB_GENDER] = null
        hmQueryResponse[MPSDefs.DB_PROOFING_ZIP] = null
        hmQueryResponse[MPSDefs.DB_LAST_MEMBER_STATUS_NAME] = null
        hmQueryResponse[MPSDefs.DB_LAST_MEMBER_STATUS_CODE] = null
        hmQueryResponse[MPSDefs.DB_CONTACT_EMAIL_EST_DATE] = null
        hmQueryResponse[MPSDefs.DB_PREVIOUS_CONTACT_EMAIL] = null
        hmQueryResponse[MPSDefs.DB_BROWSER_LANGUAGE] = null
        hmQueryResponse[MPSDefs.DB_DSL_NET_PASSWORD] = null
        hmQueryResponse[MPSDefs.DB_DSL_NET_ENCR_TYPE] = null
        hmQueryResponse[MPSDefs.DB_CONTACT_EMAIL_STATUS] = null
        hmQueryResponse[MPSDefs.DB_AUTOGENERATED_IND] = null
        hmQueryResponse[MPSDefs.DB_ACTIVATED_IND] = null
        hmQueryResponse[MPSDefs.DB_ACTIVATED_DATE] = null
        hmQueryResponse[MPSDefs.DB_CREATED_BY] = null
        hmQueryResponse[MPSDefs.DB_MERGEABLE_IND] = null
        hmQueryResponse[MPSDefs.DB_CBR_OPT_OUT] = null
        hmQueryResponse[MPSDefs.DB_ONL_QA_EST_DATE] = null
        hmQueryResponse[MPSDefs.DB_PARENT_NAME] = null
        hmQueryResponse[MPSDefs.DB_OPTOUT_IND] = null
        hmQueryResponse[MPSDefs.DB_AGG_SERVICE_STATUS] = null
        hmQueryResponse[MPSDefs.DB_MIGRATION_IND] = null
        hmQueryResponse[MPSDefs.DB_LANGUAGE] = null
        hmQueryResponse[MPSDefs.DB_NUM_TOS_REJECTS] = null
        hmQueryResponse[MPSDefs.DB_SSHA_PASSWORD] = null
        hmQueryResponse[MPSDefs.DB_PARENT_CHILD_IND] = null
        hmQueryResponse[MPSDefs.DB_MD5_PASSWORD] = null
        hmQueryResponse[MPSDefs.DB_TOS_REJECT_DATE] = null
        hmQueryResponse[MPSDefs.DB_ALERT_IND] = null
        hmQueryResponse[MPSDefs.DB_DES3_PASSWORD] = null
        hmQueryResponse[MPSDefs.DB_MAILHOST] = null
        hmQueryResponse[MPSDefs.DB_SHA1_PASSWORD] = null
        hmQueryResponse[MPSDefs.DB_PARENT_DOMAIN] = null
        hmQueryResponse[MPSDefs.DB_ENC_PASSWORD] = null
        hmQueryResponse[MPSDefs.DB_MIGRATION_DATE] = null
        hmQueryResponse[MPSDefs.DB_GROUP_NUM] = null
        hmQueryResponse[MPSDefs.DB_CSR_INITIATED_LOCKOUT_TS] = null
        hmQueryResponse[MPSDefs.DB_AGG_ACCESS_STATUS] = null
        hmQueryResponse[MPSDefs.DB_SOR_ID] = null
        hmQueryResponse[MPSDefs.DB_TOKEN] = null
        hmQueryResponse[MPSDefs.DB_DELETE_REQUEST_DATE] = null
        hmQueryResponse[MPSDefs.DB_SLID_MEMBER_NUM] = null
        hmQueryResponse[MPSDefs.DB_FULLNAME] = null
        hmQueryResponse[MPSDefs.DB_REMARKS] = null
        HashMap hmFraudLockResponse = new HashMap()
        hmFraudLockResponse[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        hmFraudLockResponse[MPSDefs.DB_USER_LOCK_LEVEL] = '1'
        hmFraudLockResponse[MPSDefs.DB_USER_LOCK_REASON] = 'FRAUD'
        hmFraudLockResponse[MPSDefs.DB_FRAUD_AGENT] = 'FRAUD'
        hmFraudLockResponse['fraud_last_modified_by'] = 'IDP'
        hmFraudLockResponse['fraud_last_modified'] = '11022009'
        hmFraudLockResponse['fraud_create_date'] = '11022009'
        HashMap<String, Object> hmServiceAttribute = new HashMap<String, Object>()
        HashMap<String, Object> hmMemberServiceAttributes = new HashMap<String, Object>()
        ArrayList alRoles = new ArrayList()
        HashMap<String, Object> eachRole = new HashMap<String, Object>()
        eachRole[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        alRoles.add(eachRole)
        hmServiceAttribute['17'] = alRoles
        hmMemberServiceAttributes['1544'] = hmServiceAttribute
        resultHashSuccess[MPSDefs.APP_STATUS_CODE] = '0'
        resultHashSuccess[MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE] = hmMemberServiceAttributes




        oFraudLockDBHelper.queryUserFraudLock(_ as HashMap<String, Object>) >> hmFraudLockResponse
        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')
    }

    final def "test null input"() throws Exception {
        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(null)
        then:
        'Input hash is empty' == hmResponse[CommonDefs.COMMON_APP_INFO]  //CErrorDefs.ERR_INVALID_DATA
    }

    final def "test mask list empty"() throws Exception {
        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        then:
        'Mask List is empty' == hmResponse[CommonDefs.COMMON_APP_INFO]  //CErrorDefs.ERR_INVALID_DATA
    }

    def "get info by mask validate mask list error"() throws Exception {
        given:
        hmGetInfoInp['dataMask'] = null
        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        then:
        'Mask List is empty' == hmResponse[CommonDefs.COMMON_APP_INFO]  //CErrorDefs.ERR_INVALID_DATA
    }

    def "get info by mask validate mask list error ci mask"() throws Exception {
        given:
        alDataMasks.add('CI')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        stAppStatusMsg = (String) hmResponse[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
    }

    def "get info by mask validate mask list error ad mask"() throws Exception {
        given:
        alDataMasks.add('AD')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        stAppStatusMsg = (String) hmResponse[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
    }

    def "get info by mask validate mask list error dd mask"() throws Exception {
        given:
        alDataMasks.add('DD')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        stAppStatusMsg = (String) hmResponse[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
    }

    def "get info by mask validate mask list error ri mask"() throws Exception {
        given:
        alDataMasks.add('RI')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        stAppStatusMsg = (String) hmResponse[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
    }

    def "get info by mask validate mask list error sd mask"() throws Exception {
        given:
        alDataMasks.add('SD')
        hmGetInfoInp['dataMask'] = alDataMasks

        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        stAppStatusMsg = (String) hmResponse[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
    }

    def "get info by mask validate success null member name value"() throws Exception {
        given:
        alDataMasks.add('SD')
        alDataMasks.add('AS')
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NAME)
        hmGetInfoInp.remove(MPSDefs.DB_DOMAIN_NAME)
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)
        hmGetInfoInp['dataMask'] = alDataMasks
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        stAppStatusMsg = (String) hmResponse[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_EMPTY'
    }

    def "get info by mask with member name value exception"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind in (\'P\',\'C\') '
        alDataMasks.add('SD')
        alDataMasks.add('AS')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)
        objectList.add('qay_123')
        objectList.add('att.net')
        jdbcTemplate.queryForList(_,_) >> null
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        stAppStatusMsg = (String) hmResponse[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_SYS_APPL'
    }

    def "get info by mask with slid member name value with row count zero"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.add('SD')
        alDataMasks.add('AS')
        hmGetInfoInp['dataMask'] = alDataMasks
        objectList.add('732234')
        jdbcTemplate.queryForList(_,_) >> alQueryresponse
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        stAppStatusMsg = (String) hmResponse[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'REC_NOT_FOUND'
    }

    def "get info by mask with member name value with row count zero"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.add('SD')
        alDataMasks.add('AS')
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)
        hmGetInfoInp['dataMask'] = alDataMasks
        objectList.add('22423533')

        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        String stAppInfo = (String) hmResponse[MPSDefs.APP_CATEGORY_CODE]
        then:
        stAppInfo == '2'
    }

    def "get info by mask with member name value voltage errror"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.add('AU')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM

        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)
        objectList.add('qay_123')
        objectList.add(MPSDefs.SLID_DUM)

        HashMap<String, Object> hmStatusTMS=new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '2'
        hmQueryResponse[MPSDefs.DB_DOMAIN_NAME] = null
        alQueryresponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_,_) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        String stAppInfo = (String) hmResponse[MPSDefs.APP_STATUS_CODE]
        then:
        stAppInfo == '2'
    }

    def "get info by mask with member name value get member service role"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.add('RI')
        alDataMasks.add('AA')
        alDataMasks.add('QFLO')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.DB_SERVICE_NAME] = MPSDefs.PORTAL_SERVICE
        hmGetInfoInp[MPSDefs.SOURCE_CALLER] = 'getSlidInfo'
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)
        String dynSql2 = ' AND memService.service_id in (10, 32, 33, 36)'

        objectList.add('qay_123')
        objectList.add(MPSDefs.SLID_DUM)
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        HashMap<String, Object> hmQueryAllResponse2=new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_PORTAL_PROVIDER] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_PLITE_IND] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '12'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        alQueryAllResponse2.add(hmQueryAllResponse2)

        String sql= queryForServiceEcommUverse + dynSql2
        objectList1.add('22423533')
        HashMap<String, Object> hmStatusTMS=new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        alQueryresponse.add(hmQueryResponse)

        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'
        oDBHelper.getServiceName(_) >> MPSDefs.PORTAL_SERVICE
        jdbcTemplate1.queryForList(_,_) >> alQueryAllResponse2
        jdbcTemplate.queryForList(_,_) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        String stAppInfo = (String) hmResponse[MPSDefs.APP_STATUS_CODE]
        then:
        stAppInfo == '0'
    }
    def "get info by mask with member name value get member service role for instance services"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.add('RI')
        alDataMasks.add('AA')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.DB_SERVICE_NAME] = MPSDefs.MOSUB_SERVICE
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)
        String dynSql2 = ' AND memService.service_id in (10, 32, 24, 33, 36)'

        objectList.add('qay_123')
        objectList.add(MPSDefs.SLID_DUM)
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '17'

        HashMap<String, Object> hmQueryAllResponse2=new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_PORTAL_PROVIDER] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_PLITE_IND] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '23'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        alQueryAllResponse2.add(hmQueryAllResponse2)

        HashMap<String, Object> hmDbInput = CommonUtil.hashMap
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '22423533'
        objectList1.add('22423533')
        HashMap<String, Object> hmStatusTMS=new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        alQueryresponse.add(hmQueryResponse)
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getServiceName(_) >> MPSDefs.MOSUB_SERVICE
        jdbcTemplate.queryForList(_,_) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oGetMemberRolesDBHelper.getMemberServiceRoles(_) >> null
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        String stAppInfo = (String) hmResponse[MPSDefs.APP_STATUS_CODE]
        then:
        stAppInfo == '602'
    }

    def "get info by mask with member name value get member service role for instance services success"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.add('AS')
        alDataMasks.add('RI')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.DB_SERVICE_NAME] = MPSDefs.MOSUB_SERVICE
        hmGetInfoInp[MPSDefs.SOURCE_CALLER] = 'getSlidInfo'
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)
        String dynSql2 = ' AND memService.service_id not in (10, 32, 33, 36)'

        objectList.add('qay_123')
        objectList.add(MPSDefs.SLID_DUM)
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '17'

        HashMap<String, Object> hmQueryAllResponse2=new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_PORTAL_PROVIDER] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_PLITE_IND] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '23'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        alQueryAllResponse2.add(hmQueryAllResponse2)

        HashMap<String, Object> hmDbInput = CommonUtil.hashMap
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '22423533'

        String sql= queryForServiceNotEcommUverse + dynSql2
        objectList1.add('22423533')
        HashMap<String, Object> hmStatusTMS=new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmRolesResponse=new HashMap<String, Object>()
        hmRolesResponse[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        HashMap<String, Object> RoleHashMap=new HashMap<String, Object>()
        RoleHashMap[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        HashMap<String, Object> hmServiceData=new HashMap<String, Object>()
        hmServiceData[MPSDefs.DB_SERVICE_TYPE] = 'R'
        hmServiceData[MPSDefs.DB_EMAIL_ELIGIBLE] = 'Y'
        hmServiceData[MPSDefs.DB_ENTITY_TYPE] = 'MU'
        hmServiceData[MPSDefs.DB_SERVICE_NAME] = MPSDefs.MOSUB_SERVICE

        ArrayList role=new ArrayList()
        role.add(RoleHashMap)
        hmRolesResponse[MPSDefs.MOSUB_SERVICE] = role
        oDBHelper.getSorName(_) >> 'NA'
        objStatusValidation.getStatusNameByCode(_) >>'Enabled'
        jdbcTemplate1.queryForList(_,_) >>alQueryAllResponse2
        oDBHelper.getServiceName(_) >> MPSDefs.MOSUB_SERVICE
        jdbcTemplate.queryForList(_,_) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oGetMemberRolesDBHelper.getMemberServiceRoles(_) >> hmRolesResponse
        oGetMemSvcAttr.getServiceAttributesByMemberNum(_) >> resultHashSuccess
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        String stAppInfo = (String) hmResponse[MPSDefs.APP_STATUS_CODE]
        then:
        stAppInfo == '0'
    }

    def "get info by mask with member name value get member service role for instance services rec not found error"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.add('AS')
        alDataMasks.add('RI')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.DB_SERVICE_NAME] = MPSDefs.MOSUB_SERVICE
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)
        String dynSql2 = ' AND memService.service_id not in (10, 32, 24, 33, 36)'

        objectList.add('qay_123')
        objectList.add(MPSDefs.SLID_DUM)
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '17'

        HashMap<String, Object> hmQueryAllResponse2=new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_PORTAL_PROVIDER] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_PLITE_IND] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '23'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        alQueryAllResponse2.add(hmQueryAllResponse2)

        HashMap<String, Object> hmDbInput = CommonUtil.hashMap
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '22423533'

        String sql= queryForServiceNotEcommUverse + dynSql2
        objectList1.add('22423533')
        HashMap<String, Object> hmStatusTMS=new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmRolesResponse=new HashMap<String, Object>()
        hmRolesResponse[CErrorDefs.COMMON_APP_STATUS_CODE] = '285'
        HashMap<String, Object> RoleHashMap=new HashMap<String, Object>()
        RoleHashMap[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        HashMap<String, Object> hmServiceData=new HashMap<String, Object>()
        hmServiceData[MPSDefs.DB_SERVICE_TYPE] = 'R'
        hmServiceData[MPSDefs.DB_EMAIL_ELIGIBLE] = 'Y'
        hmServiceData[MPSDefs.DB_ENTITY_TYPE] = 'MU'

        hmServiceData[MPSDefs.DB_SERVICE_NAME] = MPSDefs.MOSUB_SERVICE

        oDBHelper.getSorName(_) >> 'NA'
        objStatusValidation.getStatusNameByCode(_) >>'Enabled'
        jdbcTemplate1.queryForList(_,_) >> alQueryAllResponse2
        oDBHelper.getServiceName(_) >> MPSDefs.MOSUB_SERVICE
        jdbcTemplate.queryForList(_,_) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oGetMemberRolesDBHelper.getMemberServiceRoles(_) >> hmRolesResponse
        oGetMemSvcAttr.getServiceAttributesByMemberNum(_) >> resultHashSuccess

        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        String stAppInfo = (String) hmResponse[MPSDefs.APP_STATUS_CODE]
        then:
        stAppInfo == '0'
    }

    def "get info by mask with member num value error"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.add('AS')
        alDataMasks.add('AA')
        alDataMasks.add('RI')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.DB_SERVICE_NAME] = MPSDefs.MOSUB_SERVICE
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)

        objectList.add('qay_123')
        objectList.add(MPSDefs.SLID_DUM)
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '17'

        HashMap<String, Object> hmQueryAllResponse2=new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_PORTAL_PROVIDER] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_PLITE_IND] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '23'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        alQueryAllResponse2.add(hmQueryAllResponse2)

        HashMap<String, Object> hmDbInput = CommonUtil.hashMap
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '22423533'

        objectList1.add('22423533')
        HashMap<String, Object> hmStatusTMS=new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmRolesResponse=new HashMap<String, Object>()
        hmRolesResponse[CErrorDefs.COMMON_APP_STATUS_CODE] = '2'
        HashMap<String, Object> RoleHashMap=new HashMap<String, Object>()
        RoleHashMap[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        HashMap<String, Object> hmServiceData=new HashMap<String, Object>()
        hmServiceData[MPSDefs.DB_SERVICE_TYPE] = 'R'
        hmServiceData[MPSDefs.DB_EMAIL_ELIGIBLE] = 'Y'
        hmServiceData[MPSDefs.DB_ENTITY_TYPE] = 'MU'

        hmServiceData[MPSDefs.DB_SERVICE_NAME] = MPSDefs.MOSUB_SERVICE
        oDBHelper.getSorName(_) >> 'NA'
        jdbcTemplate1.queryForList(_,_) >> alQueryAllResponse2
        oDBHelper.getServiceName(_) >> MPSDefs.MOSUB_SERVICE
        jdbcTemplate.queryForList(_,_) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oGetMemberRolesDBHelper.getMemberServiceRoles(_) >> hmRolesResponse
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        String stAppInfo = (String) hmResponse[MPSDefs.APP_STATUS_CODE]
        then:
        stAppInfo == '2'
    }

    def "get info by mask with service notification services"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.add('AS')
        alDataMasks.add('AA')
        alDataMasks.add('RI')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.DB_SERVICE_NAME] = MPSDefs.TITAN_SERVICE
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)

        objectList.add('qay_123')
        objectList.add(MPSDefs.SLID_DUM)
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '17'
        hmQueryResponse[MPSDefs.DB_INSTANCE_ID] = '2'
        hmQueryResponse[MPSDefs.DB_SOR_NAME] = 'NA'
        HashMap<String, Object> hmQueryAllResponse2=new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '2'
        hmQueryAllResponse2[MPSDefs.DB_PORTAL_PROVIDER] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_PLITE_IND] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '33'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_SOR_NAME] = 'NA'
        alQueryAllResponse2.add(hmQueryAllResponse2)

        HashMap<String, Object> hmDbInput = CommonUtil.hashMap
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '22423533'

        objectList1.add('22423533')
        HashMap<String, Object> hmStatusTMS=new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmRolesResponse=new HashMap<String, Object>()
        hmRolesResponse[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        HashMap<String, Object> RoleHashMap=new HashMap<String, Object>()
        RoleHashMap[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        HashMap<String, Object> hmServiceData=new HashMap<String, Object>()
        hmServiceData[MPSDefs.DB_SERVICE_TYPE] = 'R'
        hmServiceData[MPSDefs.DB_EMAIL_ELIGIBLE] = 'Y'
        hmServiceData[MPSDefs.DB_ENTITY_TYPE] = 'MU'

        hmServiceData[MPSDefs.DB_SERVICE_NAME] = MPSDefs.TITAN_SERVICE
        oDBHelper.getSorName(_) >> 'NA'
        objStatusValidation.getStatusNameByCode(_) >>'Enabled'
        jdbcTemplate1.queryForList(_,_) >> alQueryAllResponse2
        oDBHelper.getServiceName(_) >> MPSDefs.TITAN_SERVICE
        jdbcTemplate.queryForList(_,_) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oGetMemberRolesDBHelper.getMemberServiceRoles(_) >> hmRolesResponse

        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        String stAppInfo = (String) hmResponse[MPSDefs.APP_STATUS_CODE]
        then:
        stAppInfo == '602'
    }

    def "get info by mask with error"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.remove('AU')
        alDataMasks.add('DD')
        alDataMasks.add('AH')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.DB_SERVICE_NAME] = MPSDefs.TITAN_SERVICE
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)

        objectList.add('qay_123')
        objectList.add(MPSDefs.SLID_DUM)

        hmQueryResponse = new HashMap<String, Object>()
        hmQueryResponse[MPSDefs.DB_MEMBER_NUM] = '22423533'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        alQueryresponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_,_) >> alQueryresponse
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        String stAppInfo = (String) hmResponse[MPSDefs.APP_STATUS_CODE]

        then:
        stAppInfo == '100'
    }

    def "get info by mask with mask sq"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.remove('AU')
        alDataMasks.add('DD')
        alDataMasks.add('AH')
        alDataMasks.add('SQ')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.DB_SERVICE_NAME] = MPSDefs.TITAN_SERVICE
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)

        objectList.add('qay_123')
        objectList.add(MPSDefs.SLID_DUM)

        hmQueryResponse = new HashMap<String, Object>()
        hmQueryResponse[MPSDefs.DB_MEMBER_NUM] = '22423533'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        alQueryresponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_,_) >> alQueryresponse

        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        String stAppInfo = (String) hmResponse[MPSDefs.APP_STATUS_CODE]
        then:
        stAppInfo == '602'
    }

    def "get info by mask with dsl service"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.add('RI')
        alDataMasks.add('AA')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.DB_SERVICE_NAME] = MPSDefs.DSL_SERVICE
        hmGetInfoInp[MPSDefs.SOURCE_CALLER] = 'getSlidInfo'
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)
        String dynSql2 = ' AND memService.service_id in (10, 32, 33, 36)'

        objectList.add('qay_123')
        objectList.add(MPSDefs.SLID_DUM)
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        HashMap<String, Object> hmQueryAllResponse2=new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_PORTAL_PROVIDER] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_PLITE_IND] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '12'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        alQueryAllResponse2.add(hmQueryAllResponse2)

        String sql= queryForServiceEcommUverse + dynSql2
        objectList1.add('22423533')
        HashMap<String, Object> hmStatusTMS=new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        alQueryresponse.add(hmQueryResponse)

        List<Object> objectListDSLUser = new ArrayList<Object>()
        objectListDSLUser.add('22423533')

        objStatusValidation.getStatusNameByCode(_) >>'Enabled'
        oDBHelper.getServiceName(_) >>MPSDefs.DSL_SERVICE
        jdbcTemplate1.queryForList(_,_) >> alQueryAllResponse2
        jdbcTemplate.queryForList(_,_) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        jdbcTemplate.queryForList(_,_) >> alQueryresponse

        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        String stAppInfo = (String) hmResponse[MPSDefs.APP_STATUS_CODE]
        then:
        stAppInfo == '0'
    }

    def "get info by mask with dial service"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.add('RI')
        alDataMasks.add('AA')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.DB_SERVICE_NAME] = MPSDefs.DIAL_SERVICE
        hmGetInfoInp[MPSDefs.SOURCE_CALLER] = 'getSlidInfo'
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)
        String dynSql2 = ' AND memService.service_id in (10, 32, 33, 36)'

        objectList.add('qay_123')
        objectList.add(MPSDefs.SLID_DUM)
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        HashMap<String, Object> hmQueryAllResponse2=new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_PORTAL_PROVIDER] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_PLITE_IND] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '12'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        alQueryAllResponse2.add(hmQueryAllResponse2)

        String sql= queryForServiceEcommUverse + dynSql2
        objectList1.add('22423533')
        HashMap<String, Object> hmStatusTMS=new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        alQueryresponse.add(hmQueryResponse)

        List<Object> objectListDialUser = new ArrayList<Object>()
        objectListDialUser.add('22423533')

        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'
        oDBHelper.getServiceName(_) >> MPSDefs.DIAL_SERVICE
        jdbcTemplate1.queryForList(_,_) >> alQueryAllResponse2
        jdbcTemplate.queryForList(_,_) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        jdbcTemplate.queryForList(_,_) >> alQueryresponse

        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        String stAppInfo = (String) hmResponse[MPSDefs.APP_STATUS_CODE]
        then:
        stAppInfo == '0'
    }

    def "get info by mask with isdn service"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.add('RI')
        alDataMasks.add('AA')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.DB_SERVICE_NAME] = MPSDefs.ISDN2_SERVICE
        hmGetInfoInp[MPSDefs.SOURCE_CALLER] = 'getSlidInfo'
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)
        String dynSql2 = ' AND memService.service_id in (10, 32, 33, 36)'

        objectList.add('qay_123')
        objectList.add(MPSDefs.SLID_DUM)
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        HashMap<String, Object> hmQueryAllResponse2=new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_PORTAL_PROVIDER] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_PLITE_IND] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '12'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        alQueryAllResponse2.add(hmQueryAllResponse2)

        String sql= queryForServiceEcommUverse + dynSql2
        objectList1.add('22423533')
        HashMap<String, Object> hmStatusTMS=new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        alQueryresponse.add(hmQueryResponse)

        List<Object> objectListISDNUser = new ArrayList<Object>()
        objectListISDNUser.add('22423533')

        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'
        oDBHelper.getServiceName(_) >> MPSDefs.ISDN2_SERVICE
        jdbcTemplate1.queryForList(_,_) >> alQueryAllResponse2
        jdbcTemplate.queryForList(_,_) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        jdbcTemplate.queryForList(_,_) >> alQueryresponse

        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        String stAppInfo = (String) hmResponse[MPSDefs.APP_STATUS_CODE]
        then:
        stAppInfo == '0'
    }

    def "get info by mask with wifi service"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.add('RI')
        alDataMasks.add('AA')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.DB_SERVICE_NAME] = MPSDefs.WIFI_SERVICE
        hmGetInfoInp[MPSDefs.SOURCE_CALLER] = 'getSlidInfo'
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)
        String dynSql2 = ' AND memService.service_id in (10, 32, 33, 36)'

        objectList.add('qay_123')
        objectList.add(MPSDefs.SLID_DUM)
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        HashMap<String, Object> hmQueryAllResponse2=new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_PORTAL_PROVIDER] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_PLITE_IND] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '12'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        alQueryAllResponse2.add(hmQueryAllResponse2)

        String sql= queryForServiceEcommUverse + dynSql2
        objectList1.add('22423533')
        HashMap<String, Object> hmStatusTMS=new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        alQueryresponse.add(hmQueryResponse)

        List<Object> objectListWIFIUser = new ArrayList<Object>()
        objectListWIFIUser.add('22423533')

        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'
        oDBHelper.getServiceName(_) >>MPSDefs.WIFI_SERVICE
        jdbcTemplate1.queryForList(_,_) >> alQueryAllResponse2
        jdbcTemplate.queryForList(_,_) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        jdbcTemplate.queryForList(_,_) >> alQueryresponse

        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        String stAppInfo = (String) hmResponse[MPSDefs.APP_STATUS_CODE]
        then:
        stAppInfo == '0'
    }

    def "get info by mask with data mask aep exception case"() throws Exception {
        given:
        dynSql = ' AND mem.parent_child_ind=\'S\' '
        alDataMasks.add('RI')
        alDataMasks.add('AA')
        alDataMasks.add('AEP')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.DB_SERVICE_NAME] = MPSDefs.WIFI_SERVICE
        hmGetInfoInp[MPSDefs.SOURCE_CALLER] = 'getSlidInfo'
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)
        String dynSql2 = ' AND memService.service_id in (10, 32, 33, 36)'

        objectList.add('qay_123')
        objectList.add(MPSDefs.SLID_DUM)
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        HashMap<String, Object> hmQueryAllResponse2=new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_PORTAL_PROVIDER] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_PLITE_IND] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '12'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        alQueryAllResponse2.add(hmQueryAllResponse2)

        String sql= queryForServiceEcommUverse + dynSql2
        objectList1.add('22423533')
        HashMap<String, Object> hmStatusTMS=new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        alQueryresponse.add(hmQueryResponse)

        List<Object> objectListWIFIUser = new ArrayList<Object>()
        objectListWIFIUser.add('22423533')
        objStatusValidation.getStatusNameByCode(_) >>'Enabled'
        oDBHelper.getServiceName(_) >> MPSDefs.WIFI_SERVICE
        jdbcTemplate1.queryForList(_,_) >> alQueryAllResponse2
        jdbcTemplate.queryForList(_,_) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        jdbcTemplate.queryForList(_,_) >> alQueryresponse

        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)
        when:
        String stAppInfo = (String) hmResponse[MPSDefs.APP_STATUS_CODE]
        then:
        stAppInfo == '602'
    }

    def "get info by mask with copy service data"() throws Exception {

        given:
        alDataMasks.remove('AU')
        alDataMasks.add('DD')
        alDataMasks.add('AH')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.DB_SERVICE_NAME] = MPSDefs.TITAN_SERVICE
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp[MPSDefs.DB_MEMBER_STATE] = MPSDefs.TERMINATED
        hmGetInfoInp[MPSDefs.DB_GROUP_STATUS] = MPSDefs.TERMINATED
        hmGetInfoInp[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        HashMap<String, Object> hmServiceData = new HashMap<String, Object>()
        hmServiceData[MPSDefs.DB_SERVICE_TYPE] = 'A'
        hmServiceData[MPSDefs.DB_EMAIL_ELIGIBLE] = 'Y'
        hmServiceData[MPSDefs.DB_SERVICE_NAME] = MPSDefs.TITAN_SERVICE
        hmServiceData[MPSDefs.DB_ENTITY_TYPE] = 'X'
        alQueryresponse.add(hmQueryResponse)
        objStatusValidation.getStatusNameByCode(_) >> MPSDefs.TERMINATED
        objServiceValidation.getServiceDataById(_) >> hmServiceData
        expect:
        objGetInfoByMaskDBHelper.copyServiceData(hmGetInfoInp, hmQueryResponse)
    }

    def "get info by mask with calculate status"() throws Exception {
        when:
        String status = objGetInfoByMaskDBHelper.calculateStatus(MPSDefs.SUSPENDED, MPSDefs.SUSPENDED)
        then:
        status == MPSDefs.SUSPENDED
    }

    def "get info by mask with calculate status terminated"() throws Exception {
        when:
        String status = objGetInfoByMaskDBHelper.calculateStatus(MPSDefs.TERMINATED, MPSDefs.TERMINATED)
        then:
        status == MPSDefs.TERMINATED
    }

    def "get info by mask with calculate status enabled"() throws Exception {
        when:
        String status = objGetInfoByMaskDBHelper.calculateStatus(MPSDefs.ENABLED, MPSDefs.ENABLED)
        then:
        status == MPSDefs.ENABLED
    }

    def "get info by mask with calculate status pending"() throws Exception {
        when:
        String status = objGetInfoByMaskDBHelper.calculateStatus(MPSDefs.PENDING, MPSDefs.PENDING)
        then:
        status == MPSDefs.PENDING
    }

    def "get info by mask with copy instance data"() throws Exception {

        given:
        alDataMasks.remove('AU')
        alDataMasks.add('DD')
        alDataMasks.add('AH')
       hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.DB_SERVICE_NAME] = MPSDefs.TITAN_SERVICE
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmGetInfoInp[MPSDefs.DB_GROUP_STATUS] = MPSDefs.ENABLED
        hmGetInfoInp[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        HashMap<String, Object> hmServiceData = new HashMap<String, Object>()

        hmServiceData[MPSDefs.DB_SERVICE_TYPE] = 'A'
        hmServiceData[MPSDefs.DB_EMAIL_ELIGIBLE] = 'Y'
        hmServiceData[MPSDefs.DB_SERVICE_NAME] = MPSDefs.TITAN_SERVICE
        hmServiceData[MPSDefs.DB_ENTITY_TYPE] = 'X'
        hmServiceData[MPSDefs.DB_SERVICE_NAME] = MPSDefs.TITAN_SERVICE

        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        alQueryresponse.add(hmQueryResponse)

        ArrayList hmRolesResponse = new ArrayList()

        HashMap<String, Object> RoleHashMap = new HashMap<String, Object>()
        RoleHashMap[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        HashMap<String, Object> hmMemberServiceRoles = new HashMap<String, Object>()
        RoleHashMap[MPSDefs.DB_SERVICE_TYPE] = 'R'
        RoleHashMap[MPSDefs.DB_EMAIL_ELIGIBLE] = 'Y'
        RoleHashMap[MPSDefs.DB_ENTITY_TYPE] = 'MU'
        hmRolesResponse.add(RoleHashMap)
        hmMemberServiceRoles[MPSDefs.TITAN_SERVICE] = hmRolesResponse
        HashMap<String, Object> hmMemberServiceAttributes = new HashMap<String, Object>()
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'
        objServiceValidation.getServiceDataById(_) >> hmServiceData

        expect:
        objGetInfoByMaskDBHelper.copyInstanceData(hmGetInfoInp, hmQueryResponse, hmMemberServiceRoles,
                hmMemberServiceAttributes)
    }

    def "should return member name and domain when present"() {
        given: "A memberNum with existing record and jdbcTemplate returns map"
        String memberNum = "555001"
        Map<String, String> dbResult = new HashMap<String, String>()
        dbResult.put(MPSDefs.DB_MEMBER_NAME, "john_doe")
        dbResult.put(MPSDefs.DB_DOMAIN_NAME, "att.net")
        jdbcTemplate.queryForObject({ String sql -> sql != null && sql.contains("member_name") && sql.contains("domain") }, { rowMapper -> rowMapper != null }, memberNum) >> dbResult

        when: "Method invoked"
        Optional<Map<String, String>> result = objGetInfoByMaskDBHelper.getMemberNameAndDomainByMemberNum(memberNum)

        then: "JdbcTemplate called once with expected args"
        1 * jdbcTemplate.queryForObject({ String sql -> sql != null && sql.contains("member_name") }, { it != null }, memberNum) >> dbResult
        0 * _

        and: "Result contains expected values"
        result.isPresent()
        result.get().get(MPSDefs.DB_MEMBER_NAME) == "john_doe"
        result.get().get(MPSDefs.DB_DOMAIN_NAME) == "att.net"
    }

    def "should return empty optional when no record found"() {
        given: "JdbcTemplate throws EmptyResultDataAccessException"
        String memberNum = "555002"
        jdbcTemplate.queryForObject({ String sql -> sql != null }, { it != null }, memberNum) >> { throw new org.springframework.dao.EmptyResultDataAccessException(1) }

        when: "Method invoked"
        Optional<Map<String, String>> result = objGetInfoByMaskDBHelper.getMemberNameAndDomainByMemberNum(memberNum)

        then: "JdbcTemplate invoked and empty optional returned"
        1 * jdbcTemplate.queryForObject({ String sql -> sql != null }, { it != null }, memberNum) >> { throw new org.springframework.dao.EmptyResultDataAccessException(1) }
        0 * _

        and: "Result is empty"
        !result.isPresent()
    }

    def "should return empty optional when generic exception occurs"() {
        given: "JdbcTemplate throws generic exception"
        String memberNum = "555003"
        jdbcTemplate.queryForObject({ String sql -> sql != null }, { it != null }, memberNum) >> { throw new RuntimeException("DB failure") }

        when: "Method invoked"
        Optional<Map<String, String>> result = objGetInfoByMaskDBHelper.getMemberNameAndDomainByMemberNum(memberNum)

        then: "JdbcTemplate invoked and empty optional returned after error"
        1 * jdbcTemplate.queryForObject({ String sql -> sql != null }, { it != null }, memberNum) >> { throw new RuntimeException("DB failure") }
        1 * errorMetricHandler.recordDbErrorMetric()
        0 * _

        and: "Result is empty"
        !result.isPresent()
    }
    // Added tests for null jdbcTemplate and jdbcTemplate1 conditions
    def "should return error map when primary jdbcTemplate is null"() {
        given: "Helper with primary jdbcTemplate null"
        GetInfoByMaskDBHelper helper = new GetInfoByMaskDBHelper()
        JdbcTemplate mockSecondary = null
        HashMap<String, Object> inputParamHs = new HashMap<>()
        helper.jdbcTemplate = null
        helper.@jdbcTemplate1 = mockSecondary

        when: "getInfoByMask invoked"
        HashMap result = helper.getInfoByMask(inputParamHs)

        then: "Error map returned without DB calls"
        result != null
        result.values().any { it == "jdbcTemplate is null." }
        0 * _
    }

    def "should return error map when secondary jdbcTemplate1 is null"() {
        given: "Helper with secondary jdbcTemplate1 null"
        GetInfoByMaskDBHelper helper = new GetInfoByMaskDBHelper()
        JdbcTemplate mockPrimary = Mock(JdbcTemplate)
        HashMap<String, Object> inputParamHs = new HashMap<>()
        helper.@jdbcTemplate = mockPrimary
        helper.jdbcTemplate1 = null

        when: "getInfoByMask invoked"
        HashMap result = helper.getInfoByMask(inputParamHs)

        then: "Error map returned without DB calls"
        result != null
        result.values().any { it == "jdbcTemplate is null." }
        0 * _
    }

    // --- Additional tests for validateInput method ---

    def "validateInput returns success for valid AA mask"() {
        given:
        HashMap hmValInput = new HashMap()
        ArrayList masks = new ArrayList()
        masks.add('AA')
        hmValInput['dataMask'] = masks

        when:
        HashMap result = objGetInfoByMaskDBHelper.validateInput(hmValInput)

        then:
        result[CErrorDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.COMMON_SUCCESS
    }

    def "validateInput returns success for AA and CI masks combined"() {
        given:
        HashMap hmValInput = new HashMap()
        ArrayList masks = new ArrayList()
        masks.add('AA')
        masks.add('CI')
        hmValInput['dataMask'] = masks

        when:
        HashMap result = objGetInfoByMaskDBHelper.validateInput(hmValInput)

        then:
        result[CErrorDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.COMMON_SUCCESS
    }

    def "validateInput returns success for AA and AD masks combined"() {
        given:
        HashMap hmValInput = new HashMap()
        ArrayList masks = new ArrayList()
        masks.add('AA')
        masks.add('AD')
        hmValInput['dataMask'] = masks

        when:
        HashMap result = objGetInfoByMaskDBHelper.validateInput(hmValInput)

        then:
        result[CErrorDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.COMMON_SUCCESS
    }

    def "validateInput returns success for AH and DD masks combined"() {
        given:
        HashMap hmValInput = new HashMap()
        ArrayList masks = new ArrayList()
        masks.add('AH')
        masks.add('DD')
        hmValInput['dataMask'] = masks

        when:
        HashMap result = objGetInfoByMaskDBHelper.validateInput(hmValInput)

        then:
        result[CErrorDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.COMMON_SUCCESS
    }

    def "validateInput returns success for AA and RI masks combined"() {
        given:
        HashMap hmValInput = new HashMap()
        ArrayList masks = new ArrayList()
        masks.add('AA')
        masks.add('RI')
        hmValInput['dataMask'] = masks

        when:
        HashMap result = objGetInfoByMaskDBHelper.validateInput(hmValInput)

        then:
        result[CErrorDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.COMMON_SUCCESS
    }

    def "validateInput returns success for AS and RI masks combined"() {
        given:
        HashMap hmValInput = new HashMap()
        ArrayList masks = new ArrayList()
        masks.add('AS')
        masks.add('RI')
        hmValInput['dataMask'] = masks

        when:
        HashMap result = objGetInfoByMaskDBHelper.validateInput(hmValInput)

        then:
        result[CErrorDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.COMMON_SUCCESS
    }

    def "validateInput returns success for AS and SD masks combined"() {
        given:
        HashMap hmValInput = new HashMap()
        ArrayList masks = new ArrayList()
        masks.add('AS')
        masks.add('SD')
        hmValInput['dataMask'] = masks

        when:
        HashMap result = objGetInfoByMaskDBHelper.validateInput(hmValInput)

        then:
        result[CErrorDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.COMMON_SUCCESS
    }

    def "validateInput returns error for null dataMask"() {
        given:
        HashMap hmValInput = new HashMap()
        hmValInput['dataMask'] = null

        when:
        HashMap result = objGetInfoByMaskDBHelper.validateInput(hmValInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Mask List is empty'
    }

    def "validateInput returns error for empty dataMask list"() {
        given:
        HashMap hmValInput = new HashMap()
        hmValInput['dataMask'] = new ArrayList()

        when:
        HashMap result = objGetInfoByMaskDBHelper.validateInput(hmValInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Mask List is empty'
    }

    // --- Additional tests for calculateStatus edge cases ---

    def "calculateStatus returns TERMINATED when member is TERMINATED and group is ENABLED"() {
        when:
        String status = objGetInfoByMaskDBHelper.calculateStatus(MPSDefs.TERMINATED, MPSDefs.ENABLED)

        then:
        status == MPSDefs.TERMINATED
    }

    def "calculateStatus returns TERMINATED when member is ENABLED and group is TERMINATED"() {
        when:
        String status = objGetInfoByMaskDBHelper.calculateStatus(MPSDefs.ENABLED, MPSDefs.TERMINATED)

        then:
        status == MPSDefs.TERMINATED
    }

    def "calculateStatus returns SUSPENDED when member is SUSPENDED and group is ENABLED"() {
        when:
        String status = objGetInfoByMaskDBHelper.calculateStatus(MPSDefs.SUSPENDED, MPSDefs.ENABLED)

        then:
        status == MPSDefs.SUSPENDED
    }

    def "calculateStatus returns SUSPENDED when member is ENABLED and group is SUSPENDED"() {
        when:
        String status = objGetInfoByMaskDBHelper.calculateStatus(MPSDefs.ENABLED, MPSDefs.SUSPENDED)

        then:
        status == MPSDefs.SUSPENDED
    }

    def "calculateStatus returns PENDING when member is PENDING and group is ENABLED"() {
        when:
        String status = objGetInfoByMaskDBHelper.calculateStatus(MPSDefs.PENDING, MPSDefs.ENABLED)

        then:
        status == MPSDefs.PENDING
    }

    def "calculateStatus returns PENDING when member is ENABLED and group is PENDING"() {
        when:
        String status = objGetInfoByMaskDBHelper.calculateStatus(MPSDefs.ENABLED, MPSDefs.PENDING)

        then:
        status == MPSDefs.PENDING
    }

    def "calculateStatus returns TERMINATED when both are TERMINATED over SUSPENDED"() {
        when:
        String status = objGetInfoByMaskDBHelper.calculateStatus(MPSDefs.TERMINATED, MPSDefs.SUSPENDED)

        then:
        status == MPSDefs.TERMINATED
    }

    // --- Tests for copyServiceData method ---

    def "copyServiceData populates all service fields with null service data"() {
        given:
        HashMap userServiceHash = new HashMap()
        Map resultSet = new HashMap()
        resultSet[MPSDefs.DB_SOR_INVARIANT_ID] = '100'
        resultSet[MPSDefs.DB_PENDING_DISCONNECT_DATE] = '01012024'
        resultSet[MPSDefs.DB_SERVICE_ID] = '10'
        resultSet[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        resultSet[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        resultSet[MPSDefs.DB_TERMINATE_DATE] = '02022024'
        resultSet[MPSDefs.DB_CREATE_DATE] = '03032024'
        resultSet[MPSDefs.DB_LAST_MODIFIED] = '04042024'
        resultSet[MPSDefs.DB_LAST_MODIFIED_BY] = 'SYSTEM'
        resultSet[MPSDefs.DB_SOR_ID] = '5'
        resultSet[MPSDefs.DB_SERVICE_NICKNAME] = 'MySvc'
        resultSet[MPSDefs.DB_DEFAULT_ACCOUNT] = 'Y'
        resultSet[MPSDefs.DB_DATE_DEFAULT_EST] = '05052024'
        resultSet[MPSDefs.DB_CPNI_IMPACTED] = 'N'

        objStatusValidation.getStatusNameByCode('0') >> 'Enabled'
        objServiceValidation.getServiceDataById('10') >> null
        oDBHelper.getSorName('5') >> 'ATT'

        when:
        objGetInfoByMaskDBHelper.copyServiceData(userServiceHash, resultSet)

        then:
        userServiceHash[MPSDefs.DB_SOR_INVARIANT_ID] == '100'
        userServiceHash[MPSDefs.DB_SERVICE_ID] == '10'
        userServiceHash[MPSDefs.DB_SOR_NAME] == 'ATT'
        userServiceHash[MPSDefs.DB_SERVICE_NICKNAME] == 'MySvc'
        userServiceHash[MPSDefs.DB_DEFAULT_ACCOUNT] == 'Y'
        userServiceHash[MPSDefs.DB_CPNI_IMPACTED] == 'N'
        userServiceHash[MPSDefs.SERVICE_STATUS] == MPSDefs.ENABLED
    }

    def "copyServiceData populates service type fields when service data is present"() {
        given:
        HashMap userServiceHash = new HashMap()
        Map resultSet = new HashMap()
        resultSet[MPSDefs.DB_SOR_INVARIANT_ID] = '200'
        resultSet[MPSDefs.DB_PENDING_DISCONNECT_DATE] = null
        resultSet[MPSDefs.DB_SERVICE_ID] = '33'
        resultSet[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        resultSet[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        resultSet[MPSDefs.DB_TERMINATE_DATE] = null
        resultSet[MPSDefs.DB_CREATE_DATE] = '01012024'
        resultSet[MPSDefs.DB_LAST_MODIFIED] = '01012024'
        resultSet[MPSDefs.DB_LAST_MODIFIED_BY] = 'SYS'
        resultSet[MPSDefs.DB_SOR_ID] = '6'
        resultSet[MPSDefs.DB_SERVICE_NICKNAME] = null
        resultSet[MPSDefs.DB_DEFAULT_ACCOUNT] = 'N'
        resultSet[MPSDefs.DB_DATE_DEFAULT_EST] = null
        resultSet[MPSDefs.DB_CPNI_IMPACTED] = 'Y'

        HashMap hmServiceData = new HashMap()
        hmServiceData[MPSDefs.DB_SERVICE_TYPE] = 'R'
        hmServiceData[MPSDefs.DB_EMAIL_ELIGIBLE] = 'Y'
        hmServiceData[MPSDefs.DB_SERVICE_NAME] = 'TITAN'
        hmServiceData[MPSDefs.DB_ENTITY_TYPE] = 'MU'

        objStatusValidation.getStatusNameByCode('0') >> 'Enabled'
        objServiceValidation.getServiceDataById('33') >> hmServiceData
        oDBHelper.getSorName('6') >> 'TITAN_SOR'

        when:
        objGetInfoByMaskDBHelper.copyServiceData(userServiceHash, resultSet)

        then:
        userServiceHash[MPSDefs.DB_SERVICE_TYPE] == 'R'
        userServiceHash[MPSDefs.DB_EMAIL_ELIGIBLE] == 'Y'
        userServiceHash[MPSDefs.DB_SERVICE_NAME] == 'TITAN'
        userServiceHash[MPSDefs.DB_ENTITY_TYPE] == 'MU'
    }

    def "copyServiceData calculates TERMINATED status correctly"() {
        given:
        HashMap userServiceHash = new HashMap()
        Map resultSet = new HashMap()
        resultSet[MPSDefs.DB_SOR_INVARIANT_ID] = '300'
        resultSet[MPSDefs.DB_PENDING_DISCONNECT_DATE] = null
        resultSet[MPSDefs.DB_SERVICE_ID] = '10'
        resultSet[MPSDefs.DB_MEMBER_STATUS_CODE] = '1'
        resultSet[MPSDefs.DB_GROUP_STATUS_CODE] = '2'
        resultSet[MPSDefs.DB_TERMINATE_DATE] = '01012024'
        resultSet[MPSDefs.DB_CREATE_DATE] = '01012024'
        resultSet[MPSDefs.DB_LAST_MODIFIED] = '01012024'
        resultSet[MPSDefs.DB_LAST_MODIFIED_BY] = 'SYS'
        resultSet[MPSDefs.DB_SOR_ID] = '5'
        resultSet[MPSDefs.DB_SERVICE_NICKNAME] = null
        resultSet[MPSDefs.DB_DEFAULT_ACCOUNT] = null
        resultSet[MPSDefs.DB_DATE_DEFAULT_EST] = null
        resultSet[MPSDefs.DB_CPNI_IMPACTED] = null

        objStatusValidation.getStatusNameByCode('2') >> MPSDefs.TERMINATED
        objStatusValidation.getStatusNameByCode('1') >> MPSDefs.SUSPENDED
        objServiceValidation.getServiceDataById('10') >> new HashMap()
        oDBHelper.getSorName('5') >> 'NA'

        when:
        objGetInfoByMaskDBHelper.copyServiceData(userServiceHash, resultSet)

        then:
        userServiceHash[MPSDefs.SERVICE_STATUS] == MPSDefs.TERMINATED
    }

    // --- Tests for copyInstanceData method with roles and attributes ---

    def "copyInstanceData with matching roles populates roles list"() {
        given:
        HashMap instanceHash = new HashMap()
        Map resultSet = new HashMap()
        resultSet[MPSDefs.DB_SOR_INVARIANT_ID] = '500'
        resultSet[MPSDefs.DB_PENDING_DISCONNECT_DATE] = null
        resultSet[MPSDefs.DB_SERVICE_ID] = '33'
        resultSet[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        resultSet[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        resultSet[MPSDefs.DB_TERMINATE_DATE] = null
        resultSet[MPSDefs.DB_CREATE_DATE] = '01012024'
        resultSet[MPSDefs.DB_LAST_MODIFIED] = '01012024'
        resultSet[MPSDefs.DB_LAST_MODIFIED_BY] = 'SYS'
        resultSet[MPSDefs.DB_SOR_ID] = '6'
        resultSet[MPSDefs.DB_SERVICE_NICKNAME] = null
        resultSet[MPSDefs.DB_DEFAULT_ACCOUNT] = null
        resultSet[MPSDefs.DB_DATE_DEFAULT_EST] = null
        resultSet[MPSDefs.DB_CPNI_IMPACTED] = null
        resultSet[MPSDefs.DB_PARENT_SOR_ID] = '1'
        resultSet[MPSDefs.DB_PARENT_SOR_INVARIANT_ID] = '100'
        resultSet[MPSDefs.DB_UVERSE_SERVICE_IND] = 'Y'
        resultSet[MPSDefs.DB_OWNED_BY] = 'OWNER'
        resultSet[MPSDefs.DB_UNIFICATION_PENDING] = 'N'

        HashMap hmServiceData = new HashMap()
        hmServiceData[MPSDefs.DB_SERVICE_TYPE] = 'R'
        hmServiceData[MPSDefs.DB_EMAIL_ELIGIBLE] = 'Y'
        hmServiceData[MPSDefs.DB_SERVICE_NAME] = MPSDefs.TITAN_SERVICE
        hmServiceData[MPSDefs.DB_ENTITY_TYPE] = 'MU'

        HashMap hmMemberServiceRoles = new HashMap()
        ArrayList alRolesList = new ArrayList()
        HashMap roleEntry = new HashMap()
        roleEntry[MPSDefs.DB_SOR_INVARIANT_ID] = '500'
        alRolesList.add(roleEntry)
        hmMemberServiceRoles[MPSDefs.TITAN_SERVICE] = alRolesList

        objStatusValidation.getStatusNameByCode('0') >> 'Enabled'
        objServiceValidation.getServiceDataById('33') >> hmServiceData
        oDBHelper.getSorName('6') >> 'TITAN_SOR'

        when:
        objGetInfoByMaskDBHelper.copyInstanceData(instanceHash, resultSet, hmMemberServiceRoles, null)

        then:
        instanceHash[MPSDefs.DB_ROLES] != null
        ((ArrayList) instanceHash[MPSDefs.DB_ROLES]).size() == 1
    }

    def "copyInstanceData with non-matching roles does not populate roles"() {
        given:
        HashMap instanceHash = new HashMap()
        Map resultSet = new HashMap()
        resultSet[MPSDefs.DB_SOR_INVARIANT_ID] = '500'
        resultSet[MPSDefs.DB_PENDING_DISCONNECT_DATE] = null
        resultSet[MPSDefs.DB_SERVICE_ID] = '33'
        resultSet[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        resultSet[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        resultSet[MPSDefs.DB_TERMINATE_DATE] = null
        resultSet[MPSDefs.DB_CREATE_DATE] = '01012024'
        resultSet[MPSDefs.DB_LAST_MODIFIED] = '01012024'
        resultSet[MPSDefs.DB_LAST_MODIFIED_BY] = 'SYS'
        resultSet[MPSDefs.DB_SOR_ID] = '6'
        resultSet[MPSDefs.DB_SERVICE_NICKNAME] = null
        resultSet[MPSDefs.DB_DEFAULT_ACCOUNT] = null
        resultSet[MPSDefs.DB_DATE_DEFAULT_EST] = null
        resultSet[MPSDefs.DB_CPNI_IMPACTED] = null
        resultSet[MPSDefs.DB_PARENT_SOR_ID] = '1'
        resultSet[MPSDefs.DB_PARENT_SOR_INVARIANT_ID] = '100'
        resultSet[MPSDefs.DB_UVERSE_SERVICE_IND] = 'Y'
        resultSet[MPSDefs.DB_OWNED_BY] = 'OWNER'
        resultSet[MPSDefs.DB_UNIFICATION_PENDING] = 'N'

        HashMap hmServiceData = new HashMap()
        hmServiceData[MPSDefs.DB_SERVICE_TYPE] = 'R'
        hmServiceData[MPSDefs.DB_EMAIL_ELIGIBLE] = 'Y'
        hmServiceData[MPSDefs.DB_SERVICE_NAME] = MPSDefs.TITAN_SERVICE
        hmServiceData[MPSDefs.DB_ENTITY_TYPE] = 'MU'

        HashMap hmMemberServiceRoles = new HashMap()
        ArrayList alRolesList = new ArrayList()
        HashMap roleEntry = new HashMap()
        roleEntry[MPSDefs.DB_SOR_INVARIANT_ID] = '999'
        alRolesList.add(roleEntry)
        hmMemberServiceRoles[MPSDefs.TITAN_SERVICE] = alRolesList

        objStatusValidation.getStatusNameByCode('0') >> 'Enabled'
        objServiceValidation.getServiceDataById('33') >> hmServiceData
        oDBHelper.getSorName('6') >> 'TITAN_SOR'

        when:
        objGetInfoByMaskDBHelper.copyInstanceData(instanceHash, resultSet, hmMemberServiceRoles, null)

        then:
        instanceHash[MPSDefs.DB_ROLES] == null
    }

    def "copyInstanceData with matching service attributes populates attributes"() {
        given:
        HashMap instanceHash = new HashMap()
        Map resultSet = new HashMap()
        resultSet[MPSDefs.DB_SOR_INVARIANT_ID] = '500'
        resultSet[MPSDefs.DB_PENDING_DISCONNECT_DATE] = null
        resultSet[MPSDefs.DB_SERVICE_ID] = '33'
        resultSet[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        resultSet[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        resultSet[MPSDefs.DB_TERMINATE_DATE] = null
        resultSet[MPSDefs.DB_CREATE_DATE] = '01012024'
        resultSet[MPSDefs.DB_LAST_MODIFIED] = '01012024'
        resultSet[MPSDefs.DB_LAST_MODIFIED_BY] = 'SYS'
        resultSet[MPSDefs.DB_SOR_ID] = '6'
        resultSet[MPSDefs.DB_SERVICE_NICKNAME] = null
        resultSet[MPSDefs.DB_DEFAULT_ACCOUNT] = null
        resultSet[MPSDefs.DB_DATE_DEFAULT_EST] = null
        resultSet[MPSDefs.DB_CPNI_IMPACTED] = null
        resultSet[MPSDefs.DB_PARENT_SOR_ID] = '1'
        resultSet[MPSDefs.DB_PARENT_SOR_INVARIANT_ID] = '100'
        resultSet[MPSDefs.DB_UVERSE_SERVICE_IND] = 'Y'
        resultSet[MPSDefs.DB_OWNED_BY] = 'OWNER'
        resultSet[MPSDefs.DB_UNIFICATION_PENDING] = 'N'

        HashMap hmServiceData = new HashMap()
        hmServiceData[MPSDefs.DB_SERVICE_TYPE] = 'R'
        hmServiceData[MPSDefs.DB_EMAIL_ELIGIBLE] = 'Y'
        hmServiceData[MPSDefs.DB_SERVICE_NAME] = MPSDefs.TITAN_SERVICE
        hmServiceData[MPSDefs.DB_ENTITY_TYPE] = 'MU'

        HashMap hmMemberServiceAttributes = new HashMap()
        HashMap svcAttrByInvId = new HashMap()
        ArrayList attrList = new ArrayList()
        attrList.add(new HashMap([attr_name: 'test_attr', attr_value: 'test_val']))
        svcAttrByInvId['500'] = attrList
        hmMemberServiceAttributes[MPSDefs.TITAN_SERVICE] = svcAttrByInvId

        objStatusValidation.getStatusNameByCode('0') >> 'Enabled'
        objServiceValidation.getServiceDataById('33') >> hmServiceData
        oDBHelper.getSorName('6') >> 'TITAN_SOR'

        when:
        objGetInfoByMaskDBHelper.copyInstanceData(instanceHash, resultSet, null, hmMemberServiceAttributes)

        then:
        instanceHash[MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE] != null
        ((ArrayList) instanceHash[MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE]).size() == 1
    }

    def "copyInstanceData with empty service data map"() {
        given:
        HashMap instanceHash = new HashMap()
        Map resultSet = new HashMap()
        resultSet[MPSDefs.DB_SOR_INVARIANT_ID] = '300'
        resultSet[MPSDefs.DB_PENDING_DISCONNECT_DATE] = null
        resultSet[MPSDefs.DB_SERVICE_ID] = '10'
        resultSet[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        resultSet[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        resultSet[MPSDefs.DB_TERMINATE_DATE] = null
        resultSet[MPSDefs.DB_CREATE_DATE] = '01012024'
        resultSet[MPSDefs.DB_LAST_MODIFIED] = '01012024'
        resultSet[MPSDefs.DB_LAST_MODIFIED_BY] = 'SYS'
        resultSet[MPSDefs.DB_SOR_ID] = '5'
        resultSet[MPSDefs.DB_SERVICE_NICKNAME] = 'nick'
        resultSet[MPSDefs.DB_DEFAULT_ACCOUNT] = 'N'
        resultSet[MPSDefs.DB_DATE_DEFAULT_EST] = null
        resultSet[MPSDefs.DB_CPNI_IMPACTED] = 'N'
        resultSet[MPSDefs.DB_PARENT_SOR_ID] = null
        resultSet[MPSDefs.DB_PARENT_SOR_INVARIANT_ID] = null
        resultSet[MPSDefs.DB_UVERSE_SERVICE_IND] = null
        resultSet[MPSDefs.DB_OWNED_BY] = null
        resultSet[MPSDefs.DB_UNIFICATION_PENDING] = null

        objStatusValidation.getStatusNameByCode('0') >> 'Enabled'
        objServiceValidation.getServiceDataById('10') >> new HashMap()
        oDBHelper.getSorName('5') >> 'NA'

        when:
        objGetInfoByMaskDBHelper.copyInstanceData(instanceHash, resultSet, null, null)

        then:
        instanceHash[MPSDefs.DB_SERVICE_TYPE] == null
        instanceHash[MPSDefs.DB_SERVICE_NAME] == null
        instanceHash[MPSDefs.INSTANCE_STATUS] == MPSDefs.ENABLED
    }

    // --- Tests for getInfoByMask with QFLO mask ---

    def "get info by mask with QFLO mask success"() throws Exception {
        given:
        alDataMasks.add('AA')
        alDataMasks.add('QFLO')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmStatusTMS = new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        HashMap<String, Object> hmFraudResult = new HashMap<String, Object>()
        hmFraudResult[MPSDefs.APP_STATUS_CODE] = MPSDefs.MPS_SUCCESS
        hmFraudResult[MPSDefs.DB_USER_LOCK_LEVEL] = '2'
        hmFraudResult[MPSDefs.DB_USER_LOCK_REASON] = 'SUSPECT'
        hmFraudResult[MPSDefs.DB_FRAUD_AGENT] = 'AGENT1'
        hmFraudResult[MPSDefs.DB_LAST_MODIFIED_BY] = 'SYS'
        hmFraudResult[MPSDefs.DB_LAST_MODIFIED] = '01012024'
        hmFraudResult[MPSDefs.DB_CREATE_DATE] = '01012024'

        oFraudLockDBHelper.queryUserFraudLock(_ as HashMap<String, Object>) >> hmFraudResult
        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'

        HashMap<String, Object> hmQueryAllResponse2 = new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '10'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        List allResp = new ArrayList()
        allResp.add(hmQueryAllResponse2)
        jdbcTemplate1.queryForList(_, _) >> allResp
        oDBHelper.getServiceName(_) >> MPSDefs.DSL_SERVICE

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
    }

    def "get info by mask with QFLO mask record not found"() throws Exception {
        given:
        alDataMasks.add('AA')
        alDataMasks.add('QFLO')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmStatusTMS = new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        HashMap<String, Object> hmFraudResult = new HashMap<String, Object>()
        hmFraudResult[MPSDefs.APP_STATUS_CODE] = CErrorDefs.ERR_REC_NOT_FOUND

        oFraudLockDBHelper.queryUserFraudLock(_ as HashMap<String, Object>) >> hmFraudResult
        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'

        HashMap<String, Object> hmQueryAllResponse2 = new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '10'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        List allResp = new ArrayList()
        allResp.add(hmQueryAllResponse2)
        jdbcTemplate1.queryForList(_, _) >> allResp
        oDBHelper.getServiceName(_) >> MPSDefs.DSL_SERVICE

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
    }

    // --- Tests for getInfoByMask with SQ mask and security question data ---

    def "get info by mask with SQ mask and non-null security question data"() throws Exception {
        given:
        alDataMasks.add('SQ')
        alDataMasks.add('AA')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        hmQueryResponse['security_question_id'] = '1'
        hmQueryResponse[MPSDefs.DB_SECURITY_QUESTION_ID_1] = '2'
        hmQueryResponse[MPSDefs.DB_SECURITY_QUESTION_ID_2] = '3'
        hmQueryResponse[MPSDefs.DB_BIRTHDATE_VENC] = 'enc_birth'
        hmQueryResponse[MPSDefs.DB_PASSCODE_VENC] = 'enc_pass'
        hmQueryResponse[MPSDefs.DB_SECURITY_ANSWER_VENC] = 'enc_ans'
        hmQueryResponse[MPSDefs.DB_LAST_FOUR_SSN] = '1234'
        hmQueryResponse[MPSDefs.DB_SECURITY_ANSWER_1] = 'ans1'
        hmQueryResponse[MPSDefs.DB_SECURITY_ANSWER_1_VENC] = 'enc_ans1'
        hmQueryResponse[MPSDefs.DB_SECURITY_ANSWER_2] = 'ans2'
        hmQueryResponse[MPSDefs.DB_SECURITY_ANSWER_2_VENC] = 'enc_ans2'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmStatusTMS = new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        HashMap hmSecQ = new HashMap()
        hmSecQ[MPSDefs.DB_SECURITY_QUESTION] = 'What is your pet name?'
        hmSecQ[MPSDefs.DB_SECURITY_QUESTION_TYPE] = 'custom'
        hmSecQ[MPSDefs.DB_SECURITY_QUESTION_ACTIVE] = 'Y'

        HashMap hmSecQ1 = new HashMap()
        hmSecQ1[MPSDefs.DB_SECURITY_QUESTION] = 'What city were you born?'
        hmSecQ1[MPSDefs.DB_SECURITY_QUESTION_TYPE] = 'standard'
        hmSecQ1[MPSDefs.DB_SECURITY_QUESTION_ACTIVE] = 'Y'

        HashMap hmSecQ2 = new HashMap()
        hmSecQ2[MPSDefs.DB_SECURITY_QUESTION] = 'What is your school?'
        hmSecQ2[MPSDefs.DB_SECURITY_QUESTION_TYPE] = 'standard'
        hmSecQ2[MPSDefs.DB_SECURITY_QUESTION_ACTIVE] = 'N'

        objSecurityQuestionValidation.getSecurityQuestionDataById('1') >> hmSecQ
        objSecurityQuestionValidation.getSecurityQuestionDataById('2') >> hmSecQ1
        objSecurityQuestionValidation.getSecurityQuestionDataById('3') >> hmSecQ2

        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'

        HashMap<String, Object> hmQueryAllResponse2 = new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '10'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        List allResp = new ArrayList()
        allResp.add(hmQueryAllResponse2)
        jdbcTemplate1.queryForList(_, _) >> allResp
        oDBHelper.getServiceName(_) >> MPSDefs.DSL_SERVICE

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
    }

    def "get info by mask with SQ mask and null security question data"() throws Exception {
        given:
        alDataMasks.add('SQ')
        alDataMasks.add('AA')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        hmQueryResponse['security_question_id'] = '1'
        hmQueryResponse[MPSDefs.DB_SECURITY_QUESTION_ID_1] = '2'
        hmQueryResponse[MPSDefs.DB_SECURITY_QUESTION_ID_2] = '3'
        hmQueryResponse[MPSDefs.DB_BIRTHDATE_VENC] = null
        hmQueryResponse[MPSDefs.DB_PASSCODE_VENC] = null
        hmQueryResponse[MPSDefs.DB_SECURITY_ANSWER_VENC] = null
        hmQueryResponse[MPSDefs.DB_LAST_FOUR_SSN] = null
        hmQueryResponse[MPSDefs.DB_SECURITY_ANSWER_1] = null
        hmQueryResponse[MPSDefs.DB_SECURITY_ANSWER_1_VENC] = null
        hmQueryResponse[MPSDefs.DB_SECURITY_ANSWER_2] = null
        hmQueryResponse[MPSDefs.DB_SECURITY_ANSWER_2_VENC] = null
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmStatusTMS = new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        objSecurityQuestionValidation.getSecurityQuestionDataById(_) >> null

        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'

        HashMap<String, Object> hmQueryAllResponse2 = new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '10'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        List allResp = new ArrayList()
        allResp.add(hmQueryAllResponse2)
        jdbcTemplate1.queryForList(_, _) >> allResp
        oDBHelper.getServiceName(_) >> MPSDefs.DSL_SERVICE

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
    }

    // --- Tests for getInfoByMask with AEP mask success ---

    def "get info by mask with AEP mask success path"() throws Exception {
        given:
        alDataMasks.add('AA')
        alDataMasks.add('AEP')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmStatusTMS = new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        HashMap<String, Object> hmEmailPwdResult = new HashMap<String, Object>()
        hmEmailPwdResult[MPSDefs.APP_STATUS_CODE] = MPSDefs.MPS_SUCCESS
        hmEmailPwdResult[MPSDefs.DB_APPEMAILPASSWORD_TABLE] = new ArrayList()

        oEmailAppPasswordDBHelper.queryEmailAppPwd(_) >> hmEmailPwdResult
        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'

        HashMap<String, Object> hmQueryAllResponse2 = new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '10'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        List allResp = new ArrayList()
        allResp.add(hmQueryAllResponse2)
        jdbcTemplate1.queryForList(_, _) >> allResp
        oDBHelper.getServiceName(_) >> MPSDefs.DSL_SERVICE

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
    }

    def "get info by mask with AEP mask record not found"() throws Exception {
        given:
        alDataMasks.add('AA')
        alDataMasks.add('AEP')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmStatusTMS = new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        HashMap<String, Object> hmEmailPwdResult = new HashMap<String, Object>()
        hmEmailPwdResult[MPSDefs.APP_STATUS_CODE] = CErrorDefs.ERR_REC_NOT_FOUND

        oEmailAppPasswordDBHelper.queryEmailAppPwd(_) >> hmEmailPwdResult
        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'

        HashMap<String, Object> hmQueryAllResponse2 = new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '10'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        List allResp = new ArrayList()
        allResp.add(hmQueryAllResponse2)
        jdbcTemplate1.queryForList(_, _) >> allResp
        oDBHelper.getServiceName(_) >> MPSDefs.DSL_SERVICE

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
    }

    // --- Tests for voltage decrypt failure ---

    def "get info by mask returns error when voltage decrypt fails"() throws Exception {
        given:
        alDataMasks.add('AA')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmVoltageError = new HashMap<String, Object>()
        hmVoltageError[CErrorDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.ERR_SYS_APPL
        hmVoltageError[CommonDefs.COMMON_APP_INFO] = 'Voltage decryption failed'

        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmVoltageError
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
        hmResponse[CErrorDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_SYS_APPL
    }

    // --- Tests for no rows returned ---

    def "get info by mask returns error when no rows found"() throws Exception {
        given:
        alDataMasks.add('AA')
        hmGetInfoInp['dataMask'] = alDataMasks
        jdbcTemplate.queryForList(_, _) >> new ArrayList()

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
        hmResponse[CommonDefs.COMMON_APP_INFO] != null
    }

    // --- Tests for AS-only mask path ---

    def "get info by mask with AS only mask and non-getSlidInfo caller"() throws Exception {
        given:
        alDataMasks.remove('AU')
        alDataMasks.add('AS')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.SOURCE_CALLER] = 'OTHER_CALLER'
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)

        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmStatusTMS = new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        HashMap<String, Object> hmQueryAllResponse2 = new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '12'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        List allResp = new ArrayList()
        allResp.add(hmQueryAllResponse2)

        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        jdbcTemplate1.queryForList(_, _) >> allResp
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'
        oDBHelper.getServiceName(_) >> MPSDefs.PORTAL_SERVICE
        objServiceValidation.getServiceDataById(_) >> new HashMap()

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
    }

    // --- Test for portal service path ---

    def "get info by mask with portal service populates portal fields"() throws Exception {
        given:
        alDataMasks.add('AA')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)

        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmStatusTMS = new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        HashMap<String, Object> hmQueryAllResponse2 = new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_PORTAL_PROVIDER] = 'ATT'
        hmQueryAllResponse2[MPSDefs.DB_PLITE_IND] = 'Y'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '5'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        List allResp = new ArrayList()
        allResp.add(hmQueryAllResponse2)

        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        jdbcTemplate1.queryForList(_, _) >> allResp
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'
        oDBHelper.getServiceName(_) >> MPSDefs.PORTAL_SERVICE
        objServiceValidation.getServiceDataById(_) >> new HashMap()

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
    }

    // --- Test for AA and AS combined mask ---

    def "get info by mask with both AA and AS masks uses queryAllServices"() throws Exception {
        given:
        alDataMasks.add('AA')
        alDataMasks.add('AS')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmStatusTMS = new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        HashMap<String, Object> hmQueryAllResponse2 = new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '10'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        List allResp = new ArrayList()
        allResp.add(hmQueryAllResponse2)

        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        jdbcTemplate1.queryForList(_, _) >> allResp
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'
        oDBHelper.getServiceName(_) >> MPSDefs.DSL_SERVICE
        objServiceValidation.getServiceDataById(_) >> new HashMap()

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
    }

    // --- Test for RESERVED_STATE skipping service queries ---

    def "get info by mask with reserved state skips service queries"() throws Exception {
        given:
        alDataMasks.add('AA')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.RESERVED_STATE
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmStatusTMS = new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
        0 * jdbcTemplate1.queryForList(_, _)
    }

    // --- Test for generic password encryption type ---

    def "get info by mask with generic password encryption type set"() throws Exception {
        given:
        PropertyManager.setProperty("MSCONFIG", "GENERIC_PASSWORD_ENCRYPTION_TYPE", "SSHA256")
        def helperWithGenPwd = new GetInfoByMaskDBHelper()
        helperWithGenPwd.jdbcTemplate = jdbcTemplate
        helperWithGenPwd.jdbcTemplate1 = jdbcTemplate1
        helperWithGenPwd.oDBHelper = oDBHelper
        helperWithGenPwd.objServiceValidation = objServiceValidation
        helperWithGenPwd.objStatusValidation = objStatusValidation
        helperWithGenPwd.oProcessVoltageHelper = oProcessVoltageHelper
        helperWithGenPwd.oMPSDB_EmailAppPassword_H = oEmailAppPasswordDBHelper
        helperWithGenPwd.oMPSDB_GetMemberRoles_H = oGetMemberRolesDBHelper
        helperWithGenPwd.objSecurityQuestionValidation = objSecurityQuestionValidation
        helperWithGenPwd.oFraudLockDBHelper = oFraudLockDBHelper
        helperWithGenPwd.oGetMemSvcAttr = oGetMemSvcAttr
        org.springframework.test.util.ReflectionTestUtils.setField(helperWithGenPwd, 'genericPasswordEncryptionType', 'SSHA256')

        alDataMasks.add('AA')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        hmQueryResponse[MPSDefs.DB_GEN_PASSWORD_VENC] = 'enc_gen_pwd'
        hmQueryResponse[MPSDefs.DB_GEN_PASSWORD_TYPE] = 'SSHA256'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmStatusTMS = new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        HashMap<String, Object> hmFraudResult = new HashMap<String, Object>()
        hmFraudResult[MPSDefs.APP_STATUS_CODE] = MPSDefs.MPS_SUCCESS
        hmFraudResult[MPSDefs.DB_USER_LOCK_LEVEL] = '1'
        hmFraudResult[MPSDefs.DB_USER_LOCK_REASON] = 'FRAUD'
        hmFraudResult[MPSDefs.DB_FRAUD_AGENT] = 'AGT'
        hmFraudResult[MPSDefs.DB_LAST_MODIFIED_BY] = 'SYS'
        hmFraudResult[MPSDefs.DB_LAST_MODIFIED] = '01012024'
        hmFraudResult[MPSDefs.DB_CREATE_DATE] = '01012024'
        oFraudLockDBHelper.queryUserFraudLock(_ as HashMap<String, Object>) >> hmFraudResult

        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'

        HashMap<String, Object> hmQueryAllResponse2 = new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '10'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        List allResp = new ArrayList()
        allResp.add(hmQueryAllResponse2)
        jdbcTemplate1.queryForList(_, _) >> allResp
        oDBHelper.getServiceName(_) >> MPSDefs.DSL_SERVICE

        when:
        hmResponse = helperWithGenPwd.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null

        cleanup:
        PropertyManager.setProperty("MSCONFIG", "GENERIC_PASSWORD_ENCRYPTION_TYPE", null)
    }

    // --- Test for getInfoByMask with member service attribute query ---

    def "get info by mask with member service attribute flag"() throws Exception {
        given:
        alDataMasks.add('AA')
        alDataMasks.add('RI')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG] = MPSDefs.YES
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)

        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        hmQueryResponse[MPSDefs.DB_INSTANCE_ID] = '2'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmStatusTMS = new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        HashMap<String, Object> hmQueryAllResponse2 = new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '2'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '33'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_SOR_NAME] = 'NA'
        List allResp = new ArrayList()
        allResp.add(hmQueryAllResponse2)

        HashMap<String, Object> hmServiceData = new HashMap<String, Object>()
        hmServiceData[MPSDefs.DB_SERVICE_TYPE] = 'R'
        hmServiceData[MPSDefs.DB_EMAIL_ELIGIBLE] = 'Y'
        hmServiceData[MPSDefs.DB_SERVICE_NAME] = MPSDefs.TITAN_SERVICE
        hmServiceData[MPSDefs.DB_ENTITY_TYPE] = 'MU'

        HashMap<String, Object> hmRolesResponse = new HashMap<String, Object>()
        hmRolesResponse[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        HashMap<String, Object> hmSvcAttrResp = new HashMap<String, Object>()
        hmSvcAttrResp[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        hmSvcAttrResp[MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE] = new HashMap()

        oGetMemSvcAttr.getServiceAttributesByMemberNum(_) >> hmSvcAttrResp
        oGetMemberRolesDBHelper.getMemberServiceRoles(_) >> hmRolesResponse

        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        jdbcTemplate1.queryForList(_, _) >> allResp
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'
        oDBHelper.getServiceName(_) >> MPSDefs.TITAN_SERVICE
        objServiceValidation.getServiceDataById(_) >> hmServiceData

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
    }

    // --- Test for getInfoByMask with roles returning null ---

    def "get info by mask returns error when roles helper returns null"() throws Exception {
        given:
        alDataMasks.add('AA')
        alDataMasks.add('RI')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)

        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        hmQueryResponse[MPSDefs.DB_INSTANCE_ID] = '2'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmStatusTMS = new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        HashMap<String, Object> hmQueryAllResponse2 = new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '2'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '33'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_SOR_NAME] = 'NA'
        List allResp = new ArrayList()
        allResp.add(hmQueryAllResponse2)

        HashMap<String, Object> hmServiceData = new HashMap<String, Object>()
        hmServiceData[MPSDefs.DB_SERVICE_TYPE] = 'R'
        hmServiceData[MPSDefs.DB_EMAIL_ELIGIBLE] = 'Y'
        hmServiceData[MPSDefs.DB_SERVICE_NAME] = MPSDefs.TITAN_SERVICE
        hmServiceData[MPSDefs.DB_ENTITY_TYPE] = 'MU'

        oGetMemberRolesDBHelper.getMemberServiceRoles(_) >> null

        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        jdbcTemplate1.queryForList(_, _) >> allResp
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'
        oDBHelper.getServiceName(_) >> MPSDefs.TITAN_SERVICE
        objServiceValidation.getServiceDataById(_) >> hmServiceData

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
    }

    // --- Test for getInfoByMask with member svc attr returning null ---

    def "get info by mask returns error when member svc attr helper returns null"() throws Exception {
        given:
        alDataMasks.add('AA')
        alDataMasks.add('RI')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = MPSDefs.SLID_DUM
        hmGetInfoInp[MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG] = MPSDefs.YES
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NUM)
        hmGetInfoInp.remove(MPSDefs.DB_SLID_MEMBER_NUM)

        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        hmQueryResponse[MPSDefs.DB_INSTANCE_ID] = '2'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmStatusTMS = new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        HashMap<String, Object> hmQueryAllResponse2 = new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '2'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '33'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_SOR_NAME] = 'NA'
        List allResp = new ArrayList()
        allResp.add(hmQueryAllResponse2)

        HashMap<String, Object> hmServiceData = new HashMap<String, Object>()
        hmServiceData[MPSDefs.DB_SERVICE_TYPE] = 'R'
        hmServiceData[MPSDefs.DB_EMAIL_ELIGIBLE] = 'Y'
        hmServiceData[MPSDefs.DB_SERVICE_NAME] = MPSDefs.TITAN_SERVICE
        hmServiceData[MPSDefs.DB_ENTITY_TYPE] = 'MU'

        HashMap<String, Object> hmRolesResponse = new HashMap<String, Object>()
        hmRolesResponse[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        oGetMemberRolesDBHelper.getMemberServiceRoles(_) >> hmRolesResponse
        oGetMemSvcAttr.getServiceAttributesByMemberNum(_) >> null

        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        jdbcTemplate1.queryForList(_, _) >> allResp
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'
        oDBHelper.getServiceName(_) >> MPSDefs.TITAN_SERVICE
        objServiceValidation.getServiceDataById(_) >> hmServiceData

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
    }

    // --- Test for getInfoByMask with exception ---

    def "get info by mask handles general exception gracefully"() throws Exception {
        given:
        alDataMasks.add('AA')
        hmGetInfoInp['dataMask'] = alDataMasks
        jdbcTemplate.queryForList(_, _) >> { throw new RuntimeException("DB connection failed") }

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
    }

    // --- Test for getInfoByMask querying by member_num ---

    def "get info by mask with member_num query path"() throws Exception {
        given:
        alDataMasks.add('AA')
        hmGetInfoInp['dataMask'] = alDataMasks
        hmGetInfoInp[MPSDefs.DB_MEMBER_NUM] = '123456'
        hmGetInfoInp.remove(MPSDefs.DB_MEMBER_NAME)
        hmGetInfoInp.remove(MPSDefs.DB_DOMAIN_NAME)

        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '5'
        alQueryresponse.add(hmQueryResponse)

        HashMap<String, Object> hmStatusTMS = new HashMap<String, Object>()
        hmStatusTMS[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'

        HashMap<String, Object> hmQueryAllResponse2 = new HashMap<String, Object>()
        hmQueryAllResponse2[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryAllResponse2[MPSDefs.DB_SERVICE_ID] = '10'
        hmQueryAllResponse2[MPSDefs.DB_GROUP_STATUS_CODE] = '0'
        hmQueryAllResponse2[MPSDefs.DB_MEMBER_STATUS_CODE] = '0'
        List allResp = new ArrayList()
        allResp.add(hmQueryAllResponse2)

        jdbcTemplate.queryForList(_, _) >> alQueryresponse
        jdbcTemplate1.queryForList(_, _) >> allResp
        oProcessVoltageHelper.voltageDecryptSPIFields(_) >> hmStatusTMS
        oDBHelper.getAccessName(_) >> 'att.net'
        oDBHelper.getSorName(_) >> 'NA'
        oDBHelper.getDomainName(_) >> 'att.net'
        objStatusValidation.getStatusNameByCode(_) >> 'Enabled'
        oDBHelper.getServiceName(_) >> MPSDefs.DSL_SERVICE

        when:
        hmResponse = objGetInfoByMaskDBHelper.getInfoByMask(hmGetInfoInp)

        then:
        hmResponse != null
    }
}
