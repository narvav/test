package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraph.commons.integration.CGRestClientWrapper
import com.att.idp.idgraph.commons.integration.CLMRestClient
import com.att.idp.idgraph.commons.integration.model.CLMNotificationRequest
import com.att.idp.idgraph.commons.integration.model.CLMNotificationResponse
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetAssociatedMembersDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetInfoByMaskDBHelper
import com.att.idp.idgraphuserregistrationms.queue.message.helpers.RetriggerQARQueueHelper
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.*
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ArrayNode
import com.fasterxml.jackson.databind.node.ObjectNode
import org.spockframework.util.Assert
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.ws.rs.core.Response
import spock.lang.Unroll


class RetriggerQARHelperTest extends Specification {

    def oRetriggerQARHelper=new RetriggerQARHelper();

    GetAssociatedMembersDBHelper ObjMpsdbGetAssociatedMemberH=Mock(GetAssociatedMembersDBHelper)

    GetInfoByMaskDBHelper oGetInfoByMask=Mock(GetInfoByMaskDBHelper)

    CGRestClientWrapper restClientObj=Mock(CGRestClientWrapper)

    RetriggerQARQueueHelper queueHelperObj=Mock(RetriggerQARQueueHelper)
    FeatureManagerHelper featureManager = Mock(FeatureManagerHelper)
    CLMRestClient clmRestClient = Mock(CLMRestClient)

    HashMap hmInput = new HashMap()
    HashMap hmSuccessResponse = new HashMap()
    HashMap hmErrorResponse = new HashMap()

    private Map hmResult = CommonUtil.hashMap
    private String stAppInfo
    private String stAppStatusCode
    private String stAppStatusMsg
    private String stAppCategoryCode

    HashMap services = new HashMap()
    HashMap hmMobility = new HashMap()
    HashMap ban = new HashMap()
    HashMap sor_info = new HashMap()
    ArrayList role = new ArrayList()
    HashMap assocMemdetails = new HashMap()
    HashMap assocMemdetails2 = new HashMap()
    HashMap hmGetAssociatedMembersInp = new HashMap()
    ArrayList assocMemdetailsValue = new ArrayList<>()
    private HashMap assocMem = new HashMap()
    ArrayList alDataMask = CommonUtil.arrayList
    HashMap hmGetInfoInp = new HashMap()
    HashMap hmCGResponse = new HashMap()
    HashMap hmInputTitan = new HashMap()
    HashMap hmGetAssociatedMembersInpTitan = new HashMap()
    HashMap assocMemdetailsTitan = new HashMap()
    HashMap assocMemTitan = new HashMap()
    HashMap hmGetInfoTitan = new HashMap()
    HashMap hmTitanBan = new HashMap()
    HashMap assocMemTitanBanandAccount = new HashMap()

    HashMap hmNoContactAssocMem = new HashMap()

    ArrayList dbusInput = CommonUtil.arrayList


    def setup() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {

        oRetriggerQARHelper.getAssociatedMembersDBHelperObj=ObjMpsdbGetAssociatedMemberH
        oRetriggerQARHelper.cgRestClientObj=restClientObj
        oRetriggerQARHelper.getInfoByMaskDBHelperObj=oGetInfoByMask
        oRetriggerQARHelper.retriggerQARQueueHelperObj=queueHelperObj
        oRetriggerQARHelper.clmRestClient = clmRestClient
        oRetriggerQARHelper.featureManager = featureManager

        hmResult = null

        hmSuccessResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        hmErrorResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_LENGTH_NUM, 'Error')

        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.IS_EXTERNAL_CALL] = 'Y'
        hmInput[CommonDefs.TRANSACTION_NAME] = 'RetriggerQAR'
        hmInput[CommonDefs.ACCESS_ID] = 'qay_test013'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInput[CommonDefs.BAN] = '121321113'

        role.add(sor_info)
        sor_info['sor_name'] = 'MO'
        sor_info['service_name'] = 'MOBILITY'
        sor_info['sor_id'] = '13'
        sor_info['role_name'] = 'AUTHORIZEDUSER'
        sor_info['service_id'] = '32'
        sor_info['role_id'] = '5'
        sor_info['create_date'] = '05022021'
        sor_info['last_modified'] = '05022021'

        ban['roles'] = role
        ban['create_date'] = '05022021 00:17:38'
        ban['last_modified'] = '05022021 00:17:39'
        ban['sor_name'] = 'MO'
        ban['service_name'] = 'MOBILITY'
        ban['instance_id'] = '121321113'
        ban['sor_invariant_id'] = '121321113'
        ban['sor_id'] = '13'
        hmMobility['121321113'] = ban
        services['MOBILITY'] = hmMobility

        assocMemdetails['parent_name'] = 'qay_khusko013'
        assocMemdetails['appStatusMsg'] = 'SUCCESS'
        assocMemdetails['account_type'] = 'R'
        assocMemdetails['services'] = services
        assocMemdetails['appStatusCode'] = '0'
        assocMemdetails['contact_email'] = 'qay_khushyt5@gmail.com'

        assocMemdetailsValue.add(assocMemdetails)
        assocMem['associatedMembers'] = assocMemdetailsValue
        assocMem['appStatusMsg'] = 'SUCCESS'
        assocMem['appCategoryCode'] = '0'
        assocMem['appInfo'] = 'Success'
        assocMem['appStatusCode'] = '0'

        ArrayList queryRolesInfoFlag = new ArrayList()
        queryRolesInfoFlag.add('ALL')
        hmGetAssociatedMembersInp['queryRolesInfoFlag'] = queryRolesInfoFlag
        hmGetAssociatedMembersInp['service_type'] = 'MOBILITY'
        hmGetAssociatedMembersInp['sor_invariant_id1'] = '121321113'
        hmGetAssociatedMembersInp['querySlidInfo'] = 'Y'

        hmGetInfoInp[MPSDefs.DB_MEMBER_NAME] = hmInput[CommonDefs.ACCESS_ID]
        hmGetInfoInp[MPSDefs.DB_DOMAIN_NAME] = CommonDefs.SLID_DUM
        hmGetInfoInp[CommonDefs.DATA_MASK] = alDataMask
        hmGetInfoInp['queryMemberServiceAttributes'] = 'Y'
        alDataMask.add('AU')
        alDataMask.add('AA')
        alDataMask.add('AS')
        alDataMask.add('RI')

        // response
		HashMap hmEmail = new HashMap()
        HashMap hmAccount = new HashMap()
        HashMap hmContact = new HashMap()
        //HashMap subscriberNumber = new HashMap();
		
		HashMap hmCBRInfo =  new HashMap()
        hmCBRInfo[CommonDefs.PHONE_NUMBER] = '9149140004'
        ObjectMapper mapper = new ObjectMapper()
        ArrayNode subscriber = mapper.createArrayNode()

        hmEmail['emailAddress'] = 'aaa@aaa.com'
        hmEmail['effectiveDate'] = '2017-08-22Z'

        hmContact[CommonDefs.EMAIL] = hmEmail
        hmContact[CommonDefs.CBR_INFO] = hmCBRInfo
        ObjectNode subscriberNumber = mapper.createObjectNode()
        subscriberNumber.put('subscriberId', '121321113')
        subscriberNumber.put('status', 'A')
        subscriber.add(subscriberNumber)

        hmAccount['contact'] = hmContact
        hmAccount['primaryAccountHolder'] = '123454'

        hmCGResponse['accounts'] = hmAccount
        hmCGResponse['appStatusCode'] = '0'
        hmCGResponse['subscribers'] = subscriber
        hmCGResponse['appInfo'] = 'SUCCESS'
        // getSlidInfo for TITAN
		
		//input
        hmInputTitan[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInputTitan[CommonDefs.IS_EXTERNAL_CALL] = 'Y'
        hmInputTitan[CommonDefs.TRANSACTION_NAME] = 'RetriggerQAR'
        hmInputTitan[CommonDefs.ACCESS_ID] = 'qay_jenny105'
        hmInputTitan[CommonDefs.ACCOUNT_TYPE] = 'TITAN'
        hmInputTitan[CommonDefs.BAN] = '100889099'

        hmGetInfoTitan['domain_name'] = 'slid.dum'
        hmGetInfoTitan['queryMemberServiceAttributes'] = 'Y'
        hmGetInfoTitan['dataMask'] = alDataMask
        hmGetInfoTitan['member_name'] = 'qay_jenny105'

        HashMap hmTitan = new HashMap()
        HashMap hmRoleTitan = new HashMap()
        HashMap serviceTitan = new HashMap()
        ArrayList roleTitan = new ArrayList()


        hmRoleTitan['sor_name'] = 'LS'
        hmRoleTitan['service_name'] = 'TITAN'
        hmRoleTitan['sor_id'] = '6'
        hmRoleTitan['role_name'] = 'AUTHORIZEDUSER'
        hmRoleTitan['service_id'] = '33'
        hmRoleTitan['role_id'] = '3'
        hmRoleTitan['create_date'] = '03222021 10:59:35'
        hmRoleTitan['last_modified'] = '03222021 10:59:35'
        roleTitan.add(hmRoleTitan)

        hmTitanBan['roles'] = roleTitan
        hmTitanBan['create_date'] = '03222021 10:59:35'
        hmTitanBan['last_modified'] = '03222021 10:59:35'
        hmTitanBan['sor_name'] = 'LS'
        hmTitanBan['service_name'] = 'TITAN'
        hmTitanBan['instance_id'] = '100889099'
        hmTitanBan['sor_invariant_id'] = '100889099'
        hmTitanBan['sor_id'] = '6'

        hmTitan['100889099'] = hmTitanBan
        serviceTitan['TITAN'] = hmTitan


        assocMemdetailsTitan['parent_name'] = 'qay_jenny105'
        //assocMemdetailsTitan.put("appStatusMsg", "SUCCESS");
        assocMemdetailsTitan['account_type'] = 'R'
        assocMemdetailsTitan['services'] = serviceTitan
        assocMemdetailsTitan['appStatusCode'] = '0'
        assocMemdetailsTitan['contact_email'] = 'vincent@gmail.com'

        //error data
		HashMap hmAssocMemWithoutContact = new HashMap<>()
        hmAssocMemWithoutContact['parent_name'] = 'qay_jenny105'
        hmAssocMemWithoutContact['account_type'] = 'R'
        hmAssocMemWithoutContact['services'] = serviceTitan
        hmAssocMemWithoutContact['appStatusCode'] = '0'

        HashMap hmTitan1 = new HashMap()
        HashMap hmRoleTitan1 = new HashMap()
        HashMap serviceTitan1 = new HashMap()
        ArrayList roleTitan1 = new ArrayList()
        HashMap assocMemdetailsTitan1 = new HashMap()
        HashMap hmTitanBan1 = new HashMap()

        hmRoleTitan1['sor_name'] = 'LS'
        hmRoleTitan1['service_name'] = 'TITAN'
        hmRoleTitan1['sor_id'] = '6'
        hmRoleTitan1['role_name'] = 'OWNER'
        hmRoleTitan1['service_id'] = '33'
        hmRoleTitan1['role_id'] = '2'
        hmRoleTitan1['create_date'] = '10282020 04:56:51'
        hmRoleTitan1['last_modified'] = '10282020 04:58:24'
        roleTitan1.add(hmRoleTitan1)

        hmTitanBan1['roles'] = roleTitan1
        hmTitanBan1['create_date'] = '10282020 04:56:51'
        hmTitanBan1['last_modified'] = '10282020 04:58:24'
        hmTitanBan1['sor_name'] = 'LS'
        hmTitanBan1['service_name'] = 'TITAN'
        hmTitanBan1['instance_id'] = '100889097'
        hmTitanBan1['sor_invariant_id'] = '100889097'
        hmTitanBan1['sor_id'] = '6'

        hmTitan1['100889097'] = hmTitanBan1
        serviceTitan1['TITAN'] = hmTitan1

        assocMemdetailsTitan1['parent_name'] = 'kadgrtoiu89'
        //assocMemdetailsTitan1.put("appStatusMsg", "SUCCESS");
        assocMemdetailsTitan1['account_type'] = 'R'
        assocMemdetailsTitan1['services'] = serviceTitan1
        assocMemdetailsTitan1['appStatusCode'] = '0'
        assocMemdetailsTitan1['contact_email'] = 'myemail@gmail.com'

        hmGetAssociatedMembersInpTitan['queryRolesInfoFlag'] = queryRolesInfoFlag
        hmGetAssociatedMembersInpTitan['service_type'] = 'TITAN'
        hmGetAssociatedMembersInpTitan['sor_invariant_id1'] = '100889099'
        hmGetAssociatedMembersInpTitan['querySlidInfo'] = 'Y'

        ArrayList assocMemdetailsValueTitan = new ArrayList()
        ArrayList assocMemdetailsAccountandban = new ArrayList()
        assocMemdetailsValueTitan .add(assocMemdetailsTitan)

        assocMemdetailsAccountandban.add(assocMemdetailsTitan1)
        assocMemdetailsAccountandban.add(assocMemdetailsTitan)

        assocMemTitan['associatedMembers'] = assocMemdetailsValueTitan
        assocMemTitan['appStatusMsg'] = 'SUCCESS'
        assocMemTitan['appCategoryCode'] = '0'
        assocMemTitan['appInfo'] = 'Success'
        assocMemTitan['appStatusCode'] = '0'

        assocMemTitanBanandAccount['associatedMembers'] = assocMemdetailsAccountandban
        assocMemTitanBanandAccount['appStatusMsg'] = 'SUCCESS'
        assocMemTitanBanandAccount['appCategoryCode'] = '0'
        assocMemTitanBanandAccount['appInfo'] = 'Success'
        assocMemTitanBanandAccount['appStatusCode'] = '0'
        //DTV
		
		
		//No contact data
		ArrayList alAssocMemNoContact = new ArrayList()
        alAssocMemNoContact.add(hmAssocMemWithoutContact)
        hmNoContactAssocMem.putAll(hmSuccessResponse)
        hmNoContactAssocMem['associatedMembers'] = alAssocMemNoContact


        HashMap<String, Object> hmDbusInputNotification = new HashMap()
        hmDbusInputNotification[CommonDefs.EVENTNAME] = CommonDefs.CONTEXT_NotificationEvent
        hmDbusInputNotification[CommonDefs.SUBEVENT] = CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID
        hmDbusInputNotification[CommonDefs.DBUS_DICTIONARY_NAME] = CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE
        hmDbusInputNotification[CommonDefs.KEY_ACCOUNT_ID] = '121321113'
        hmDbusInputNotification["notificationData"] = [Map.of("qarKey", "mockedQarToken")]

        dbusInput.add(hmDbusInputNotification)


        ReflectionTestUtils.setField(oRetriggerQARHelper, 'propValidAccountTypes', 'MOBILITY|TITAN')
        ReflectionTestUtils.setField(oRetriggerQARHelper, 'propRetriggerQAREmailRTVCallingSystemIds', 'DATAMGT')
        ReflectionTestUtils.setField(oRetriggerQARHelper, 'propIGURStaticQARURLNewQAR', 'https://test2.att.com/acctmgmt/registration?origination_point=shmguest&token=')
        ReflectionTestUtils.setField(oRetriggerQARHelper, 'propIGURStaticQARURLSHMGuest', 'https://test2.att.com/acctmgmt/registration?origination_point=newqar&token=')
    }


    def "test invalid input account type error"() throws Exception
	{
        given:
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOSUB'
        hmInput[CommonDefs.BAN] = '121321113'

        hmResult = oRetriggerQARHelper.retriggerQAR(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Invalid Account Type'
    }


    def "test input null"() throws Exception
	{
        given:
        hmResult = oRetriggerQARHelper.retriggerQAR(null)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Input Hash is NULL'
    }


    def "test get associated member null"() throws Exception
	{
        given:
        hmInput[CommonDefs.ACCESS_ID] = '123'
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_)>> null
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Response from  GetAssociatedMembersDBHelper is either null or empty'
    }


    def "test get slid info null"() throws Exception {
        given:
        hmInput[CommonDefs.ACCESS_ID] = 'qay_khusko013'
        hmInput[CommonDefs.BAN] = null
        hmInput[CommonDefs.ACCOUNT_TYPE] = null
        oGetInfoByMask.getInfoByMask(_)>> null
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Response from getSlidInfo is either null or empty'
    }


    def "testmake async call null"() throws Exception {

        given:
        hmInput[CommonDefs.ACCESS_ID] = 'qay_test013'
        hmInput[CommonDefs.BAN] = null
        hmInput[CommonDefs.ACCOUNT_TYPE] = null

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput


        oGetInfoByMask.getInfoByMask(_)>>assocMemdetails
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_)>>assocMem
        restClientObj.getCGSyncCall(_)>>hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_, _)>>hmSuccessResponse
        queueHelperObj.makeAsyncCall(_ as ArrayList, _ as HashMap)>>null
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Null Response returned from makeAsyncCall()'
    }


    def "testcall c gnull by pass c g error"() throws Exception {

        given:
        hmInput[CommonDefs.ACCESS_ID] = 'qay_test013'
        hmInput[CommonDefs.BAN] = null
        hmInput[CommonDefs.ACCOUNT_TYPE] = null

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        oGetInfoByMask.getInfoByMask(hmGetInfoInp)>>assocMemdetails
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(hmGetAssociatedMembersInp)>>assocMem
        restClientObj.getCGSyncCall(_ as HashMap)>>null
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap)>>hmSuccessResponse
        queueHelperObj.makeAsyncCall(_ as ArrayList, _ as HashMap)>>hmSuccessResponse
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInput)

        hmResult = oRetriggerQARHelper.retriggerQAR(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
    }


    def "test mobility with access success"() throws Exception {

        given:
        hmInput[CommonDefs.ACCESS_ID] = 'qay_test013'
        hmInput[CommonDefs.BAN] = null
        hmInput[CommonDefs.ACCOUNT_TYPE] = null


        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        oGetInfoByMask.getInfoByMask(hmGetInfoInp)>>assocMemdetails
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(hmGetAssociatedMembersInp)>>assocMem
        restClientObj.getCGSyncCall(_ as HashMap)>>hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap)>>hmSuccessResponse
        queueHelperObj.makeAsyncCall(_ as ArrayList, _ as HashMap)>>hmSuccessResponse
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
    }

    def "test mobility with guid success"() throws Exception {

        given:
        hmInput[CommonDefs.GUID] = '1234567890'
        hmInput[CommonDefs.BAN] = null
        hmInput[CommonDefs.ACCOUNT_TYPE] = null


        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        oGetInfoByMask.getInfoByMask(hmGetInfoInp)>>assocMemdetails
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(hmGetAssociatedMembersInp)>>assocMem
        restClientObj.getCGSyncCall(_ as HashMap)>>hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap)>>hmSuccessResponse
        queueHelperObj.makeAsyncCall(_ as ArrayList, _ as HashMap)>>hmSuccessResponse
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Response from getSlidInfo is either null or empty'
    }


    def "test mobility with accountand ban success"() throws Exception {

        given:
        hmInput[CommonDefs.ACCESS_ID] = null
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInput[CommonDefs.BAN] = '121321113'

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(hmGetAssociatedMembersInp)>>assocMem
        restClientObj.getCGSyncCall(_ as HashMap)>>hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap)>>hmSuccessResponse
        queueHelperObj.makeAsyncCall(_ as ArrayList, _ as HashMap)>>hmSuccessResponse
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
    }


    def "test prepare data for async call error"() throws Exception {

        given:
        hmInput[CommonDefs.ACCESS_ID] = null
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInput[CommonDefs.BAN] = '121321113'
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(hmGetAssociatedMembersInp)>>assocMem
        restClientObj.getCGSyncCall(_ as HashMap)>>hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap)>>hmSuccessResponse
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'dbus input is null from RetriggerQARQueueHelper. prepareDataForAsyncCall()'
    }


    def "test t i t a n with access success"() throws Exception {

        given:
        hmInputTitan[CommonDefs.ACCESS_ID] = 'qay_jenny105'
        hmInputTitan[CommonDefs.BAN] = null
        hmInputTitan[CommonDefs.ACCOUNT_TYPE] = null

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        oGetInfoByMask.getInfoByMask(hmGetInfoTitan)>>assocMemdetailsTitan
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap)>>assocMemTitan
        restClientObj.getCGSyncCall(_ as HashMap)>>hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap)>>hmSuccessResponse
        queueHelperObj.makeAsyncCall(_ as ArrayList, _ as HashMap)>>hmSuccessResponse
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInputTitan)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
    }


    def "test t i t a n with accountand ban success"() throws Exception {

        given:
        hmInputTitan[CommonDefs.ACCESS_ID] = null
        hmInputTitan[CommonDefs.ACCOUNT_TYPE] = 'TITAN'
		hmInputTitan[CommonDefs.BAN] = '100889097'

		hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

		ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap)>>assocMemTitanBanandAccount
		restClientObj.getCGSyncCall(_)>>hmCGResponse
		queueHelperObj.prepareDataForAsyncCall(_, _)>>hmSuccessResponse
		queueHelperObj.makeAsyncCall(_ as ArrayList, _ as HashMap)>>hmSuccessResponse
		hmResult = oRetriggerQARHelper.retriggerQAR(hmInputTitan)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
    }

    def "test returnQARToken in response success"() throws Exception {

        given:
        hmInputTitan[CommonDefs.ACCESS_ID] = null
        hmInputTitan[CommonDefs.ACCOUNT_TYPE] = 'TITAN'
        hmInputTitan[CommonDefs.BAN] = '100889097'
        hmInputTitan['returnQARToken'] = 'Y'

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap)>>assocMemTitanBanandAccount
        queueHelperObj.prepareDataForAsyncCall(_, _)>>hmSuccessResponse
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInputTitan)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
    }

    def "test returnQARTokenSHM in response success"() throws Exception {

        given:
        hmInputTitan[CommonDefs.ACCESS_ID] = null
        hmInputTitan[CommonDefs.ACCOUNT_TYPE] = 'TITAN'
        hmInputTitan[CommonDefs.BAN] = '100889097'
        hmInputTitan['returnQARTokenSHM'] = 'Y'

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap)>>assocMemTitanBanandAccount
        queueHelperObj.prepareDataForAsyncCall(_, _)>>hmSuccessResponse
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInputTitan)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
    }

    def "test Account is already registered error"() throws Exception {

        given:
        hmInput[CommonDefs.ACCESS_ID] = 'qay_test013'
        hmInput[CommonDefs.BAN] = null
        hmInput[CommonDefs.ACCOUNT_TYPE] = null
        assocMemdetails2 = assocMemdetails.clone()
        assocMemdetails2[MPSDefs.DB_ACTIVATED_IND] = 'Y'
        assocMemdetailsValue.clear()
        assocMemdetailsValue.add(assocMemdetails2)
        assocMem['associatedMembers'] = assocMemdetailsValue

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        oGetInfoByMask.getInfoByMask(hmGetInfoInp)>>assocMemdetails2
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(hmGetAssociatedMembersInp)>>assocMem
        restClientObj.getCGSyncCall(_ as HashMap)>>hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap)>>hmSuccessResponse
        queueHelperObj.makeAsyncCall(_ as ArrayList, _ as HashMap)>>hmSuccessResponse
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Account is already registered'
    }

    def "test retriggerQAR with valid BAN and account type"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_) >> assocMem
        oGetInfoByMask.getInfoByMask(_) >> assocMemdetails
        restClientObj.getCGSyncCall(_) >> hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_, _) >> hmSuccessResponse
        queueHelperObj.makeAsyncCall(_, _) >> hmSuccessResponse

        when:
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == "602"
    }
    def "test retriggerQAR with invalid account type"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'INVALID_TYPE'

        when:
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == "100"
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Invalid Account Type'
    }

    def "test exception handling in retriggerQAR"() {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_) >>new RuntimeException("Test Exception")

        when:
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == "602"
    }

    def "test returnQARTokenSHM in response success2"() throws Exception {

        given:
        hmInputTitan[CommonDefs.ACCESS_ID] = null
        hmInputTitan[CommonDefs.ACCOUNT_TYPE] = 'TITAN'
        hmInputTitan[CommonDefs.BAN] = '100889097'
        hmInputTitan['returnQARTokenSHM'] = 'Y'
        String stQarURL
        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap)>>assocMemTitanBanandAccount
        queueHelperObj.prepareDataForAsyncCall(_, _)>>hmSuccessResponse
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInputTitan)

        when:
        stQarURL = (String) hmResult["qarURL"]
        then:
        Assert.notNull(stQarURL)
    }

    def "test retriggerQAR with CLM - success"() throws Exception {
        given:
        hmInputTitan[CommonDefs.ACCESS_ID] = null
        hmInputTitan[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInputTitan[CommonDefs.BAN] = '100889097'

        featureManager.isEnabled(_ as String)>>true
        clmRestClient.sendCLMNotification(_ as CLMNotificationRequest) >> { CLMNotificationRequest req ->
            assert req.communication[0].customers[0].notificationInfo[0].longURL == "https://test2.att.com/acctmgmt/registration?origination_point=shmguest&token=mockedQarToken&c=IDP"
            return new CLMNotificationResponse()
        }

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput
        queueHelperObj.prepareDataForAsyncCall(_, _)>>hmSuccessResponse

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap)>>assocMemTitanBanandAccount
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInputTitan)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        stAppStatusCode = (String) hmResult[CommonDefs.COMMON_APP_STATUS_CODE]
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        stAppCategoryCode = (String) hmResult[CommonDefs.COMMON_APP_CATEGORY_CODE]

        then:
        stAppInfo == 'SUCCESS'
        stAppStatusCode == '0'
        stAppStatusMsg == 'SUCCESS'
        stAppCategoryCode == '0'
    }

    def "test retriggerQAR with CLM - null clm response"() throws Exception {
        given:
        hmInputTitan[CommonDefs.ACCESS_ID] = null
        hmInputTitan[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInputTitan[CommonDefs.BAN] = '100889097'

        featureManager.isEnabled(_ as String)>>true
        clmRestClient.sendCLMNotification(_ as CLMNotificationRequest)>>null

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput
        queueHelperObj.prepareDataForAsyncCall(_, _)>>hmSuccessResponse

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap)>>assocMemTitanBanandAccount
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInputTitan)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        stAppStatusCode = (String) hmResult[CommonDefs.COMMON_APP_STATUS_CODE]
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        stAppCategoryCode = (String) hmResult[CommonDefs.COMMON_APP_CATEGORY_CODE]

        then:
        stAppInfo == 'CLMRestClient response is null'
        stAppStatusCode == '602'
        stAppStatusMsg == 'ERR_SYS_APPL'
        stAppCategoryCode == '2'
    }

    def "test retriggerQAR with CLM - invalid clm request"() throws Exception {
        given:
        hmInputTitan[CommonDefs.ACCESS_ID] = null
        hmInputTitan[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInputTitan[CommonDefs.BAN] = '100889097'

        def clmNotificationResponse = new CLMNotificationResponse()
        clmNotificationResponse.setStatusCode(Response.Status.BAD_REQUEST.getStatusCode())
        clmNotificationResponse.setStatusMessage("CLM: IInvalid Request")

        featureManager.isEnabled(_ as String)>>true
        clmRestClient.sendCLMNotification(_ as CLMNotificationRequest)>>clmNotificationResponse

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput
        queueHelperObj.prepareDataForAsyncCall(_, _)>>hmSuccessResponse

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap)>>assocMemTitanBanandAccount
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInputTitan)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        stAppStatusCode = (String) hmResult[CommonDefs.COMMON_APP_STATUS_CODE]
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        stAppCategoryCode = (String) hmResult[CommonDefs.COMMON_APP_CATEGORY_CODE]

        then:
        stAppInfo == 'CLM: IInvalid Request'
        stAppStatusCode == '602'
        stAppStatusMsg == 'ERR_SYS_APPL'
        stAppCategoryCode == '2'
    }

    def "test retriggerQAR with CLM - error clm response"() throws Exception {
        given:
        hmInputTitan[CommonDefs.ACCESS_ID] = null
        hmInputTitan[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInputTitan[CommonDefs.BAN] = '100889097'

        def clmNotificationResponse = new CLMNotificationResponse()
        clmNotificationResponse.setStatusCode(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode())
        clmNotificationResponse.setStatusMessage("CLM: Internal Server Error")

        featureManager.isEnabled(_ as String)>>true
        clmRestClient.sendCLMNotification(_ as CLMNotificationRequest)>>clmNotificationResponse

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput
        queueHelperObj.prepareDataForAsyncCall(_, _)>>hmSuccessResponse

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap)>>assocMemTitanBanandAccount
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInputTitan)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        stAppStatusCode = (String) hmResult[CommonDefs.COMMON_APP_STATUS_CODE]
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        stAppCategoryCode = (String) hmResult[CommonDefs.COMMON_APP_CATEGORY_CODE]

        then:
        stAppInfo == 'CLM: Internal Server Error'
        stAppStatusCode == '602'
        stAppStatusMsg == 'ERR_SYS_APPL'
        stAppCategoryCode == '2'
    }

    def "test retriggerQAR with CLM - error for empty/null callingSystemId"() throws Exception {
        given:
        hmInputTitan[CommonDefs.ACCESS_ID] = null
        hmInputTitan[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInputTitan[CommonDefs.BAN] = '100889097'
        hmInputTitan[CommonDefs.CALLING_SYSTEM_ID] = callingSystemId

        featureManager.isEnabled(_ as String)>>true

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput
        queueHelperObj.prepareDataForAsyncCall(_, _)>>hmSuccessResponse

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap)>>assocMemTitanBanandAccount
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInputTitan)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        stAppStatusCode = (String) hmResult[CommonDefs.COMMON_APP_STATUS_CODE]
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        stAppCategoryCode = (String) hmResult[CommonDefs.COMMON_APP_CATEGORY_CODE]

        then:
        stAppInfo == 'Exception :Calling system ID must not be null or empty'
        stAppStatusCode == '602'
        stAppStatusMsg == 'ERR_SYS_APPL'
        stAppCategoryCode == '2'

        where:
        callingSystemId << [null, '']
    }

    def "test retriggerQAR with CLM - error for empty/null qarToken"() throws Exception {
        given:
        hmInputTitan[CommonDefs.ACCESS_ID] = null
        hmInputTitan[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInputTitan[CommonDefs.BAN] = '100889097'

        def dInput = new ArrayList()
        dInput.add(Map.of("notificationData", [Map.of("qarKey", mockedQarToken)]))

        featureManager.isEnabled(_ as String)>>true

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dInput
        queueHelperObj.prepareDataForAsyncCall(_, _)>>hmSuccessResponse

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap)>>assocMemTitanBanandAccount
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInputTitan)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        stAppStatusCode = (String) hmResult[CommonDefs.COMMON_APP_STATUS_CODE]
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        stAppCategoryCode = (String) hmResult[CommonDefs.COMMON_APP_CATEGORY_CODE]

        then:
        stAppInfo == 'Exception :QAR token must not be null or empty'
        stAppStatusCode == '602'
        stAppStatusMsg == 'ERR_SYS_APPL'
        stAppCategoryCode == '2'

        where:
        mockedQarToken << ['']
    }

    def "moveOldestCTNFirst returns primary account holder as oldest when activation date is null"() throws Exception {
        given:
        ArrayList alListOfCTN = [
                [(CommonDefs.CTN): "1234567890", (CommonDefs.STATUS): "A", (CommonDefs.ACTIVATION_DATE): null],
                [(CommonDefs.CTN): "0987654321", (CommonDefs.STATUS): "A", (CommonDefs.ACTIVATION_DATE): "2023-01-01"]
        ]
        String sPrimaryAccountHolder = "1234567890"

        when:
        HashMap result = oRetriggerQARHelper.moveOldestCTNFirst(alListOfCTN, sPrimaryAccountHolder)

        then:
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        alListOfCTN[0][CommonDefs.CTN] == "1234567890"
    }

    def "moveOldestCTNFirst returns oldest CTN when primary account holder is not active"() throws Exception {
        given:
        ArrayList alListOfCTN = [
                [(CommonDefs.CTN): "1234567890", (CommonDefs.STATUS): "I", (CommonDefs.ACTIVATION_DATE): "2023-01-01"],
                [(CommonDefs.CTN): "0987654321", (CommonDefs.STATUS): "A", (CommonDefs.ACTIVATION_DATE): "2022-01-01"]
        ]
        String sPrimaryAccountHolder = "1234567890"

        when:
        HashMap result = oRetriggerQARHelper.moveOldestCTNFirst(alListOfCTN, sPrimaryAccountHolder)

        then:
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        alListOfCTN[0][CommonDefs.CTN] == "0987654321"
    }

       def "moveOldestCTNFirst handles empty CTN list gracefully"() throws Exception {
        given:
        ArrayList alListOfCTN = []
        String sPrimaryAccountHolder = "1234567890"

        when:
        HashMap result = oRetriggerQARHelper.moveOldestCTNFirst(alListOfCTN, sPrimaryAccountHolder)

        then:
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        alListOfCTN.isEmpty()
    }

    def "moveOldestCTNFirst handles null activation dates correctly"() throws Exception {
        given:
        ArrayList alListOfCTN = [
                [(CommonDefs.CTN): "1234567890", (CommonDefs.STATUS): "A", (CommonDefs.ACTIVATION_DATE): null],
                [(CommonDefs.CTN): "0987654321", (CommonDefs.STATUS): "A", (CommonDefs.ACTIVATION_DATE): null]
        ]
        String sPrimaryAccountHolder = "1234567890"

        when:
        HashMap result = oRetriggerQARHelper.moveOldestCTNFirst(alListOfCTN, sPrimaryAccountHolder)

        then:
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        alListOfCTN[0][CommonDefs.CTN] == "1234567890"
    }
    def "returns error when valid account types config is null"() throws Exception {
        given:
        ReflectionTestUtils.setField(oRetriggerQARHelper, "propValidAccountTypes", null)

        when:
        HashMap result = oRetriggerQARHelper.getOldestAccountForQAR(new HashMap())

        then:
        result[CommonDefs.COMMON_APP_STATUS_CODE] == '605'
     //   result[CommonDefs.COMMON_APP_INFO] == "accountTypesForQARRetrigger Config is null or empty"
    }

    def "returns error when valid account list is empty"() throws Exception {
        given:
        HashMap hmSlidAccounts = [:]
        HashMap hmSlidInfo = [
                (MPSDefs.SERVICES): hmSlidAccounts
        ]
        ReflectionTestUtils.setField(oRetriggerQARHelper, "propValidAccountTypes", "MOBILITY|TITAN")

        when:
        HashMap result = oRetriggerQARHelper.getOldestAccountForQAR(hmSlidInfo)

        then:
        result[CommonDefs.COMMON_APP_STATUS_CODE] == '100'
        result[CommonDefs.COMMON_APP_INFO] == "Valid Account not found "
    }
    def "returns user not found error when access id is invalid"() throws Exception {
        given:
        HashMap hmInput = [
                (CommonDefs.ACCESS_ID): "invalid_access_id"
        ]
        HashMap hmSlidInfo = [
                (CErrorDefs.COMMON_APP_STATUS_CODE): CErrorDefs.ERR_REC_NOT_FOUND
        ]
        oGetInfoByMask.getInfoByMask(_) >> hmSlidInfo

        when:
        HashMap result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_STATUS_CODE] == '121'
        result[CommonDefs.COMMON_APP_INFO] == "User not found with input access id."
    }
    @Unroll
    def "should return error when triggerAccountQAR result is null or empty for #scenarioName"() {
        given: "A valid input map and triggerAccountQAR returns null or empty"

        hmInputTitan[CommonDefs.ACCESS_ID] = null
        hmInputTitan[CommonDefs.ACCOUNT_TYPE] = 'TITAN'
        hmInputTitan[CommonDefs.BAN] = '100889097'
        hmInputTitan['returnQARTokenSHM'] = 'Y'
        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap)>>assocMemTitanBanandAccount
        queueHelperObj.prepareDataForAsyncCall(_, _)>>null
        hmResult = oRetriggerQARHelper.retriggerQAR(hmInputTitan)


        oRetriggerQARHelper.propValidAccountTypes = "MOBILITY|TITAN"

        when: "retriggerQAR is called"
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInputTitan)

        then: "triggerAccountQAR is called with correct input"
        0 * oRetriggerQARHelper.triggerAccountQAR({ Map<String, Object> param ->
            param[CommonDefs.BAN] == "123456789" &&
                    param[CommonDefs.ACCOUNT_TYPE] == "MOBILITY"
        }) >> triggerResult


        result != null
        result[CommonDefs.COMMON_APP_INFO] == "Null Response returned from prepareDataForAsyncCall()"
        result[CErrorDefs.COMMON_APP_STATUS_CODE] =='602'

        where: "Different scenarios for null and empty result"
        scenarioName      | triggerResult
        "null result"     | null
    }


    // ===========================================================================================
    // NEW TESTS — Uncovered branches in RetriggerQARHelper
    // ===========================================================================================

    // ----- retriggerQAR: empty input hash -----

    def "verify empty input hash returns ERR_INVALID_DATA"() {
        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(new HashMap())

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Input Hash is NULL'
    }

    // ----- retriggerQAR: BAN path — triggerAccountQAR returns ERR_REC_NOT_FOUND -----

    def "verify BAN path ERR_REC_NOT_FOUND returns user not found"() {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'

        // getMemberDetails returns ERR_REC_NOT_FOUND
        HashMap hmRecNotFound = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, 'Record not found')
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> hmRecNotFound

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Input ban is not associated to any user.'
    }

    // ----- retriggerQAR: BAN path — triggerAccountQAR returns other non-success -----

    def "verify BAN path other non-success error propagated"() {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'

        // getMemberDetails returns a system error
        HashMap hmSysError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, 'System application error')
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> hmSysError

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'System application error'
        result[CommonDefs.COMMON_APP_STATUS_CODE] == '602'
    }

    // ----- retriggerQAR: AccessId path — getSlidInfo non-success, non-ERR_REC_NOT_FOUND -----

    def "verify accessId path getSlidInfo non-success non-REC_NOT_FOUND returns error"() {
        given:
        HashMap hmLocalInput = new HashMap()
        hmLocalInput[CommonDefs.ACCESS_ID] = 'testuser123'
        hmLocalInput[CommonDefs.BAN] = null
        hmLocalInput[CommonDefs.ACCOUNT_TYPE] = null

        HashMap hmSlidError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, 'DB connection error')
        oGetInfoByMask.getInfoByMask(_ as HashMap) >> hmSlidError

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmLocalInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'DB connection error'
        result[CommonDefs.COMMON_APP_STATUS_CODE] == '602'
    }

    // ----- retriggerQAR: AccessId path — getOldestAccountForQAR null -----

    def "verify accessId path getOldestAccountForQAR null returns error"() {
        given:
        hmInput[CommonDefs.ACCESS_ID] = 'qay_test013'
        hmInput[CommonDefs.BAN] = null
        hmInput[CommonDefs.ACCOUNT_TYPE] = null

        // getSlidInfo returns success with services containing no valid accounts
        HashMap hmSlidInfoResp = new HashMap()
        hmSlidInfoResp.putAll(assocMemdetails)
        hmSlidInfoResp[CErrorDefs.COMMON_APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        // services has no MOBILITY or TITAN → getOldestAccountForQAR returns "Valid Account not found"
        HashMap emptyServices = new HashMap()
        hmSlidInfoResp[MPSDefs.SERVICES] = emptyServices

        oGetInfoByMask.getInfoByMask(_ as HashMap) >> hmSlidInfoResp

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Valid Account not found '
    }

    // ----- retriggerQAR: AccessId path — getOldestAccountForQAR non-success -----

    def "verify accessId path getOldestAccountForQAR non-success returns error"() {
        given:
        hmInput[CommonDefs.ACCESS_ID] = 'qay_test013'
        hmInput[CommonDefs.BAN] = null
        hmInput[CommonDefs.ACCOUNT_TYPE] = null

        // getSlidInfo returns success with null services → getOldestAccountForQAR will fail
        HashMap hmSlidInfoResp = new HashMap()
        hmSlidInfoResp[CErrorDefs.COMMON_APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmSlidInfoResp[MPSDefs.SERVICES] = null

        ReflectionTestUtils.setField(oRetriggerQARHelper, 'propValidAccountTypes', null)
        oGetInfoByMask.getInfoByMask(_ as HashMap) >> hmSlidInfoResp

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'accountTypesForQARRetrigger Config is null or empty'

        cleanup:
        ReflectionTestUtils.setField(oRetriggerQARHelper, 'propValidAccountTypes', 'MOBILITY|TITAN')
    }

    // ----- retriggerQAR: neither BAN nor accessId/guid → returns null -----

    def "verify retriggerQAR with no BAN no accessId no guid returns null"() {
        given:
        HashMap hmLocalInput = new HashMap()
        hmLocalInput[CommonDefs.BAN] = null
        hmLocalInput[CommonDefs.ACCOUNT_TYPE] = null
        hmLocalInput[CommonDefs.ACCESS_ID] = null
        hmLocalInput[CommonDefs.GUID] = null

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmLocalInput)

        then:
        result == null
    }

    // ----- retriggerQAR: BAN with blank spaces only -----

    def "verify retriggerQAR with blank BAN falls to accessId path"() {
        given:
        HashMap hmLocalInput = new HashMap()
        hmLocalInput[CommonDefs.BAN] = '   '
        hmLocalInput[CommonDefs.ACCOUNT_TYPE] = null
        hmLocalInput[CommonDefs.ACCESS_ID] = null
        hmLocalInput[CommonDefs.GUID] = null

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmLocalInput)

        then:
        result == null
    }

    // ----- triggerAccountQAR: CG non-success response bypassed -----

    def "verify CG non-success response is bypassed gracefully"() {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> assocMem

        // CG returns error → bypassed
        HashMap hmCGError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, 'CG service error')
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGError

        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap) >> hmSuccessResponse
        queueHelperObj.makeAsyncCall(_ as ArrayList, _ as HashMap) >> hmSuccessResponse

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ----- triggerAccountQAR: prepareDataForAsyncCall null -----

    def "verify prepareDataForAsyncCall null returns error from triggerAccountQAR"() {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> assocMem
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap) >> null

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Null Response returned from prepareDataForAsyncCall()'
        result[CommonDefs.COMMON_APP_STATUS_CODE] == '602'
    }

    // ----- triggerAccountQAR: prepareDataForAsyncCall non-success -----

    def "verify prepareDataForAsyncCall non-success returns error"() {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'

        HashMap hmPrepError = new HashMap()
        hmPrepError[MPSDefs.APP_STATUS_CODE] = '602'
        hmPrepError[CommonDefs.COMMON_APP_INFO] = 'Preparation failed'

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> assocMem
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap) >> hmPrepError

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Preparation failed'
    }

    // ----- triggerAccountQAR: EmailRTV check — callingSystem in RTV list, emailRTV not Y -----

    def "verify EmailRTV not Y clears contact email for RTV calling system"() {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> assocMem

        // CG returns email with isEmailRTV = N
        HashMap hmCGRespWithRTV = new HashMap()
        hmCGRespWithRTV.putAll(hmCGResponse)
        HashMap hmAcctRTV = new HashMap()
        HashMap hmContactRTV = new HashMap()
        HashMap hmEmailRTV = new HashMap()
        hmEmailRTV['emailAddress'] = 'test@test.com'
        hmEmailRTV['isEmailRTV'] = 'N'
        hmContactRTV[CommonDefs.EMAIL] = hmEmailRTV
        hmAcctRTV['contact'] = hmContactRTV
        hmAcctRTV['primaryAccountHolder'] = '123454'
        hmCGRespWithRTV['accounts'] = hmAcctRTV

        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGRespWithRTV
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap) >> hmSuccessResponse
        queueHelperObj.makeAsyncCall(_ as ArrayList, _ as HashMap) >> hmSuccessResponse

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        // email should have been cleared due to EmailRTV=N
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ----- sendQARToEDD: makeAsyncCall non-success -----

    def "verify sendQARToEDD makeAsyncCall non-success returns error"() {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        HashMap hmAsyncError = new HashMap()
        hmAsyncError[MPSDefs.APP_STATUS_CODE] = '602'
        hmAsyncError[CommonDefs.COMMON_APP_INFO] = 'Async call failed'

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> assocMem
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap) >> hmSuccessResponse
        queueHelperObj.makeAsyncCall(_ as ArrayList, _ as HashMap) >> hmAsyncError

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Async call failed'
    }

    // ----- getMemberDetails: getAssociatedMembers non-success -----

    def "verify getMemberDetails getAssociatedMembers non-success returns error in BAN path"() {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'

        HashMap hmError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, 'DB query failed')
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> hmError

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'DB query failed'
    }

    // ----- getQarToken: edge cases -----

    def "verify getQarToken with empty list returns null"() {
        expect:
        oRetriggerQARHelper.getQarToken(new ArrayList()) == null
    }

    def "verify getQarToken with list without notificationData returns null"() {
        given:
        ArrayList input = new ArrayList()
        input.add(new HashMap())

        expect:
        oRetriggerQARHelper.getQarToken(input) == null
    }

    def "verify getQarToken with list with null qarKey returns null"() {
        given:
        ArrayList input = new ArrayList()
        input.add(Map.of("notificationData", [Map.of("otherKey", "someValue")]))

        expect:
        oRetriggerQARHelper.getQarToken(input) == null
    }

    def "verify getQarToken extracts qarKey successfully"() {
        given:
        ArrayList input = new ArrayList()
        input.add(Map.of("notificationData", [Map.of("qarKey", "myToken123")]))

        expect:
        oRetriggerQARHelper.getQarToken(input) == 'myToken123'
    }

    def "verify getQarToken with non-map entries in list returns null"() {
        given:
        ArrayList input = new ArrayList()
        input.add("not a map")
        input.add(42)

        expect:
        oRetriggerQARHelper.getQarToken(input) == null
    }

    // ----- CLM path: fname and languagePreference logic -----

    def "verify CLM path sets languagePreference to EN when not provided"() {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInput[CommonDefs.LANGUAGE_PREFERENCE] = null

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        featureManager.isEnabled(_ as String) >> true

        // assocMem member details with first name
        HashMap assocMemWithName = new HashMap()
        assocMemWithName.putAll(assocMem)
        ArrayList alMembers = (ArrayList) assocMemWithName['associatedMembers']
        if (alMembers != null && !alMembers.isEmpty()) {
            HashMap firstMember = (HashMap) alMembers[0]
            firstMember[MPSDefs.DB_LC_FIRSTNAME] = 'John'
        }

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> assocMemWithName
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap) >> hmSuccessResponse

        CLMNotificationResponse clmResp = new CLMNotificationResponse()
        clmResp.setStatusCode(0)
        clmResp.setStatusMessage('SUCCESS')
        clmRestClient.sendCLMNotification(_ as CLMNotificationRequest) >> clmResp

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "verify CLM path preserves existing languagePreference"() {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInput[CommonDefs.LANGUAGE_PREFERENCE] = 'ES'

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        featureManager.isEnabled(_ as String) >> true

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> assocMem
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap) >> hmSuccessResponse

        CLMNotificationResponse clmResp = new CLMNotificationResponse()
        clmResp.setStatusCode(0)
        clmResp.setStatusMessage('SUCCESS')
        clmRestClient.sendCLMNotification(_ as CLMNotificationRequest) >> clmResp

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ----- getOldestAccountForQAR: hmSlidAccounts null -----

    def "verify getOldestAccountForQAR with null services returns success with empty oldest account"() {
        given:
        HashMap hmSlidInfo = new HashMap()
        hmSlidInfo[MPSDefs.SERVICES] = null
        ReflectionTestUtils.setField(oRetriggerQARHelper, 'propValidAccountTypes', 'MOBILITY|TITAN')

        when:
        HashMap result = oRetriggerQARHelper.getOldestAccountForQAR(hmSlidInfo)

        then:
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    // ----- getOldestAccountForQAR: with valid accounts -----

    def "verify getOldestAccountForQAR selects oldest account correctly"() {
        given:
        HashMap hmInstanceService1 = new HashMap()
        hmInstanceService1[MPSDefs.DB_CREATE_DATE] = '01012023 00:00:00'
        hmInstanceService1[MPSDefs.DB_SOR_NAME] = 'MO'
        hmInstanceService1[MPSDefs.DB_SOR_INVARIANT_ID] = '111111'
        hmInstanceService1[MPSDefs.DB_INSTANCE_ID] = '111111'

        HashMap hmInstanceService2 = new HashMap()
        hmInstanceService2[MPSDefs.DB_CREATE_DATE] = '06012022 00:00:00'
        hmInstanceService2[MPSDefs.DB_SOR_NAME] = 'MO'
        hmInstanceService2[MPSDefs.DB_SOR_INVARIANT_ID] = '222222'
        hmInstanceService2[MPSDefs.DB_INSTANCE_ID] = '222222'

        HashMap hmBan1 = new HashMap()
        hmBan1[MPSDefs.DB_CREATE_DATE] = '01012023 00:00:00'
        hmBan1[MPSDefs.DB_SOR_NAME] = 'MO'
        hmBan1[MPSDefs.DB_SOR_INVARIANT_ID] = '111111'
        hmBan1[CommonDefs.ROLES] = []

        HashMap hmBan2 = new HashMap()
        hmBan2[MPSDefs.DB_CREATE_DATE] = '06012022 00:00:00'
        hmBan2[MPSDefs.DB_SOR_NAME] = 'MO'
        hmBan2[MPSDefs.DB_SOR_INVARIANT_ID] = '222222'
        hmBan2[CommonDefs.ROLES] = []

        HashMap hmMobilityAccts = new HashMap()
        hmMobilityAccts['111111'] = hmBan1
        hmMobilityAccts['222222'] = hmBan2

        HashMap hmSlidAccounts = new HashMap()
        hmSlidAccounts['MOBILITY'] = hmMobilityAccts

        HashMap hmSlidInfo = new HashMap()
        hmSlidInfo[MPSDefs.SERVICES] = hmSlidAccounts

        ReflectionTestUtils.setField(oRetriggerQARHelper, 'propValidAccountTypes', 'MOBILITY|TITAN')

        when:
        HashMap result = oRetriggerQARHelper.getOldestAccountForQAR(hmSlidInfo)

        then:
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        result[CommonDefs.OLDEST_ACCOUNT] != null
    }

    // ----- moveOldestCTNFirst: indexPAHCTN < indexOldestCTN -----

    def "verify moveOldestCTNFirst with PAH before oldest CTN"() {
        given:
        ArrayList alListOfCTN = [
                [(CommonDefs.CTN): "1111111111", (CommonDefs.STATUS): "A", (CommonDefs.ACTIVATION_DATE): "2022-01-01"],
                [(CommonDefs.CTN): "2222222222", (CommonDefs.STATUS): "A", (CommonDefs.ACTIVATION_DATE): "2023-06-01"],
                [(CommonDefs.CTN): "3333333333", (CommonDefs.STATUS): "A", (CommonDefs.ACTIVATION_DATE): "2021-01-01"]
        ]
        // PAH is at index 0, oldest is at index 2 → indexPAHCTN < indexOldestCTN
        String sPrimaryAccountHolder = "1111111111"

        when:
        HashMap result = oRetriggerQARHelper.moveOldestCTNFirst(alListOfCTN, sPrimaryAccountHolder)

        then:
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        alListOfCTN[0][CommonDefs.CTN] == "1111111111"
    }

    // ----- moveOldestCTNFirst: exception handling -----

    def "verify moveOldestCTNFirst handles parse exception"() {
        given:
        ArrayList alListOfCTN = [
                [(CommonDefs.CTN): "1111111111", (CommonDefs.STATUS): "A", (CommonDefs.ACTIVATION_DATE): "INVALID_DATE"]
        ]

        when:
        HashMap result = oRetriggerQARHelper.moveOldestCTNFirst(alListOfCTN, null)

        then:
        result[CommonDefs.COMMON_APP_STATUS_CODE] != CommonDefs.COMMON_SUCCESS
    }

    // ----- moveOldestCTNFirst: all inactive CTNs -----

    def "verify moveOldestCTNFirst with all inactive CTNs"() {
        given:
        ArrayList alListOfCTN = [
                [(CommonDefs.CTN): "1111111111", (CommonDefs.STATUS): "I", (CommonDefs.ACTIVATION_DATE): "2022-01-01"],
                [(CommonDefs.CTN): "2222222222", (CommonDefs.STATUS): "S", (CommonDefs.ACTIVATION_DATE): "2021-01-01"]
        ]

        when:
        HashMap result = oRetriggerQARHelper.moveOldestCTNFirst(alListOfCTN, null)

        then:
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        // no reordering since none are active
        alListOfCTN.size() == 2
    }

    // ----- moveOldestCTNFirst: single CTN is PAH -----

    def "verify moveOldestCTNFirst with single CTN that is PAH"() {
        given:
        ArrayList alListOfCTN = [
                [(CommonDefs.CTN): "5555555555", (CommonDefs.STATUS): "A", (CommonDefs.ACTIVATION_DATE): "2022-03-15"]
        ]

        when:
        HashMap result = oRetriggerQARHelper.moveOldestCTNFirst(alListOfCTN, "5555555555")

        then:
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        alListOfCTN[0][CommonDefs.CTN] == "5555555555"
    }

    // ----- AccessId path full success with oldest account -----

    def "verify accessId path selects oldest account and triggers QAR"() {
        given:
        hmInput[CommonDefs.ACCESS_ID] = 'qay_test013'
        hmInput[CommonDefs.BAN] = null
        hmInput[CommonDefs.ACCOUNT_TYPE] = null

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        oGetInfoByMask.getInfoByMask(_ as HashMap) >> assocMemdetails
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> assocMem
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap) >> hmSuccessResponse
        queueHelperObj.makeAsyncCall(_ as ArrayList, _ as HashMap) >> hmSuccessResponse

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ----- GUID path — getSlidInfo with guid key -----

    def "verify GUID path uses member_num in getSlidInfo"() {
        given:
        HashMap hmLocalInput = new HashMap()
        hmLocalInput[CommonDefs.GUID] = '9876543210'
        hmLocalInput[CommonDefs.BAN] = null
        hmLocalInput[CommonDefs.ACCOUNT_TYPE] = null
        hmLocalInput[CommonDefs.ACCESS_ID] = null

        // getSlidInfo with guid should use DB_SLID_MEMBER_NUM
        HashMap hmSlidResult = new HashMap()
        hmSlidResult.putAll(assocMemdetails)
        hmSlidResult[CErrorDefs.COMMON_APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS

        oGetInfoByMask.getInfoByMask(_ as HashMap) >> hmSlidResult
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> assocMem
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap) >> hmSuccessResponse
        queueHelperObj.makeAsyncCall(_ as ArrayList, _ as HashMap) >> hmSuccessResponse

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmLocalInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ----- triggerAccountQAR: TITAN account type sets service_type to uverse -----

    def "verify TITAN account type sets CG service_type to uverse"() {
        given:
        hmInputTitan[CommonDefs.BAN] = '100889099'
        hmInputTitan[CommonDefs.ACCOUNT_TYPE] = 'TITAN'
        hmInputTitan[CommonDefs.ACCESS_ID] = null

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> assocMemTitan
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap) >> hmSuccessResponse
        queueHelperObj.makeAsyncCall(_ as ArrayList, _ as HashMap) >> hmSuccessResponse

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInputTitan)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ----- triggerAccountQAR: returnQARToken=Y skips dbus and CG calls -----

    def "verify returnQARToken Y skips DBUS and CG calls for MOBILITY"() {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInput['returnQARToken'] = 'Y'

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> assocMem
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap) >> hmSuccessResponse

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        result['qarToken'] != null
    }

    // ----- triggerAccountQAR: returnQARTokenSHM=Y returns qarTokenSHM -----

    def "verify returnQARTokenSHM Y returns qarTokenSHM and qarURL"() {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInput['returnQARTokenSHM'] = 'Y'

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> assocMem
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap) >> hmSuccessResponse

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        result['qarTokenSHM'] != null
    }

    // ----- isABoolean: various combinations -----

    @Unroll
    def "verify isABoolean returns #expected for accessId=#accessId guid=#guid"() {
        expect:
        oRetriggerQARHelper.isABoolean(accessId, guid) == expected

        where:
        accessId    | guid       || expected
        null        | null       || false
        ''          | ''         || false
        'user123'   | null       || true
        null        | '12345'    || true
        'user123'   | '12345'    || true
        ''          | '12345'    || true
        'user123'   | ''         || true
    }

    // ----- AccessId path: triggerAccountQAR non-success after getOldestAccount -----

    def "verify accessId path triggerAccountQAR non-success after oldest account"() {
        given:
        hmInput[CommonDefs.ACCESS_ID] = 'qay_test013'
        hmInput[CommonDefs.BAN] = null
        hmInput[CommonDefs.ACCOUNT_TYPE] = null

        // getSlidInfo returns success
        oGetInfoByMask.getInfoByMask(_ as HashMap) >> assocMemdetails

        // getOldestAccountForQAR returns success → triggers triggerAccountQAR
        // getMemberDetails returns error on the second call
        HashMap hmMemberError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, 'Member lookup failed')
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> hmMemberError

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Member lookup failed'
    }

    // ----- No contact data in assocMem -----

    def "verify retriggerQAR with no contact email in member data"() {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'

        hmSuccessResponse[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> hmNoContactAssocMem
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap) >> hmSuccessResponse
        queueHelperObj.makeAsyncCall(_ as ArrayList, _ as HashMap) >> hmSuccessResponse

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ----- buildNestedElementList: short BAN -----

    def "verify buildNestedElementList with short BAN sets accountLast4 to null"() {
        given:
        HashMap hmLocalInput = new HashMap()
        hmLocalInput[CommonDefs.BAN] = '12'
        hmLocalInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmLocalInput[RetriggerQARHelper.QAR_TOKEN] = 'testToken'

        when:
        Object result = oRetriggerQARHelper.buildComplexValList(hmLocalInput[CommonDefs.BAN], hmLocalInput)

        then:
        result != null
    }

    def "verify buildNestedElementList with null BAN sets accountLast4 to null"() {
        given:
        HashMap hmLocalInput = new HashMap()
        hmLocalInput[CommonDefs.BAN] = null

        when:
        Object result = oRetriggerQARHelper.buildComplexValList(null, hmLocalInput)

        then:
        result != null
    }

    // ----- formatTitanCGResponse: altCBRInfo fallback -----

    def "verify formatTitanCGResponse uses altCBRInfo when CBRInfo is null"() {
        given:
        HashMap hmLocalCGResp = new HashMap()
        HashMap hmAcct = new HashMap()
        HashMap hmContactLocal = new HashMap()
        HashMap hmAltCBR = new HashMap()
        hmAltCBR[CommonDefs.PHONE_NUMBER] = '5551234567'
        hmContactLocal[CommonDefs.ALT_CBR_INFO] = hmAltCBR
        hmContactLocal[CommonDefs.CBR_INFO] = null
        hmAcct['contact'] = hmContactLocal
        hmLocalCGResp['accounts'] = hmAcct

        when:
        HashMap result = oRetriggerQARHelper.formatTitanCGResponse(hmLocalCGResp)

        then:
        result[CommonDefs.CTN] == '5551234567'
    }

    // ----- formatTitanCGResponse: null contact -----

    def "verify formatTitanCGResponse with null contact"() {
        given:
        HashMap hmLocalCGResp = new HashMap()
        HashMap hmAcct = new HashMap()
        hmAcct['contact'] = null
        hmLocalCGResp['accounts'] = hmAcct

        when:
        HashMap result = oRetriggerQARHelper.formatTitanCGResponse(hmLocalCGResp)

        then:
        result[CommonDefs.CTN] == null
        result[CommonDefs.CONTACT_EMAIL] == null
    }

    // ----- formatMobilityCGResponse: null contact -----

    def "verify formatMobilityCGResponse with null contact"() {
        given:
        HashMap hmLocalCGResp = new HashMap()
        HashMap hmAcct = new HashMap()
        hmAcct['contact'] = null
        hmAcct['primaryAccountHolder'] = '12345'
        hmLocalCGResp['accounts'] = hmAcct
        hmLocalCGResp['subscribers'] = null

        when:
        HashMap result = oRetriggerQARHelper.formatMobilityCGResponse(hmLocalCGResp)

        then:
        result[CommonDefs.CTN] == null
        result[CommonDefs.CONTACT_EMAIL] == null
    }

    // ----- formatMobilityCGResponse: altCBRInfo fallback -----

    def "verify formatMobilityCGResponse uses altCBRInfo when CBRInfo empty"() {
        given:
        ObjectMapper mapper = new ObjectMapper()
        ArrayNode subscriber = mapper.createArrayNode()
        ObjectNode sub1 = mapper.createObjectNode()
        sub1.put('subscriberId', '999999')
        sub1.put('status', 'A')
        sub1.put('effectiveDate', '2022-01-01')
        subscriber.add(sub1)

        HashMap hmLocalCGResp = new HashMap()
        HashMap hmAcct = new HashMap()
        HashMap hmContactLocal = new HashMap()
        HashMap hmAltCBR = new HashMap()
        hmAltCBR[CommonDefs.PHONE_NUMBER] = '5559876543'
        hmContactLocal[CommonDefs.ALT_CBR_INFO] = hmAltCBR
        hmContactLocal[CommonDefs.CBR_INFO] = null
        hmAcct['contact'] = hmContactLocal
        hmAcct['primaryAccountHolder'] = '999999'
        hmLocalCGResp['accounts'] = hmAcct
        hmLocalCGResp['subscribers'] = subscriber

        when:
        HashMap result = oRetriggerQARHelper.formatMobilityCGResponse(hmLocalCGResp)

        then:
        result[CommonDefs.CONTACT_TYPE_PRIMARY_PHONE] == '5559876543'
    }

    // ----- getOldestAccountForQAR: exception handling -----

    def "verify getOldestAccountForQAR handles exception gracefully"() {
        given:
        // Pass a services map that will cause a parse exception
        HashMap hmSlidInfo = new HashMap()
        HashMap hmSlidAccounts = new HashMap()
        HashMap hmBadAccount = new HashMap()
        hmBadAccount['INVALID_DATE_ENTRY'] = new HashMap()
        ((HashMap) hmBadAccount['INVALID_DATE_ENTRY'])[MPSDefs.DB_CREATE_DATE] = 'NOT_A_DATE'
        ((HashMap) hmBadAccount['INVALID_DATE_ENTRY'])[MPSDefs.DB_SOR_NAME] = 'MO'
        ((HashMap) hmBadAccount['INVALID_DATE_ENTRY'])[MPSDefs.DB_SOR_INVARIANT_ID] = '111'
        hmSlidAccounts['MOBILITY'] = hmBadAccount
        hmSlidInfo[MPSDefs.SERVICES] = hmSlidAccounts

        ReflectionTestUtils.setField(oRetriggerQARHelper, 'propValidAccountTypes', 'MOBILITY|TITAN')

        when:
        HashMap result = oRetriggerQARHelper.getOldestAccountForQAR(hmSlidInfo)

        then:
        // Exception caught → returns exception map
        result != null
        result[CommonDefs.COMMON_APP_STATUS_CODE] != null
    }

    // ----- propValidAccountTypes null in retriggerQAR BAN path -----

    def "verify BAN path with null propValidAccountTypes skips validation"() {
        given:
        ReflectionTestUtils.setField(oRetriggerQARHelper, 'propValidAccountTypes', null)
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        // propValidAccountTypes null → skips the if block, returns null hmResult
        result == null

        cleanup:
        ReflectionTestUtils.setField(oRetriggerQARHelper, 'propValidAccountTypes', 'MOBILITY|TITAN')
    }

    // ----- retriggerQAR: BAN path with triggerAccountQAR null response -----

    def "verify BAN path triggerAccountQAR null response returns error"() {
        given:
        hmInput[CommonDefs.BAN] = '121321113'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'

        // getMemberDetails returns success but empty associated members → hmDBMember will be empty
        HashMap hmEmptyAssoc = new HashMap()
        hmEmptyAssoc.putAll(hmSuccessResponse)
        hmEmptyAssoc[MPSDefs.ASSOCIATED_MEMBERS] = new ArrayList()

        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> hmEmptyAssoc
        restClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        queueHelperObj.prepareDataForAsyncCall(_ as HashMap, _ as HashMap) >> null

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Null Response returned from prepareDataForAsyncCall()'
    }

    // ----- AccessId path: triggerAccountQAR null after oldest account -----

    def "verify accessId path triggerAccountQAR null response after oldest account"() {
        given:
        hmInput[CommonDefs.ACCESS_ID] = 'qay_test013'
        hmInput[CommonDefs.BAN] = null
        hmInput[CommonDefs.ACCOUNT_TYPE] = null

        oGetInfoByMask.getInfoByMask(_ as HashMap) >> assocMemdetails

        // For the getOldest call, need getAssociatedMembers to work
        // But then triggerAccountQAR → getMemberDetails returns empty → error
        ObjMpsdbGetAssociatedMemberH.getAssociatedMembers(_ as HashMap) >> null

        when:
        Map<String, Object> result = oRetriggerQARHelper.retriggerQAR(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Response from  GetAssociatedMembersDBHelper is either null or empty'
    }

}
