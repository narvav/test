package com.att.idp.idgraphuserregistrationms.queue.message.sender

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.jms.core.JmsTemplate
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.jms.*

class JMSQueueSenderTest extends Specification {

	def jmsQueueSenderObj = new JMSQueueSender()

	JmsTemplate jmsTemplateObj = Mock(JmsTemplate)

	def connectionFactoryObj = Stub(ConnectionFactory)

	def connectionObj = Stub(Connection)

	def sessionObj = Stub(Session)

	def queueObj = Stub(Queue)

	def destinationObj = Stub(Destination)

	def bytesMessageObj = Stub(BytesMessage)

	def messageProducerObj = Stub(MessageProducer)

	Map<String, Object> hmInput = null
	Map<String, Object> hmResult = null
	Logger logger = null


	def setup() {
	    jmsQueueSenderObj.jmsTemplate = jmsTemplateObj
		hmInput = CommonUtil.hashMap
		logger = LoggerFactory.getLogger('WirelessAutoReg')

		hmInput['msOperation'] = 'WirelessAutoReg'
		hmInput[CommonDefs.TRANSACTION_ID] = 'trma_ng56734'
		hmInput['mainHashKey'] = '2'
		ReflectionTestUtils.setField(jmsQueueSenderObj, 'mqQueueName', 'MPSQL.MSDBUS.DEV3.INT.MSRIL')
		ReflectionTestUtils.setField(jmsQueueSenderObj, 'mqQueueCount', 3)
	}


	def "test send with null input"() {
		given:
		hmInput = null
		when:
		hmResult = jmsQueueSenderObj.send( hmInput)
		then:
		hmResult['appInfo'] == 'Input map is null for MQ'
	}


	def "test sendwith nullms operation"() {
		given:
		hmInput['msOperation'] = null
		when:
		hmResult = jmsQueueSenderObj.send(hmInput)
		then:
		hmResult['appInfo'] == 'msOperation cannot be null or empty for MQ'
	}


	def "test sendwith nulltransaction i d"() {
		given:
		hmInput[CommonDefs.TRANSACTION_ID] = null
		when:
		hmResult = jmsQueueSenderObj.send(hmInput)
		then:
		hmResult['appInfo'] == 'transactionId cannot be null or empty for MQ'
	}


	def "test sendwith nullmain hash key"() {
		given:
		hmInput['mainHashKey'] = null
		when:
		hmResult = jmsQueueSenderObj.send(hmInput)
		then:
		hmResult['appInfo'] == 'mainHashKey cannot be null or empty for MQ'
	}


	def "test sendwith emptymq queue name"() {
		given:
		ReflectionTestUtils.setField(jmsQueueSenderObj, 'mqQueueName', '')
		when:
		hmResult = jmsQueueSenderObj.send(hmInput)
		then:
		hmResult['appInfo'] == 'queueName value not found in property'
	}


	def "test send null exception"() {
		when:
		hmResult = jmsQueueSenderObj.send(hmInput)
		then:
		hmResult['appInfo'] == 'Exception caught:null'
	}


	def "test send j m s exception1"() throws JMSException {
		given:
		JMSException jmsEx = new JMSException('could not connect')
		Exception innerEx = new Exception('host not found')
		jmsEx.linkedException = innerEx
		jmsTemplateObj.getConnectionFactory() >> connectionFactoryObj
		connectionFactoryObj.createConnection() >> { throw jmsEx }
		when:
		hmResult = jmsQueueSenderObj.send(hmInput)
		then:
		hmResult['appInfo'] == 'JMSException:could not connect'
	}


	def "test send j m s exception2"() throws JMSException {
		given:
		JMSException jmsEx = new JMSException('could not close session')
		Exception innerEx = new Exception('host not found')
		jmsEx.linkedException = innerEx
		jmsTemplateObj.getConnectionFactory() >> connectionFactoryObj
		connectionFactoryObj.createConnection() >> connectionObj
		connectionObj.createSession(false, Session.AUTO_ACKNOWLEDGE) >> sessionObj
		sessionObj.createQueue(_ as String) >> queueObj
		queueObj.getQueueName() >> 'MPSQL.MSDBUS.DEV3.INT.MSRIL.2'
		sessionObj.createBytesMessage() >> bytesMessageObj
		sessionObj.createProducer(_ as Destination) >> messageProducerObj
		sessionObj.close() >> { throw jmsEx }
		when:
		hmResult = jmsQueueSenderObj.send(hmInput)
		then:
		hmResult['appInfo'] == 'JMSException:could not close session'
	}


	def "test send success"() throws JMSException {
		given:
		jmsTemplateObj.getConnectionFactory() >> connectionFactoryObj
		connectionFactoryObj.createConnection() >> connectionObj
		connectionObj.createSession(false, Session.AUTO_ACKNOWLEDGE) >> sessionObj
		sessionObj.createQueue(_ as String) >> queueObj
		queueObj.getQueueName() >> 'MPSQL.MSDBUS.DEV3.INT.MSRIL.2'
		sessionObj.createBytesMessage() >> bytesMessageObj
		sessionObj.createProducer(_ as Destination) >> messageProducerObj
		when:
		hmResult = jmsQueueSenderObj.send(hmInput)
		then:
		hmResult['appInfo'] == 'WirelessAutoReg Message sent successfully from sendmessagetoQueue'
	}
}
