package com.att.idp.idgraphuserregistrationms.request.validator

import com.att.idp.idgraphuserregistrationms.resource.request.UpdateUnifiedTOSRequest
import com.att.idp.idgraphuserregistrationms.resource.response.UpdateUnifiedTOSResponse
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap


class UpdateUnifiedTOSRequestValidatorTest extends Specification {
	

	def updateUnifiedTOSRequestValidator=new UpdateUnifiedTOSRequestValidator()

	UpdateUnifiedTOSRequest requestObj = null
	UpdateUnifiedTOSResponse responseObj=null
	Map<String, String> headers = new HashMap<>()
	public HttpHeaders requestHeader = null
	MultivaluedHashMap requestHeaders =null


	def setup() throws Exception {
		requestObj = new UpdateUnifiedTOSRequest()
		responseObj= new UpdateUnifiedTOSResponse()
		requestHeader= Mock(HttpHeaders)

		requestObj.callingSystemId = 'IDP'
		requestObj.isExternalCall = 'Y'
		requestObj.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
		requestObj.ban = '876110000'
		requestObj.hsiaTOSAcceptance = 'Y'

		ReflectionTestUtils.setField(updateUnifiedTOSRequestValidator, 'propUpdateUnifiedTOSCallingSystemIds', 'IDP|CSRIDP|DATAMGT|BBNMS')
		ReflectionTestUtils.setField(updateUnifiedTOSRequestValidator, 'propValidAgentCSIds', 'CSRIDP')

	}


	def "update unified tos request validator null req test"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, null)
		then:
		response.appInfo == 'Input Request Parameter is NULL / Empty.'

	}

	def "update unified tos req validator success without trace id test"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		//Mockito.doReturn(null).when(requestHeader).getHeaderString("idp-trace-id");
		//	requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'

		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Missing or Invalid IdpTraceId'
	}

	def "update unified tos requestunknownattribues"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		Map<String,Object> allUnknownAttributes =new HashMap<>()
		requestObj.setUnknownAttributes(allUnknownAttributes)
		allUnknownAttributes.put("test","test")
		when:
		UpdateUnifiedTOSResponse responseObj = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		responseObj.appInfo == 'Invalid Attributes passed in UpdateUnifiedTOSRequest : {test=test}'

	}
	def "update unified tos request validator success test"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response == null

	}


	def "update unified tos request null client id test"() throws Exception{
		//Mockito.doReturn(null).when(requestHeader).getHeaderString("idp-trace-id");
		given:
		//requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}


	def "update unified tos request empty client id test"() throws Exception{
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>' '
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Missing X-ATT-ClientId in request header'
	}


	def "update unified tos request invalid client id test"() throws Exception{
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>'ILM'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Invalid X-ATT-ClientId in request header'
	}
	def "update unified tos request  is external call level"() {
		given:
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestObj.isExternalCall = 'A'
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader,
				requestObj)
		then:
		response.appInfo == 'IsExternalCall is Invalid :: Should be Y or N'
	}

	def "update unified tos request  is external call level Y"() {
		given:
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestObj.setIsExternalCall("Y")
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader,
				requestObj)
		then:
		response == null
	}

	def "update unified tos request validator null ban test"() throws Exception {
		given:
		requestObj.ban = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Input ban is null or empty'

		when:
		requestObj.ban = ''
		UpdateUnifiedTOSResponse response2 = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response2.appInfo == 'Input ban is null or empty'

	}


	def "update unified tos request validator null tos flag test"() throws Exception {
		given:
		requestObj.hsiaTOSAcceptance = null
		requestObj.e911TOSAcceptance = null
		requestObj.iptvTOSAcceptance = null
		requestObj.wdmTOSAcceptance = null
		requestObj.wvmTOSAcceptance = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'TOS Acceptance Flags are null or empty in input'

	}


	def "update unified tos request validator invalid voiptos flag test"() throws Exception {
		given:
		requestObj.e911TOSAcceptance = 'P'
		requestObj.hsiaTOSAcceptance = 'Y'
		requestObj.iptvTOSAcceptance = 'Y'
		requestObj.wdmTOSAcceptance = 'N'
		requestObj.wvmTOSAcceptance = 'N'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Value of e911TOSAcceptance should be Y or N'

	}

	def "update unified tos request validator invalid hsiatos flag test"() throws Exception {
		given:
		requestObj.e911TOSAcceptance = 'Y'
		requestObj.hsiaTOSAcceptance = 'P'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Value of hsiaTOSAcceptance should be Y or N'

	}


	def "update unified tos request validator invalid iptvtos flag test"() throws Exception {
		given:
		requestObj.iptvTOSAcceptance = 'P'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Value of iptvTOSAcceptance should be Y or N'

	}

	def "update unified tos request validator invalid wdmtos flag test"() throws Exception {
		given:
		requestObj.wdmTOSAcceptance = 'P'
		requestObj.wvmTOSAcceptance = 'N'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Value of wdmTOSAcceptance should be Y or N'

	}

	def "update unified tos request validator invalid wvmtos flag test"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestObj.wdmTOSAcceptance = 'N'
		requestObj.wvmTOSAcceptance = 'P'
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Value of wvmTOSAcceptance should be Y or N'

	}


	def "update unified tos request validator all tos flag y test"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		String expectedResponse = 'HSIA, IPTV or E911 TOS AND WLL TOS cannot be Y together'
		requestObj.e911TOSAcceptance = 'Y'
		requestObj.hsiaTOSAcceptance = 'N'
		requestObj.wdmTOSAcceptance = 'Y'
		requestObj.wvmTOSAcceptance = 'Y'
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator
				.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == expectedResponse

		when:
		requestObj.e911TOSAcceptance = 'N'
		requestObj.iptvTOSAcceptance = 'Y'
		UpdateUnifiedTOSResponse response2 = updateUnifiedTOSRequestValidator
				.updateUnifiedTOSRequestValidator(requestHeader, requestObj)

		then:
		response2.appInfo == expectedResponse
		when:
		requestObj.iptvTOSAcceptance = 'N'
		requestObj.e911TOSAcceptance = 'N'
		requestObj.hsiaTOSAcceptance = 'Y'
		UpdateUnifiedTOSResponse response3 = updateUnifiedTOSRequestValidator
				.updateUnifiedTOSRequestValidator(requestHeader, requestObj)

		then:
		response3.appInfo == expectedResponse

	}

	def "update unified tos request validator missing prop test"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		ReflectionTestUtils.setField(updateUnifiedTOSRequestValidator, 'propUpdateUnifiedTOSCallingSystemIds', null)
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'The value of property updateUnifiedTOSCallingSystemIds is not configured in property files'

	}


	def "update unified tos request validator null agent id prop test"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		ReflectionTestUtils.setField(updateUnifiedTOSRequestValidator, 'propValidAgentCSIds', null)
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'The value of property Valid_Agent_CSIds is not configured in property files'

	}
	def "update unified tos request validator missing agent id prop test"() throws Exception {
		given:
		requestObj.getAgentId()== null
		requestObj.callingSystemId == 'CSRIDP'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'CSRIDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		ReflectionTestUtils.setField(updateUnifiedTOSRequestValidator, 'propValidAgentCSIds', 'CSRIDP')
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'AgentId is null or empty in input'

	}

	def "update unified tos request exception" () throws Exception {
		given:
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>> { throw ex }

		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSRequestValidator.updateUnifiedTOSRequestValidator(requestHeader, requestObj)

		then:
		response.appInfo== 'Exception thrown in UpdateUnifiedTOSRequestValidator.UpdateUnifiedTOSRequestValidator : No such property: ex for class: org.spockframework.mock.runtime.MockInvocation'

	}
}
