package com.att.idp.component

import com.att.idp.idgraphuserregistrationms.helper.G2GetBANByIPHelper
import org.hamcrest.CoreMatchers
import org.spockframework.spring.SpringBean

import static org.hamcrest.Matchers.anyOf

class QueryByIPEligibilityCompTest extends CompTestBase {

	private String uri = '/lsreg/queryByIPEligibility'


	private Map<String, String> getHeaders() {
		Map<String, String> headers = new HashMap<String, String>()
		headers['Content-Type'] = 'application/json'
		headers['X-ATT-ClientId'] ='DATAMGT'
		headers['idp-trace-id'] = 'cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0'
		return headers
	}


	def "query by i p eligibility success"() {
		HashMap g2GetBANByIPResp = readJsonFileToMap("mockResponse/g2GetBANByIP.json") as HashMap

		given:
		g2GetBANByIP.getBANByIP(_ as Map) >> g2GetBANByIPResp


		String req = '{' + '"ipAddress": "2611:1711:4881:3931:2a16:adsf:fe19:7be4"' + '}'

		expect:
		givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then()
				.statusCode(200).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
				.body("appStatusCode", CoreMatchers.equalTo("0"))
			//	.body("ban", CoreMatchers.equalTo("601210011"))
				.body("siteId",CoreMatchers.equalTo("601210011"))
		//		.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}

	def "query by i p eligibility error response"() {
		HashMap g2GetBANByIPResp = new HashMap()
		g2GetBANByIPResp.put("appStatusMsg", "ERR_BAN_NOT_FOUND")
		g2GetBANByIPResp.put("appStatusCode", "130")
		g2GetBANByIPResp.put("appCategoryCode", "4")
		g2GetBANByIPResp.put("appInfo","BAN does NOT exist in G2")

		given:
		g2GetBANByIP.getBANByIP(_ as Map) >> g2GetBANByIPResp


		String req = '{' + '"ipAddress": "2611:1711:4881:3931:2a16:adsf:fe19:7be4"' + '}'

		expect:
		givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then()
				.statusCode(404).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_BAN_NOT_FOUND"))
				.body("appStatusCode", CoreMatchers.equalTo("130"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}

	def "query by i p eligibility getBANByIP null response"() {
		given:
		g2GetBANByIP.getBANByIP(_ as Map) >> null


		String req = '{' + '"ipAddress": "2611:1711:4881:3931:2a16:adsf:fe19:7be4"' + '}'

		expect:
		givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then()
				.statusCode(500).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_SYS_APPL"))
				.body("appStatusCode", CoreMatchers.equalTo("602"))
				.body("appInfo",CoreMatchers.equalTo("Null Response from G2GetBANByIPHelper"))
				.body("error.errorId",CoreMatchers.equalTo("MS_MPSYS_BE_602"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}
}
