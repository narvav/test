package com.att.idp.idgraphuserregistrationms.request.validator

import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.idp.idgraphuserregistrationms.resource.response.SyncUserProfileResponse
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap


class ReprovisionUverseRequestValidatorTest extends Specification {

   def reprovisionUverseRequestValidator =new ReprovisionUverseRequestValidator()

     SyncUserProfileRequest requestObj = null
     SyncUserProfileResponse responseObj = null
     public HttpHeaders requestHeader=null

    MultivaluedHashMap requestHeaders =null

    def setup() {
        requestObj = new SyncUserProfileRequest()
        responseObj = new SyncUserProfileResponse()
        requestHeader = Mock(HttpHeaders)
        requestHeaders = new MultivaluedHashMap<>()

    }


    def "reprovision uverse returns error response when request is null"() {
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = reprovisionUverseRequestValidator.reprovisionUverse(null, requestHeader)
        then:
        response.appInfo == 'Input Request is NULL / Empty.'
    }


    def "reprovision uverse req validator success without trace id test"() throws Exception {

         given:
         requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'

        when:
        SyncUserProfileResponse response = reprovisionUverseRequestValidator.reprovisionUverse( requestObj,requestHeader)
        then:
        response.appInfo == 'Missing or Invalid IdpTraceId'
    }
       def "reprovision uverse returns error response when invalid attributes passed"() {
            given:
            Map<String,Object> allUnknownAttributes =new HashMap<>()
            requestObj.unknownAttributes = allUnknownAttributes
            allUnknownAttributes['test'] = 'test'
            requestObj.guid = '1234'
            requestObj.handle = 'handle'
            requestObj.source = 'source'
            requestObj.domain = 'domain'
            requestObj.destination = 'destination'
            requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
            requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
            ReflectionTestUtils.setField(reprovisionUverseRequestValidator, 'propReprovisionUverseCSI', 'ATLAS-UI')
            when:
            SyncUserProfileResponse response = reprovisionUverseRequestValidator.reprovisionUverse(requestObj, requestHeader)
            then:
            response.appStatusMsg == 'ERR_INVALID_DATA'
            response.appInfo=='Invalid Attributes passed in reprovisionUverseRequest : {destination=destination, guid=1234, handle=handle, source=source, test=test, domain=domain}'
        }

    def "reprovision request validator success test"() throws Exception {
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        requestObj.ban = '122434'
        ReflectionTestUtils.setField(reprovisionUverseRequestValidator, 'propReprovisionUverseCSI', 'IDP')
        when:
        SyncUserProfileResponse response = reprovisionUverseRequestValidator.reprovisionUverse(requestObj, requestHeader)
        then:
        response == null

    }

    def "reprovision requestnullclientid test"() throws Exception{
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        requestHeader.getHeaderString('X-ATT-ClientId')>>null
        when:
        SyncUserProfileResponse responseObj = reprovisionUverseRequestValidator.reprovisionUverse(requestObj,requestHeader)
        then:
        responseObj.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
    }

      def "reprovision uverse returns error response when request is invalid"() {
        given:
        requestObj.ban = '122434'
        requestObj.unvalidatedDomain = 'domain'
        requestObj.unvalidatedHandle = 'handle'
        requestObj.idpTraceId = '63430423=e32e323'
        requestObj.callingSystemId = 'IDP'
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'

        when:
        SyncUserProfileResponse response = reprovisionUverseRequestValidator.reprovisionUverse(requestObj, requestHeader)
        then:
         response.appInfo=='Exception thrown in ReprovisionUverseRequestValidator : null'
    }


    def "reprovision uverse returns valid response when request is valid"() {
        given:
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(reprovisionUverseRequestValidator, 'propReprovisionUverseCSI', 'IDP')
        when:
        SyncUserProfileResponse response = reprovisionUverseRequestValidator.reprovisionUverse(requestObj, requestHeader)
        then:
        response.appInfo == 'BAN is required in input request.'
    }

    def "reprovision uverse returns valid response when ban is valid"() {
        given:
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = '123243'
        ReflectionTestUtils.setField(reprovisionUverseRequestValidator, 'propReprovisionUverseCSI', 'validClientId')
        when:
        SyncUserProfileResponse response = reprovisionUverseRequestValidator.reprovisionUverse(request, requestHeader)
        then:
        response.appInfo == 'CallingSystemId Not Allowed :: Invalid CallingSystemId'
    }


    def "reprovision uverse returns valid response when exception"() {
        given:
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = '123243'
        when:
        SyncUserProfileResponse response = reprovisionUverseRequestValidator.reprovisionUverse(request, requestHeader)
        then:
        response.appInfo == 'Exception thrown in ReprovisionUverseRequestValidator : null'
    }

    def "reprovision uverse returns valid response when external call is not valid"() {
        given:
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = '123243'
        request.isExternalCall = 's'
        ReflectionTestUtils.setField(reprovisionUverseRequestValidator, 'propReprovisionUverseCSI', 'validClientId')
        when:
        SyncUserProfileResponse response = reprovisionUverseRequestValidator.reprovisionUverse(request, requestHeader)
        then:
        response.appInfo == 'IsExternalCall should be Y or N.'
    }

    def "reprovision uverse returns valid response when success"() {
        given:
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = '123243'
        request.isExternalCall = 's'
        request.agentId = 'cs4573'
        request.unvalidatedHandle = 'handel'
        request.unvalidatedDomain = 'domain'
        ReflectionTestUtils.setField(reprovisionUverseRequestValidator, 'propReprovisionUverseCSI', 'validClientId')
        when:
        SyncUserProfileResponse response = reprovisionUverseRequestValidator.reprovisionUverse(request, requestHeader)
        then:
        response.appInfo == 'IsExternalCall should be Y or N.'
    }

}
