package com.att.idp.component

import com.att.idp.idgraphuserregistrationms.queue.message.sender.JMSQueueSender
import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.MPSDefs
import org.spockframework.spring.SpringBean
import org.springframework.jdbc.core.JdbcTemplate

import static org.hamcrest.Matchers.equalTo

class ValidateAndSyncG2CompTest extends CompTestBase{

    private String uri = '/userprofile/activate/uban'
   // ToDo : The lines has been commented coz the ComopnentTestCases has put on hold for now. The Commented lines needed for the writing more ComponentTestCases.
    /*@SpringBean
    JmsTemplate jmsTemplate = Mock()*/
    @SpringBean FeatureManagerHelper featureManager= Mock()

    @SpringBean
    JdbcTemplate jdbcTemplate = Mock()
    @SpringBean
    JMSQueueSender jmsQueueSender = Mock()

    Map<String, String> requestHeader = null
    SyncUserProfileRequest requestObj = null;
    Map<String, String> queryAccountInfoResponse = null
    Map<String, String> getProvisionedServicesDBHelperResponse = null
    Map<String, String> getMemberServicesDBHelperResponse = null
    Map<String, String> hmResponse = null
    Map<String, String> hmBanQuery = null
    List<Object> objectList = null
    List<Object> alBanQuery = null
    ArrayList<HashMap<String,Object>> alQueryAccountInfoResponse= null
    ArrayList<HashMap<String,Object>> alGetProvisionedServicesDBHelperResponse= null

    String queryAccountInfo
    String banQuery
    String memberServiceBanQuery

        def setup(){

            getMemberServicesDBHelperResponse = new HashMap<>()

            requestHeader = new HashMap<String, String>()
            requestHeader['Content-Type'] = 'application/json'
            requestHeader['idp.trace_id'] = '47e8df49d3410d77:e9123acf450013b3:0:0'
            requestHeader['X-ATT-ClientId'] = 'ATLAS-UI'

            hmResponse = new HashMap<String, String>()
            hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
            hmResponse['appInfo'] = 'Success'

            requestObj = new SyncUserProfileRequest()
            requestObj.transactionName = 'ValidateAndSyncG2'
            requestObj.ban = '1020095106'
            requestObj.agentId = 'ak1568'

            objectList = new ArrayList<String>();
            objectList.add("1020095106")

            queryAccountInfoResponse = new HashMap<>()
            queryAccountInfoResponse.put("BAN","000982680");
            queryAccountInfoResponse.put("BILL_CYCLE","30");
            queryAccountInfoResponse.put("LEGAL_ENTITY","JTT C");
            queryAccountInfoResponse.put("FULLNAME","Reg@ Dev");
            queryAccountInfoResponse.put("ACCOUNT_TYPE","B");
            queryAccountInfoResponse.put("ACCOUNT_SUBTYPE","9");
            queryAccountInfoResponse.put("CREATE_DATE","2017-02-28 09:06:10.0");
            queryAccountInfoResponse.put("LAST_MODIFIED","2017-02-28 09:07:05.0");
            queryAccountInfoResponse.put("LAST_MODIFIED_BY","LSRegWeb");
            queryAccountInfoResponse.put("SITE_ID","site1");
            queryAccountInfoResponse.put("STREET1","2600Camino Ramon");
            queryAccountInfoResponse.put("STREET2",null);
            queryAccountInfoResponse.put("STREET3",null);
            queryAccountInfoResponse.put("STREET4",null);
            queryAccountInfoResponse.put("STREET5",null);
            queryAccountInfoResponse.put("CITY","San Ramon");
            queryAccountInfoResponse.put("STATE","CA");
            queryAccountInfoResponse.put("ZIP","10606-1234");
            queryAccountInfoResponse.put("IPDSLAM_IND","N");
            queryAccountInfoResponse.put("SUPERSEDED_MAIN_MID",null);
            queryAccountInfoResponse.put("TOS_ACCEPTANCE_FLAGS",null);
            queryAccountInfoResponse.put("wll_tos_acceptance_flags",null);
            queryAccountInfoResponse.put("PREPROVISION_IND",null);
            queryAccountInfoResponse.put("ORDER_DUE_DATE","2017-06-27T00:00:00.000Z");
            queryAccountInfoResponse.put("HSIA_TOS_DATE",null);
            queryAccountInfoResponse.put("E911_TOS_DATE",null);
            queryAccountInfoResponse.put("IPTV_TOS_DATE",null);
            queryAccountInfoResponse.put("WDM_TOS_DATE","02282017 06:07:05");
            queryAccountInfoResponse.put("WVM_TOS_DATE",null);
            queryAccountInfoResponse.put("ORDER_TAKEN_DATE","2014-03-14T07:59:59.000Z");
            queryAccountInfoResponse.put("RG_ACTIVATED",null);
            queryAccountInfoResponse.put("TN_ACTIVATED",null);

            alQueryAccountInfoResponse = new ArrayList<>()
            alQueryAccountInfoResponse.add(queryAccountInfoResponse)

            getProvisionedServicesDBHelperResponse = new HashMap<>()
            getProvisionedServicesDBHelperResponse.put("PROVISIONED_SERVICE_NUM" , "148")
            getProvisionedServicesDBHelperResponse.put("PRODUCT_ID" , "8")
            getProvisionedServicesDBHelperResponse.put("INSTANCE_ID" , "gdInstance303")
            getProvisionedServicesDBHelperResponse.put("SERVICE_ELIGIBILITY" , "Y")
            getProvisionedServicesDBHelperResponse.put("CREATE_DATE" , "07282005 13:02:31")
            getProvisionedServicesDBHelperResponse.put("LAST_MODIFIED" , "07282005 13:02:31")
            getProvisionedServicesDBHelperResponse.put("LAST_MODIFIED_BY" , "SDP")
            getProvisionedServicesDBHelperResponse.put("PORTAL_PROVIDER" , "BYOP")
            getProvisionedServicesDBHelperResponse.put("UNVALIDATED_HANDLE" , "qay_dev_provHSIA303")
            getProvisionedServicesDBHelperResponse.put("UNVALIDATED_DOMAIN" , "sbcglobal.net")
            getProvisionedServicesDBHelperResponse.put("BAN" , "222222303")
            getProvisionedServicesDBHelperResponse.put("service_name" , "HSIA")
            getProvisionedServicesDBHelperResponse.put("EMAIL_ELIGIBLE" , "N")
            getProvisionedServicesDBHelperResponse.put("SOR_INVARIANT_ID" , null)

            alGetProvisionedServicesDBHelperResponse = new ArrayList<>()
            alGetProvisionedServicesDBHelperResponse.add(getProvisionedServicesDBHelperResponse)

            hmBanQuery = new HashMap<>()
            hmBanQuery.put("PROVISIONED_SERVICE_NUM" , "148")
            hmBanQuery.put("PRODUCT_ID" , "8")
            hmBanQuery.put("INSTANCE_ID" , "gdInstance303")
            hmBanQuery.put("SERVICE_ELIGIBILITY" , "Y")
            hmBanQuery.put("CREATE_DATE" , "07282005 13:02:31")
            hmBanQuery.put("LAST_MODIFIED" , "07282005 13:02:31")
            hmBanQuery.put("LAST_MODIFIED_BY" , "SDP")
            hmBanQuery.put("PORTAL_PROVIDER" , "BYOP")
            hmBanQuery.put("UNVALIDATED_HANDLE" , "qay_dev_provHSIA303")
            hmBanQuery.put("UNVALIDATED_DOMAIN" , "sbcglobal.net")
            hmBanQuery.put("BAN" , "222222303")
            hmBanQuery.put("service_name" , "HSIA")
            hmBanQuery.put("EMAIL_ELIGIBLE" , "N")
            hmBanQuery.put("SOR_INVARIANT_ID" , null)

            alBanQuery = new ArrayList<>()
            alBanQuery.add(hmBanQuery)

            queryAccountInfo = "SELECT ban,bill_cycle, legal_entity, fullname,account_type,account_subtype, create_date,last_modified,last_modified_by, site_id, street1, street2, street3, street4, street5, city, state, zip, ipdslam_ind, superseded_main_mid, tos_acceptance_flags, wll_tos_acceptance_flags, preprovision_ind, TO_CHAR(order_due_date, 'YYYY-MM-DD\"T\"HH24:MI:SS.ff3\"Z\"') as order_due_date, TO_CHAR (hsia_tos_date, 'MMddyyyy HH24:mi:ss') as hsia_tos_date, TO_CHAR (e911_tos_date, 'MMddyyyy HH24:mi:ss') as e911_tos_date, TO_CHAR (iptv_tos_date, 'MMddyyyy HH24:mi:ss') as iptv_tos_date, TO_CHAR (wdm_tos_date, 'MMddyyyy HH24:mi:ss') as wdm_tos_date, TO_CHAR (wvm_tos_date, 'MMddyyyy HH24:mi:ss') as wvm_tos_date, TO_CHAR (order_taken_date, 'YYYY-MM-DD\"T\"HH24:MI:SS.ff3\"Z\"') as order_taken_date, rg_activated, tn_activated FROM AccountInfo WHERE ban = ?";

            banQuery = " select provservice.provisioned_service_num, provservice.product_id, provservice.instance_id,  provservice.service_eligibility, to_char(provservice.create_date, 'MMDDYYYY HH24:mi:ss') as create_date, to_char(provservice.last_modified, 'MMDDYYYY HH24:mi:ss') as last_modified, provservice.last_modified_by, pro.portal_provider, pro.unvalidated_handle , pro.unvalidated_domain , pro.provisioned_service_num, provservice.ban, serv.service_name, serv.email_eligible, provservice.sor_invariant_id from provisionedhsia pro,  provisionedservice provservice, service serv where provservice.product_id=serv.service_id (+) AND provservice.provisioned_service_num = pro.provisioned_service_num (+) AND provservice.ban = ?";

            memberServiceBanQuery = "SELECT  secq.security_question_type as security_question_type, secq.security_question_active as security_question_active,  mem.security_question_id_1, secq1.security_question as security_question_1, mem.security_answer_1,  secq1.security_question_type as security_question_1_type, secq1.security_question_active as security_question_1_active,  mem.security_question_id_2, secq2.security_question as security_question_2, mem.security_answer_2,  secq2.security_question_type as security_question_2_type, secq2.security_question_active as security_question_2_active,  mem.previous_contact_email, TO_CHAR(mem.contact_email_est_date,'MMDDYYYY HH24:mi:ss') as contact_email_est_date,  mem.language, TO_CHAR(mem.tos_reject_date, 'MMDDYYYY HH24:mi:ss') AS tos_reject_date, mem.num_tos_rejects,  mem.alert_ind,  mem.agg_email_status, mem.last_member_status as last_member_status_code, stat3.status_name as last_member_status_name, mem.credit_checked_ind, mem.yreg_complete_ind, TO_CHAR(mem.lockout_timestamp, 'MMDDYYYY HH24:mi:ss') as lockout_timestamp, mem.firstname, mem.lastname, mem.nickname, mem.last_four_ssn, mem.security_question_id,  mem.gender, mem.proofing_zip, secq.security_question,  mem.contact_email, mem.contact_email_valid, mem.password_dirty, mem.sha1_password,  mem.des3_password, mem.failed_auth_count,  TO_CHAR(mem.delete_request_date, 'MMDDYYYY HH24:mi:ss') AS delete_request_date, mem.token, mem.remarks, mem.ban, mem.member_num, mem.member_name, mem.group_num,  dom.domain_name, mem.domain_id, mem.enc_password,  mem.md5_password, mem.parent_child_ind, mem.member_state,  mem.agg_access_status, mem.agg_service_status, mem.mailhost,  mem.fullname, mem.account_type,mem.optout_ind, mem.migration_ind,  TO_CHAR(mem.migration_date, 'MMDDYYYY HH24:mi:ss') AS migration_date,  TO_CHAR(mem.create_date, 'MMDDYYYY HH24:mi:ss') AS mem_create_date,  TO_CHAR(mem.last_modified, 'MMDDYYYY HH24:mi:ss') AS mem_last_modified,  mem.last_modified_by AS last_modified_by,  memGroup.parent_name, parentDom.domain_name as parent_domain, memGroup.premium_800_ind, memGroup.bulk_billing_ind,  memGroup.access_code, mem.sor_id, sor.sor_name, mem.access_id,  acc.access_name, serv.service_name, serv.service_type,  serv.subaccount_eligible, serv.email_eligible, serv.entity_type,  memService.service_id, memService.member_status AS member_status_code,  memService.group_status AS group_status_code, stat1.status_name AS group_status_name,  stat2.status_name AS member_status_name,  TO_CHAR(memService.terminate_date, 'MMDDYYYY HH24:mi:ss') AS terminate_date,  TO_CHAR(memService.create_date, 'MMDDYYYY HH24:mi:ss') AS create_date, TO_CHAR(memService.last_modified, 'MMDDYYYY HH24:mi:ss') AS last_modified, memService.last_modified_by AS last_modified_by, memService.instance_id,  TO_CHAR(memService.pending_disconnect_date, 'MMDDYYYY HH24:mi:ss') AS pending_disconnect_date, portal.last_modified_by AS portal_last_modified_by, TO_CHAR(portal.create_date, 'MMDDYYYY HH24:mi:ss') AS portal_create_date, portal.portal_provider as portal_provider, memService.sor_id as service_sor_id, sor1.sor_name as service_sor_name,  iptv.portal_svc_provider as portal_svc_provider,  memService.sor_invariant_id, memService.atlas_last_timestamp, memService.nickname as service_nickname,  memService.default_account, TO_CHAR(memService.date_default_est, 'MMDDYYYY HH24:mi:ss') AS date_default_est, memService.cpni_impacted, memService.suspend_reason_code, mem.dsl_net_password, mem.dsl_net_pw_encr_type,  servassoc.sor_id1,  nvl(servassoc.sor_invariant_id1, '--NULL--') as sor_invariant_id1, sor2.sor_name as sor_name1,  servassoc.sor_id2,  nvl(servassoc.sor_invariant_id2, '--NULL--') as sor_invariant_id2, sor3.sor_name as sor_name2,  servassoc.assigned_by as asso_assigned_by, servassoc.last_modified_by as asso_last_modified_by,  TO_CHAR(servassoc.create_date, 'MMDDYYYY HH24:mi:ss') AS asso_create_date,  TO_CHAR(servassoc.last_modified, 'MMDDYYYY HH24:mi:ss') AS asso_last_modified,  TO_CHAR(portal.last_modified, 'MMDDYYYY HH24:mi:ss') AS portal_provider_last_modified, dsl.tdsl_ind, dsl.wtn, dsl.dslam_type, TO_CHAR(mem.csr_initiated_lockout_ts, 'MMDDYYYY HH24:mi:ss') AS csr_initiated_lockout_ts, mem.browser_language, mem.contact_email_status, mem.ssha_password,  mem.slid_member_num, mem.autogenerated_ind, mem.activated_ind, portal.plite_ind,  memService.parent_sor_id, memService.parent_sor_invariant_id, memService.uverse_service_ind, serv.major_service_id,  mem.birthdate_venc, mem.passcode_venc, mem.security_answer_venc, TO_CHAR(mem.last_verified, 'MMDDYYYY HH24:mi:ss') AS last_verified, mem.created_by, TO_CHAR(mem.main_ctn_opt_out, 'MMDDYYYY HH24:mi:ss') AS main_ctn_opt_out, dsl.dns_err_optout_ind, memService.unification_pending, TO_CHAR(mem.onl_qa_est_date, 'MMDDYYYY HH24:mi:ss') AS onl_qa_est_date,  memaux.enc_password_venc, memaux.md5_password_venc, memaux.sha1_password_venc,  memaux.des3_password_venc, memaux.ssha_password_venc, memaux.security_answer_1_venc,  memaux.security_answer_2_venc, TO_CHAR(memaux.recent_fraud_pw_date, 'MMDDYYYY HH24:mi:ss') AS recent_fraud_pw_date  FROM  MEMBER mem,MEMBERGROUP memGroup,MEMBERSERVICE memService,DOMAIN dom, DOMAIN parentDom, SecurityQuestion secq, SYSTEMOFRECORD sor,NETWORKACCESS acc,SERVICE serv,STATUS stat1,STATUS stat2,STATUS stat3,  PORTALUSER portal, SYSTEMOFRECORD sor1, SecurityQuestion secq1, SecurityQuestion secq2, IPTVUSER iptv,  serviceassociation servassoc, SYSTEMOFRECORD sor2, SYSTEMOFRECORD sor3,  MEMBERAUX memaux,  DSLUSER dsl  WHERE  mem.sor_id=sor.sor_id AND mem.access_id=acc.access_id  AND mem.domain_id=dom.domain_id AND memGroup.domain_id=parentDom.domain_id AND mem.group_num=memGroup.group_num  AND mem.security_question_id =secq.security_question_id (+)  AND mem.security_question_id_1 =secq1.security_question_id (+)  AND mem.security_question_id_2 =secq2.security_question_id (+)  AND memService.sor_id =sor1.sor_id (+)  AND memService.member_num = portal.member_num(+) AND memService.service_id = portal.service_id(+) AND mem.member_num=memService.member_num (+) AND memService.service_id=serv.service_id  (+)  AND memService.member_status=stat2.status_code (+) AND memService.group_status = stat1.status_code (+) AND mem.last_member_status = stat3.status_code(+)  AND memService.member_num = iptv.member_num(+) AND memService.service_id = iptv.service_id(+)  AND servassoc.sor_id1(+) = memService.sor_id AND servassoc.sor_id1 = sor2.sor_id (+) AND servassoc.sor_id2 = sor3.sor_id (+)  AND servassoc.sor_invariant_id1(+) = memService.sor_invariant_id  AND memService.member_num = dsl.member_num (+)  AND mem.member_num = memaux.member_num (+)  AND mem.parent_child_ind='P' AND mem.ban=?"

            jdbcTemplate.queryForList(queryAccountInfo as String, _) >> alQueryAccountInfoResponse
            jdbcTemplate.queryForList(banQuery as String, _) >> alGetProvisionedServicesDBHelperResponse
            jdbcTemplate.queryForList(memberServiceBanQuery as String, _) >> null

        }

    def "test ValidateAndSyncG2 null CallingSystemId error case"() {

        given:
        requestHeader['X-ATT-ClientId'] = null

        expect:
        givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri).then().statusCode(400)
                .assertThat().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .assertThat().body("appStatusCode", equalTo("100"))
                .assertThat().body("appInfo", equalTo("Input callingSystemId is invalid"))
    }

    def "test ValidateAndSyncG2 missing CallingSystemId error case"() {

        given:
        requestHeader.remove('X-ATT-ClientId')

        expect:
        givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri).then().statusCode(400)
                .assertThat().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .assertThat().body("appStatusCode", equalTo("100"))
                .assertThat().body("appInfo", equalTo("Missing or invalid X-ATT-ClientId in request header"))
    }

    def "test ValidateAndSyncG2 invalid CallingSystemId error case"() {

        given:
        requestHeader['X-ATT-ClientId'] = 'invalid'

        expect:
        givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri).then().statusCode(400)
                .assertThat().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .assertThat().body("appStatusCode", equalTo("100"))
                .assertThat().body("appInfo", equalTo("Input callingSystemId is invalid"))
    }

    def "test ValidateAndSyncG2 unknown attributes error case"() {

        given:
        requestObj.source = 'YAHOO'
        requestObj.guid = '123456789'
        requestObj.handle = 'handle'
        requestObj.domain = 'domain'
        requestObj.unvalidatedHandle = 'unvalidatedHandle'
        requestObj.unvalidatedDomain = 'unvalidated.Domain'

        expect:
        givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri).then().statusCode(400)
                .assertThat().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .assertThat().body("appStatusCode", equalTo("100"))
                .assertThat().body("appInfo", equalTo("Invalid Attributes passed in ValidatAndSyncG2 Request : {unvalidatedDomain=YAHOO, domain=domain, guid=123456789, handle=handle, unvalidatedUserId=null, source=YAHOO}"))
    }

    def "test ValidateAndSyncG2 when ban contains white space"() {

        given:
        requestObj.ban = "             "

        expect:
        givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri).then().statusCode(400)
                .assertThat().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .assertThat().body("appStatusCode", equalTo("100"))
                .assertThat().body("appInfo", equalTo("BAN must be numeric"))
    }

    def "test ValidateAndSyncG2 when ban contains non-numeric data"() {

        given:
        requestObj.ban = "123svwdf @'/."

        expect:
        givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri).then().statusCode(400)
                .assertThat().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .assertThat().body("appStatusCode", equalTo("100"))
                .assertThat().body("appInfo", equalTo("BAN must be numeric"))
    }

    def "test ValidateAndSyncG2 when ban not present"() {

        given:
        requestObj.ban = null

        expect:
        givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri).then().statusCode(400)
                .assertThat().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .assertThat().body("appStatusCode", equalTo("100"))
                .assertThat().body("appInfo", equalTo("BAN is required in input request."))
    }

    def "test ValidateAndSyncG2 when agentId contains white space"() {

        given:
        requestObj.agentId = "     "

        expect:
        givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri).then().statusCode(400)
                .assertThat().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .assertThat().body("appStatusCode", equalTo("100"))
                .assertThat().body("appInfo", equalTo("agentId length is invalid"))
    }

    def "test ValidateAndSyncG2 when agentId contains more than max length"() {

        given:
        requestObj.agentId = "123svwdf @'/."

        expect:
        givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri).then().statusCode(400)
                .assertThat().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .assertThat().body("appStatusCode", equalTo("100"))
                .assertThat().body("appInfo", equalTo("agentId length is invalid"))
    }

    def "test ValidateAndSyncG2 when IsExternalCall not contains Y or N"() {

        given:
        requestObj.isExternalCall = 'a'

        expect:
        givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri).then().statusCode(400)
                .assertThat().body("appStatusMsg", equalTo("ERR_INVALID_DATA"))
                .assertThat().body("appStatusCode", equalTo("100"))
                .assertThat().body("appInfo", equalTo("IsExternalCall should be Y or N."))
    }

    def "test ValidateAndSyncG2 when ValidateAndSyncG2 Message sent successfully from sendmessagetoQueue Success case"() {

        given:

        queryAccountInfoResponse.put("wll_tos_acceptance_flags","|WDM|");
        jmsQueueSender.send(_) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "ValidateAndSyncG2 Message sent successfully from sendmessagetoQueue")

        expect:
        givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri).then().statusCode(200)
                .assertThat().body("appStatusMsg", equalTo("SUCCESS"))
                .assertThat().body("appStatusCode", equalTo("0"))
                .assertThat().body("appInfo", equalTo("ValidateAndSyncG2 Message sent successfully from sendmessagetoQueue"))

    }

   /* def "test ValidateAndSyncG2 when ERR_BAN_NOT_REGISTERED Error case"() {

        given:

        expect:
        givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri).then().statusCode(400)
                .assertThat().body("appStatusMsg", equalTo("ERR_BAN_NOT_REGISTERED"))
                .assertThat().body("appStatusCode", equalTo("449"))
                .assertThat().body("appInfo", equalTo("Customer not registered"))

    }

    def "test ValidateAndSyncG2 when ERR_BAN_NOT_FOUND Error case1"() {

        given:

        getProvisionedServicesDBHelperResponse.remove("service_name")

        expect:
        givenBaseSpec().headers(requestHeader).body(requestObj).when().post(uri).then().statusCode(400)
                .assertThat().body("appStatusMsg", equalTo("ERR_NOT_PROVISIONED"))
                .assertThat().body("appStatusCode", equalTo("202"))
                .assertThat().body("appInfo", equalTo("Customer not provisioned"))

    }*/

}
