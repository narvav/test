package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.helper.SyncUserProfileHelper
import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.idp.idgraphuserregistrationms.resource.response.SyncUserProfileResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.junit.jupiter.api.Assertions
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders


class SyncUserProfileServiceImplTest extends Specification {


    def syncUserProfileServiceImplObj= new SyncUserProfileServiceImpl()

    SyncUserProfileHelper syncUserProfileHelperObj=Mock(SyncUserProfileHelper)

    SyncUserProfileRequest requestObj = null

    private HttpHeaders httpHeaders


    def setup() throws Exception {
        syncUserProfileServiceImplObj.syncUserProfileHelper=syncUserProfileHelperObj
        requestObj = new SyncUserProfileRequest()
        requestObj.callingSystemId = 'IDP'
        requestObj.ban = '112222222'
        requestObj.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
        requestObj.transactionName = 'SyncUserProfile'
    }


    def "test syncuserprofile null case"() {
        when:
        SyncUserProfileResponse response = syncUserProfileServiceImplObj.syncUserProfile(requestObj,httpHeaders)
        then:
        response.appInfo == 'Null response from syncUserProfileHelper.syncUserProfile'
        HashMap hmResponse = new HashMap()
        when:
        hmResponse[MPSDefs.APP_STATUS_CODE] = null
        syncUserProfileHelperObj.syncUserProfile(_)>>hmResponse
        then:
        response.appInfo == 'Null response from syncUserProfileHelper.syncUserProfile'
    }


    def "test syncuserprofile success case"() {
        given:
        HashMap hmResponse = new HashMap()
        hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
        hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
        hmResponse['appInfo'] = 'Success'
        syncUserProfileHelperObj.syncUserProfile(_)>>hmResponse
        when:
        SyncUserProfileResponse response = syncUserProfileServiceImplObj.syncUserProfile(requestObj, httpHeaders)
        then:
        response != null
        response.idpTraceId != null
        response.transactionName == 'SyncUserProfile'
    }


    def "test syncuserprofile null app status code"() {
        given:
        HashMap hmResponse = new HashMap()
        hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
        hmResponse[MPSDefs.APP_STATUS_CODE] = null
        syncUserProfileHelperObj.syncUserProfile(_) >> hmResponse
        when:
        SyncUserProfileResponse response = syncUserProfileServiceImplObj.syncUserProfile(requestObj, httpHeaders)
        then:
        response.appInfo == 'Null response from syncUserProfileHelper.syncUserProfile'
    }
}