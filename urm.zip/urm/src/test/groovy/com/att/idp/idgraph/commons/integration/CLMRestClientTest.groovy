package com.att.idp.idgraph.commons.integration

import com.att.idp.http.client.config.RestTemplateBeanFactory
import com.att.idp.idgraph.commons.integration.model.CLMNotificationRequest
import com.att.idp.idgraph.commons.integration.model.CLMNotificationResponse
import com.att.mpsys.common.utils.CErrorDefs
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.retry.RetryContext
import org.springframework.retry.support.RetrySynchronizationManager
import org.springframework.web.client.HttpServerErrorException
import org.springframework.web.client.RestTemplate
import spock.lang.Specification

class CLMRestClientTest extends Specification {
    def restTemplate = Mock(RestTemplate)
    def beanFactory = Mock(RestTemplateBeanFactory)
    def clmNotificationRequest
    def clmNotificationResponse
    def responseEntity
    def client

    def setup() {
        RetrySynchronizationManager.register(Mock(RetryContext))

        beanFactory.getObject(CLMRestClient.MULE_SOFT_REST_CLIENT) >> restTemplate
        client = new CLMRestClient(beanFactory)
        client.restTemplate = restTemplate

        client.ccmulesoftServerUrl = "http://localhost:8080"
        client.ccmulesoftEndpoint = "/api/notify"
        client.clientid = "test-client-id"
        client.clientsecret = "test-client-secret"

        clmNotificationRequest = CLMNotificationRequest.builder().build()

    }

    def "should send notification successfully with 200 OK"() {
        given:
        def clmNotificationResponse = new CLMNotificationResponse(statusCode: statusCode, statusMessage: "Success")
        def responseEntity = new ResponseEntity<>(clmNotificationResponse, HttpStatus.OK)

        restTemplate.postForEntity(_ as String, _, CLMNotificationResponse) >> responseEntity

        when:
        def result = client.sendCLMNotification(clmNotificationRequest)

        then:
        result.statusCode == statusCode

        where:
        statusCode << [200, 201, 202] // Testing multiple success codes
    }

    def "should send notification successfully with 4xx"() {
        given:
        def clmNotificationResponse = new CLMNotificationResponse(statusCode: status.value(), statusMessage: "Client Error")
        def responseEntity = new ResponseEntity<>(clmNotificationResponse, status)

        restTemplate.postForEntity(_ as String, _, CLMNotificationResponse) >> responseEntity

        when:
        def result = client.sendCLMNotification(clmNotificationRequest)

        then:
        result.statusCode == status.value()

        where:
        status << [HttpStatus.BAD_REQUEST, HttpStatus.FORBIDDEN, HttpStatus.UNAUTHORIZED] // Testing multiple 4xx codes
    }

    def "should handle 500 Internal Server Error"() {
        given:
        def clmNotResponse = new CLMNotificationResponse(statusCode: 500, statusMessage: "Internal Server Error")
        def errorResponse = new ResponseEntity<>(clmNotResponse, HttpStatus.INTERNAL_SERVER_ERROR)
        def error = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error", null, null, null)
        restTemplate.postForEntity(_ as String, _, CLMNotificationResponse) >> { throw error }

        when:
        def result = client.sendCLMNotification(clmNotificationRequest)

        then:
        thrown(HttpServerErrorException)
    }

    def "should handle error response from CLM"() {
        given:
        restTemplate.postForEntity(_ as String, _, CLMNotificationResponse) >> null

        when:
        def result = client.sendCLMNotification(clmNotificationRequest)

        then:
        thrown(HttpServerErrorException)
    }

    def "should handle null response from CLM"() {
        given:
        def errorResponse = new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR)
        restTemplate.postForEntity(_ as String, _, CLMNotificationResponse) >> errorResponse

        when:
        def result = client.sendCLMNotification(clmNotificationRequest)

        then:
        thrown(HttpServerErrorException)
    }

    def "should handle 502 Bad Gateway error"() {
        given:
        def errorResponse = new ResponseEntity<>(null, HttpStatus.BAD_GATEWAY)
        restTemplate.postForEntity(_, _, CLMNotificationResponse) >> errorResponse

        when:
        def result = client.sendCLMNotification(clmNotificationRequest)

        then:
        thrown(HttpServerErrorException)
    }

    def "should handle other exceptions and set external system error code"() {
        given:
        restTemplate.postForEntity(_, _, CLMNotificationResponse) >> { throw new RuntimeException("other error") }

        when:
        def result = client.sendCLMNotification(clmNotificationRequest)

        then:
        result.statusCode == CErrorDefs.ERR_EXTERNAL_SYS_NUM
        result.statusMessage.contains("other error")
    }
}
