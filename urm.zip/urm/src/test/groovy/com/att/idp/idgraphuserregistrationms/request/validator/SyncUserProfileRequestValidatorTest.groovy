package com.att.idp.idgraphuserregistrationms.request.validator

import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.idp.idgraphuserregistrationms.resource.response.SyncUserProfileResponse
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap


class SyncUserProfileRequestValidatorTest extends Specification {


    def syncUserProfileRequestValidator = new SyncUserProfileRequestValidator()

    SyncUserProfileRequest requestObj = null
    SyncUserProfileResponse responseObj = null

    private Map<String, String> headers = new HashMap<>()

    public HttpHeaders requestHeader = null

    MultivaluedHashMap requestHeaders =null


    def setup() throws Exception {
        requestObj = new SyncUserProfileRequest()
        requestHeader = Mock(HttpHeaders)
        responseObj = new SyncUserProfileResponse()
        requestHeaders = new MultivaluedHashMap<>(headers)

        requestObj.callingSystemId = 'ATLAS-UI'
        requestObj.transactionName = 'SyncUserProfile'
        requestObj.ban = 'VD0007556'
        requestObj.agentId = '12345'
        requestObj.guid = '12321323'
        requestObj.destination = 'YAHOO'
        requestObj.source = 'MPS'
        requestObj.handle = 'myhandle'
        requestObj.destination = 'att.com'
        requestObj.isExternalCall = 'N'


        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystemCSI', 'DATAMGT|UST|ATLAS-UI|IDP')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'defaultSyncCcrTableNames', 'member|memberdevice' )
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'defaultSyncCgTableNames', 'subscriberinfo|subscriberprofile|componentid|componentprofile|userid|userprofile')
    }


    def "sync user profile request validator null req test"() throws Exception {
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, null)
        then:
        response.appInfo == 'Input Request Parameter is NULL / Empty.'
    }
    def "sync user profile req validator without trace id test"() throws Exception {
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response.appInfo == 'Missing or Invalid IdpTraceId'
    }
    def "sync user profile request unknown attributes test"() throws Exception{
        given:
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'

        Map<String,Object> allUnknownAttributes =new HashMap<>()
        allUnknownAttributes['test'] = 'test'
        allUnknownAttributes['unvalidatedUserId'] = 'test'
        allUnknownAttributes['unvalidatedDomain'] = 'test'

        requestObj.unknownAttributes = allUnknownAttributes
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response.appInfo == 'Invalid Attributes passed in syncUserProfileRequest : {unvalidatedUserId=test, unvalidatedDomain=test, test=test}'
    }

    def "sync user profile success test"() throws Exception{
        given:
        requestObj.domain = null
        requestObj.handle = null
        requestObj.guid = null
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response==null
    }

    def "sync user profile request null client id test"() throws Exception{
        given:
        requestHeader.getHeaderString('X-ATT-ClientId')>>null
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
    }


    def "sync user profile request request empty client id test"() throws Exception{
        given:
        requestObj.guid = null
        requestObj.domain = null
        requestObj.handle = null
        requestHeader.getHeaderString('X-ATT-ClientId')>>''
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response.appInfo == 'Missing X-ATT-ClientId in request header'
    }

    def "sync user profile is external call test"() throws Exception{
        given:
        requestObj.isExternalCall = 'Test'
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response.appInfo == 'IsExternalCall must be one of Y or N'
    }


    def "sync user profile if ban and domain and handle or guid null test"() throws Exception{
        given:
        requestObj.guid = null
        requestObj.domain = null
        requestObj.ban = null
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response.appInfo == 'Either ban, guid OR userId/domain must be present'
    }

    def "sync user profile if destination null test"() throws Exception{
        given:
        requestObj.destination = null

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response.appInfo == 'Destination is missing in the input request'
    }

    def "sync user profile if domain and handle or guid test"() throws Exception{
        given:
        requestObj.domain = null
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response.appInfo == 'Only one of ban, guid and userId/domain is valid'
    }


    def "sync user profile if ban not null test"() throws Exception{
        given:
        requestObj.ban = null
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response.appInfo == 'Only one of guid and userId/domain is valid'
    }


    def "sync user profile if ban not null and destination yahoo test"() throws Exception{
        given:
        requestObj.guid = null
        requestObj.domain = null
        requestObj.handle = null
        requestObj.destination = 'YAHOO'
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response.appInfo == 'BAN not valid for Sync to YAHOO or HALOC/CCR destinations'
    }
    def "sync user profile if returns valid response when ban is valid"() {
        given:
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = '123243'
        request.destination = 'G2LDAP'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystemCSI', 'validClientId')
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)
        then:
        response.appInfo == 'CallingSystemId Not Allowed :: Invalid CallingSystemId'
    }
    def "sync user profile if ban not null and dest test"() throws Exception{
        given:
        requestObj.guid = null
        requestObj.domain = null
        requestObj.handle = null
        requestObj.destination = 'ABC'
        requestObj.isExternalCall = 'Y'
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response.appInfo == 'Invalid Sync between Source/Destination'
    }

    def "sync user profile dest test"() throws Exception{
        given:
        requestObj.guid = null
        requestObj.ban = '12214214'
       // requestObj.domain = 'att.net'
        requestObj.handle = null
        requestObj.destination = 'ABC'
        requestObj.isExternalCall = 'Y'
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response.appInfo == 'ABC destination needs userId/domain to process'
    }

    def "sync user profile ccr test"() throws Exception{
        given:
        requestObj.ban = null
        requestObj.handle = null
        requestObj.domain = null
        requestObj.guid  = '12214214'
        requestObj.destination = 'CCR'
        requestObj.syncCCRMemberTables=["member"]
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response== null
    }

    def "sync user profile ccr with handle and domain"() throws Exception{
        given:
        requestObj.ban = null
        requestObj.handle =  '12214214'
        requestObj.domain = 'att.net'
        requestObj.guid  = null
        requestObj.destination = 'CCR'
        requestObj.syncCCRMemberTables=["member"]
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response== null
    }

    def "sync user profile ccr with no syncccrtables"() throws Exception{
        given:
        requestObj.ban = null
        requestObj.handle =  '12214214'
        requestObj.domain = 'att.net'
        requestObj.guid  = null
        requestObj.destination = 'CCR'

        requestObj.syncCCRMemberTables=null
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response== null
        requestObj.syncCCRMemberTables.size() == 2
    }

    def "sync user profile ccr with no syncccrtables present in default properties"() throws Exception{
        given:
        requestObj.ban = null
        requestObj.handle =  '12214214'
        requestObj.domain = 'att.net'
        requestObj.guid  = null
        requestObj.destination = 'CCR'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'defaultSyncCcrTableNames', '' )
        requestObj.syncCCRMemberTables=null
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        when:
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, requestObj)
        then:
        response.appInfo== "No default CCR member tables configured in the system.";
    }

    // ====== Tests for SyncCCR destination ======

    def "sync user profile CCR request validation with guid success"() throws Exception{
        given: "A CCR request with guid"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = null
        request.guid = '12214214'
        request.handle = null
        request.domain = null
        request.destination = 'CCR'
        request.syncCCRMemberTables = ["member"]
        request.callingSystemId = 'ATLAS-UI'
        request.isExternalCall = 'N'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')

        when: "CCR request is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation should pass"
        response == null
    }

    def "sync user profile CCR request validation with userid and domain success"() throws Exception{
        given: "A CCR request with userid and domain"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = null
        request.guid = null
        request.handle = 'testuser'
        request.domain = 'att.net'
        request.destination = 'CCR'
        request.syncCCRMemberTables = ["member", "memberdevice"]
        request.callingSystemId = 'ATLAS-UI'
        request.isExternalCall = 'N'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')

        when: "CCR request with userid and domain is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation should pass"
        response == null
    }

    def "sync user profile CCR request validation without syncCCRMemberTables applies defaults"() throws Exception{
        given: "A CCR request without syncCCRMemberTables"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = null
        request.guid = '12214214'
        request.handle = null
        request.domain = null
        request.destination = 'CCR'
        request.syncCCRMemberTables = null
        request.callingSystemId = 'ATLAS-UI'
        request.isExternalCall = 'N'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'defaultSyncCcrTableNames', 'member|memberdevice')

        when: "CCR request without tables is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation passes and defaults are applied"
        response == null
        request.syncCCRMemberTables != null
        request.syncCCRMemberTables.size() == 2
    }

    def "sync user profile CCR request validation with empty syncCCRMemberTables applies defaults"() throws Exception{
        given: "A CCR request with empty syncCCRMemberTables"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = null
        request.guid = '12214214'
        request.handle = null
        request.domain = null
        request.destination = 'CCR'
        request.syncCCRMemberTables = []
        request.callingSystemId = 'ATLAS-UI'
        request.isExternalCall = 'N'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'defaultSyncCcrTableNames', 'member|memberdevice')

        when: "CCR request with empty tables is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation passes and defaults are applied"
        response == null
        request.syncCCRMemberTables.size() == 2
    }

    def "sync user profile CCR request validation with ban and guid fails"() throws Exception{
        given: "A CCR request with both ban and guid"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = 'VD0007556'
        request.guid = '12214214'
        request.handle = null
        request.domain = null
        request.destination = 'CCR'
        request.syncCCRMemberTables = ["member"]
        request.callingSystemId = 'ATLAS-UI'
        request.isExternalCall = 'N'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')

        when: "CCR request with both ban and guid is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation fails with error"
        response != null
        response.appInfo == 'Only one of ban, guid and userId/domain is valid'
    }

    def "sync user profile CCR request validation with guid and userid fails"() throws Exception{
        given: "A CCR request with both guid and userid"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = null
        request.guid = '12214214'
        request.handle = 'testuser'
        request.domain = 'att.net'
        request.destination = 'CCR'
        request.syncCCRMemberTables = ["member"]
        request.callingSystemId = 'ATLAS-UI'
        request.isExternalCall = 'N'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')

        when: "CCR request with both guid and userid is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation fails with error"
        response != null
        response.appInfo == 'Only one of guid and userId/domain is valid'
    }

    def "sync user profile CCR request validation with missing userid fails"() throws Exception{
        given: "A CCR request with domain but no userid"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = null
        request.guid = null
        request.handle = null
        request.domain = 'att.net'
        request.destination = 'CCR'
        request.syncCCRMemberTables = ["member"]
        request.callingSystemId = 'ATLAS-UI'
        request.isExternalCall = 'N'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')

        when: "CCR request with missing userid is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation fails with error"
        response != null
        response.appInfo == 'Either ban, guid OR userId/domain must be present'
    }

    def "sync user profile CCR request validation with case insensitive destination"() throws Exception{
        given: "A CCR request with lowercase ccr destination"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = null
        request.guid = '12214214'
        request.handle = null
        request.domain = null
        request.destination = 'ccr'
        request.syncCCRMemberTables = ["member"]
        request.callingSystemId = 'ATLAS-UI'
        request.isExternalCall = 'N'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')

        when: "CCR request with lowercase destination is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation should pass and destination should be converted to uppercase"
        response == null
        request.destination == 'CCR'
    }

    // ====== Tests for SyncCG destination ======

    def "sync user profile CG request validation with guid error"() throws Exception{
        given: "A CG request with guid"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = null
        request.guid = '12214214'
        request.handle = null
        request.domain = null
        request.destination = 'CG'
        request.callingSystemId = 'ATLAS-UI'
        request.isExternalCall = 'N'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')

        when: "CG request is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation should pass"
        response != null
        response.appInfo == 'CG destination only supports ban'


    }

    def "sync user profile CG request validation with userid and domain error"() throws Exception{
        given: "A CG request with userid and domain"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = null
        request.guid = null
        request.handle = 'testuser'
        request.domain = 'att.net'
        request.destination = 'CG'
        request.callingSystemId = 'ATLAS-UI'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')

        when: "CG request with userid and domain is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation should pass and source should be set to MPSSS"
        response != null
        response.appInfo == 'CG destination only supports ban'
    }

    def "sync user profile CG request validation with ban success"() throws Exception{
        given: "A CG request with ban"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = 'VD0007556'
        request.guid = null
        request.handle = null
        request.domain = null
        request.destination = 'CG'
        request.callingSystemId = 'ATLAS-UI'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')

        when: "CG request with ban is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation should pass"
        response == null
        request.source == 'MPSSS'
    }

    def "sync user profile CG request validation with case insensitive destination"() throws Exception{
        given: "A CG request with lowercase cg destination"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = null
        request.guid = '12214214'
        request.handle = null
        request.domain = null
        request.destination = 'cg'
        request.callingSystemId = 'ATLAS-UI'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')

        when: "CG request with lowercase destination is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation should pass and destination should be converted to uppercase"
        response != null
        response.appInfo== 'CG destination only supports ban'
    }

    def "sync user profile CG request validation with both ban and guid fails"() throws Exception{
        given: "A CG request with both ban and guid"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = 'VD0007556'
        request.guid = '12214214'
        request.handle = null
        request.domain = null
        request.destination = 'CG'
        request.callingSystemId = 'ATLAS-UI'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')

        when: "CG request with both ban and guid is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation fails with error"
        response != null
        response.appInfo == 'Only one of ban, guid and userId/domain is valid'
    }

    def "sync user profile CG request validation with guid and userid fails"() throws Exception{
        given: "A CG request with both guid and userid"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = null
        request.guid = '12214214'
        request.handle = 'testuser'
        request.domain = 'att.net'
        request.destination = 'CG'
        request.callingSystemId = 'ATLAS-UI'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')

        when: "CG request with both guid and userid is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation fails with error"
        response != null
        response.appInfo == 'Only one of guid and userId/domain is valid'
    }

    def "sync user profile CG request validation with only ban success"() throws Exception{
        given: "A CG request with only ban"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = 'VD0007556'
        request.guid = null
        request.handle = null
        request.domain = null
        request.destination = 'CG'
        request.callingSystemId = 'ATLAS-UI'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')

        when: "CG request with only ban is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation should pass"
        response == null
    }

    def "sync user profile CG request validation with guid only fails"() throws Exception{
        given: "A CG request with guid but no ban"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = null
        request.guid = '12214214'
        request.handle = null
        request.domain = null
        request.destination = 'CG'
        request.callingSystemId = 'ATLAS-UI'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')

        when: "CG request with guid is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation fails with error"
        response != null
        response.appInfo == 'CG destination only supports ban'
    }

    def "sync user profile CG request validation with userid domain only fails"() throws Exception{
        given: "A CG request with userid/domain but no ban"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = null
        request.guid = null
        request.handle = 'testuser'
        request.domain = 'att.net'
        request.destination = 'CG'
        request.callingSystemId = 'ATLAS-UI'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')

        when: "CG request with userid/domain is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation fails with error"
        response != null
        response.appInfo == 'CG destination only supports ban'
    }

    def "sync user profile CG request validation with missing ban fails"() throws Exception{
        given: "A CG request with no ban, guid, or userid"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = null
        request.guid = null
        request.handle = null
        request.domain = null
        request.destination = 'CG'
        request.callingSystemId = 'ATLAS-UI'

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')

        when: "CG request with no identifier is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation fails with error"
        response != null
        response.appInfo == 'Either ban, guid OR userId/domain must be present'
    }

    // ====== Tests for SyncCG destination with syncCGTables ======

    def "sync user profile CG request validation with syncCGTables provided success"() throws Exception{
        given: "A CG request with ban and syncCGTables explicitly provided"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = 'VD0007556'
        request.guid = null
        request.handle = null
        request.domain = null
        request.destination = 'CG'
        request.callingSystemId = 'ATLAS-UI'
        request.syncCGTables = ["subscriberinfo", "subscriberprofile"]

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'defaultSyncCgTableNames', 'subscriberinfo|subscriberprofile|componentid|componentprofile|userid|userprofile')

        when: "CG request with syncCGTables is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation should pass and provided tables should be used"
        response == null
        request.syncCGTables != null
        request.syncCGTables.size() == 2
        request.syncCGTables.contains("subscriberinfo")
        request.syncCGTables.contains("subscriberprofile")
    }

    def "sync user profile CG request validation without syncCGTables applies defaults"() throws Exception{
        given: "A CG request with ban but no syncCGTables"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = 'VD0007556'
        request.guid = null
        request.handle = null
        request.domain = null
        request.destination = 'CG'
        request.callingSystemId = 'ATLAS-UI'
        request.syncCGTables = null

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'defaultSyncCgTableNames', 'subscriberinfo|subscriberprofile|componentid')

        when: "CG request without syncCGTables is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation passes and defaults are applied"
        response == null
        request.syncCGTables != null
        request.syncCGTables.size() == 3
        request.syncCGTables.contains("subscriberinfo")
        request.syncCGTables.contains("subscriberprofile")
        request.syncCGTables.contains("componentid")
    }

    def "sync user profile CG request validation with empty syncCGTables applies defaults"() throws Exception{
        given: "A CG request with ban and empty syncCGTables"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = 'VD0007556'
        request.guid = null
        request.handle = null
        request.domain = null
        request.destination = 'CG'
        request.callingSystemId = 'ATLAS-UI'
        request.syncCGTables = []

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'defaultSyncCgTableNames', 'subscriberinfo|subscriberprofile')

        when: "CG request with empty syncCGTables is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation passes and defaults are applied"
        response == null
        request.syncCGTables != null
        request.syncCGTables.size() == 2
    }

    def "sync user profile CG request validation with no default syncCGTables configured fails"() throws Exception{
        given: "A CG request with ban but no default syncCGTables configured"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = 'VD0007556'
        request.guid = null
        request.handle = null
        request.domain = null
        request.destination = 'CG'
        request.callingSystemId = 'ATLAS-UI'
        request.syncCGTables = null

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'defaultSyncCgTableNames', '')

        when: "CG request with no default tables configured is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation fails with error"
        response != null
        response.appInfo == 'No default CG tables configured in the system.'
    }

    def "sync user profile CG request validation with single syncCGTable provided success"() throws Exception{
        given: "A CG request with ban and single syncCGTable"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = 'VD0007556'
        request.guid = null
        request.handle = null
        request.domain = null
        request.destination = 'CG'
        request.callingSystemId = 'ATLAS-UI'
        request.syncCGTables = ["subscriberinfo"]

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'defaultSyncCgTableNames', 'subscriberinfo|subscriberprofile|componentid|componentprofile|userid|userprofile')

        when: "CG request with single syncCGTable is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation should pass and provided table should be used"
        response == null
        request.syncCGTables != null
        request.syncCGTables.size() == 1
        request.syncCGTables.contains("subscriberinfo")
    }

    def "sync user profile CG request validation with all syncCGTables provided success"() throws Exception{
        given: "A CG request with ban and all available syncCGTables"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.unknownAttributes = new HashMap<>()
        request.ban = 'VD0007556'
        request.guid = null
        request.handle = null
        request.domain = null
        request.destination = 'CG'
        request.callingSystemId = 'ATLAS-UI'
        request.syncCGTables = ["subscriberinfo", "subscriberprofile", "componentid", "componentprofile", "userid", "userprofile"]

        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'banInvalidDestinations', 'YAHOO|HALOC|ABC')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'propSyncSystems', 'MPS:YAHOO|MPS:MPSLDAP|MPS:G2LDAP|MPS:HALOC|MPSSS:CG')
        ReflectionTestUtils.setField(syncUserProfileRequestValidator, 'defaultSyncCgTableNames', 'subscriberinfo|subscriberprofile|componentid|componentprofile|userid|userprofile')

        when: "CG request with all syncCGTables is validated"
        SyncUserProfileResponse response = syncUserProfileRequestValidator.syncUserProfileRequestValidator(requestHeader, request)

        then: "Validation should pass and all provided tables should be used"
        response == null
        request.syncCGTables != null
        request.syncCGTables.size() == 6
        request.syncCGTables.containsAll(["subscriberinfo", "subscriberprofile", "componentid", "componentprofile", "userid", "userprofile"])
    }
 }