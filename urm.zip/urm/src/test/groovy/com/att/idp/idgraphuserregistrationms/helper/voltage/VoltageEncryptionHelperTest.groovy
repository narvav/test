package com.att.idp.idgraphuserregistrationms.helper.voltage

import com.att.mpsys.common.utils.CommonDefs
import com.voltage.securedata.enterprise.VeException
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import com.att.mpsys.common.utils.PropertyManager;

class VoltageEncryptionHelperTest extends Specification {

    def voltageEncryption_H

	VoltageEncryptDecryptHelper voltageEncryptDecryptHelper = Mock()

	VoltageEncryptDecryptHelper voltageHelper = Mock()

    static HashMap<String, Object> hmInput = null

    public static final Logger logger = LoggerFactory.getLogger(VoltageEncryptionHelper.class)

    def setupSpec() {
        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')
    }

    def setup()
	{
        PropertyManager.setProperty("MSCONFIG", "voltageEncryptFields","passcode|wsPasscode|securityAnswer|wsSecurityAnswer|security_answer|dateOfBirth|birthdate_venc|security_answer_venc|passcode_venc|dsl_net_password|issuser_password|wirelineuser_passcode|securitycode_passcode|md5_password_venc|enc_password_venc|sha1_password_venc|des3_password_venc|ssha_password_venc|security_answer_1_venc|security_answer_2_venc|generatedPassword|dialEnrollPassword|yahoo_app_pwd|gen_password_venc");
        PropertyManager.setProperty("MSCONFIG", "voltageDecryptFields","birthdate_venc|security_answer_venc|passcode_venc|password_venc|dsl_net_password|md5_password_venc|enc_password_venc|sha1_password_venc|des3_password_venc|ssha_password_venc|security_answer_1_venc|security_answer_2_venc|gen_password_venc");
        PropertyManager.setProperty("MSCONFIG", "voltagePCIEncryptFields","ccNumber");
        PropertyManager.setProperty("MSCONFIG", "voltagePCIDecryptFields","");
        PropertyManager.setProperty("MSCONFIG", "voltageSSNEncryptFields","");
        PropertyManager.setProperty("MSCONFIG", "voltageSSNDecryptFields","fedTaxId");
        PropertyManager.setProperty("MSCONFIG", "voltageGenStringEncryptFields","CBR|CTNCBR");
        PropertyManager.setProperty("MSCONFIG", "voltageGenStringDecryptFields","CBR|CTNCBR");
        PropertyManager.setProperty("MSCONFIG", "voltageDOBDecryptFields","vc_dateOfBirth");
        voltageEncryption_H = new VoltageEncryptionHelper()
        voltageEncryption_H.voltageHelper = voltageHelper
		hmInput = new HashMap<String, Object>()
    }

    def "testget efpe encrypted values voltage encryption fields success"()
	{
        given:
        hmInput['passcode'] = '67365'
        when:
        HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEEncryptedValues(hmInput)
        then:
        hmResult['appStatusMsg'] == 'SUCCESS'
    }

    def "testget efpe encrypted values voltage pci encryption fields success"()
	{
        given:
        hmInput['ccNumber'] = '567987'
        when:
        HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEEncryptedValues(hmInput)
        then:
        hmResult['appStatusMsg'] == 'SUCCESS'
    }

    def "testget efpe encrypted values voltage gen str encryption fields success"()
	{
        given:
        hmInput['CBR'] = 'r6279'
        when:
        HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEEncryptedValues(hmInput)
        then:
        hmResult['appStatusMsg'] == 'SUCCESS'
    }

    def "test get efpe encrypted values success"()
	{
        given:
        hmInput['fedTaxId'] = 'trma6fg9'
        when:
        HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEEncryptedValues(hmInput)
        then:
        hmResult['appStatusMsg'] == 'SUCCESS'

    }

    def "test get efpe encrypted values exception"()
	{
        given:
        hmInput['passcode'] = '67365'
        voltageHelper.getEncryptedValue(_,_) >> NullPointerException.class
        when:
        HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEEncryptedValues(hmInput)
        then:
        hmResult['appStatusMsg'] == 'SUCCESS'
    }

    def "test get efpe decrypted values voltage decryption fields success"()
	{
        given:
        hmInput['birthdate_venc'] = "!%6667565654R"
        when:
        HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEDecryptedValues(hmInput)
        then:
        hmResult['appStatusMsg'] == 'SUCCESS'
    }

    def "test get efpe decrypted values voltage ssn decryption fields success"()
	{
        given:
        hmInput['fedTaxId'] = 'trma6f99'
        when:
        HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEDecryptedValues(hmInput)
        then:
        hmResult['appStatusMsg'] == 'SUCCESS'
    }

    def "test get efpe decrypted values voltage gen str decryption fields success"()
	{
        given:
        hmInput['CBR'] = "6fg&^#%9"
        when:
        HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEDecryptedValues(hmInput)
        then:
        hmResult['appStatusMsg'] == 'SUCCESS'
    }

    def "test get efpe decrypted values success"()
	{
        given:
        hmInput['passcode'] = '673^&96&65'
        when:
        HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEDecryptedValues(hmInput)
        then:
        hmResult['appStatusMsg'] == 'SUCCESS'
    }

    def "test get efpe decrypted values exception"()
	{
        given:
        hmInput['birthdate_venc'] = '6%#873GVD%^65'
        voltageHelper.getDecryptedValue(_,_) >>NullPointerException.class
        when:
        HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEDecryptedValues(hmInput)
        then:
        hmResult['appStatusMsg'] == 'SUCCESS'
    }

    def "test getEFPEDecryptedValues handles missing config parameter"() {
        given:
        VoltageEncryptionHelper.sVoltageDecryptionFields = null

        when:
        def result = voltageEncryption_H.getEFPEDecryptedValues(new HashMap())

        then:
        result['appInfo'] == "Missing or empty config parameter - VOLTAGE_DECRYPTED_FIELDS"
        result['appStatusCode'] == "605"
    }

    def "test exception during encryption"() {
        given:
        voltageEncryptDecryptHelper.getEncryptedValue(_ as String, _ as String) >> new Exception("Test Exception")
        voltageHelper.getEncryptedValue(_ as String, _ as String) >> Exception.class
        hmInput=null
        when:
        def result = voltageEncryption_H.getEFPEEncryptedValues(hmInput)

        then:
        result['appInfo'] == "SYSTEM ERROR"
    }

    def "test missing or empty config parameter for encryption fields"() {
        given:
        VoltageEncryptionHelper.sVoltageEncryptionFields = null

        when:
        def result = voltageEncryption_H.getEFPEEncryptedValues(new HashMap())

        then:
        result['appInfo'] == "Missing or empty config parameter - VOLTAGE_ENCRYPTION_FIELDS"

    }

    def "test exception during decryption"() {
        given:
        voltageEncryptDecryptHelper.getDecryptedValue(_ as String, _ as String) >> new Exception("Test Exception")
        voltageHelper.getDecryptedValue(_ as String, _ as String) >> Exception.class
        hmInput=null
        when:
        def result = voltageEncryption_H.getEFPEDecryptedValues(hmInput)

        then:
        result['appInfo'] == "SYSTEM ERROR"
    }

    def "test missing or empty config parameter for decryption fields"() {
        given:
        VoltageEncryptionHelper.sVoltageDecryptionFields = null

        when:
        def result = voltageEncryption_H.getEFPEDecryptedValues(new HashMap())

        then:
        result['appInfo'] == "Missing or empty config parameter - VOLTAGE_DECRYPTED_FIELDS"

    }
}
