package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import com.att.idp.idgraphuserregistrationms.exceptions.MPSException
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.MPSDefs
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import spock.lang.Specification

class GetAssociatedMembersDBHelperTest extends Specification  {

    def  oGetAssociatedMembersDBHelper = new GetAssociatedMembersDBHelper()

    JdbcTemplate jdbcTemplate = Mock(JdbcTemplate)
    ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)

    DBHelper oDBHelper = Mock(DBHelper)

    GetMemberServicesDBHelper oGetMemberServicesDBHelper = Mock(GetMemberServicesDBHelper)

    private HashMap<String, Object> hmMPSInput = new HashMap<String, Object>()
    private HashMap<String, Object> hmDbInput = new HashMap<String, Object>()
    private HashMap<String, Object> hmResponse = null
    private HashMap<String, Object> successHash = new HashMap<String, Object>()

    private String queryGetMemberNum = null
    private String queryArg = null
    private List<Object> objectList = new ArrayList<Object>()
    private List alQueryResponse = new ArrayList()

    def setup() {
        oGetAssociatedMembersDBHelper.jdbcTemplate = jdbcTemplate
        oGetAssociatedMembersDBHelper.errorMetricHandler = errorMetricHandler
        oGetAssociatedMembersDBHelper.oDBHelper = oDBHelper
        String transId = 'test123'
        hmMPSInput[CommonDefs.TRANSACTION_ID] = transId
        hmMPSInput[CommonDefs.TRANSACTION_NAME] = 'AddAssociation'
        hmMPSInput[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        objectList.add('127689473')
        hmDbInput[CommonDefs.DB_MEMBER_NUM] = '2242353463'
        queryGetMemberNum = 'SELECT ms.member_num  FROM memberservice ms, service svc  WHERE ms.service_id = svc.service_id (+) AND '
        queryArg = 'ms.sor_invariant_id=? AND ms.sor_invariant_id is not null'
        successHash = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)
    }

    def "test get associated members err empty"() {
        when:
        hmResponse = oGetAssociatedMembersDBHelper.getAssociatedMembers(hmMPSInput)
        then:
        hmResponse[CommonDefs.COMMON_APP_CATEGORY_CODE] == '3'
    }

    def "test get associated members rec not found"() {
        given:
        hmMPSInput[MPSDefs.DB_SOR_ID] = '13'
        hmMPSInput[MPSDefs.DB_SERVICE_TYPE] = 'NON-ACCESS'
        hmMPSInput[MPSDefs.DB_SOR_INVARIANT_ID1] = '127689473'
        when:
        hmResponse = oGetAssociatedMembersDBHelper.getAssociatedMembers(hmMPSInput)
        then:
        hmResponse[CommonDefs.COMMON_APP_CATEGORY_CODE] == '2'
    }

    def "test get associated members success"() {
        given:
        hmMPSInput[CommonDefs.SOR] = 'MO'
        hmMPSInput[MPSDefs.DB_SOR_INVARIANT_ID1] = '127689473'
        hmMPSInput[MPSDefs.DB_SERVICE_TYPE] = 'NON-ACCESS'
        hmMPSInput[MPSDefs.QUERY_ROLES_INFO_FLAG] = 'N'
        hmMPSInput[MPSDefs.QUERY_ONLY_SLIDS_FLAG] = 'N'
        hmMPSInput[MPSDefs.QUERY_SLID_INFO_FLAG] = 'N'
        hmDbInput[MPSDefs.QUERY_ROLES_INFO_FLAG] = 'N'
        hmDbInput[MPSDefs.QUERY_ONLY_SLIDS_FLAG] = 'N'
        hmDbInput[MPSDefs.QUERY_SLID_INFO_FLAG] = 'N'
        alQueryResponse.add(hmDbInput)
        objectList.add('NON-ACCESS')
        successHash[MPSDefs.SQLCODE] = ''
        successHash[MPSDefs.SQLMSG] = ''
        queryArg += ' AND svc.service_name = ? '
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        oGetMemberServicesDBHelper.getMemberServices(_) >> successHash
        when:
        hmResponse = oGetAssociatedMembersDBHelper.getAssociatedMembers(hmMPSInput)
        then:
        hmResponse[CommonDefs.COMMON_APP_CATEGORY_CODE] == '2'
    }

    def "test get member services rec not found"() {
        given:
        hmMPSInput[MPSDefs.DB_SOR_ID] = '13'
        hmMPSInput[MPSDefs.DB_SOR_INVARIANT_ID1] = '127689473'
        objectList.add('13')
        queryArg += ' AND ms.sor_id = ? '
        successHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, CErrorDefs.ERR_REC_NOT_FOUND_MSG)
        alQueryResponse.add(hmDbInput)
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        oGetMemberServicesDBHelper.getMemberServices(_) >> successHash
        when:
        hmResponse = oGetAssociatedMembersDBHelper.getAssociatedMembers(hmMPSInput)
        then:
        hmResponse[CommonDefs.COMMON_APP_CATEGORY_CODE] == '2'
    }

    def "test get member services instance id error"() throws MPSException {
        given:
        hmMPSInput[MPSDefs.DB_SOR_ID] = '13'
        hmMPSInput[MPSDefs.DB_SOR_NAME] = 'MO'
        hmMPSInput[MPSDefs.DB_INSTANCE_ID] = '10'
        hmMPSInput[MPSDefs.DB_SOR_INVARIANT_ID1] = null
        hmMPSInput[MPSDefs.DB_SERVICE_TYPE] = 'NON-ACCESS'
        objectList.add('13')
        queryArg += ' AND ms.sor_id = ? '
        successHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, CErrorDefs.ERR_REC_NOT_FOUND_MSG)
        alQueryResponse.add(hmDbInput)
        oDBHelper.getSorId(_) >> 12
        when:
        hmResponse = oGetAssociatedMembersDBHelper.getAssociatedMembers(hmMPSInput)
        then:
        hmResponse[CommonDefs.COMMON_APP_CATEGORY_CODE] == '2'

    }
    def "test get member services sor_name error"() throws MPSException {
        given:
        hmMPSInput[MPSDefs.DB_SOR_ID] = '13'
        hmMPSInput[MPSDefs.DB_SOR_NAME] = 'MO'
        hmMPSInput[MPSDefs.DB_INSTANCE_ID] = '10'
        hmMPSInput[MPSDefs.DB_SOR_INVARIANT_ID1] = null
        hmMPSInput[MPSDefs.DB_SERVICE_TYPE] = 'NON-ACCESS'
        objectList.add('13')
        queryArg += ' AND ms.sor_id = ? '
        successHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, CErrorDefs.ERR_REC_NOT_FOUND_MSG)
        alQueryResponse.add(hmDbInput)
        oDBHelper.getSorId(_) >> 12
        when:
        hmMPSInput[CommonDefs.SOR] = 'M'
        hmMPSInput[MPSDefs.DB_SERVICE_TYPE] = 'NON-ACCESS'
        hmMPSInput[MPSDefs.DB_SOR_NAME] = null
        hmResponse = oGetAssociatedMembersDBHelper.getAssociatedMembers(hmMPSInput)
        then:
        hmResponse[CommonDefs.COMMON_APP_CATEGORY_CODE] == '2'
    }

    def "test get member services sor_invariant_id error"() throws MPSException {
        given:
        hmMPSInput[MPSDefs.DB_SOR_ID] = '13'
        hmMPSInput[MPSDefs.DB_SOR_NAME] = 'MO'
        hmMPSInput[MPSDefs.DB_INSTANCE_ID] = '10'
        hmMPSInput[MPSDefs.DB_SOR_INVARIANT_ID1] = null
        hmMPSInput[MPSDefs.DB_SERVICE_TYPE] = 'NON-ACCESS'
        objectList.add('13')
        queryArg += ' AND ms.sor_id = ? '
        successHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, CErrorDefs.ERR_REC_NOT_FOUND_MSG)
        alQueryResponse.add(hmDbInput)
        oDBHelper.getSorId(_) >> 12
        when:
        oDBHelper.getSorId(_) >> 12
        hmMPSInput[MPSDefs.DB_SERVICE_TYPE] = null
        hmResponse = oGetAssociatedMembersDBHelper.getAssociatedMembers(hmMPSInput)
        then:
        hmResponse[CommonDefs.COMMON_APP_CATEGORY_CODE] == '2'
    }

    def "test get member services service_type error"() throws MPSException {
        given:
        hmMPSInput[MPSDefs.DB_SOR_ID] = '13'
        hmMPSInput[MPSDefs.DB_SOR_NAME] = 'MO'
        hmMPSInput[MPSDefs.DB_INSTANCE_ID] = '10'
        hmMPSInput[MPSDefs.DB_SOR_INVARIANT_ID1] = null
        hmMPSInput[MPSDefs.DB_SERVICE_TYPE] = 'NON-ACCESS'
        objectList.add('13')
        queryArg += ' AND ms.sor_id = ? '
        successHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, CErrorDefs.ERR_REC_NOT_FOUND_MSG)
        alQueryResponse.add(hmDbInput)
        oDBHelper.getSorId(_) >> 12
        when:
        hmMPSInput[MPSDefs.DB_SERVICE_TYPE] = null
        hmResponse = oGetAssociatedMembersDBHelper.getAssociatedMembers(hmMPSInput)
        then:
        hmResponse[CommonDefs.COMMON_APP_CATEGORY_CODE] == '2'
    }
    def "test get associated members catch exception"() {
        given:
        hmMPSInput[MPSDefs.DB_SOR_INVARIANT_ID1] = '127689473'
        alQueryResponse = null
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        when:
        hmResponse = oGetAssociatedMembersDBHelper.getAssociatedMembers(hmMPSInput)
        then:
        hmResponse[CommonDefs.COMMON_APP_CATEGORY_CODE] == '2'
    }
}
