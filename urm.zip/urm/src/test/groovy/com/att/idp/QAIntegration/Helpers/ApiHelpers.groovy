package com.att.idp.QAIntegration.Helpers

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.GlobalConfig
import com.att.idp.QAIntegration.Utils.Utility
import groovy.json.JsonOutput
import groovy.util.logging.Slf4j
import io.restassured.response.Response

@Slf4j
class ApiHelpers {

    private static Map<String, String> getDefaultHeaders(String clientId = "IDP") {
        return [
                "X-ATT-ClientId": clientId,
                "idp-trace-id" : Utility.getRandomTraceId()
        ]
    }

    // ==================== AutoReg Operations ====================

    static Response autogenTempAccessId(Map<String, Object> payload, String clientId = "IDP") {
        String jsonBody = JsonOutput.toJson(payload)
        Map<String, String> headers = getDefaultHeaders(clientId)
        return TestBase.sendRequest(GlobalConfig.Endpoints.AUTOGEN_TEMP_ACCESS_ID, "POST", jsonBody, headers)
    }

    static Map<String, Object> buildAutogenTempAccessIdPayload(Map args = [:]) {
        return [
                ban        : args.ban ?: Utility.randomBan(),
                accountType: args.accountType ?: "UVERSE",
                firstName  : args.firstName ?: "QG7First",
                lastName   : args.lastName ?: "QG7Last"
        ].findAll { k, v -> v != null }
    }

    static Response preAccountReg(Map<String, Object> payload, String clientId = "IDP") {
        String jsonBody = JsonOutput.toJson(payload)
        Map<String, String> headers = getDefaultHeaders(clientId)
        return TestBase.sendRequest(GlobalConfig.Endpoints.PRE_ACCOUNT_REG, "POST", jsonBody, headers)
    }

    static Map<String, Object> buildPreAccountRegPayload(Map args = [:]) {
        return [
                sorId         : args.sorId ?: Utility.randomAlphaNumeric(10),
                sorInvariantId: args.sorInvariantId ?: Utility.randomAlphaNumeric(10),
                guid          : args.guid ?: Utility.randomGuid()
        ].findAll { k, v -> v != null }
    }

    // ==================== LsReg Operations ====================

    static Response queryByIPEligibility(Map<String, Object> payload, String clientId = "IDP") {
        String jsonBody = JsonOutput.toJson(payload)
        Map<String, String> headers = getDefaultHeaders(clientId)
        return TestBase.sendRequest(GlobalConfig.Endpoints.QUERY_BY_IP_ELIGIBILITY, "POST", jsonBody, headers)
    }

    static Map<String, Object> buildQueryByIPEligibilityPayload(Map args = [:]) {
        return [
                ipAddress: args.ipAddress ?: Utility.randomIpAddress()
        ].findAll { k, v -> v != null }
    }

    static Response verifyExistingMemberEligibility(Map<String, Object> payload, String clientId = "IDP") {
        String jsonBody = JsonOutput.toJson(payload)
        Map<String, String> headers = getDefaultHeaders(clientId)
        return TestBase.sendRequest(GlobalConfig.Endpoints.VERIFY_EXISTING_MEMBER_ELIGIBILITY, "POST", jsonBody, headers)
    }

    static Map<String, Object> buildVerifyExistingMemberEligibilityPayload(Map args = [:]) {
        return [
                ban     : args.ban ?: Utility.randomBan(),
                memberId: args.memberId,
                domain  : args.domain ?: "att.net"
        ].findAll { k, v -> v != null }
    }

    static Response registerLSUser(Map<String, Object> payload, String clientId = "IDP") {
        String jsonBody = JsonOutput.toJson(payload)
        Map<String, String> headers = getDefaultHeaders(clientId)
        return TestBase.sendRequest(GlobalConfig.Endpoints.REGISTER_LS_USER, "POST", jsonBody, headers)
    }

    // ==================== SyncUserProfile Operations ====================

    static Response syncUserProfile(Map<String, Object> payload, String clientId = "IDP") {
        String jsonBody = JsonOutput.toJson(payload)
        Map<String, String> headers = getDefaultHeaders(clientId)
        return TestBase.sendRequest(GlobalConfig.Endpoints.SYNC_USER_PROFILE, "POST", jsonBody, headers)
    }

    static Map<String, Object> buildSyncUserProfilePayload(Map args = [:]) {
        return [
                accessId       : args.accessId,
                domain         : args.domain ?: "att.net",
                destinationType: args.destinationType ?: "G2"
        ].findAll { k, v -> v != null }
    }

    static Response validateAndSyncG2(Map<String, Object> payload, String clientId = "IDP") {
        String jsonBody = JsonOutput.toJson(payload)
        Map<String, String> headers = getDefaultHeaders(clientId)
        return TestBase.sendRequest(GlobalConfig.Endpoints.VALIDATE_AND_SYNC_G2, "POST", jsonBody, headers)
    }

    static Response reprovisionUverse(Map<String, Object> payload, String clientId = "IDP") {
        String jsonBody = JsonOutput.toJson(payload)
        Map<String, String> headers = getDefaultHeaders(clientId)
        return TestBase.sendRequest(GlobalConfig.Endpoints.REPROVISION_UVERSE, "POST", jsonBody, headers)
    }

    // ==================== UnifiedTOS Operations ====================

    static Response queryUnifiedTOS(Map<String, Object> payload, String clientId = "IDP") {
        String jsonBody = JsonOutput.toJson(payload)
        Map<String, String> headers = getDefaultHeaders(clientId)
        return TestBase.sendRequest(GlobalConfig.Endpoints.QUERY_UNIFIED_TOS, "POST", jsonBody, headers)
    }

    static Map<String, Object> buildQueryUnifiedTOSPayload(Map args = [:]) {
        return [
                accessId: args.accessId,
                domain  : args.domain ?: "att.net"
        ].findAll { k, v -> v != null }
    }

    static Response updateUnifiedTOS(Map<String, Object> payload, String clientId = "IDP") {
        String jsonBody = JsonOutput.toJson(payload)
        Map<String, String> headers = getDefaultHeaders(clientId)
        return TestBase.sendRequest(GlobalConfig.Endpoints.UPDATE_UNIFIED_TOS, "POST", jsonBody, headers)
    }

    static Map<String, Object> buildUpdateUnifiedTOSPayload(Map args = [:]) {
        return [
                accessId     : args.accessId,
                domain       : args.domain ?: "att.net",
                tosAccepted  : args.tosAccepted ?: "Y",
                tosVersion   : args.tosVersion ?: "1.0",
                tosAcceptDate: args.tosAcceptDate
        ].findAll { k, v -> v != null }
    }

    // ==================== EmailAppPassword Operations ====================

    static Response listEmailAppPassword(String memberId, String domain, String guid = null, String clientId = "IDP") {
        Map<String, String> headers = getDefaultHeaders(clientId)
        Map<String, String> queryParams = [
                memberId: memberId,
                domain  : domain
        ]
        if (guid) queryParams.guid = guid
        return TestBase.sendRequest(GlobalConfig.Endpoints.LIST_EMAIL_APP_PASSWORD, "GET", null, headers, queryParams)
    }

    static Response createEmailAppPassword(Map<String, Object> payload, String clientId = "IDP") {
        String jsonBody = JsonOutput.toJson(payload)
        Map<String, String> headers = getDefaultHeaders(clientId)
        return TestBase.sendRequest(GlobalConfig.Endpoints.CREATE_EMAIL_APP_PASSWORD, "POST", jsonBody, headers)
    }

    static Map<String, Object> buildCreateEmailAppPasswordPayload(Map args = [:]) {
        return [
                memberId       : args.memberId,
                domain         : args.domain ?: "att.net",
                guid           : args.guid,
                applicationName: args.applicationName ?: "QG7TestApp"
        ].findAll { k, v -> v != null }
    }

    static Response deleteEmailAppPassword(Map<String, Object> payload, String clientId = "IDP") {
        String jsonBody = JsonOutput.toJson(payload)
        Map<String, String> headers = getDefaultHeaders(clientId)
        return TestBase.sendRequest(GlobalConfig.Endpoints.DELETE_EMAIL_APP_PASSWORD, "DELETE", jsonBody, headers)
    }

    // ==================== WirelessAutoReg Operations ====================

    static Response wirelessAutoReg(Map<String, Object> payload, String clientId = "IDP") {
        String jsonBody = JsonOutput.toJson(payload)
        Map<String, String> headers = getDefaultHeaders(clientId)
        return TestBase.sendRequest(GlobalConfig.Endpoints.WIRELESS_AUTO_REG, "POST", jsonBody, headers)
    }

    static Map<String, Object> buildWirelessAutoRegPayload(Map args = [:]) {
        return [
                ban        : args.ban ?: Utility.randomBan(),
                ctn        : args.ctn ?: Utility.randomNumeric(10),
                accountType: args.accountType ?: "WIRELESS"
        ].findAll { k, v -> v != null }
    }

    // ==================== RetriggerQAR Operations ====================

    static Response retriggerQAR(Map<String, Object> payload, String clientId = "IDP") {
        String jsonBody = JsonOutput.toJson(payload)
        Map<String, String> headers = getDefaultHeaders(clientId)
        return TestBase.sendRequest(GlobalConfig.Endpoints.RETRIGGER_QAR, "POST", jsonBody, headers)
    }

    static Map<String, Object> buildRetriggerQARPayload(Map args = [:]) {
        return [
                ban              : args.ban,
                guid             : args.guid,
                accessId         : args.accessId,
                accountType      : args.accountType,
                returnQARToken   : args.returnQARToken ?: "N",
                returnQARTokenSHM: args.returnQARTokenSHM ?: "N"
        ].findAll { k, v -> v != null }
    }
}
