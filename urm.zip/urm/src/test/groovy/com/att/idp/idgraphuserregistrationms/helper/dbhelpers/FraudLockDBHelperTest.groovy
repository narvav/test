package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import spock.lang.Specification

class FraudLockDBHelperTest extends Specification {

    def oFraudLockDBHelper = new FraudLockDBHelper()

    JdbcTemplate jdbcTemplate = Mock(JdbcTemplate)
    ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)
    DBHelper dBHelper = Mock(DBHelper)

    private HashMap<String, Object> hmDBInput = null
    private HashMap<String, Object> hmUserInfo = new HashMap<String, Object>()
    private List alQueryResponse = new ArrayList<Object>()
    private List<Object> objectList = new ArrayList<Object>()
    private String sQueryUserFraudLockSql = null

    def setup() throws Exception {
        oFraudLockDBHelper.jdbcTemplate = jdbcTemplate
        oFraudLockDBHelper.errorMetricHandler = errorMetricHandler
        oFraudLockDBHelper.dBHelper = dBHelper
        hmDBInput = new HashMap<String, Object>()
        hmDBInput[CommonDefs.DB_MEMBER_NUM] = '12324324354'

        sQueryUserFraudLockSql = '''SELECT MEMBER_NUM , USER_LOCK_LEVEL, USER_LOCK_REASON, FRAUD_AGENT, TO_CHAR(CREATE_DATE, \''
				+ dateFormat + '\') AS CREATE_DATE, TO_CHAR(LAST_MODIFIED, \'' + dateFormat
				+'\') AS LAST_MODIFIED, LAST_MODIFIED_BY' + ' FROM USERFRAUDLOCK WHERE MEMBER_NUM = ?'''

        hmUserInfo[MPSDefs.DB_MEMBER_NAME] = '12324324354'
        alQueryResponse.add(hmUserInfo)
        objectList.add('12324324354')
    }
    def cleanup() throws Exception {

    }
    def "test query user fraud lock null input"() {
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryUserFraudLock(null)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test query user fraud lock success"() {
        given:
        hmUserInfo['usernameqaydgeurts6571'] = 'qaydgeurts6572'
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryUserFraudLock(hmDBInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test query user fraud lock error"() {
        given:
        jdbcTemplate.queryForList(_,_) >> null
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryUserFraudLock(hmDBInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'REC_NOT_FOUND'
    }

    def "test query user fraud lock error membernum"() {
        given:
        hmDBInput[CommonDefs.DB_MEMBER_NUM] = null
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryUserFraudLock(hmDBInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test add user fraud lock null input"() {

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addUserFraudLock(null)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test add user fraud lock null"() {
        given:
        hmUserInfo[MPSDefs.DB_MEMBER_NUM] = null
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addUserFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test add user fraud lock success"() {
        given:
        hmUserInfo = new HashMap<String, Object>()
        hmUserInfo[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        hmUserInfo[MPSDefs.DB_USER_LOCK_LEVEL] = '1'
        hmUserInfo[MPSDefs.DB_USER_LOCK_REASON] = 'NA'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        objectList.add(1)
        objectList.add('NA')
        objectList.add('Y')
        objectList.add('DATAMGT')
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addUserFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test add user fraud lock success no sor"() {
        given:
        hmUserInfo = new HashMap<String, Object>()
        hmUserInfo[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        objectList.add(null)
        objectList.add(null)
        objectList.add('Y')
        objectList.add('DATAMGT')
        jdbcTemplate.update(_,_) >> 0
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addUserFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test update user fraud lock null input"() {
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateUserFraudLock(null)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test update user fraud lock null"() {
        given:
        hmUserInfo.remove(MPSDefs.DB_MEMBER_NAME)
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateUserFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test update user fraud lock record not found"() {
        given:
        hmUserInfo = new HashMap<String, Object>()
        hmUserInfo[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        hmUserInfo[MPSDefs.DB_USER_LOCK_LEVEL] = '1'
        hmUserInfo[MPSDefs.DB_USER_LOCK_REASON] = 'NA'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        objectList = new ArrayList<Object>()
        objectList.add('DATAMGT')
        objectList.add('Y')
        objectList.add('NA')
        objectList.add('1')
        objectList.add('12324324354')
        jdbcTemplate.update(_,_) >> 0
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateUserFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'REC_NOT_FOUND'
    }

    def "test update user fraud lock success"() {
        given:
        hmUserInfo = new HashMap<String, Object>()
        hmUserInfo[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        hmUserInfo[MPSDefs.DB_USER_LOCK_LEVEL] = '1'
        hmUserInfo[MPSDefs.DB_USER_LOCK_REASON] = 'NA'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        objectList = new ArrayList<Object>()
        objectList.add('DATAMGT')
        objectList.add('Y')
        objectList.add('NA')
        objectList.add('1')
        objectList.add('12324324354')
        jdbcTemplate.update(_,_) >> 1
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateUserFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test delete user fraud lock null input"() {
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteUserFraudLock(null)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test delete user fraud lock null"() {
        given:
        hmUserInfo.remove(MPSDefs.DB_MEMBER_NAME)
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteUserFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test delete user fraud lock success"() {
        given:
        hmUserInfo[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        jdbcTemplate.update(_,_) >> 0
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteUserFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test query account fraud lock null input"() {
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryAccountFraudLock(null)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test query account fraud lock sorid null"() {
        given:
        hmUserInfo[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test query account fraud lock sorid not correct"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_ID] = '-1'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test query account fraud lock sorinvariant id null"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_ID] = '1'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test query account fraud lock null"() {
        given:
        hmUserInfo = new HashMap<String, Object>()
        hmUserInfo[MPSDefs.DB_SOR_ID] = '1'
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = '1312324234'
        objectList = new ArrayList<Object>()
        objectList.add(1)
        objectList.add('1312324234')
        jdbcTemplate.queryForList(_,_) >> null
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test query account fraud lock success"() {
        given:
        hmUserInfo = new HashMap<String, Object>()
        hmUserInfo[MPSDefs.DB_SOR_ID] = '1'
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = '1312324234'
        objectList = new ArrayList<Object>()
        objectList.add(1)
        objectList.add('1312324234')
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test add account fraud lock sorid null"() {
        given:
        hmUserInfo[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test add account fraud lock sorid not correct"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_ID] = '-1'
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test add account fraud lock sorinvariant id null"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_NAME] = 'NA'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test add account fraud lock null"() {
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addAccountFraudLock(null)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test add account fraud lock sor id null"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test add account fraud lock error"() {
        given:
        hmUserInfo = new HashMap<String, Object>()
        hmUserInfo[MPSDefs.DB_SOR_ID] = '1'
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmUserInfo[MPSDefs.DB_ACCOUNT_LOCKED] = 'Y'
        hmUserInfo[MPSDefs.DB_ACCOUNT_LOCK_REASON] = 'Y'
        objectList = new ArrayList<Object>()
        objectList.add(1)
        objectList.add('123434567')
        objectList.add('Y')
        objectList.add('Y')
        objectList.add('Y')
        objectList.add('123434567')
        jdbcTemplate.update(_,_) >> 1
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test add account fraud lock error no lockout"() {
        given:
        hmUserInfo = new HashMap<String, Object>()
        hmUserInfo[MPSDefs.DB_SOR_ID] = '1'
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        objectList = new ArrayList<Object>()
        objectList.add(1)
        objectList.add('123434567')
        objectList.add(null)
        objectList.add(null)
        objectList.add('Y')
        objectList.add('123434567')
        jdbcTemplate.update(_,_) >> 1
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test update account fraud lock null"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_NAME] = 'NA'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test update account fraud lock error"() {
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateAccountFraudLock(null)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test update account fraud lock sor null"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test update account fraud lock sor id null"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_ID] = null
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test update account fraud lock sor id invalid"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_ID] = '-1'
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test update account fraud lock"() {
        given:
        hmUserInfo = new HashMap<String, Object>()
        hmUserInfo[MPSDefs.DB_SOR_ID] = '1'
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        objectList = new ArrayList<Object>()
        objectList.add('DATAMGT')
        objectList.add('Y')
        objectList.add(1)
        objectList.add('123434567')
        StringBuilder sUpdateAccountFraudLockSql = new StringBuilder(
                ' UPDATE ACCOUNTFRAUDLOCK SET LAST_MODIFIED_BY = ?, ')
        sUpdateAccountFraudLockSql.append('fraud_agent' + '=?')
        String whereClause = 'sor_id = ? AND sor_invariant_id = ? '
        sUpdateAccountFraudLockSql.append(' WHERE ' + whereClause)
        jdbcTemplate.update(_,_) >> 0
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'REC_NOT_FOUND'
    }

    def "test update account fraud lock success"() {
        given:
        hmUserInfo = new HashMap<String, Object>()
        hmUserInfo[MPSDefs.DB_SOR_ID] = '1'
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        List<Object> objectList = CommonUtil.arrayList
        objectList.add('DATAMGT')
        objectList.add('Y')
        objectList.add(1)
        objectList.add('123434567')
        StringBuilder sUpdateAccountFraudLockSql = new StringBuilder(
                ' UPDATE ACCOUNTFRAUDLOCK SET LAST_MODIFIED_BY = ?, ')
        sUpdateAccountFraudLockSql.append('fraud_agent' + '=?')
        String whereClause = 'sor_id = ? AND sor_invariant_id = ? '
        sUpdateAccountFraudLockSql.append(' WHERE ' + whereClause)
        jdbcTemplate.update(_,_) >> 1
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test delete account fraud lock null"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_NAME] = 'NA'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test delete account fraud lock error"() {
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteAccountFraudLock(null)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test delete account fraud lock sor null"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test delete account fraud lock sor id null"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_ID] = null
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test delete account fraud lock sor id invalid"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_ID] = '-1'
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test delete account fraud lock sor id error"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_ID] = '1'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        objectList = new ArrayList<Object>()
        objectList.add(1)
        objectList.add('123434567')
        jdbcTemplate.update(_,_) >> 1
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteAccountFraudLock(input)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test process data null"() {
        given:
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test process data error"() {
        given:
        ArrayList<Object> alUserFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmUserFraudLockOperation = new HashMap<String, Object>()
        hmUserFraudLockOperation[MPSDefs.DB_OPERATION] = null
        alUserFraudLockOperations.add(hmUserFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['userfraudlock'] = alUserFraudLockOperations
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test  process data operation type error"() {
        given:
        ArrayList<Object> alUserFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmUserFraudLockOperation = new HashMap<String, Object>()
        hmUserFraudLockOperation[MPSDefs.DB_OPERATION] = 'x'
        alUserFraudLockOperations.add(hmUserFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['userfraudlock'] = alUserFraudLockOperations
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test process data operation type insert error"() {
        given:
        ArrayList<Object> alUserFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmUserFraudLockOperation = new HashMap<String, Object>()
        hmUserFraudLockOperation[MPSDefs.DB_OPERATION] = 'insert'
        alUserFraudLockOperations.add(hmUserFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['userfraudlock'] = alUserFraudLockOperations
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test process data operation type update error"() {
        given:
        ArrayList<Object> alUserFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmUserFraudLockOperation = new HashMap<String, Object>()
        hmUserFraudLockOperation[MPSDefs.DB_OPERATION] = 'update'
        alUserFraudLockOperations.add(hmUserFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['userfraudlock'] = alUserFraudLockOperations
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test process data operation type delete error"() {
        given:
        ArrayList<Object> alUserFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmUserFraudLockOperation = new HashMap<String, Object>()
        hmUserFraudLockOperation[MPSDefs.DB_OPERATION] = 'delete'
        alUserFraudLockOperations.add(hmUserFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['userfraudlock'] = alUserFraudLockOperations
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test process data operation type error null"() {
        given:
        ArrayList<Object> alUserFraudLockOperations = new ArrayList<Object>()
        alUserFraudLockOperations.add(null)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['userfraudlock'] = alUserFraudLockOperations
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test process data operation type account fraud lock error"() {
        given:
        ArrayList<Object> alUserFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmUserFraudLockOperation = new HashMap<String, Object>()
        hmUserFraudLockOperation[MPSDefs.DB_OPERATION] = null
        alUserFraudLockOperations.add(hmUserFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['accountfraudlock'] = alUserFraudLockOperations
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test process data operation type account fraud lock invalid error"() {
        given:
        ArrayList<Object> alUserFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmUserFraudLockOperation = new HashMap<String, Object>()
        hmUserFraudLockOperation[MPSDefs.DB_OPERATION] = 'X'
        alUserFraudLockOperations.add(hmUserFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['accountfraudlock'] = alUserFraudLockOperations
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test process data operation type account fraud lock insert error"() {
        given:
        ArrayList<Object> alUserFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmUserFraudLockOperation = new HashMap<String, Object>()
        hmUserFraudLockOperation[MPSDefs.DB_OPERATION] = 'insert'
        alUserFraudLockOperations.add(hmUserFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['accountfraudlock'] = alUserFraudLockOperations
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test process data operation type account fraud lock update error"() {
        given:
        ArrayList<Object> alUserFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmUserFraudLockOperation = new HashMap<String, Object>()
        hmUserFraudLockOperation[MPSDefs.DB_OPERATION] = 'update'
        alUserFraudLockOperations.add(hmUserFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['accountfraudlock'] = alUserFraudLockOperations
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test process data operation type account fraud lock delete error"() {
        given:
        ArrayList<Object> alUserFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmUserFraudLockOperation = new HashMap<String, Object>()
        hmUserFraudLockOperation[MPSDefs.DB_OPERATION] = 'delete'
        alUserFraudLockOperations.add(hmUserFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['accountfraudlock'] = alUserFraudLockOperations
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test process data operation type account fraud lock null error"() {
        given:
        ArrayList<Object> alUserFraudLockOperations = new ArrayList<Object>()
        alUserFraudLockOperations.add(null)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['accountfraudlock'] = alUserFraudLockOperations
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test query user fraud lock exception"() {
        given:
        hmUserInfo[MPSDefs.DB_MEMBER_NUM] = 12
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryUserFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test add user fraud lock exception"() {
        given:
        hmUserInfo[MPSDefs.DB_MEMBER_NUM] = 1
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addUserFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test update user fraud lock exception"() {
        given:
        hmUserInfo[MPSDefs.DB_MEMBER_NUM] = 1
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateUserFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test delete user fraud lock exception"() {
        given:
        hmUserInfo[MPSDefs.DB_MEMBER_NUM] = 1
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteUserFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test query account fraud lock exception"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = 12
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test add account fraud lock exception"() {
        given:
        hmUserInfo[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        hmUserInfo[MPSDefs.DB_SOR_INVARIANT_ID] = 1
        hmUserInfo[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmUserInfo[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test update account fraud lock exception"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_NAME] = 1
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test delete account fraud lock exception"() {
        given:
        hmUserInfo[MPSDefs.DB_SOR_NAME] = 1
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteAccountFraudLock(hmUserInfo)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test process data exception"() {
        given:
        HashMap<String, Object> hmUserFraudLockOperation = new HashMap<String, Object>()
        hmUserFraudLockOperation[MPSDefs.DB_OPERATION] = null
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['userfraudlock'] = hmUserFraudLockOperation
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    // --- Additional tests for addUserFraudLock UpdateUserFraud transaction path ---

    def "test add user fraud lock with UpdateUserFraud transaction name success"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        input[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        input[CommonDefs.TRANSACTION_NAME] = 'UpdateUserFraud'
        input[MPSDefs.DB_USER_LOCK_LEVEL] = '2'
        input[MPSDefs.DB_USER_LOCK_REASON] = 'SUSPECT'
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addUserFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test add user fraud lock with UpdateUserFraud missing member num"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_MEMBER_NUM] = null
        input[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        input[CommonDefs.TRANSACTION_NAME] = 'UpdateUserFraud'

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addUserFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test add user fraud lock with UpdateUserFraud missing calling system id"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        input[CommonDefs.CALLING_SYSTEM_ID] = null
        input[CommonDefs.TRANSACTION_NAME] = 'UpdateUserFraud'

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addUserFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test add user fraud lock with empty input map"() {
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addUserFraudLock(new HashMap<String, Object>())

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    // --- Additional tests for queryUserFraudLock ---

    def "test query user fraud lock with empty result list"() {
        given:
        jdbcTemplate.queryForList(_, _) >> new ArrayList()

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryUserFraudLock(hmDBInput)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'REC_NOT_FOUND'
    }

    def "test query user fraud lock with empty input map"() {
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryUserFraudLock(new HashMap<String, Object>())

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test query user fraud lock with empty member num"() {
        given:
        hmDBInput[CommonDefs.DB_MEMBER_NUM] = ''

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryUserFraudLock(hmDBInput)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    // --- Additional tests for queryAccountFraudLock with sor_name path ---

    def "test query account fraud lock with sor_name instead of sor_id"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_NAME] = 'ATT'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = '1312324234'
        dBHelper.getSorId('ATT') >> 5
        jdbcTemplate.queryForList(_, _) >> alQueryResponse

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test query account fraud lock with sor_name returning invalid id"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_NAME] = 'INVALID'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = '1312324234'
        dBHelper.getSorId('INVALID') >> -1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test query account fraud lock with empty input map"() {
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryAccountFraudLock(new HashMap<String, Object>())

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    // --- Additional tests for addAccountFraudLock with sor_name path ---

    def "test add account fraud lock with sor_name success"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_NAME] = 'ATT'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        input[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        input[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        input[MPSDefs.DB_ACCOUNT_LOCKED] = 'Y'
        input[MPSDefs.DB_ACCOUNT_LOCK_REASON] = 'FRAUD'
        dBHelper.getSorId('ATT') >> 5
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test add account fraud lock with sor_name returning invalid id"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_NAME] = 'INVALID'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        input[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        input[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        dBHelper.getSorId('INVALID') >> -1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test add account fraud lock missing fraud agent"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_ID] = '1'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        input[MPSDefs.DB_FRAUD_AGENT] = null
        input[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test add account fraud lock missing calling system id"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_ID] = '1'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        input[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        input[CommonDefs.CALLING_SYSTEM_ID] = null

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.addAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    // --- Additional tests for updateAccountFraudLock ---

    def "test update account fraud lock with sor_name success"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_NAME] = 'ATT'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        input[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        input[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        input['account_locked'] = 'Y'
        input['account_lock_reason'] = 'FRAUD'
        dBHelper.getSorId('ATT') >> 5
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test update account fraud lock with sor_name returning invalid id"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_NAME] = 'INVALID'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        input[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        dBHelper.getSorId('INVALID') >> -1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test update account fraud lock missing sor invariant id"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_ID] = '1'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = null
        input[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test update account fraud lock with account locked and lock reason attrs"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_ID] = '1'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        input[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        input['account_locked'] = 'N'
        input['account_lock_reason'] = 'CLEARED'
        input['fraud_agent'] = 'AGENT2'
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    // --- Additional tests for deleteAccountFraudLock ---

    def "test delete account fraud lock with sor_name success"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_NAME] = 'ATT'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        dBHelper.getSorId('ATT') >> 5
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test delete account fraud lock with sor_name returning invalid id"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_NAME] = 'INVALID'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        dBHelper.getSorId('INVALID') >> -1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test delete account fraud lock missing sor invariant id"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_ID] = '1'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = null

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test delete account fraud lock empty sor invariant id"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_ID] = '1'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = ''

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    // --- Additional tests for deleteUserFraudLock ---

    def "test delete user fraud lock with null member num in map"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_MEMBER_NUM] = null
        input[MPSDefs.DB_MEMBER_NAME] = 'testuser'

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteUserFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test delete user fraud lock with empty member num"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_MEMBER_NUM] = '  '
        input[MPSDefs.DB_MEMBER_NAME] = 'testuser'

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteUserFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test delete user fraud lock with valid member num and rows deleted"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_MEMBER_NUM] = '99999999'
        input[MPSDefs.DB_MEMBER_NAME] = 'testuser'
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.deleteUserFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    // --- Additional tests for updateUserFraudLock ---

    def "test update user fraud lock with missing calling system id"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        input[CommonDefs.CALLING_SYSTEM_ID] = null

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateUserFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test update user fraud lock with empty member num"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_MEMBER_NUM] = ''
        input[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateUserFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test update user fraud lock with partial attrs only fraud_agent"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        input[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        input['fraud_agent'] = 'AGENT_NEW'
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateUserFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test update user fraud lock with all updatable attrs"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        input[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        input['user_lock_level'] = '3'
        input['user_lock_reason'] = 'CONFIRMED_FRAUD'
        input['fraud_agent'] = 'AGENT_NEW'
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.updateUserFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    // --- Additional tests for processData with successful operations ---

    def "test process data user fraud lock insert success"() {
        given:
        ArrayList<Object> alUserFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmUserFraudLockOperation = new HashMap<String, Object>()
        hmUserFraudLockOperation[MPSDefs.DB_OPERATION] = 'insert'
        hmUserFraudLockOperation[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        hmUserFraudLockOperation[MPSDefs.DB_USER_LOCK_LEVEL] = '1'
        hmUserFraudLockOperation[MPSDefs.DB_USER_LOCK_REASON] = 'FRAUD'
        hmUserFraudLockOperation[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        hmUserFraudLockOperation[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        alUserFraudLockOperations.add(hmUserFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['userfraudlock'] = alUserFraudLockOperations
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test process data user fraud lock update success"() {
        given:
        ArrayList<Object> alUserFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmUserFraudLockOperation = new HashMap<String, Object>()
        hmUserFraudLockOperation[MPSDefs.DB_OPERATION] = 'update'
        hmUserFraudLockOperation[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        hmUserFraudLockOperation[MPSDefs.DB_USER_LOCK_LEVEL] = '2'
        hmUserFraudLockOperation[MPSDefs.DB_USER_LOCK_REASON] = 'SUSPECT'
        hmUserFraudLockOperation[MPSDefs.DB_FRAUD_AGENT] = 'AGENT1'
        hmUserFraudLockOperation[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        alUserFraudLockOperations.add(hmUserFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['userfraudlock'] = alUserFraudLockOperations
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test process data user fraud lock delete success"() {
        given:
        ArrayList<Object> alUserFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmUserFraudLockOperation = new HashMap<String, Object>()
        hmUserFraudLockOperation[MPSDefs.DB_OPERATION] = 'delete'
        hmUserFraudLockOperation[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        alUserFraudLockOperations.add(hmUserFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['userfraudlock'] = alUserFraudLockOperations
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test process data account fraud lock insert success"() {
        given:
        ArrayList<Object> alAcctFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmAcctFraudLockOperation = new HashMap<String, Object>()
        hmAcctFraudLockOperation[MPSDefs.DB_OPERATION] = 'insert'
        hmAcctFraudLockOperation[MPSDefs.DB_SOR_ID] = '1'
        hmAcctFraudLockOperation[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        hmAcctFraudLockOperation[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        hmAcctFraudLockOperation[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmAcctFraudLockOperation[MPSDefs.DB_ACCOUNT_LOCKED] = 'Y'
        hmAcctFraudLockOperation[MPSDefs.DB_ACCOUNT_LOCK_REASON] = 'FRAUD'
        alAcctFraudLockOperations.add(hmAcctFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['accountfraudlock'] = alAcctFraudLockOperations
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test process data account fraud lock update success"() {
        given:
        ArrayList<Object> alAcctFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmAcctFraudLockOperation = new HashMap<String, Object>()
        hmAcctFraudLockOperation[MPSDefs.DB_OPERATION] = 'update'
        hmAcctFraudLockOperation[MPSDefs.DB_SOR_ID] = '1'
        hmAcctFraudLockOperation[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        hmAcctFraudLockOperation[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmAcctFraudLockOperation['fraud_agent'] = 'AGENT2'
        alAcctFraudLockOperations.add(hmAcctFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['accountfraudlock'] = alAcctFraudLockOperations
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test process data account fraud lock delete success"() {
        given:
        ArrayList<Object> alAcctFraudLockOperations = new ArrayList<Object>()
        HashMap<String, Object> hmAcctFraudLockOperation = new HashMap<String, Object>()
        hmAcctFraudLockOperation[MPSDefs.DB_OPERATION] = 'delete'
        hmAcctFraudLockOperation[MPSDefs.DB_SOR_ID] = '1'
        hmAcctFraudLockOperation[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        alAcctFraudLockOperations.add(hmAcctFraudLockOperation)
        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['accountfraudlock'] = alAcctFraudLockOperations
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test process data with both user and account fraud lock operations"() {
        given:
        ArrayList<Object> alUserOps = new ArrayList<Object>()
        HashMap<String, Object> hmUserOp = new HashMap<String, Object>()
        hmUserOp[MPSDefs.DB_OPERATION] = 'insert'
        hmUserOp[MPSDefs.DB_MEMBER_NUM] = '12324324354'
        hmUserOp[MPSDefs.DB_USER_LOCK_LEVEL] = '1'
        hmUserOp[MPSDefs.DB_USER_LOCK_REASON] = 'FRAUD'
        hmUserOp[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        hmUserOp[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        alUserOps.add(hmUserOp)

        ArrayList<Object> alAcctOps = new ArrayList<Object>()
        HashMap<String, Object> hmAcctOp = new HashMap<String, Object>()
        hmAcctOp[MPSDefs.DB_OPERATION] = 'insert'
        hmAcctOp[MPSDefs.DB_SOR_ID] = '1'
        hmAcctOp[MPSDefs.DB_SOR_INVARIANT_ID] = '123434567'
        hmAcctOp[MPSDefs.DB_FRAUD_AGENT] = 'Y'
        hmAcctOp[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmAcctOp[MPSDefs.DB_ACCOUNT_LOCKED] = 'Y'
        hmAcctOp[MPSDefs.DB_ACCOUNT_LOCK_REASON] = 'FRAUD'
        alAcctOps.add(hmAcctOp)

        HashMap<String, Object> hmInput = new HashMap<String, Object>()
        hmInput['userfraudlock'] = alUserOps
        hmInput['accountfraudlock'] = alAcctOps
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test process data with null input"() {
        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.processData(null)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    // --- Additional tests for queryAccountFraudLock edge cases ---

    def "test query account fraud lock with sor_id zero"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_ID] = '0'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = '1312324234'
        jdbcTemplate.queryForList(_, _) >> alQueryResponse

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test query account fraud lock with empty sor_invariant_id"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_ID] = '1'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = ''

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "test query account fraud lock with null result from db"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_ID] = '1'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = '1312324234'
        jdbcTemplate.queryForList(_, _) >> null

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test query account fraud lock with empty result list from db"() {
        given:
        HashMap<String, Object> input = new HashMap<String, Object>()
        input[MPSDefs.DB_SOR_ID] = '1'
        input[MPSDefs.DB_SOR_INVARIANT_ID] = '1312324234'
        jdbcTemplate.queryForList(_, _) >> new ArrayList()

        when:
        HashMap<String, Object> resp = oFraudLockDBHelper.queryAccountFraudLock(input)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }
}
