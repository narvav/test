//package com.att.idp.integration
//
//import com.att.ajsc.common.utility.SystemPropertiesLoader
//import io.restassured.RestAssured
//import io.restassured.http.ContentType
//import io.restassured.specification.RequestSpecification
//import org.springframework.beans.factory.annotation.Value
//import org.springframework.boot.test.context.ConfigDataApplicationContextInitializer
//import org.springframework.context.support.PropertySourcesPlaceholderConfigurer
//import org.springframework.test.context.ContextConfiguration
//import spock.lang.Specification
//
//import java.util.concurrent.ThreadLocalRandom
//
//
//@ContextConfiguration(classes = PropertySourcesPlaceholderConfigurer.class, initializers = ConfigDataApplicationContextInitializer.class)
//abstract class IntegrationTestBase extends Specification {
//
//	static {
//		SystemPropertiesLoader.addSystemProperties()
//	}
//
//	@Value("${server.servlet.context-path}")
//	private String contextPath
//
//	@Value("${api.schemaVersion}")
//	private String apiVersion
//
//	@Value("${spring.application.name}")
//	private String appPath
//
//	@Value("${apiclient.rest.default.userTypes.guest.username}")
//	protected String guestUsername
//
//	@Value("${apiclient.rest.default.userTypes.guest.password}")
//	protected String guestPassword
//
//	@Value("${apiclient.rest.default.userTypes.registered.username}")
//	protected String registeredUsername
//
//	@Value("${apiclient.rest.default.userTypes.registered.password}")
//	protected String registeredPassword
//
//
//    def setup() throws Exception {
//		String baseURI = System.getProperty('BASE_URL')
//		String isAzure = System.getProperty('IS_AZURE')
//		if (isAzure.equalsIgnoreCase('N')) {
//			RestAssured.baseURI = baseURI + contextPath + '/' + appPath.toLowerCase() + '/' + apiVersion
//		} else {
//			String role = System.getProperty('TARGET_ROLE')
//			RestAssured.baseURI = baseURI + contextPath + '/' + appPath.toLowerCase() + '-' + role + '/' + apiVersion
//		}
//	}
//
//	/**
//	 * Returns the traceId for tracking logs in integration testing.
//	 *
//	 * @return traceId
//	 */
//	protected String getTraceId() {
//		long id = ThreadLocalRandom.current().nextLong()
//		byte flags = 0
//		String traceId = String.format('%x:%x:%x:%x', id, 0, 0, flags)
//		return traceId
//	}
//
//	/*
//	 * Base spec with guest user
//	 */
//	protected RequestSpecification givenBaseSpec() {
//		Map<String, String> headers = new HashMap<>()
//		headers['idpctx-user-type'] = 'guest'
//		headers['idp-trace-id'] = traceId
//
//		return RestAssured.given().relaxedHTTPSValidation().accept(ContentType.JSON).contentType(ContentType.JSON)
//				.auth().basic(guestUsername, guestPassword).headers(headers)
//	}
//
//	/*
//	 * Base spec for registered user
//	 */
//	protected RequestSpecification givenRegisteredBaseSpec() {
//		Map<String, String> headers = new HashMap<>()
//		headers['idpctx-user-type'] = 'registered'
//		headers['idp-trace-id'] = traceId
//
//		return RestAssured.given().relaxedHTTPSValidation().accept(ContentType.JSON).contentType(ContentType.JSON)
//				.auth().basic(registeredUsername, registeredPassword).headers(headers)
//	}
//
//}
