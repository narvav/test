package com.att.idp.idgraphuserregistrationms.queue.message.helpers

import com.att.idp.idgraphuserregistrationms.helper.voltage.VoltageEncryptionHelper
import com.att.idp.idgraphuserregistrationms.queue.message.sender.JMSQueueSender
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.CommonUtil
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import java.text.SimpleDateFormat

class WirelessAutoRegQueueHelperTest extends Specification {

	VoltageEncryptionHelper voltageEncryptionHelperObj = Mock(VoltageEncryptionHelper)
    PublishEventHelper publishEventHelper = Mock(PublishEventHelper)
    def wirelessAutoRegQHelperObj = new WirelessAutoRegQueueHelper(voltageEncryptionHelperObj, "10", publishEventHelper)

    Map<String, Object> hmInput = null
    Map<String, Object> hmResult = null
    HashMap<String, Object> hmEncInput = null
    HashMap<String, Object> hmSuccessResponse = null
    Map<String, Object> hmDBMember = null
    Logger logger = null

    ArrayList dbusInput = null


    def setup() {
		hmInput = CommonUtil.hashMap
        hmResult = CommonUtil.hashMap

        logger = LoggerFactory.getLogger('RetriggerQARQueueHelper')

        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.GUID] = '121212120'
        hmInput[CommonDefs.SOR_INVARIANT_ID] = '121212120'
        hmInput[CommonDefs.SERVICE_NAME] = 'MOBILITY'
        hmInput[CommonDefs.SOR_ID] = '13'
        hmInput[CommonDefs.CONTACT_EMAIL] = hmInput[CommonDefs.CONTACT_EMAIL]
        hmInput[CommonDefs.TRANSACTION_ID] = 'bc6253c94e0d42b4'
        hmInput[CommonDefs.ORIG_TRANSID] = 'bc6253c94e0d42b4'
        hmInput[CommonDefs.CONTACT_EMAIL] = 'qay_test'

        SimpleDateFormat dateformat = new SimpleDateFormat('YYYYMMdd')
        Calendar cal = Calendar.instance

        cal.add(Calendar.DAY_OF_MONTH, Integer.parseInt('30'))
        String date = (dateformat.format(cal.time))

        hmEncInput = new HashMap<String, Object>()

        String sVoltageEncryptString = hmInput[CommonDefs.SOR_ID] + '_' + hmInput[CommonDefs.SOR_INVARIANT_ID] + '_' + date
        hmEncInput['CBR'] = sVoltageEncryptString

        hmSuccessResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')

    }


    def "test property error"() {
        given:
        def wirelessAutoRegQHelperObjLocal = new WirelessAutoRegQueueHelper(voltageEncryptionHelperObj, null, publishEventHelper)
        when:
        hmResult = wirelessAutoRegQHelperObjLocal.prepareEDDDataForAsyncCall(hmInput, 'slid')
        then:
        hmResult['appInfo'] == 'The value of QAR_EXPIRY_DAYS is not configured in property files'
    }


    def "test prepare e d d data for async call success"() {

        given:
        ReflectionTestUtils.setField(wirelessAutoRegQHelperObj, 'sPropQarExpiryDays', '30')
        HashMap<String, Object> voltageResult = new HashMap<String, Object>()
        voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
        voltageEncryptionHelperObj.getEFPEEncryptedValues(_ as HashMap) >> voltageResult

        when:
        hmResult = wirelessAutoRegQHelperObj.prepareEDDDataForAsyncCall(hmInput, 'valid@att.com')

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "test prepare e d d data for async call error"() {

        given:
        ReflectionTestUtils.setField(wirelessAutoRegQHelperObj, 'sPropQarExpiryDays', '30')

        HashMap<String, Object> voltageResult = new HashMap<String, Object>()
        voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '118'
        voltageEncryptionHelperObj.getEFPEEncryptedValues(_ as HashMap) >> voltageResult

        when:
        hmResult = wirelessAutoRegQHelperObj.prepareEDDDataForAsyncCall(hmInput, 'valid@att.com')

        then:
        hmResult['appStatusCode'] == '118'
    }


    def "test prepare data for async call system error"() {

        given:
        ReflectionTestUtils.setField(wirelessAutoRegQHelperObj, 'sPropQarExpiryDays', '30')
         NullPointerException ex = new NullPointerException('NullPointerException thrown')
        voltageEncryptionHelperObj.getEFPEEncryptedValues(_ as HashMap) >> { throw ex }
        when:
        hmResult = wirelessAutoRegQHelperObj.prepareEDDDataForAsyncCall(hmInput, 'valid@att.com')
        then:
        hmResult['appStatusCode'] == '602'
    }


    def "test make async call success"() {
        given:
        publishEventHelper.publishEvent(_ as String, _ as String, _ as Map<String, Object>,_ as Map<String, Object>) >> hmSuccessResponse
        when:
        hmResult = wirelessAutoRegQHelperObj.sendMessage(dbusInput, hmInput)
        then:
        hmResult['appStatusCode'] == '0'
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Success'
    }
	

}
