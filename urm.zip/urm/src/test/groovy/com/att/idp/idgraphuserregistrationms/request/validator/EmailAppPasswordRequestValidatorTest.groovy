package com.att.idp.idgraphuserregistrationms.request.validator

import com.att.idp.idgraphuserregistrationms.resource.response.EmailAppPasswordResponse
import com.att.mpsys.common.utils.CErrorDefs
import jakarta.ws.rs.core.HttpHeaders
import spock.lang.Specification
import spock.lang.Unroll

class EmailAppPasswordRequestValidatorTest extends Specification {

    EmailAppPasswordRequestValidator validator
    HttpHeaders mockHeaders

    void setup() {
        validator = new EmailAppPasswordRequestValidator()
        mockHeaders = Stub(HttpHeaders)
    }

    @Unroll
    def "should return error when X-ATT-ClientId is missing or invalid for #scenarioName"() {
        given: "HttpHeaders with missing or invalid X-ATT-ClientId"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> clientIdValue
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-123"

        when: "emailPasswordReqValidator is called"
        EmailAppPasswordResponse result = validator.emailPasswordReqValidator(memberId, domain, guid, mockHeaders)

        then: "Error response is returned for invalid clientId"
        result != null
        0 * _

        where:
        scenarioName          | clientIdValue | memberId  | domain    | guid
        "null clientId"       | null          | "user1"   | "att.net" | null
        "empty clientId"      | ""            | "user1"   | "att.net" | null
        "wrong clientId"      | "WRONG"       | "user1"   | "att.net" | null
    }

    def "should return null (valid) when guid is provided with valid clientId"() {
        given: "Valid clientId and guid present"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-456"

        when: "emailPasswordReqValidator is called"
        EmailAppPasswordResponse result = validator.emailPasswordReqValidator("user1", "att.net", "123456", mockHeaders)

        then: "Null is returned indicating valid request"
        result == null
        0 * _
    }

    def "should return null (valid) when guid is provided with case-insensitive clientId"() {
        given: "Valid clientId in lowercase and guid present"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "idmprofile"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-789"

        when: "emailPasswordReqValidator is called"
        EmailAppPasswordResponse result = validator.emailPasswordReqValidator(null, null, "456789", mockHeaders)

        then: "Null is returned indicating valid request"
        result == null
        0 * _
    }

    def "should return null when memberId and domain are both provided without guid"() {
        given: "Valid clientId, memberId and domain present, no guid"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-101"

        when: "emailPasswordReqValidator is called"
        EmailAppPasswordResponse result = validator.emailPasswordReqValidator("user1", "att.net", null, mockHeaders)

        then: "Null is returned indicating valid request"
        result == null
        0 * _
    }

    @Unroll
    def "should return error when guid is not all numeric for #scenarioName"() {
        given: "Valid clientId and a guid that is not purely numeric"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-alpha"

        when: "emailPasswordReqValidator is called with a non-numeric guid"
        EmailAppPasswordResponse result = validator.emailPasswordReqValidator(null, null, invalidGuid, mockHeaders)

        then: "Error response is returned"
        result != null
        result.errors != null
        0 * _

        where:
        scenarioName               | invalidGuid
        "letters only"            | "abcdef"
        "alphanumeric guid"       | "guid-12345"
        "hex alpha guid"          | "a1b2c3d4-e5f6-7890"
        "mixed alpha and numeric" | "123abc456"
        "uppercase letters"       | "ABCDEF123"
        "hyphen separated"        | "1234-5678"
        "guid with spaces"        | "1234 5678"
        "guid with special chars" | "1234@5678"
    }

    @Unroll
    def "should return error when guid missing and memberId/domain incomplete for #scenarioName"() {
        given: "Valid clientId but incomplete memberId/domain"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-202"

        when: "emailPasswordReqValidator is called"
        EmailAppPasswordResponse result = validator.emailPasswordReqValidator(memberId, domain, guid, mockHeaders)

        then: "Error response is returned"
        result != null
        0 * _

        where:
        scenarioName                  | memberId  | domain    | guid
        "null guid, null memberId"    | null      | "att.net" | null
        "null guid, null domain"      | "user1"   | null      | null
        "null guid, both null"        | null      | null      | null
        "null guid, empty memberId"   | ""        | "att.net" | null
        "null guid, empty domain"     | "user1"   | ""        | null
        "null guid, blank memberId"   | "   "     | "att.net" | null
        "null guid, blank domain"     | "user1"   | "   "     | null
        "empty guid, null memberId"   | null      | "att.net" | ""
        "blank guid, null domain"     | "user1"   | null      | "   "
    }
}
