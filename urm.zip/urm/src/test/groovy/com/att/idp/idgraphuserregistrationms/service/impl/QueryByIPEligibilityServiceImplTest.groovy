package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.helper.QueryByIPEligibilityHelper
import com.att.idp.idgraphuserregistrationms.resource.request.QueryByIPEligibilityRequest
import com.att.idp.idgraphuserregistrationms.resource.response.QueryByIPEligibilityResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.junit.jupiter.api.extension.ExtendWith

import spock.lang.Specification

import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap

class QueryByIPEligibilityServiceImplTest extends Specification {

	def queryByIPEligServiceImplObj=new QueryByIPEligibilityServiceImpl()

	QueryByIPEligibilityHelper queryByIPEligibilityHelperObj=Mock(QueryByIPEligibilityHelper)

	QueryByIPEligibilityRequest requestObj = null
	public MultivaluedMap<String, String> requestHeader = null
	private Map<String, String> headers = new HashMap<>()


	def setup() throws Exception {
		queryByIPEligServiceImplObj.queryByIPEligibilityHelper = queryByIPEligibilityHelperObj
		requestObj = new QueryByIPEligibilityRequest()
		requestHeader = new MultivaluedHashMap<>(headers)

		requestObj.callingSystemId = 'IDP'
		requestObj.ipAddress = '2611:1711:4881:3931:2a16:adsf:fe19:7be4'
		requestObj.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
	}


	def "test querybyipeligibility null response"() {

		when:
		QueryByIPEligibilityResponse response = queryByIPEligServiceImplObj.queryByIPEligibility(requestObj, requestHeader)
		then:
		response.appInfo == 'Null response from queryByIPEligibilityHelper.queryByIPEligibility'
		Map<String, Object> hmResponse = new HashMap()

		when:
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_163748566777'
		hmResponse[MPSDefs.APP_STATUS_CODE] = null
		queryByIPEligibilityHelperObj.queryByIPEligibility(_ as Map<String, Object>) >> hmResponse

		and:
		response = queryByIPEligServiceImplObj.queryByIPEligibility(requestObj, requestHeader)

		then:
		response.appInfo == 'Null response from queryByIPEligibilityHelper.queryByIPEligibility'

	}


	def "test querybyipeligibility success"() {

		given:
		Map<String, Object> hmResponse = new HashMap()
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_163748566777'
		hmResponse['siteId'] = '45'
		hmResponse['ban'] = '673528899272689'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['appInfo'] = 'Success'
		hmResponse['ErrorEnum'] = CommonDefs.COMMON_SUCCESS_MSG
		queryByIPEligibilityHelperObj.queryByIPEligibility(_ as Map<String, Object>) >> hmResponse

		when:
		QueryByIPEligibilityResponse response = queryByIPEligServiceImplObj.queryByIPEligibility(requestObj, requestHeader)

		then:
		response.appStatusCode == '0'
		response.ban != null
	}

}
