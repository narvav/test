package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraph.extclient.model.ExtClientResponse
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetInfoByMaskDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetSlidInfoDBHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import com.fasterxml.jackson.databind.node.ObjectNode
import spock.lang.Specification
import spock.lang.Unroll

class SyncOperationTest extends Specification {

    GetSlidInfoDBHelper getSlidInfoDBHelper
    GetInfoByMaskDBHelper getInfoByMaskDBHelper
    GetMemberServicesDBHelper getMemberServicesDBHelper
    TestSyncOperation syncOperation

    static class TestSyncOperation extends SyncOperation {
        @Override
        protected HashMap<String, Object> validateInput(HashMap<String, Object> hmInput) { return new HashMap<>() }
        @Override
        protected HashMap<String, Object> checkEligibility(HashMap<String, Object> hmInput) { return new HashMap<>() }
        @Override
        protected HashMap<String, Object> buildSyncRequest(HashMap<String, Object> profileDiff, HashMap<String, Object> servicesDiff, HashMap<String, Object> aliasDiff) { return new HashMap<>() }
        @Override
        protected HashMap<String, Object> performSync(HashMap<String, Object> hmInput) { return new HashMap<>() }
    }

    private static void inject(Object target, String fieldName, Object value) {
        java.lang.reflect.Field f = target.getClass().getSuperclass().getDeclaredField(fieldName)
        f.setAccessible(true)
        f.set(target, value)
    }

    def setup() {
        getSlidInfoDBHelper = Mock(GetSlidInfoDBHelper)
        getInfoByMaskDBHelper = Mock(GetInfoByMaskDBHelper)
        getMemberServicesDBHelper = Mock(GetMemberServicesDBHelper)
        syncOperation = new TestSyncOperation()
        inject(syncOperation, "oGetSlidInfoDBHelper", getSlidInfoDBHelper)
        inject(syncOperation, "oGetInfoByMaskDBHelper", getInfoByMaskDBHelper)
        inject(syncOperation, "getMemberServicesDBHelper", getMemberServicesDBHelper)
    }

    @Unroll
    def "should return invalid data error for #scenarioName"() {
        given: "Null or empty input map"
        HashMap<String, Object> input = provided

        when: "getSlidMidInfo is invoked"
        HashMap<String, Object> result = syncOperation.getSlidMidInfo(input)

        then: "No DB helpers are called"
        0 * getSlidInfoDBHelper.getSlidInfo(_)
        0 * getInfoByMaskDBHelper.getInfoByMask(_)
        0 * _

        and: "Result contains invalid data error code"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_INVALID_DATA_NUM)
        result.get(CErrorDefs.COMMON_APP_INFO) instanceof String
        (result.get(CErrorDefs.COMMON_APP_INFO) as String).toLowerCase().contains("input")

        where:
        scenarioName      | provided
        "null input map"  | null
        "empty input map" | new HashMap<String, Object>()
    }

    def "should handle exception path when GUID only (domain null -> NPE)"() {
        given: "Input containing only GUID"
        HashMap<String, Object> input = new HashMap<>()
        input.put(CommonDefs.GUID, "12345")

        when: "getSlidMidInfo is invoked causing NullPointerException on domain access"
        HashMap<String, Object> result = syncOperation.getSlidMidInfo(input)

        then: "No DB helpers are called"
        0 * getSlidInfoDBHelper.getSlidInfo(_)
        1 * getInfoByMaskDBHelper.getInfoByMask(_ as HashMap) >> null


        and: "Result contains system application error code"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_SYS_APPL_NUM)
        result.get(CErrorDefs.COMMON_APP_INFO) instanceof String
        result.get(CErrorDefs.COMMON_APP_INFO) != null
    }

    def "should return system error when DB response empty (dummy domain path)"() {
        given: "Handle+dummy domain producing empty DB response"
        String handle = "userA"
        String domain = CommonDefs.SLID_DUM
        HashMap<String, Object> input = new HashMap<>()
        input.put(CommonDefs.HANDLE, handle)
        input.put(CommonDefs.DOMAIN, domain)

        when: "getSlidMidInfo is invoked"
        HashMap<String, Object> result = syncOperation.getSlidMidInfo(input)

        then: "Dummy domain helper called once with expected query map"
        getSlidInfoDBHelper.getSlidInfo({ HashMap<String, Object> arg ->
            arg.get(MPSDefs.DB_MEMBER_NAME) == handle &&
                    arg.get(MPSDefs.DB_DOMAIN_NAME) == domain &&
                    arg.get("slid") == handle &&
                    arg.get("queryMemberServiceAttributes") == "Y" &&
                    arg.get("slidMask") instanceof ArrayList &&
                    ((ArrayList<?>) arg.get("slidMask")).size() >= 12
        }) >> new HashMap<String, Object>() // empty triggers system error

        and: "Result contains system application error code and message"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_SYS_APPL_NUM)
        (result.get(CErrorDefs.COMMON_APP_INFO) as String).toLowerCase().contains("response")
    }

    def "should return user not found error when status code REC_NOT_FOUND (non dummy domain)"() {
        given: "Handle+regular domain with REC_NOT_FOUND status"
        String handle = "userB"
        String domain = "att.net"
        HashMap<String, Object> input = new HashMap<>()
        input.put(CommonDefs.HANDLE, handle)
        input.put(CommonDefs.DOMAIN, domain)

        HashMap<String, Object> dbResponse = new HashMap<>()
        dbResponse.put(CErrorDefs.COMMON_APP_STATUS_CODE, CErrorDefs.ERR_REC_NOT_FOUND)
        dbResponse.put(CErrorDefs.COMMON_APP_INFO, "Not found")

        when:
        HashMap<String, Object> result = syncOperation.getSlidMidInfo(input)

        then: "GetInfoByMask helper called"
        1 * getInfoByMaskDBHelper.getInfoByMask({ HashMap<String, Object> arg ->
            arg.get(MPSDefs.DB_MEMBER_NAME) == handle &&
                    arg.get(MPSDefs.DB_DOMAIN_NAME) == domain &&
                    arg.get("slid") == handle
        }) >> dbResponse
        0 * getSlidInfoDBHelper.getSlidInfo(_)
        0 * _

        and: "Result reflects user not found error code"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_USER_NOT_FOUND_NUM)
        (result.get(CErrorDefs.COMMON_APP_INFO) as String).toLowerCase().contains("access id")
    }

    def "should return raw DB response on non-success non-rec-not-found status"() {
        given: "Failure status other than REC_NOT_FOUND"
        String handle = "userC"
        String domain = "att.net"
        HashMap<String, Object> input = new HashMap<>()
        input.put(CommonDefs.HANDLE, handle)
        input.put(CommonDefs.DOMAIN, domain)

        HashMap<String, Object> dbResponse = new HashMap<>()
        dbResponse.put(CErrorDefs.COMMON_APP_STATUS_CODE, "999")
        dbResponse.put(CErrorDefs.COMMON_APP_INFO, "Generic failure")
        dbResponse.put("extra", "X")

        when:
        HashMap<String, Object> result = syncOperation.getSlidMidInfo(input)

        then:
        1 * getInfoByMaskDBHelper.getInfoByMask({ HashMap<String, Object> arg ->
            arg.get(MPSDefs.DB_MEMBER_NAME) == handle &&
                    arg.get(MPSDefs.DB_DOMAIN_NAME) == domain
        }) >> dbResponse
        0 * getSlidInfoDBHelper.getSlidInfo(_)
        0 * _

        and: "Result equals original DB response"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == "999"
        result.get(CErrorDefs.COMMON_APP_INFO) == "Generic failure"
        result.get("extra") == "X"
    }
    @Unroll
    def "should retrieve member name and domain for #scenarioName"() {
        given: "Member number with expected repository outcome"
        String inputMemberNum = memberNum
        Optional<Map<String, String>> repositoryResponse = present ?
                Optional.of(new HashMap<String, String>() {{
                    put(MPSDefs.DB_MEMBER_NAME, expectedMemberName)
                    put(MPSDefs.DB_DOMAIN_NAME, expectedDomain)
                }}) :
                Optional.empty()

        when: "retrieveMemberNameAndDomain is invoked"
        Optional<Map<String, String>> result = syncOperation.retrieveMemberNameAndDomain(inputMemberNum)

        then: "DB helper called with correct member number"
        1 * getInfoByMaskDBHelper.getMemberNameAndDomainByMemberNum(inputMemberNum) >> repositoryResponse
        0 * _

        and: "Result presence and contents match expectation"
        result.isPresent() == present
        if (present) {
            result.get().get(MPSDefs.DB_MEMBER_NAME) == expectedMemberName
            result.get().get(MPSDefs.DB_DOMAIN_NAME) == expectedDomain
        }

        where: "Different retrieval scenarios"
        scenarioName        | memberNum | present | expectedMemberName | expectedDomain
        "existing member"   | "111"     | true    | "userX"            | "att.net"
        "missing member"    | "222"     | false   | null               | null
    }

    def "should return top-level map when success without nested slidInfo (non dummy domain)"() {
        given: "Success response lacking slidInfo key"
        String handle = "userE"
        String domain = "example.com"
        HashMap<String, Object> input = new HashMap<>()
        input.put(CommonDefs.HANDLE, handle)
        input.put(CommonDefs.DOMAIN, domain)

        HashMap<String, Object> dbResponse = new HashMap<>()
        dbResponse.put(CErrorDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        dbResponse.put("member_name", "topLevel")
        dbResponse.put("attr", "Z")

        when:
        HashMap<String, Object> result = syncOperation.getSlidMidInfo(input)

        then:
        1 * getInfoByMaskDBHelper.getInfoByMask({ HashMap<String, Object> arg ->
            arg.get(MPSDefs.DB_MEMBER_NAME) == handle &&
                    arg.get(MPSDefs.DB_DOMAIN_NAME) == domain
        }) >> dbResponse
        0 * getSlidInfoDBHelper.getSlidInfo(_)
        0 * _

        and: "Result equals original DB response"
        result != null
        result.get("member_name") == "topLevel"
        result.get("attr") == "Z"
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
    }

    @Unroll
    def "should return error for invalid input in getMemberServicesByBan for #scenarioName"() {
        given: "Null or empty input"
        HashMap<String, Object> input = provided

        when: "getMemberServicesByBan is called"
        HashMap result = syncOperation.getMemberServicesByBan(input)

        then: "No DB helper is called"
        0 * getMemberServicesDBHelper.getMemberServices(_)
        0 * _

        and: "Result contains invalid data error"
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_INVALID_DATA_NUM)
        ((String) result.get(CErrorDefs.COMMON_APP_INFO)).toLowerCase().contains("input")

        where:
        scenarioName      | provided
        "null input map"  | null
        "empty input map" | new HashMap<String, Object>()
    }

    def "should return error when BAN is missing in getMemberServicesByBan"() {
        given: "Input without BAN"
        HashMap<String, Object> input = new HashMap<>()
        input.put("foo", "bar")

        when: "getMemberServicesByBan is called"
        HashMap result = syncOperation.getMemberServicesByBan(input)

        then: "No DB helper is called"
        0 * getMemberServicesDBHelper.getMemberServices(_)
        0 * _

        and: "Result contains invalid data error"
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_INVALID_DATA_NUM)
        ((String) result.get(CErrorDefs.COMMON_APP_INFO)).toLowerCase().contains("ban is missing")
    }

    def "should return error when DB response is null or empty in getMemberServicesByBan"() {
        given: "Input with BAN"
        HashMap<String, Object> input = new HashMap<>()
        input.put(CommonDefs.BAN, "12345")

        when: "getMemberServicesByBan is called"
        1 * getMemberServicesDBHelper.getMemberServices(input) >> dbResponse
        0 * _

        then: "Result contains system error"
        HashMap result = syncOperation.getMemberServicesByBan(input)
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_SYS_APPL_NUM)
        ((String) result.get(CErrorDefs.COMMON_APP_INFO)).toLowerCase().contains("response from getmemberservices is either null or empty")

        where:
        dbResponse << [null, new HashMap<String, Object>()]
    }

    @Unroll
    def "should handle non-success status in getMemberServicesByBan for #scenarioName"() {
        given: "Input with BAN and DB response with error"
        HashMap<String, Object> input = new HashMap<>()
        input.put(CommonDefs.BAN, "12345")
        HashMap<String, Object> dbResponse = new HashMap<>()
        dbResponse.put(CErrorDefs.COMMON_APP_STATUS_CODE, statusCode)
        dbResponse.put(CErrorDefs.COMMON_APP_INFO, appInfo)

        when: "getMemberServicesByBan is called"
        1 * getMemberServicesDBHelper.getMemberServices(input) >> dbResponse
        0 * _

        then: "Result contains expected error"
        HashMap result = syncOperation.getMemberServicesByBan(input)
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == expectedStatus
        ((String) result.get(CErrorDefs.COMMON_APP_INFO)).toLowerCase().contains(expectedInfo)

        where:
        scenarioName         | statusCode                        | appInfo         | expectedStatus                                 | expectedInfo
        "REC_NOT_FOUND"      | CErrorDefs.ERR_REC_NOT_FOUND      | "Not found"     | String.valueOf(CErrorDefs.ERR_USER_NOT_FOUND_NUM) | "user not found"
        "Other error"        | "999"                             | "Generic fail"  | "999"                                             | "generic fail"
    }

    def "should return DB response for success in getMemberServicesByBan"() {
        given: "Input with BAN and DB response with success"
        HashMap<String, Object> input = new HashMap<>()
        input.put(CommonDefs.BAN, "12345")
        HashMap<String, Object> dbResponse = new HashMap<>()
        dbResponse.put(CErrorDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        dbResponse.put("foo", "bar")

        when: "getMemberServicesByBan is called"
        1 * getMemberServicesDBHelper.getMemberServices(input) >> dbResponse
        0 * _

        then: "Result is the DB response"
        HashMap result = syncOperation.getMemberServicesByBan(input)
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get("foo") == "bar"
    }

    def "should handle exception in getMemberServicesByBan"() {
        given: "Input with BAN and DB helper throws exception"
        HashMap<String, Object> input = new HashMap<>()
        input.put(CommonDefs.BAN, "12345")
        RuntimeException ex = new RuntimeException("DB error")

        when: "getMemberServicesByBan is called"
        1 * getMemberServicesDBHelper.getMemberServices(input) >> { throw ex }
        0 * _

        then: "Result contains system error"
        HashMap result = syncOperation.getMemberServicesByBan(input)
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_SYS_APPL_NUM)
        ((String) result.get(CErrorDefs.COMMON_APP_INFO)).toLowerCase().contains("exception in getmemberservicesbyban")
    }

    @Unroll
    def "should handle ExtClientResponse in handleResponse for #scenarioName"() {
        given: "ExtClientResponse with various status codes"
        ExtClientResponse response = new ExtClientResponse()
        response.setAppStatusCode(appStatusCode)
        response.setAppInfo(appInfo)

        when: "handleResponse is called"
        HashMap result = syncOperation.handleResponse(response, "testMethod")

        then: "Result contains expected status and info"
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == expectedStatus

        where:
        scenarioName         | appStatusCode                | appInfo         | expectedStatus | expectedInfo
        "non-success code"   | "999"                       | "fail info"     | "999"          | "failed with status"
        "success code"       | CommonDefs.COMMON_SUCCESS   | ""          | CommonDefs.COMMON_SUCCESS | ""
    }

    def "should handle null ExtClientResponse in handleResponse"() {
        given: "Null ExtClientResponse"
        ExtClientResponse response = null

        when: "handleResponse is called"
        HashMap result = syncOperation.handleResponse(response, "testMethod")

        then: "Result contains system error"
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_SYS_APPL_NUM)
        ((String) result.get(CErrorDefs.COMMON_APP_INFO)).toLowerCase().contains("null response")
    }

    def "should convert map to ObjectNode in toObjectNode"() {
        given: "A map to convert"
        Map<String, Object> input = new HashMap<>()
        input.put("foo", "bar")
        input.put("num", 123)

        when: "toObjectNode is called"
        ObjectNode result = syncOperation.toObjectNode(input)

        then: "Result is an ObjectNode with expected fields"
        result.get("foo").asText() == "bar"
        result.get("num").asInt() == 123
    }
}