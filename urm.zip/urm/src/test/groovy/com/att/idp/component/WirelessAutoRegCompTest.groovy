package com.att.idp.component

import com.att.idp.idgraphuserregistrationms.client.CSIIAPSoapHandler
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.AccountAutoRegDBHelper
import com.att.idp.idgraphuserregistrationms.queue.message.helpers.WirelessAutoRegQueueHelper
import com.att.mpsys.common.helpers.FeatureManagerHelper
import org.hamcrest.CoreMatchers
import org.spockframework.spring.SpringBean
import org.springframework.transaction.PlatformTransactionManager

/**
 * Component test for POST /orchestration/wireless endpoint.
 *
 * Dependency chain:
 *   WirelessAutoRegResourceImpl (INTERNAL — real)
 *     ├── WirelessAutoRegRequestValidator (INTERNAL — real)
 *     └── WirelessAutoRegServiceImpl (INTERNAL — real, @Transactional)
 *          └── WirelessAutoRegHelper (INTERNAL — real, @Scope("prototype"), 1190 lines)
 *               ├── MPSYSInternalRestClient (EXTERNAL — mock)
 *               ├── AccountAutoRegDBHelper (EXTERNAL — mock)
 *               ├── WirelessAutoRegQueueHelper (EXTERNAL — mock, JMS)
 *               ├── CGRestClient (EXTERNAL — mock, REST)
 *               ├── FeatureManagerHelper (EXTERNAL — mock)
 *               ├── CSIIAPSoapHandler (EXTERNAL — mock, SOAP)
 *               └── ExternalDestinationHelper (INTERNAL — real, calls SOAP handlers)
 */
class WirelessAutoRegCompTest extends CompTestBase {

    private String uri = '/orchestration/wireless'

    @SpringBean
    AccountAutoRegDBHelper accountAutoRegDBHelper = Mock()

    @SpringBean
    WirelessAutoRegQueueHelper wirelessAutoRegQueueHelper = Mock()

    @SpringBean
    FeatureManagerHelper featureManager = Mock()

    @SpringBean
    CSIIAPSoapHandler csiSoapHandler = Mock()

    @SpringBean
    PlatformTransactionManager transactionManager = Mock()

    private Map<String, String> validHeaders() {
        [
            'Content-Type' : 'application/json',
            'X-ATT-ClientId': 'IDP',
            'idp-trace-id' : 'trace123:trace123:0:0'
        ]
    }

    private String validRequest() {
        '{"firstName":"Att","lastName":"Network","sorId":"13","sorInvariantId":"57378282888","serviceName":"MOBILITY"}'
    }

    // ========== Validation Error Scenarios ==========

    // NOTE: 'missing idp-trace-id' is not testable at CT level — SDK auto-generates trace IDs via CommonUtil.getTraceId()

    def "missing X-ATT-ClientId returns 400"() {
        given:
        Map<String, String> headers = [
            'Content-Type' : 'application/json',
            'idp-trace-id' : 'trace123:trace123:0:0'
        ]

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .body(validRequest())
                .when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then()
                .body('appStatusCode', CoreMatchers.equalTo('100'))
                .body('appInfo', CoreMatchers.containsString('Missing or invalid X-ATT-ClientId'))
    }

    def "invalid sorId returns 400"() {
        given:
        def headers = validHeaders()
        String req = '{"firstName":"Att","lastName":"Network","sorId":"11","sorInvariantId":"57378282888","serviceName":"MOBILITY"}'

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .body(req)
                .when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then()
                .body('appStatusCode', CoreMatchers.equalTo('100'))
                .body('appInfo', CoreMatchers.containsString('Invalid sorId'))
    }

    def "missing sorInvariantId returns 400"() {
        given:
        def headers = validHeaders()
        String req = '{"firstName":"Att","lastName":"Network","sorId":"13","serviceName":"MOBILITY"}'

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .body(req)
                .when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then()
                .body('appStatusCode', CoreMatchers.equalTo('100'))
                .body('appInfo', CoreMatchers.containsString('sorInvariantId is required'))
    }

    def "invalid serviceName returns 400"() {
        given:
        def headers = validHeaders()
        String req = '{"firstName":"Att","lastName":"Network","sorId":"13","sorInvariantId":"57378282888","serviceName":"INVALID"}'

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .body(req)
                .when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then()
                .body('appStatusCode', CoreMatchers.equalTo('100'))
                .body('appInfo', CoreMatchers.containsString('Only MOBILITY service allowed'))
    }

    def "missing firstName lastName and contactEmail returns 400"() {
        given:
        def headers = validHeaders()
        String req = '{"sorId":"13","sorInvariantId":"57378282888","serviceName":"MOBILITY"}'

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .body(req)
                .when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then()
                .body('appStatusCode', CoreMatchers.equalTo('100'))
                .body('appInfo', CoreMatchers.containsString('Either FirstName & LastName Or ContactEmail must be passed'))
    }

    def "invalid isExternalCall returns 400"() {
        given:
        def headers = validHeaders()
        String req = '{"firstName":"Att","lastName":"Network","sorId":"13","sorInvariantId":"57378282888","serviceName":"MOBILITY","isExternalCall":"X"}'

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .body(req)
                .when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then()
                .body('appStatusCode', CoreMatchers.equalTo('100'))
                .body('appInfo', CoreMatchers.containsString('isExternalCall must be one of Y or N'))
    }

    // ========== Success Path ==========
    // TECH_DEBT: MISSING_TEST — success path requires extensive mock setup for WirelessAutoRegHelper (1190 lines)
    // with 7+ external dependencies (MPSYSInternalRestClient for 5+ different calls, CGRestClient, CSIIAPSoapHandler,
    // AccountAutoRegDBHelper, WirelessAutoRegQueueHelper, FeatureManagerHelper, ExternalDestinationHelper dependencies).
    // Need dedicated effort to trace the happy-path through the helper and provide correct mock return values.
}
