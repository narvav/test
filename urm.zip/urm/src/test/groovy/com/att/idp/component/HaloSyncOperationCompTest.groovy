package com.att.idp.component

import com.att.idp.idgraph.extclient.db.service.TworkitemService
import com.att.idp.idgraph.extclient.haloc.model.GetUserResponse
import com.att.idp.idgraph.extclient.haloc.service.HaloCService
import com.att.idp.idgraph.extclient.model.ExtClientResponse

import com.att.idp.idgraphuserregistrationms.client.MPSSyncDestinationSoapHandler
import com.att.idp.idgraphuserregistrationms.helper.ConsolidatedProfileHelper
import com.att.idp.idgraphuserregistrationms.helper.HaloSyncHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetInfoByMaskDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetSlidInfoDBHelper
import com.att.idp.idgraphuserregistrationms.helper.voltage.ProofingEncryptionHelper
import com.att.idp.idgraphuserregistrationms.utils.RILCheckAndEncryptPasswordHelper
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import com.att.mpsys.common.utils.CommonErrorMap

import org.hamcrest.CoreMatchers
import org.spockframework.spring.SpringBean
import org.springframework.transaction.PlatformTransactionManager
import org.springframework.transaction.TransactionStatus

/**
 * Additional component tests to expand coverage of HaloSyncOperation branches:
 *  - Add path with SLID + linked aliases
 *  - Delete path with SLID having aliases (deleteAlias + deleteUser)
 *  - Eligibility failure short-circuit
 *  - HALO password SOR temp password generation
 *  - Alias diff (halo-only -> deleteAlias) & (mps-only -> addUser + addAlias)
 *  - No diffs (skip updateMember/updateServiceList)
 */
class HaloSyncOperationCompTest extends CompTestBase {

    private final String uri = '/userprofile/sync'


    @SpringBean
    PlatformTransactionManager transactionManager = Stub(PlatformTransactionManager) {
        getTransaction(_) >> Stub(TransactionStatus)
    }



    private Map<String,String> headers() {
        [
                'Content-Type':'application/json',
                'X-ATT-ClientId':'IDP',
                'idp-trace-id':'traceid:traceid:0:0'
        ]
    }

    private String req(String userId,String domain='att.net') {
        return '{"userId":"'+userId+'","domain":"'+domain+'","destination":"HALOC","agentId":"ag1"}'
    }

    private GetUserResponse haloAbsent() {
        def r = new GetUserResponse()
        r.appStatusCode = '0'; r.appStatusMsg='SUCCESS'
        return r
    }
    private GetUserResponse haloPresent(String handle,String domain) {
        def r = new GetUserResponse()
        r.handle=handle; r.domain=domain; r.appStatusCode='0'; r.appStatusMsg='SUCCESS'
        return r
    }
    private ExtClientResponse successResp() {
        def e = new ExtClientResponse(); e.appStatusCode='0'; e.appInfo='SUCCESS'; return e
    }

    private HashMap<String,Object> mpsProfile(String handle,String domain, Map services=[:], Map extra=[:]) {
        def p = new HashMap<String,Object>()
        p[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        p[CErrorDefs.COMMON_APP_INFO] = 'SUCCESS'
        p[MPSDefs.DB_MEMBER_NAME] = handle
        p[MPSDefs.DB_DOMAIN_NAME] = domain
        if(services) { p[CommonDefs.SERVICES] = services }
        extra.each { k,v -> p[k]=v }
        return p
    }

    private HashMap<String,Object> aliasLinkedUser(String handle,String domain) {
        [ (MPSDefs.DB_MEMBER_NAME):handle, (MPSDefs.DB_DOMAIN_NAME):domain ] as HashMap<String,Object>
    }

    // S1: SLID add path with aliases -> expect addMember + updateServiceList + alias operations (addAlias)
    def "slid add path with linked aliases triggers addMember and addAlias"() {
        given:
        featureManager.isEnabled(_) >> true
        String handle = 'sliduser'; String domain = CommonDefs.SLID_DUM
        HashMap slidInfo = readJsonFileToMap("mockResponse/SlidInfo.json") as HashMap
        getSlidInfoDBHelper.getSlidInfo(_ as HashMap) >> slidInfo
        // Halo absent
        1 * haloCService.getUser(_ as Object) >> haloAbsent()
        haloCService.addMember(_ as Object) >> successResp()
        haloCService.updateAliasList(_ as Object) >> successResp()
        // Eligibility passes (empty map)
        haloSyncHelper.evaluateEligibility(_,_,_) >> [:]
        // Password selection
        haloSyncHelper.selectPasswordAndType(_ as Map) >> new AbstractMap.SimpleEntry<String,String>('SHA256','PWDHASH')
        haloSyncHelper.putPasswordByType(_ as Map,_ as Map.Entry) >> { Map t, Map.Entry e -> t[CommonDefs.DB_GEN_PASSWORD]=e.value }

        when:
        def resp = givenBaseSpec().headers(headers()).body(req(handle,domain)).post(uri)

        then:
        resp.statusCode() == 200
        resp.body().asString().contains('"appStatusCode":"0"')
    }

    // S2: SLID delete path with halo present + aliases -> expect deleteAlias then deleteUser
    def "slid delete path halo present mps missing executes deleteAlias then deleteUser"() {
        given:
        featureManager.isEnabled(_) >> true
        String handle='slidDel'; String domain=CommonDefs.SLID_DUM
        // MPS not found
        getSlidInfoDBHelper.getSlidInfo(_ as HashMap) >> CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM,'User not found with input access id.')
        // Halo present with aliasList
        def halo = haloPresent(handle,domain)
        halo.setSlidID('slidDel@'+domain)
        halo.aliasList = [ [aliasId:'childA@att.net'], [aliasId:'childB@att.net'] ]
        1 * haloCService.getUser(_ as Object) >> halo
        1 * haloCService.deleteUser(_ as Object) >> successResp()

        when:
        def resp = givenBaseSpec().headers(headers()).body(req(handle,domain)).post(uri)

        then:
        resp.statusCode() == 200
        resp.body().asString().contains('"appStatusCode":"0"')
    }

    // S7: Eligibility failure short-circuits
    def "eligibility failure returns error without further calls"() {
        given:
        featureManager.isEnabled(_) >> true
        HashMap slidInfo = readJsonFileToMap("mockResponse/SlidInfoMid.json") as HashMap
        getInfoByMaskDBHelper.getInfoByMask(_ as HashMap) >> slidInfo
        haloCService.getUser(_ as Object) >> haloAbsent()
        haloSyncHelper.evaluateEligibility(_,_,_) >> CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NOT_ALLOWED_NUM,'SOR not allowed')

        when:
        def resp = givenBaseSpec().headers(headers()).body(req('eliguser','att.net')).post(uri)

        then:
        resp.statusCode() == 400
        resp.body().asString().contains('SOR not allowed')

    }

    // S8: HALO password SOR – temp password generation occurs (add path)
    def "halo password SOR generates temp password on add"() {
        given:
        featureManager.isEnabled(_) >> true
        System.setProperty('HALO_PWD_SOR','Y') // if property resolution used elsewhere
        HashMap slidInfo = readJsonFileToMap("mockResponse/SlidInfoMid.json") as HashMap
        getInfoByMaskDBHelper.getInfoByMask(_ as HashMap) >> slidInfo
        haloCService.getUser(_ as Object) >> haloAbsent()
        haloSyncHelper.evaluateEligibility(_,_,_) >> [:]
        rilPwdHelper.generateTempPasswordDigitsOnly() >> '123456'
        rilPwdHelper.generateGenericPassword('123456','SHA256') >> [ (CommonDefs.DB_GEN_PASSWORD):'GEN_HASH', (CommonDefs.DB_GEN_PASSWORD_TYPE):'SHA256', (CErrorDefs.COMMON_APP_STATUS_CODE):'0']
        haloSyncHelper.handlePasswordGenerationFailure(_ as HashMap) >> false
        haloSyncHelper.selectPasswordAndType(_ as Map) >> new AbstractMap.SimpleEntry<String,String>('SHA256','IGNORED')
        haloSyncHelper.putPasswordByType(_ as Map,_ as Map.Entry) >> { }
        haloCService.addMember(_ as Object) >> successResp()
        haloCService.updateMember(_ as Object) >> successResp()
        haloCService.updateServiceList(_ as Object) >> successResp()
        haloCService.updateAliasList(_ as Object) >> successResp()

        when:
        def resp = givenBaseSpec().headers(headers()).body(req('pwuser','att.net')).post(uri)

        then:
        resp.statusCode() == 200
        resp.body().asString().contains('"appStatusCode":"0"')
    }

    // TECH_DEBT: MISSING_TEST — HaloSyncOperation alias diff path (slid.dum domain)
    // hits 500 due to incomplete mock data in the deep internal flow (1500+ line orchestrator).
    def "alias diff halo only triggers deleteAlias"() {
        given:
        featureManager.isEnabled(_) >> true
        String handle='slidAliasOnly'; String domain=CommonDefs.SLID_DUM
        HashMap slidInfo = readJsonFileToMap("mockResponse/SlidInfo.json") as HashMap
        getSlidInfoDBHelper.getSlidInfo(_ as HashMap) >> slidInfo
        def halo = haloPresent(handle,domain)
        halo.setSlidID(handle+'@'+domain)
        halo.aliasList = [ [aliasId:'orphan@att.net'] ]
        haloCService.getUser(_ as Object) >> halo
        haloSyncHelper.evaluateEligibility(_,_,_) >> [:]
        // Expect deleteAlias + deleteMember not triggered since both present (profile diff maybe none) but alias diff leads to deleteAlias only
        haloCService.updateMember(_ as Object) >> successResp()
        haloCService.updateAliasList(_ as Object) >> successResp()
        haloCService.addMember(_ as Object) >> successResp()
        haloCService.updateServiceList(_ as Object) >> successResp()

        when:
        def resp = givenBaseSpec().headers(headers()).body(req(handle,domain)).post(uri)

        then:
        resp.statusCode()==200
        resp.body().asString().contains('"appStatusCode":"0"')
    }

    // TECH_DEBT: MISSING_TEST — Same root cause as S9 alias diff test.
    def "alias diff mps only triggers addUser and addAlias"() {
        given:
        featureManager.isEnabled(_) >> true
        String handle='slidMpsOnly'; String domain=CommonDefs.SLID_DUM
        HashMap slidInfo = readJsonFileToMap("mockResponse/SlidInfo.json") as HashMap
        getSlidInfoDBHelper.getSlidInfo(_ as HashMap) >> slidInfo
        def halo = haloPresent(handle,domain)
        halo.setSlidID(handle+'@'+domain)
        halo.aliasList = []
        haloCService.getUser(_ as Object) >> halo
        haloSyncHelper.evaluateEligibility(_,_,_) >> [:]
        haloCService.updateMember(_ as Object) >> successResp()
        haloCService.addMember(_ as Object) >> successResp()
        haloCService.updateAliasList(_ as Object) >> successResp()
        haloCService.updateServiceList(_ as Object) >> successResp()

        when:
        def resp = givenBaseSpec().headers(headers()).body(req(handle,domain)).post(uri)

        then:
        resp.statusCode()==200
        resp.body().asString().contains('"appStatusCode":"0"')
    }

    // S12: HaloC error propagated
    def "haloc getUser non-ghost error propagates"() {
        given:
        featureManager.isEnabled(_) >> true
        HashMap slidInfo = readJsonFileToMap("mockResponse/SlidInfoMid.json") as HashMap
        getInfoByMaskDBHelper.getInfoByMask(_ as HashMap) >> slidInfo
        def halo = new GetUserResponse(); halo.appStatusCode='500'; halo.appStatusMsg='HALO_DOWN';halo.appCategoryCode='2';
        haloCService.getUser(_ as Object) >> halo
        haloCService.addMember(_ as Object) >> successResp()
        haloCService.updateAliasList(_ as Object) >> successResp()

        when:
        def resp = givenBaseSpec().headers(headers()).body(req('erruser','att.net')).post(uri)

        then:
        resp.statusCode()==500
    }

    // S13: MPSYS error propagates
    def "mpsys db error propagates"() {
        given:
        featureManager.isEnabled(_) >> true
        def dbErr = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,'DB failure')
        getInfoByMaskDBHelper.getInfoByMask(_ as HashMap) >> dbErr

        when:
        def resp = givenBaseSpec().headers(headers()).body(req('dberr','att.net')).post(uri)

        then:
        resp.statusCode()==500
        resp.body().asString().contains('DB failure')
    }

    // S6: No diffs -> success without updateMember/updateServiceList
    def "no diffs returns success without update calls"() {
        given:
        featureManager.isEnabled(_) >> true
        HashMap slidInfo = readJsonFileToMap("mockResponse/SlidInfoMid.json") as HashMap
        getInfoByMaskDBHelper.getInfoByMask(_ as HashMap) >> slidInfo
        def halo = haloPresent('nodiff','att.net')
        haloCService.getUser(_ as Object) >> halo
        haloSyncHelper.evaluateEligibility(_,_,_) >> [:]
        haloCService.updateMember(_ as Object) >> successResp()
        haloCService.updateServiceList(_ as Object) >> successResp()

        when:
        def resp = givenBaseSpec().headers(headers()).body(req('nodiff','att.net')).post(uri)

        then:
        resp.statusCode()==200
    }
}

