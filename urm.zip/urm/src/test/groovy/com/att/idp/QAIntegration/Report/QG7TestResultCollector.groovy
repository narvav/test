package com.att.idp.QAIntegration.Report

import com.att.idp.QAIntegration.Config.GlobalConfig

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger

class QG7TestResultCollector {

    private static final QG7TestResultCollector INSTANCE = new QG7TestResultCollector()
    static QG7TestResultCollector getInstance() { INSTANCE }

    final AtomicInteger totalTests   = new AtomicInteger(0)
    final AtomicInteger passedTests  = new AtomicInteger(0)
    final AtomicInteger failedTests  = new AtomicInteger(0)
    final AtomicInteger skippedTests = new AtomicInteger(0)

    volatile long startTimeMs = System.currentTimeMillis()
    volatile long endTimeMs   = 0

    final ConcurrentHashMap<String, AtomicInteger> specTotal   = new ConcurrentHashMap<>()
    final ConcurrentHashMap<String, AtomicInteger> specPassed  = new ConcurrentHashMap<>()
    final ConcurrentHashMap<String, AtomicInteger> specFailed  = new ConcurrentHashMap<>()
    final ConcurrentHashMap<String, AtomicInteger> specSkipped = new ConcurrentHashMap<>()

    final ConcurrentLinkedQueue<Map<String, String>> failedFlows = new ConcurrentLinkedQueue<>()
    final ConcurrentLinkedQueue<Map<String, String>> serverErrors = new ConcurrentLinkedQueue<>()

    void recordPass(String specName, String featureName) {
        totalTests.incrementAndGet()
        passedTests.incrementAndGet()
        specTotal.computeIfAbsent(specName ?: "Unknown",  { new AtomicInteger(0) }).incrementAndGet()
        specPassed.computeIfAbsent(specName ?: "Unknown", { new AtomicInteger(0) }).incrementAndGet()
    }

    void recordFail(String specName, String featureName, String errorMessage) {
        totalTests.incrementAndGet()
        failedTests.incrementAndGet()
        specTotal.computeIfAbsent(specName ?: "Unknown",  { new AtomicInteger(0) }).incrementAndGet()
        specFailed.computeIfAbsent(specName ?: "Unknown", { new AtomicInteger(0) }).incrementAndGet()
        failedFlows.add([spec: specName ?: "Unknown", feature: featureName ?: "Unknown", error: truncate(errorMessage ?: "No details", 500)])
    }

    void recordSkip(String specName, String featureName) {
        totalTests.incrementAndGet()
        skippedTests.incrementAndGet()
        specTotal.computeIfAbsent(specName ?: "Unknown",   { new AtomicInteger(0) }).incrementAndGet()
        specSkipped.computeIfAbsent(specName ?: "Unknown", { new AtomicInteger(0) }).incrementAndGet()
    }

    void recordServerError(String specName, String endpoint, int statusCode) {
        serverErrors.add([spec: specName ?: "Unknown", endpoint: endpoint ?: "", status: String.valueOf(statusCode)])
    }

    String getEnvironment() {
        try { return GlobalConfig.getCurrentTestEnv() } catch (Exception ignored) {
            return System.getProperty("INTEGRATION_TEST_ENV", "N/A")
        }
    }

    String getGitHubWorkflow()  { System.getProperty("GH_WORKFLOW")   ?: System.getenv("GITHUB_WORKFLOW")   ?: "Local Run" }
    String getGitHubRunNumber() { System.getProperty("GH_RUN_NUMBER") ?: System.getenv("GITHUB_RUN_NUMBER") ?: "N/A" }
    String getGitHubActor()     { System.getProperty("GH_ACTOR")      ?: System.getenv("GITHUB_ACTOR")      ?: System.getProperty("user.name") ?: "N/A" }

    String getGitHubRunUrl() {
        String url = System.getProperty("GH_RUN_URL") ?: System.getenv("GH_RUN_URL") ?: ""
        if (url) return url
        String server = System.getenv("GITHUB_SERVER_URL") ?: "https://github.com"
        String repo   = System.getProperty("GH_REPO") ?: System.getenv("GITHUB_REPOSITORY") ?: ""
        String runId  = System.getenv("GITHUB_RUN_ID") ?: ""
        return (repo && runId) ? "${server}/${repo}/actions/runs/${runId}" : ""
    }

    double getPassRate() {
        int total = totalTests.get()
        return total > 0 ? (passedTests.get() * 100.0 / total) : 0.0
    }

    String getDuration() {
        long ms   = (endTimeMs > 0 ? endTimeMs : System.currentTimeMillis()) - startTimeMs
        long secs = (ms / 1000) as long
        long mins = secs / 60
        secs = secs % 60
        return mins > 0 ? "${mins}m ${secs}s" : "${secs}s"
    }

    List<Map<String, Object>> getServerErrorsByEndpoint() {
        Map<String, Integer> counts = [:]
        serverErrors.each { Map<String, String> e ->
            String ep = e.endpoint ?: "Unknown"
            try { URI uri = new URI(ep); ep = uri.path ?: ep } catch (ignored) {}
            counts[ep] = (counts[ep] ?: 0) + 1
        }
        return counts.collect { k, v -> [endpoint: k, count: v] }.sort { -(it.count as int) }
    }

    void reset() {
        totalTests.set(0); passedTests.set(0); failedTests.set(0); skippedTests.set(0)
        failedFlows.clear(); serverErrors.clear()
        specTotal.clear(); specPassed.clear(); specFailed.clear(); specSkipped.clear()
        startTimeMs = System.currentTimeMillis(); endTimeMs = 0
    }

    private static String truncate(String s, int max) {
        (s != null && s.length() > max) ? s.substring(0, max) + "…" : (s ?: "")
    }
}
