package com.att.idp.idgraphuserregistrationms.resource.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.request.validator.AutoGenTempAIDRequestValidator
import com.att.idp.idgraphuserregistrationms.request.validator.PreAccountRegRequestValidator
import com.att.idp.idgraphuserregistrationms.resource.request.AutoGenTempAIDRequest
import com.att.idp.idgraphuserregistrationms.resource.request.PreAccountRegRequest
import com.att.idp.idgraphuserregistrationms.resource.response.AutoGenTempAIDResponse
import com.att.idp.idgraphuserregistrationms.resource.response.PreAccountRegResponse
import com.att.idp.idgraphuserregistrationms.service.AutoGenTempAIDService
import com.att.idp.idgraphuserregistrationms.service.PreAccountRegService
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.Response
import java.sql.SQLException

class AutoRegResourceImplTest extends Specification {
	
	def autoRegResourceImpl=new AutoRegResourceImpl()

	HttpHeaders httpHeaders = Mock(HttpHeaders) as HttpHeaders

	AutoGenTempAIDRequestValidator autoGenTempAIDRequestValidator=Mock(AutoGenTempAIDRequestValidator)

	AutoGenTempAIDService autoGenTempAIDService=Mock(AutoGenTempAIDService)

	PreAccountRegRequestValidator preAccountRegRequestValidator=Mock(PreAccountRegRequestValidator)

	PreAccountRegService preAccountRegService=Mock(PreAccountRegService)
	
	def setup() {
		autoRegResourceImpl.autoGenTempAIDServiceObj = autoGenTempAIDService
		autoRegResourceImpl.autoGenTempAIDRequestvalidatorObj = autoGenTempAIDRequestValidator
		
		autoRegResourceImpl.preAccountRegServiceObj = preAccountRegService
		autoRegResourceImpl.preAccountRegRequestvalidatorObj = preAccountRegRequestValidator
	}


	def "test auto gen temp a i d error"() throws Exception {
		
		// error from request validator
		given:
		AutoGenTempAIDResponse autoGenTempAIDResponse = new AutoGenTempAIDResponse()
		autoGenTempAIDResponse.appCategoryCode = '2'
		autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(_ as HttpHeaders, _ as AutoGenTempAIDRequest)>>autoGenTempAIDResponse
		when:
		Response response = autoRegResourceImpl.autogenTempAccessId(new AutoGenTempAIDRequest(), httpHeaders)
		then:
		response.status == 500

		// error from service
		when:
		autoGenTempAIDResponse.appCategoryCode = '3'
		response = autoRegResourceImpl.autogenTempAccessId(new AutoGenTempAIDRequest(), httpHeaders)
		then:
		response.status == 400
	}


	def "test auto gen temp a i d success"() throws Exception {
		
		// error from request validator
		given:
		AutoGenTempAIDResponse autoGenTempAIDResponse = new AutoGenTempAIDResponse()
		autoGenTempAIDResponse.appCategoryCode = '0'
		autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(_ as HttpHeaders, _ as AutoGenTempAIDRequest)>>null
		autoGenTempAIDService.autoGenTempAID(_ as AutoGenTempAIDRequest, _)>>autoGenTempAIDResponse
		when:
		Response response = autoRegResourceImpl.autogenTempAccessId(new AutoGenTempAIDRequest(), httpHeaders)
		then:
		response.status == 200
	}


	def "test auto gen temp a i d data exception"() throws Exception {

		given:
		InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
		when:autoGenTempAIDService.autoGenTempAID(_ as AutoGenTempAIDRequest, _) >> { throw ex }
		autoRegResourceImpl.autogenTempAccessId(new AutoGenTempAIDRequest(), httpHeaders)
        then:
        thrown(InvalidInputDataException.class)

	}


	def "test auto gen temp a i d exception"() throws Exception {

		given:
		NullPointerException ex = new NullPointerException('NullPointerException thrown')
		when:autoGenTempAIDService.autoGenTempAID(_ as AutoGenTempAIDRequest, _) >> { throw ex }
		Response response = autoRegResourceImpl.autogenTempAccessId(new AutoGenTempAIDRequest(), httpHeaders)
        then:
		response.status == 500
	}


	def "test pre account reg error"() throws Exception {
		
		// error from request validator
		given:
		PreAccountRegResponse preAccountRegResponse = new PreAccountRegResponse()
		preAccountRegResponse.appCategoryCode = '2'
		preAccountRegRequestValidator.preAccountRegRequestValidator(_ as HttpHeaders, _ as PreAccountRegRequest) >> preAccountRegResponse
		when:
		Response response = autoRegResourceImpl.preAccountReg(new PreAccountRegRequest(), httpHeaders)
		then:
		response.status == 500

		// error from service
		when:
		preAccountRegResponse.appCategoryCode = '3'
		response = autoRegResourceImpl.preAccountReg(new PreAccountRegRequest(), httpHeaders)
		then:
		response.status == 400
	}


	def "test pre account reg success"() throws Exception {
		
		// error from request validator
		given:
		PreAccountRegResponse preAccountRegResponse = new PreAccountRegResponse()
		preAccountRegResponse.appCategoryCode = '0'
		preAccountRegRequestValidator.preAccountRegRequestValidator(_ as HttpHeaders, _ as PreAccountRegRequest) >> null
		preAccountRegService.preAccountReg(_ as PreAccountRegRequest, _) >> preAccountRegResponse
		when:
		Response response = autoRegResourceImpl.preAccountReg(new PreAccountRegRequest(), httpHeaders)
		then:
		response.status == 200
	}


	def "test pre account reg data exception"() throws Exception {

		given:
		InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
		when:preAccountRegService.preAccountReg(_ as PreAccountRegRequest, _) >> { throw ex }
		autoRegResourceImpl.preAccountReg(new PreAccountRegRequest(), httpHeaders)
        then:
        thrown(InvalidInputDataException.class)

	}


	def "test pre account reg exception"() throws Exception {

		given:
		NullPointerException ex = new NullPointerException('NullPointerException thrown')
		when:preAccountRegService.preAccountReg(_ as PreAccountRegRequest, _) >> { throw ex }
		Response response = autoRegResourceImpl.preAccountReg(new PreAccountRegRequest(), httpHeaders)
		then:
        response.status == 500
	}
	def "test pre account reg sql exception"() throws Exception {

		given:
		SQLException ex = new SQLException('SQLException thrown')
		when:preAccountRegService.preAccountReg(_ as PreAccountRegRequest, _) >> { throw ex }
		Response response = autoRegResourceImpl.preAccountReg(new PreAccountRegRequest(), httpHeaders)
		then:
		response.status == 500
	}
}
