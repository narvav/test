package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.helper.SyncCGHelper
import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.idp.idgraphuserregistrationms.resource.response.SyncUserProfileResponse
import com.att.mpsys.common.utils.CommonDefs
import jakarta.ws.rs.core.HttpHeaders
import spock.lang.Specification
import spock.lang.Unroll

class SyncCGServiceImplTest extends Specification {

    SyncCGHelper syncCGHelper
    SyncCGServiceImpl serviceUnderTest
    HttpHeaders headers = Mock(HttpHeaders)

    def setup() {
        syncCGHelper = Mock(SyncCGHelper)
        serviceUnderTest = new SyncCGServiceImpl(syncCGHelper)
    }

    @Unroll
    def "should return success response for CG sync for #scenarioName"() {
        given: "A valid CG request with ban and helper success map"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setIdpTraceId(idpTraceId)
        request.setTransactionName(transactionName)
        request.setBan(ban)
        request.setCallingSystemId(callingSystemId)
        request.setSyncCGTables(["subscriberinfo", "subscriberprofile"])

        Map<String, Object> helperResponse = new HashMap<>()
        helperResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        helperResponse.put(CommonDefs.COMMON_APP_INFO, appInfo)

        when: "syncCG is invoked"
        SyncUserProfileResponse result = serviceUnderTest.syncCG(request, headers)

        then: "Helper is called with ban and callingSystemId and no other interactions"
        1 * syncCGHelper.syncCGByBan(ban, syncCgTables,callingSystemId) >> helperResponse
        0 * _

        and: "Result contains expected response attributes"
        result != null
        result.getTransactionName() == transactionName
        result.getAppStatusCode() == CommonDefs.COMMON_SUCCESS
        result.getAppInfo() == appInfo
        result.getIdpTraceId() == idpTraceId

        where: "Different successful scenarios"
        scenarioName    | idpTraceId   | transactionName | ban      |syncCgTables | callingSystemId | appInfo
        "standard CG"   | "trace-123" | "SyncCG"        | "123456" | ["subscriberinfo", "subscriberprofile"]  | "SYSTEM-A"      | "Success"
        "another CG"    | "trace-456" | "SyncCG"        | "789012" |  ["subscriberinfo", "subscriberprofile"] | "SYSTEM-B"      | "Updated"
        "long ban"      | "trace-789" | "SyncCG"        | "999999" | ["subscriberinfo", "subscriberprofile"]  | "SYSTEM-C"      | "Synced"
    }

    def "should throw InvalidInputDataException when helper indicates transaction rollback for CG"() {
        given: "A CG request and helper response with rollback flag"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setIdpTraceId("trace-err")
        request.setTransactionName("SyncCG")
        request.setBan("123456")
        request.setCallingSystemId("SYSTEM-C")
        request.setSyncCGTables(["subscriberinfo", "subscriberprofile"])

        Map<String, Object> helperResponse = new HashMap<>()
        helperResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, "0")
        helperResponse.put(CommonDefs.COMMON_APP_INFO, "DB error")
        helperResponse.put("isTransactionRollback", "Y")

        when: "syncCG is invoked"
        serviceUnderTest.syncCG(request, headers)

        then: "Helper called and exception thrown"
        1 * syncCGHelper.syncCGByBan("123456",["subscriberinfo", "subscriberprofile"], "SYSTEM-C") >> helperResponse
        0 * _

        and: "Exception details are propagated"
        InvalidInputDataException ex = thrown()
    }

    def "should handle response without rollback flag and return response"() {
        given: "A CG request and helper response without rollback flag"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setIdpTraceId("trace-no-rollback")
        request.setTransactionName("SyncCG")
        request.setBan("555555")
        request.setCallingSystemId("SYSTEM-D")
        request.setSyncCGTables(["componentid", "componentprofile", "userid"])

        Map<String, Object> helperResponse = new HashMap<>()
        helperResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        helperResponse.put(CommonDefs.COMMON_APP_INFO, "No rollback")

        when: "syncCG is invoked"
        SyncUserProfileResponse result = serviceUnderTest.syncCG(request, headers)

        then: "Helper called with exact parameters"
        1 * syncCGHelper.syncCGByBan("555555",  ["componentid", "componentprofile", "userid"] ,"SYSTEM-D") >> helperResponse
        0 * _

        and: "Result is returned without exception"
        result != null
        result.getIdpTraceId() == "trace-no-rollback"
        result.getTransactionName() == "SyncCG"
    }

    @Unroll
    def "should preserve trace id and transaction name for #scenarioName"() {
        given: "A CG request with specific trace id and transaction name"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setIdpTraceId(expectedTraceId)
        request.setTransactionName(expectedTransactionName)
        request.setBan("111111")
        request.setCallingSystemId("SYSTEM-E")
        request.setSyncCGTables(["subscriberinfo", "subscriberprofile"])

        Map<String, Object> helperResponse = new HashMap<>()
        helperResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        helperResponse.put(CommonDefs.COMMON_APP_INFO, "Info")

        when: "syncCG is invoked"
        SyncUserProfileResponse result = serviceUnderTest.syncCG(request, headers)

        then: "Helper is called"
        1 * syncCGHelper.syncCGByBan("111111", ["subscriberinfo", "subscriberprofile"],"SYSTEM-E") >> helperResponse
        0 * _

        and: "Trace id and transaction name are preserved in response"
        result != null
        result.getIdpTraceId() == expectedTraceId
        result.getTransactionName() == expectedTransactionName

        where: "Different trace and transaction scenarios"
        scenarioName              | expectedTraceId        | expectedTransactionName
        "standard values"         | "trace-abc-123"        | "SyncCG"
        "long trace id"           | "trace-very-long-id"   | "SyncCG"
        "special chars in trace"  | "trace-!@#-id"         | "SyncCG"
    }
}
