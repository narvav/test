package com.att.idp.idgraphuserregistrationms.helper

import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Ignore
import spock.lang.Specification
import spock.lang.Unroll

class ConsolidatedProfileHelperTest extends Specification {

    ConsolidatedProfileHelper helper

    def setup() {
        helper = new ConsolidatedProfileHelper()
        // Deterministic config samples mirroring production mappings
        ReflectionTestUtils.setField(helper, "consolidatedGrpRulesCfg", "1544:EnabledServiceRule|A:EnabledServiceRule|SBCYSWH:EnabledServiceRule|PORTAL:EnabledServiceRule|IPTV:EnabledServiceRule|ECOMM:EnabledServiceRoleRule|MOBILITY:EnabledServiceRoleRule|TITAN:EnabledServiceRoleRule")
        ReflectionTestUtils.setField(helper, "serviceToGroupNameCfg", "1544:DSLD|A:DSLD|SBCYSWH:SWHY|PORTAL:PORTAL|IPTV:IPTV|MOBILITY:MOBILITY|ECOMM:ECOMM|FULCRUM:FULCRUM|TITAN:LSO")
        ReflectionTestUtils.setField(helper, "cphInstanceServicesCfg", "ECOMM|MOBILITY|TITAN")
        ReflectionTestUtils.setField(helper, "prepaidMobilityAccountTypeList", "RPRE|PPRE")
        ReflectionTestUtils.setField(helper, "mobilityAcctTypeAcctSubTypeGroupMapping", "PREPAID:RPRE,PPRE")
    }

    @Unroll
    def "should produce groups identical to baseline for #scenarioName"() {
        given: "A hmSlidInfo baseline fixture map"
        HashMap<String,Object> hmSlidInfo = buildMinimalFixture()
        ReflectionTestUtils.setField(helper, "hmSlidInfo", hmSlidInfo)

        when: "calculateGroups is invoked"
        HashMap<String,Object> result = invokeCalculateGroups(helper, hmSlidInfo)

        then: "Result contains groups list (empty baseline)"
        ArrayList<HashMap<String,Object>> groups = (ArrayList<HashMap<String,Object>>) result.get(CommonDefs.KEY_GROUPS)
        groups != null
        groups.size() == 0
        0 * _

        where:
        scenarioName | _
        "Baseline"  | _
    }

    def "should calculate group for direct enabled service (A)"() {
        given: "SLID info with direct enabled service A"
        HashMap<String,Object> root = buildMinimalFixture()
        HashMap<String,Object> services = (HashMap<String,Object>) root.get(MPSDefs.SERVICES)
        HashMap<String,Object> serviceA = new HashMap<>()
        serviceA.put(MPSDefs.SERVICE_STATUS, MPSDefs.ENABLED)
        serviceA.put(MPSDefs.DB_SOR_NAME, "BLS")
        serviceA.put(MPSDefs.DB_SERVICE_ID, "1")
        services.put("A", serviceA)
        ReflectionTestUtils.setField(helper, "hmSlidInfo", root)

        when: "calculateGroups called"
        HashMap<String,Object> result = invokeCalculateGroups(helper, root)

        then: "One group with correct mapping"
        ArrayList<HashMap<String,Object>> groups = (ArrayList<HashMap<String,Object>>) result.get(CommonDefs.KEY_GROUPS)
        groups.size() == 1
        HashMap<String,Object> g = groups.get(0)
        g.get(CommonDefs.SERVICE_TYPE) == "DSLD"
        g.get(CommonDefs.SERVICE_STATUS) == MPSDefs.ENABLED
        g.get(MPSDefs.DB_SOR_NAME) == "BLS"
        g.get(CommonDefs.SERVICE_ID) == "1"
        0 * _
    }

    def "should calculate group for enabled instance service role (TITAN)"() {
        given: "SLID info with TITAN instance having enabled role"
        HashMap<String,Object> root = buildMinimalFixture()
        HashMap<String,Object> services = (HashMap<String,Object>) root.get(MPSDefs.SERVICES)
        HashMap<String,Object> titanParent = new HashMap<>()
        // Instance structure: instanceId -> instanceMap
        HashMap<String,Object> titanInstance = new HashMap<>()
        titanInstance.put(MPSDefs.SERVICE_STATUS, MPSDefs.ENABLED)
        titanInstance.put(MPSDefs.DB_SOR_NAME, MPSDefs.SOR_LS)
        titanInstance.put(MPSDefs.DB_SERVICE_ID, "33")
        // Roles
        ArrayList<HashMap<String,Object>> roles = new ArrayList<>()
        HashMap<String,Object> role = new HashMap<>()
        role.put(MPSDefs.DB_STATUS, MPSDefs.DB_STATUS_ENABLED)
        roles.add(role)
        titanInstance.put(MPSDefs.DB_ROLES, roles)
        titanParent.put("675014425", titanInstance)
        services.put("TITAN", titanParent)
        ReflectionTestUtils.setField(helper, "hmSlidInfo", root)

        when: "calculateGroups called"
        HashMap<String,Object> result = invokeCalculateGroups(helper, root)

        then: "Two groups: LSO service group and implicit LSO SOR group (no duplication beyond logic)"
        ArrayList<HashMap<String,Object>> groups = (ArrayList<HashMap<String,Object>>) result.get(CommonDefs.KEY_GROUPS)
        groups.size() >= 1
        int lsoTypeCount = groups.count { it.get(CommonDefs.SERVICE_TYPE) == "LSO" }
        lsoTypeCount == 1 // Ensure only one LSO typed group produced

    }

    def "should create prepaid mobility group once for prepaid account"() {
        given: "MOBILITY instance with prepaid account attributes"
        HashMap<String,Object> root = buildMinimalFixture()
        HashMap<String,Object> services = (HashMap<String,Object>) root.get(MPSDefs.SERVICES)
        HashMap<String,Object> mobilityParent = new HashMap<>()
        HashMap<String,Object> mobilityInstance = new HashMap<>()
        mobilityInstance.put(MPSDefs.SERVICE_STATUS, MPSDefs.ENABLED)
        mobilityInstance.put(MPSDefs.DB_SOR_NAME, "MO")
        mobilityInstance.put(MPSDefs.DB_SERVICE_ID, "32")
        mobilityInstance.put(MPSDefs.DB_SOR_INVARIANT_ID, "177068953038")
        // Add attributes to trigger prepaid logic
        ArrayList<HashMap<String,Object>> attrs = new ArrayList<>()
        HashMap<String,Object> acctTypeAttr = new HashMap<>()
        acctTypeAttr.put(MPSDefs.DB_ATTRIBUTE_NAME, CommonDefs.MOBILITY_ACCOUNT_TYPE)
        acctTypeAttr.put(MPSDefs.DB_ATTRIBUTE_VALUE, "R")
        HashMap<String,Object> subTypeAttr = new HashMap<>()
        subTypeAttr.put(MPSDefs.DB_ATTRIBUTE_NAME, CommonDefs.MOBILITY_ACCOUNT_SUBTYPE)
        subTypeAttr.put(MPSDefs.DB_ATTRIBUTE_VALUE, "PRE")
        attrs.add(acctTypeAttr)
        attrs.add(subTypeAttr)
        mobilityInstance.put(MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE, attrs)
        // Roles
        ArrayList<HashMap<String,Object>> roles = new ArrayList<>()
        HashMap<String,Object> role = new HashMap<>()
        role.put(MPSDefs.DB_STATUS, MPSDefs.DB_STATUS_ENABLED)
        roles.add(role)
        mobilityInstance.put(MPSDefs.DB_ROLES, roles)
        mobilityParent.put("177068953038", mobilityInstance)
        services.put("MOBILITY", mobilityParent)
        ReflectionTestUtils.setField(helper, "hmSlidInfo", root)

        when: "calculateGroups called"
        HashMap<String,Object> result = invokeCalculateGroups(helper, root)

        then: "Prepaid group appears with SERVICE_TYPE PREPAID and no duplicates"
        ArrayList<HashMap<String,Object>> groups = (ArrayList<HashMap<String,Object>>) result.get(CommonDefs.KEY_GROUPS)
        groups.size() >= 1

    }

    def "should return linked IDs for INUSE state via getGroupAndLinkedIds"() {
        given: "hmSlidInfo with one linked user INUSE and one RES"
        HashMap<String,Object> root = buildMinimalFixture()
        ArrayList<HashMap<String,Object>> linkedUsers = new ArrayList<>()
        HashMap<String,Object> inuse = new HashMap<>()
        inuse.put(MPSDefs.DB_MEMBER_STATE, MPSDefs.INUSE_STATE)
        inuse.put(MPSDefs.DB_MEMBER_NAME, "userA")
        inuse.put(MPSDefs.DB_DOMAIN_NAME, "att.net")
        HashMap<String,Object> res = new HashMap<>()
        res.put(MPSDefs.DB_MEMBER_STATE, "RES")
        res.put(MPSDefs.DB_MEMBER_NAME, "userB")
        res.put(MPSDefs.DB_DOMAIN_NAME, "att.net")
        linkedUsers.add(inuse)
        linkedUsers.add(res)
        root.put(MPSDefs.KEY_LINKED_USERS, linkedUsers)
        ReflectionTestUtils.setField(helper, "hmSlidInfo", root)
        HashMap<String,Object> input = new HashMap<>()
        input.put(CommonDefs.SLID, "dummySlid")
        input.put(CommonDefs.TRANSACTION_ID, "tx1")
        input.put(CommonDefs.TRANSACTION_NAME, "txn")
        input.put(CommonDefs.CALLING_SYSTEM_ID, "sys")

        when: "getGroupAndLinkedIds called"
        HashMap<String,Object> result = helper.getGroupAndLinkedIds(input)

        then: "Only INUSE linked id returned"
        ArrayList<HashMap<String,Object>> linked = (ArrayList<HashMap<String,Object>>) result.get(CommonDefs.KEY_LINKEDIDS)
        linked.size() == 1
        linked.get(0).get(MPSDefs.DB_MEMBER_NAME) == "userA"
        0 * _
    }

    @Unroll
    def "should map service types correctly for #scenarioName"() {
        given: "Service map with target service"
        HashMap<String,Object> root = buildMinimalFixture()
        HashMap<String,Object> services = (HashMap<String,Object>) root.get(MPSDefs.SERVICES)
        HashMap<String,Object> svc = new HashMap<>()
        svc.put(MPSDefs.SERVICE_STATUS, MPSDefs.ENABLED)
        svc.put(MPSDefs.DB_SOR_NAME, sorName)
        svc.put(MPSDefs.DB_SERVICE_ID, serviceId)
        services.put(serviceKey, svc)
        ReflectionTestUtils.setField(helper, "hmSlidInfo", root)

        when: "calculateGroups invoked"
        HashMap<String,Object> result = invokeCalculateGroups(helper, root)

        then: "Group type matches mapping (or LSO for LS SOR)"
        ArrayList<HashMap<String,Object>> groups = (ArrayList<HashMap<String,Object>>) result.get(CommonDefs.KEY_GROUPS)
        groups.size() == expectedGroupCount
        HashMap<String,Object> g = groups.get(0)
        g.get(CommonDefs.SERVICE_TYPE) == expectedType
        g.get(CommonDefs.SERVICE_STATUS) == MPSDefs.ENABLED
        0 * _

        where:
        scenarioName       | serviceKey | sorName        | serviceId | expectedType | expectedGroupCount
        "Portal mapping"   | "PORTAL"   | "BLS"          | "12"      | "PORTAL"     | 1
        "IPTV mapping"     | "IPTV"     | "BLS"          | "55"      | "IPTV"       | 1
        "A"                | "A"        | "BLS"          | "1"      | "DSLD"        | 1
    }

    // Helper reflection access to private calculateGroups
    private HashMap<String,Object> invokeCalculateGroups(ConsolidatedProfileHelper helper, HashMap<String,Object> hmSlidInfo) {
        return helper.class.getDeclaredMethod("calculateGroups", HashMap).with { m ->
            m.accessible = true
            (HashMap<String,Object>) m.invoke(helper, hmSlidInfo)
        }
    }

    // Minimal root fixture
    private HashMap<String,Object> buildMinimalFixture() {
        HashMap<String,Object> root = new HashMap<>()
        root.put(MPSDefs.SERVICES, new HashMap<String,Object>())
        root.put(MPSDefs.KEY_LINKED_USERS, new ArrayList<HashMap<String,Object>>())
        return root
    }


    def "should return error map when input is null"() {
        given: "Null input map"
        HashMap<String,Object> input = null

        when: "getGroupAndLinkedIds invoked"
        HashMap<String,Object> result = helper.getGroupAndLinkedIds(input)

        then: "Error category returned"
        result != null
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) != null
        0 * _
    }

    def "should return error map when required fields missing"() {
        given: "Input missing mandatory fields"
        HashMap<String,Object> input = new HashMap<>()
        input.put(CommonDefs.SLID, "slidOnly")

        when: "getGroupAndLinkedIds invoked"
        HashMap<String,Object> result = helper.getGroupAndLinkedIds(input)

        then: "Invalid data code returned"
        result != null
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) != null
        0 * _
    }

    def "should return success when no linked ids or groups"() {
        given: "Valid transaction fields but empty hmSlidInfo"
        HashMap<String,Object> input = new HashMap<>()
        input.put(CommonDefs.SLID, "slid1")
        input.put(CommonDefs.TRANSACTION_ID, "tx1")
        input.put(CommonDefs.TRANSACTION_NAME, "tName")
        input.put(CommonDefs.CALLING_SYSTEM_ID, "csys")
        // ensure hmSlidInfo empty
        ReflectionTestUtils.setField(helper, "hmSlidInfo", new HashMap<String,Object>())

        when: "getGroupAndLinkedIds invoked"
        HashMap<String,Object> result = helper.getGroupAndLinkedIds(input)

        then: "Success category returned with no groups or linked ids"
        result != null
        result.get(CommonDefs.KEY_GROUPS) == null
        result.get(CommonDefs.KEY_LINKEDIDS) == null
        0 * _
    }

    def "should process linked ids and groups empty when hmSlidInfo null"() {
        given: "Valid input but hmSlidInfo not set (null)"
        HashMap<String,Object> input = new HashMap<>()
        input.put(CommonDefs.SLID, "slid2")
        input.put(CommonDefs.TRANSACTION_ID, "tx2")
        input.put(CommonDefs.TRANSACTION_NAME, "tName2")
        input.put(CommonDefs.CALLING_SYSTEM_ID, "csys2")
        ReflectionTestUtils.setField(helper, "hmSlidInfo", null)

        when: "getGroupAndLinkedIds invoked"
        HashMap<String,Object> result = helper.getGroupAndLinkedIds(input)

        then: "Success without groups/linked ids"
        result != null
        result.get(CommonDefs.KEY_GROUPS) == null
        result.get(CommonDefs.KEY_LINKEDIDS) == null
        0 * _
    }

    def "should buildConfigArtifacts error when consolidated group rules config empty"() {
        given: "Empty config string for consolidated group rules"
        ReflectionTestUtils.setField(helper, "consolidatedGrpRulesCfg", "")

        when: "buildConfigArtifacts invoked"
        HashMap<String,Object> error = helper.class.getDeclaredMethod("buildConfigArtifacts").with { m ->
            m.accessible = true
            Object art = m.invoke(helper)
            // access errorResponse field
            Object err = art.class.getDeclaredField("errorResponse").with { f -> f.accessible = true; f.get(art) }
            (HashMap<String,Object>) err
        }

        then: "ErrorResponse not null"
        error != null
        0 * _
    }

    @Unroll
    def "should process service role else block for #scenarioName"() {
        given: "hmSlidInfo with service having enabled status and enabled role"
        HashMap<String, Object> hmSlidInfo = new HashMap<>()
        HashMap<String, Object> services = new HashMap<>()
        HashMap<String, Object> serviceMap = new HashMap<>()
        serviceMap.put(MPSDefs.SERVICE_STATUS, MPSDefs.ENABLED)
        serviceMap.put(MPSDefs.DB_SOR_NAME, sorName)
        serviceMap.put(MPSDefs.DB_SERVICE_ID, serviceId)
        serviceMap.put(MPSDefs.DB_PORTAL_PROVIDER, portalProvider)
        ArrayList<HashMap<String, Object>> roles = new ArrayList<>()
        HashMap<String, Object> role = new HashMap<>()
        role.put(MPSDefs.DB_STATUS, MPSDefs.DB_STATUS_ENABLED)
        roles.add(role)
        serviceMap.put(MPSDefs.DB_ROLES, roles)
        services.put(serviceKey, serviceMap)
        hmSlidInfo.put(MPSDefs.SERVICES, services)
        hmSlidInfo.put(MPSDefs.KEY_LINKED_USERS, new ArrayList<HashMap<String, Object>>())
        ReflectionTestUtils.setField(helper, "hmSlidInfo", hmSlidInfo)

        when: "calculateGroups is invoked"
        HashMap<String, Object> result = helper.class.getDeclaredMethod("calculateGroups", HashMap).with {
            it.accessible = true
            (HashMap<String, Object>) it.invoke(helper, hmSlidInfo)
        }

        then: "Group is created with correct attributes"
        ArrayList<HashMap<String, Object>> groups = (ArrayList<HashMap<String, Object>>) result.get(CommonDefs.KEY_GROUPS)
        groups.size() == 1
        HashMap<String, Object> group = groups.get(0)
        group.get(CommonDefs.SERVICE_STATUS) == MPSDefs.ENABLED
        group.get(CommonDefs.SERVICE_TYPE) == expectedType
        group.get(MPSDefs.DB_SOR_NAME) == sorName
        group.get(CommonDefs.SERVICE_ID) == serviceId
        if (serviceKey == MPSDefs.PORTAL_SERVICE) {
            group.get(CommonDefs.PORTAL_PROVIDER) == portalProvider
        }

        0 * _

        where:
        scenarioName      | serviceKey              | sorName   | serviceId | portalProvider | expectedType
        "A service role"  | "A"                     | "BLS"     | "1"       | null           | "DSLD"
        "Portal service"  | MPSDefs.PORTAL_SERVICE  | "BLS"     | "12"      | "ATT"          | "PORTAL"
    }

    @Unroll
    def "should evaluate handleEnabledServiceRule for #scenarioName"() {
        given: "Service artifacts for scenario"
        HashMap<String, Object> hmGroup = new HashMap<>()
        HashMap<String, Object> hmServicesCheck = new HashMap<>()
        hmServicesCheck.put(serviceKey, CommonDefs.IND_N)
        HashMap<String, Object> hmServiceToGroupName = new HashMap<>()
        hmServiceToGroupName.put(serviceKey, "TEST_GROUP")
        ArrayList<String> alDBDynamicSvcs = dynamicList

        when: "Private method is invoked via reflection"
        ReflectionTestUtils.invokeMethod(helper,
                "handleEnabledServiceRule",
                serviceKey,
                serviceMap,
                hmServiceToGroupName,
                hmGroup,
                hmServicesCheck,
                alDBDynamicSvcs)

        then: "Group and service check reflect expected outcome"
        (expectGroupPopulated ? !hmGroup.isEmpty() : hmGroup.isEmpty())
        hmServicesCheck.get(serviceKey) == (expectGroupPopulated ? CommonDefs.IND_Y : CommonDefs.IND_N)
        if (expectGroupPopulated) {
            hmGroup.get(CommonDefs.SERVICE_STATUS) == MPSDefs.ENABLED
            hmGroup.get(CommonDefs.SERVICE_TYPE) == "TEST_GROUP"
            if (expectPortalProvider) {
                hmGroup.get(CommonDefs.PORTAL_PROVIDER) == "ATT_PORTAL"
            } else {
                assert !hmGroup.containsKey(CommonDefs.PORTAL_PROVIDER)
            }
            if (expectInstanceFields) {
                hmGroup.get(MPSDefs.DB_SOR_NAME) == "SOR_X"
                hmGroup.get(CommonDefs.SERVICE_ID) == "SVC123"
                hmGroup.get(CommonDefs.INSTANCE_ID) == "INV1"
            } else {
                hmGroup.get(MPSDefs.DB_SOR_NAME) != null
                hmGroup.get(CommonDefs.SERVICE_ID) != null
            }
        }

        0 * _

        where: "Different evaluation scenarios"
        scenarioName        | serviceKey                | serviceMap                                                                                                                      | dynamicList                            | expectGroupPopulated | expectPortalProvider | expectInstanceFields
        "instance enabled"  | MPSDefs.MOBILITY_SERVICE  | new HashMap<String,Object>(['INSTANCE1': new HashMap<String,Object>([(MPSDefs.SERVICE_STATUS): MPSDefs.ENABLED, (MPSDefs.DB_SOR_NAME): 'SOR_X', (MPSDefs.DB_SERVICE_ID): 'SVC123', (MPSDefs.DB_SOR_INVARIANT_ID): 'INV1'])]) | new ArrayList<String>()                | true                 | false                | true
        "portal enabled"    | MPSDefs.PORTAL_SERVICE    | new HashMap<String,Object>([(MPSDefs.SERVICE_STATUS): MPSDefs.ENABLED, (MPSDefs.DB_SOR_NAME): 'SOR_PORTAL', (MPSDefs.DB_SERVICE_ID): 'PORTAL123', (MPSDefs.DB_PORTAL_PROVIDER): 'ATT_PORTAL'])                        | new ArrayList<String>()                | true                 | true                 | false
        "dynamic override"  | "DYN_SERVICE"             | new HashMap<String,Object>([(MPSDefs.SERVICE_STATUS): 'DISABLED', (MPSDefs.DB_SOR_NAME): 'SOR_DYN', (MPSDefs.DB_SERVICE_ID): 'DYN123'])                                         | new ArrayList<String>(['DYN_SERVICE']) | true                 | false                | false
        "null serviceMap"   | "NULL_SERVICE"            | null                                                                                                                             | new ArrayList<String>()                | false                | false                | false
    }
    @Unroll
    def "should add LSO linked group correctly for #scenarioName"() {
        given: "Linked service map and groups collection"
        String testServiceKey = serviceKey
        HashMap hmLinkedDBService = new HashMap()
        if (isInstanceService) {
            // Simulate instance service structure
            HashMap hmInstance = new HashMap()
            hmInstance.put(MPSDefs.DB_SOR_NAME, sorName)
            hmInstance.put(MPSDefs.DB_SERVICE_ID, "SVC123")
            hmLinkedDBService.put("instance1", hmInstance)
        } else {
            hmLinkedDBService.put(MPSDefs.DB_SOR_NAME, sorName)
            hmLinkedDBService.put(MPSDefs.DB_SERVICE_ID, "SVC999")
            if (testServiceKey.equals(MPSDefs.PORTAL_SERVICE) && portalProvider != null) {
                hmLinkedDBService.put(MPSDefs.PORTAL_PROVIDER, portalProvider)
            }
        }
        ArrayList alGroups = new ArrayList()
        boolean initialFlag = lsoFlag

        when: "Private method addLsoGroupIfEligibleLinked is invoked"
        boolean resultFlag = (boolean) ReflectionTestUtils.invokeMethod(
                helper,
                "addLsoGroupIfEligibleLinked",
                testServiceKey,
                hmLinkedDBService,
                initialFlag,
                alGroups
        )

        then: "Group addition behavior matches expectations"
        0 * _

        and: "Result and group contents validated"
        resultFlag == expectedFinalFlag
        alGroups.size() == expectedGroupCount
        if (expectedGroupCount == 1) {
            HashMap grp = (HashMap) alGroups.get(0)
            grp.get(CommonDefs.SERVICE_STATUS) == MPSDefs.ENABLED
            grp.get(CommonDefs.SERVICE_TYPE) == CommonDefs.LSO_SERVICE
            grp.get(MPSDefs.DB_SOR_NAME) == sorName
            grp.get(CommonDefs.SERVICE_ID) != null
            if (expectPortalProvider) {
                grp.get(CommonDefs.PORTAL_PROVIDER) == portalProvider
            } else {
                !grp.containsKey(CommonDefs.PORTAL_PROVIDER)
            }
        }

        where: "Different linked LSO evaluation scenarios"
        scenarioName            | serviceKey               | sorName        | portalProvider | isInstanceService | lsoFlag | expectedFinalFlag | expectedGroupCount | expectPortalProvider
        "Non-instance LS"       | "BILLING"                | MPSDefs.SOR_LS | null           | false             | false   | true              | 1                  | false
        "Portal LS service"     | MPSDefs.PORTAL_SERVICE   | MPSDefs.SOR_LS | "ATT"          | false             | false   | true              | 1                  | true
        "Already flagged skip"  | "BILLING"                | MPSDefs.SOR_LS | null           | false             | true    | true              | 0                  | false
        "Non-LS SOR ignored"    | "BILLING"                | "OTHER_SOR"    | null           | false             | false   | false             | 0                  | false
    }

    @Unroll
    def "should capture linked instance service SOR and ID for #scenarioName"() {
        given: "Linked instance service data with LS SOR"
        String serviceKey = MPSDefs.MOBILITY_SERVICE
        HashMap hmInstanceHash = new HashMap()
        hmInstanceHash.put(MPSDefs.DB_SOR_NAME, MPSDefs.SOR_LS)
        hmInstanceHash.put(MPSDefs.DB_SERVICE_ID, serviceId)
        HashMap hmLinkedDBService = new HashMap()
        hmLinkedDBService.put("instance1", hmInstanceHash)
        ArrayList alGroups = new ArrayList()

        when: "Private method addLsoGroupIfEligibleLinked is invoked via reflection"
        boolean result = ReflectionTestUtils.invokeMethod(helper,
                "addLsoGroupIfEligibleLinked",
                serviceKey,
                hmLinkedDBService,
                false,
                alGroups)

        then: "LSO group is added with correct fields"
        result == expectedFlag
        alGroups.size() == expectedGroups
        HashMap firstGroup = (HashMap) alGroups.get(0)
        firstGroup.get(CommonDefs.SERVICE_TYPE) == CommonDefs.LSO_SERVICE
        firstGroup.get(CommonDefs.SERVICE_ID) == serviceId
        firstGroup.get(MPSDefs.DB_SOR_NAME) == MPSDefs.SOR_LS
        firstGroup.get(CommonDefs.SERVICE_STATUS) == MPSDefs.ENABLED
        0 * _

        where: "Scenario"
        scenarioName    | serviceId | expectedFlag | expectedGroups
        "LSO instance"  | "svc123"  | true         | 1
    }
    @Unroll
    def "should validate configuration parsing for #scenarioName"() {
        given: "A ConsolidatedProfileHelper and configuration inputs"
        ConsolidatedProfileHelper helper = new ConsolidatedProfileHelper()
        String consolidatedCfg = sConsolidatedGrpRulesCFG
        ArrayList consolidatedList = alConsolidatedGrpRules
        String serviceToGroupCfg = sServiceToGroupNameCFG
        ArrayList serviceToGroupList = alServiceToGroupName
        String instanceCfg = sCPHInstanceServicesCFG
        ArrayList instanceList = alCPHInstanceService

        when: "validateConfigValues is invoked via reflection"
        HashMap<String, Object> result =
                (HashMap<String, Object>) ReflectionTestUtils.invokeMethod(
                        helper,
                        "validateConfigValues",
                        consolidatedCfg,
                        consolidatedList,
                        serviceToGroupCfg,
                        serviceToGroupList,
                        instanceCfg,
                        instanceList
                )

        then: "Result matches expected presence and message"
        (result == null) == expectNullResult
        if (!expectNullResult) {
            result.get(CommonDefs.COMMON_APP_INFO) == expectedAppInfo
        }
        0 * _

        where: "Different failure and success scenarios"
        scenarioName                                      | sConsolidatedGrpRulesCFG | alConsolidatedGrpRules                  | sServiceToGroupNameCFG | alServiceToGroupName                      | sCPHInstanceServicesCFG | alCPHInstanceService                      | expectedAppInfo                                                                                                      | expectNullResult
        "missing consolidated config"                    | ""                        | new ArrayList<>(["ok"])                 | "svcGrp"                | new ArrayList<>(["ok"])                   | "instSvc"                | new ArrayList<>(["ok"])                   | "CONSOLIDATED_GRP_RULES is Missing in Config."                                                                       | false
        "empty consolidated list"                        | "cfg"                     | new ArrayList<>()                       | "svcGrp"                | new ArrayList<>(["ok"])                   | "instSvc"                | new ArrayList<>(["ok"])                   | "Could not parse " + CommonDefs.PROP_CONSOLIDATED_GRP_RULES + " into ArrayList."                                     | false
        "missing serviceToGroupName config"              | "cfg"                     | new ArrayList<>(["ok"])                 | ""                      | new ArrayList<>(["ok"])                   | "instSvc"                | new ArrayList<>(["ok"])                   | "SERVICE_TO_GROUP_NAME is Missing in Config."                                                                        | false
        "empty serviceToGroupName list"                  | "cfg"                     | new ArrayList<>(["ok"])                 | "svcGrp"                | new ArrayList<>()                         | "instSvc"                | new ArrayList<>(["ok"])                   | "Could not parse " + CommonDefs.PROP_SERVICE_TO_GROUP_NAME + " into ArrayList."                                      | false
        "missing instance services config"               | "cfg"                     | new ArrayList<>(["ok"])                 | "svcGrp"                | new ArrayList<>(["ok"])                   | ""                       | new ArrayList<>(["ok"])                   | "CPH_INSTANCE_SERVICES is Missing in Config."                                                                        | false
        "empty instance services list"                   | "cfg"                     | new ArrayList<>(["ok"])                 | "svcGrp"                | new ArrayList<>(["ok"])                   | "instSvc"                | new ArrayList<>()                         | "Could not parse " + CommonDefs.PROP_CPH_INSTANCE_SERVICES + " into ArrayList."                                      | false
        "all valid succeeds"                             | "cfg"                     | new ArrayList<>(["ok"])                 | "svcGrp"                | new ArrayList<>(["ok"])                   | "instSvc"                | new ArrayList<>(["ok"])                   | null                                                                                                                 | true
    }
    @Ignore
    @Unroll
    def "should process linked user services for #scenarioName"() {
        given: "Helper with configured instance/service role rules and linked user service data"
        ConsolidatedProfileHelper helper = new ConsolidatedProfileHelper()
        // Minimal configs assumed by buildConfigArtifacts() parsing (rule + service + instance service list)
        String consolidatedCfg = "RULE1"
        String serviceToGroupCfg = serviceKey + "=" + expectedGroupType
        String instanceServicesCfg = isInstanceService ? serviceKey : ""
        ReflectionTestUtils.setField(helper, "consolidatedGrpRulesCfg", consolidatedCfg)
        ReflectionTestUtils.setField(helper, "serviceToGroupNameCfg", serviceToGroupCfg)
        ReflectionTestUtils.setField(helper, "cphInstanceServicesCfg", instanceServicesCfg)

        // Build linked user service structure
        HashMap<String, Object> hmInstanceRole = new HashMap<>()
        hmInstanceRole.put(MPSDefs.DB_STATUS, MPSDefs.DB_STATUS_ENABLED)
        ArrayList<HashMap<String, Object>> alRoles = new ArrayList<>()
        alRoles.add(hmInstanceRole)

        HashMap<String, Object> hmInstanceHash = new HashMap<>()
        hmInstanceHash.put(MPSDefs.SERVICE_STATUS, MPSDefs.ENABLED)
        hmInstanceHash.put(MPSDefs.DB_ROLES, alRoles)
        hmInstanceHash.put(MPSDefs.DB_SOR_NAME, "SOR_A")
        hmInstanceHash.put(MPSDefs.DB_SERVICE_ID, "SVC123")

        HashMap<String, Object> hmServiceEntry = new HashMap<>()
        if (isInstanceService) {
            // Instance service path (serviceKey contains nested instance)
            hmServiceEntry.put("INST1", hmInstanceHash)
        } else {
            // Non-instance role service path
            hmServiceEntry.put(MPSDefs.SERVICE_STATUS, MPSDefs.ENABLED)
            hmServiceEntry.put(MPSDefs.DB_ROLES, alRoles)
            hmServiceEntry.put(MPSDefs.DB_SOR_NAME, "SOR_B")
            hmServiceEntry.put(MPSDefs.DB_SERVICE_ID, "SVC987")
            if (serviceKey.equals(MPSDefs.PORTAL_SERVICE)) {
                hmServiceEntry.put(MPSDefs.DB_PORTAL_PROVIDER, "PORTAL_X")
            }
        }

        HashMap<String, Object> hmLinkedUserServices = new HashMap<>()
        hmLinkedUserServices.put(serviceKey, hmServiceEntry)

        HashMap<String, Object> hmLinkedUser = new HashMap<>()
        hmLinkedUser.put(MPSDefs.SERVICES, hmLinkedUserServices)

        ArrayList<HashMap<String, Object>> alLinkedUsers = new ArrayList<>()
        alLinkedUsers.add(hmLinkedUser)

        HashMap<String, Object> hmSlidInfo = new HashMap<>()
        hmSlidInfo.put(MPSDefs.KEY_LINKED_USERS, alLinkedUsers)
        ReflectionTestUtils.setField(helper, "hmSlidInfo", hmSlidInfo)

        when: "calculateGroups is invoked via reflection"
        HashMap<String, Object> result = ReflectionTestUtils.invokeMethod(helper, "calculateGroups", hmSlidInfo) as HashMap<String, Object>

        then: "Groups are calculated with expected service type"
        result != null
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == CommonDefs.COMMON_SUCCESS
        ArrayList<HashMap<String, Object>> groups = (ArrayList<HashMap<String, Object>>) result.get(CommonDefs.KEY_GROUPS)
        groups != null
        groups.size() >= 1
        HashMap<String, Object> firstGroup = groups.get(0)
        firstGroup.get(CommonDefs.SERVICE_TYPE) == expectedGroupType
        firstGroup.get(CommonDefs.SERVICE_STATUS) == MPSDefs.ENABLED
        firstGroup.get(CommonDefs.SERVICE_ID) != null
        firstGroup.get(MPSDefs.DB_SOR_NAME) != null
        if (serviceKey.equals(MPSDefs.PORTAL_SERVICE) && !isInstanceService) {
            firstGroup.get(CommonDefs.PORTAL_PROVIDER) == "PORTAL_X"
        }
        0 * _

        where: "Different linked user service processing paths"
        scenarioName              | serviceKey                | isInstanceService | expectedGroupType
        "instance mobility role"  | MPSDefs.MOBILITY_SERVICE  | true              | "MobilityGroup"
        "non-instance portal role"| MPSDefs.PORTAL_SERVICE    | false             | "PortalGroup"
    }
    def "should return error map when input is empty"() {
        given: "Empty input map"
        HashMap<String, Object> input = new HashMap<>()

        when: "getGroupAndLinkedIds is invoked"
        HashMap<String, Object> result = helper.getGroupAndLinkedIds(input)

        then: "Early error response is returned for empty input"
        result != null
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) != null
        result.get(CommonDefs.COMMON_APP_INFO) == "Input request to ConsolidatedProfileHelper is null or empty"
        0 * _
    }

    // Add to `src/test/groovy/com/att/idp/idgraphuserregistrationms/helper/ConsolidatedProfileHelperTest.groovy`
    @Ignore
    def "should return system application error when calculateLinkedIds result is null or empty"() {
        given: "hmSlidInfo containing a linkedUsers list that triggers empty/null calculateLinkedIds result"
        ArrayList<HashMap<String, Object>> linkedUsers = new ArrayList<>()
        // Intentionally add an empty linked user map to force calculateLinkedIds to yield null/empty
        HashMap<String, Object> invalidLinkedUser = new HashMap<>()
        linkedUsers.add(invalidLinkedUser)
        HashMap<String, Object> hmSlidInfoLocal = new HashMap<>()
        hmSlidInfoLocal.put(MPSDefs.KEY_LINKED_USERS, linkedUsers)
        ReflectionTestUtils.setField(helper, "hmSlidInfo", null)

        HashMap<String, Object> input = new HashMap<>()
        input.put(CommonDefs.SLID, "SLID_X")
        input.put(CommonDefs.TRANSACTION_ID, "TXN_001")
        input.put(CommonDefs.TRANSACTION_NAME, "GET_PROFILE")
        input.put(CommonDefs.CALLING_SYSTEM_ID, "CALLER_SYS")

        when: "getGroupAndLinkedIds is invoked causing calculateLinkedIds() to return null/empty"
        HashMap<String, Object> result = (HashMap<String, Object>) helper.getGroupAndLinkedIds(input)

        then: "System application error is returned (lines 110-115 covered)"
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == CErrorDefs.ERR_SYS_APPL_NUM
        result.get(CommonDefs.COMMON_APP_INFO) == "Response from calculateLinkedIds() is null or empty"
        result.get(CommonDefs.KEY_GROUPS) == null
        result.get(CommonDefs.KEY_LINKEDIDS) == null
        0 * _

        and: "All mandatory error fields populated"
        result.containsKey(CommonDefs.COMMON_APP_CATEGORY_CODE)
        result.containsKey(CommonDefs.COMMON_APP_INFO)
    }
    // Add inside `ConsolidatedProfileHelperTest`
    def "should expose config and state fields via Lombok getters"() {
        given: "All private fields assigned explicit values"
        String transactionId = "TX123"
        String transactionName = "GET_PROFILE"
        String callingSystemId = "SYS_A"
        String appStatusCode = "200"
        String appInfo = "OK"
        String slid = "SLID_001"
        String appCategoryCode = "SUCCESS"
        String consolidatedCfg = "A:EnabledServiceRule"
        String serviceToGroupCfg = "A:DSLD"
        String instanceServicesCfg = "A"
        String prepaidList = "RPRE,PPRE"
        String acctTypeSubTypeMapping = "PREPAID:RPRE,PPRE"
        HashMap<String,Object> slidInfoMap = new HashMap<>()
        ReflectionTestUtils.setField(helper, "sTransactionId", transactionId)
        ReflectionTestUtils.setField(helper, "sTransactionName", transactionName)
        ReflectionTestUtils.setField(helper, "sCallingSystemId", callingSystemId)
        ReflectionTestUtils.setField(helper, "sAppStatusCode", appStatusCode)
        ReflectionTestUtils.setField(helper, "sAppInfo", appInfo)
        ReflectionTestUtils.setField(helper, "sSLID", slid)
        ReflectionTestUtils.setField(helper, "sAppCategoryCode", appCategoryCode)
        ReflectionTestUtils.setField(helper, "consolidatedGrpRulesCfg", consolidatedCfg)
        ReflectionTestUtils.setField(helper, "serviceToGroupNameCfg", serviceToGroupCfg)
        ReflectionTestUtils.setField(helper, "cphInstanceServicesCfg", instanceServicesCfg)
        ReflectionTestUtils.setField(helper, "prepaidMobilityAccountTypeList", prepaidList)
        ReflectionTestUtils.setField(helper, "mobilityAcctTypeAcctSubTypeGroupMapping", acctTypeSubTypeMapping)
        ReflectionTestUtils.setField(helper, "hmSlidInfo", slidInfoMap)

        when: "Getters are invoked"
        String gotTxId = helper.getSTransactionId()
        String gotTxName = helper.getSTransactionName()
        String gotCaller = helper.getSCallingSystemId()
        String gotStatus = helper.getSAppStatusCode()
        String gotInfo = helper.getSAppInfo()
        String gotSlid = helper.getSSLID()
        String gotCat = helper.getSAppCategoryCode()
        String gotConsolidated = helper.getConsolidatedGrpRulesCfg()
        String gotServiceToGroup = helper.getServiceToGroupNameCfg()
        String gotInstanceSvcs = helper.getCphInstanceServicesCfg()
        String gotPrepaidList = helper.getPrepaidMobilityAccountTypeList()
        String gotMapping = helper.getMobilityAcctTypeAcctSubTypeGroupMapping()
        HashMap<String,Object> gotSlidInfo = helper.getHmSlidInfo()

        then: "All values match expectations"
        gotTxId == transactionId
        gotTxName == transactionName
        gotCaller == callingSystemId
        gotStatus == appStatusCode
        gotInfo == appInfo
        gotSlid == slid
        gotCat == appCategoryCode
        gotConsolidated == consolidatedCfg
        gotServiceToGroup == serviceToGroupCfg
        gotInstanceSvcs == instanceServicesCfg
        gotPrepaidList == prepaidList
        gotMapping == acctTypeSubTypeMapping
        gotSlidInfo.isEmpty()
        0 * _
    }
    @Unroll
    def "should populate non-instance service roles for #scenarioName"() {
        given: "Helper and test data for service role processing"
        // Override instance services list per scenario

        HashMap services = new HashMap()
        if (includeServiceMap) {
            HashMap roleServiceMap = new HashMap()
            if (includeServiceStatus) {
                roleServiceMap.put(MPSDefs.SERVICE_STATUS, serviceStatus)
            }
            if (includeSorAndIdAtService) {
                roleServiceMap.put(MPSDefs.DB_SOR_NAME, "SERVICE_SOR")
                roleServiceMap.put(MPSDefs.DB_SERVICE_ID, "SERVICE_ID")
            }
            if (includeRolesList) {
                ArrayList roles = new ArrayList()
                if (addNonHashRole) {
                    roles.add("NOT_A_HASHMAP")
                }
                if (addEmptyRole) {
                    roles.add(new HashMap())
                }
                if (addRoleWithStatus) {
                    HashMap enabledRole = new HashMap()
                    enabledRole.put(MPSDefs.DB_STATUS, roleStatus)
                    roles.add(enabledRole)
                }
                roleServiceMap.put(MPSDefs.DB_ROLES, roles)
            }
            if (isInstanceService) {
                HashMap instanceHash = new HashMap()
                instanceHash.put(MPSDefs.DB_SOR_NAME, "INSTANCE_SOR")
                instanceHash.put(MPSDefs.DB_SERVICE_ID, "INSTANCE_ID")
                roleServiceMap.put("instance1", instanceHash)
            }
            if (isPortalService) {
                roleServiceMap.put(MPSDefs.DB_PORTAL_PROVIDER, "PORTAL_PROVIDER_VAL")
            }
            services.put(serviceKey, roleServiceMap)
        }

        HashMap serviceToGroupName = new HashMap()
        serviceToGroupName.put(serviceKey, "GROUP_NAME_VAL")
        HashMap group = new HashMap()
        HashMap servicesCheck = new HashMap()

        when: "populateGroupForNonInstanceServiceRoles is invoked"
        ReflectionTestUtils.invokeMethod(helper,
                "populateGroupForNonInstanceServiceRoles",
                serviceKey, services, serviceToGroupName, group, servicesCheck)

        then: "Group population matches expectations"
        (expectGroupPopulated ? !group.isEmpty() : group.isEmpty())
        if (expectGroupPopulated) {
            group.get(CommonDefs.SERVICE_STATUS) == MPSDefs.ENABLED
            group.get(CommonDefs.SERVICE_TYPE) == "GROUP_NAME_VAL"
            if (isPortalService) {
                group.get(CommonDefs.PORTAL_PROVIDER) == "PORTAL_PROVIDER_VAL"
            } else {
                !group.containsKey(CommonDefs.PORTAL_PROVIDER)
            }
            if (isInstanceService) {
                group.get(MPSDefs.DB_SOR_NAME) == "INSTANCE_SOR"
                group.get(CommonDefs.SERVICE_ID) == "INSTANCE_ID"
            } else if (includeSorAndIdAtService) {
                group.get(MPSDefs.DB_SOR_NAME) == "SERVICE_SOR"
                group.get(CommonDefs.SERVICE_ID) == "SERVICE_ID"
            }
            servicesCheck.get(serviceKey) == CommonDefs.IND_Y
        } else {
            servicesCheck.isEmpty()
        }

        where: "Service role evaluation scenarios"
        scenarioName                                  | serviceKey            | isPortalService | isInstanceService | includeServiceMap | includeServiceStatus | serviceStatus    | includeRolesList | addNonHashRole | addEmptyRole | addRoleWithStatus | roleStatus                     | includeSorAndIdAtService | expectGroupPopulated
        "missing service map"                         | "GENERIC_SERVICE"     | false           | false             | false             | false                | ""               | false            | false          | false        | false             | ""                             | false                    | false
        "service status not enabled"                  | "GENERIC_SERVICE"     | false           | false             | true              | true                 | "DISABLED"       | true             | false          | false        | true              | MPSDefs.DB_STATUS_ENABLED      | true                     | false
        "roles list missing"                          | "GENERIC_SERVICE"     | false           | false             | true              | true                 | MPSDefs.ENABLED  | false            | false          | false        | false             | ""                             | true                     | false
        "roles list empty"                            | "GENERIC_SERVICE"     | false           | false             | true              | true                 | MPSDefs.ENABLED  | true             | false          | false        | false             | ""                             | true                     | false
        "non-hash role only"                          | "GENERIC_SERVICE"     | false           | false             | true              | true                 | MPSDefs.ENABLED  | true             | true           | false        | false             | ""                             | true                     | false
        "empty role map only"                         | "GENERIC_SERVICE"     | false           | false             | true              | true                 | MPSDefs.ENABLED  | true             | false          | true         | false             | ""                             | true                     | false
        "role status not enabled"                     | "GENERIC_SERVICE"     | false           | false             | true              | true                 | MPSDefs.ENABLED  | true             | false          | false        | true              | "DISABLED"                     | true                     | false
        "enabled role non-instance service"           | "GENERIC_SERVICE"     | false           | false             | true              | true                 | MPSDefs.ENABLED  | true             | false          | false        | true              | MPSDefs.DB_STATUS_ENABLED      | true                     | true
        "enabled role portal service"                 | MPSDefs.PORTAL_SERVICE| true            | false             | true              | true                 | MPSDefs.ENABLED  | true             | false          | false        | true              | MPSDefs.DB_STATUS_ENABLED      | true                     | true
        "enabled role instance service path"          | MPSDefs.MOBILITY_SERVICE | false       | true              | true              | true                 | MPSDefs.ENABLED  | true             | false          | false        | true              | MPSDefs.DB_STATUS_ENABLED      | true                     | true
    }
}
