package com.att.idp.idgraphuserregistrationms.helper

import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import org.springframework.jdbc.core.JdbcTemplate
import spock.lang.Specification
import spock.lang.Unroll

class SyncCGHelperTest extends Specification {

    JdbcTemplate jdbcTemplate
    SyncCGHelper helperUnderTest

    def setup() {
        jdbcTemplate = Mock(JdbcTemplate)
        helperUnderTest = new SyncCGHelper(jdbcTemplate)
    }

    @Unroll
    def "should update all CG tables successfully for #scenarioName"() {
        given: "A valid BAN and callingSystemId"
        String ban = banNumber
        String callingSystemId = systemId
        List<String> syncCgTables = ["SUBSCRIBERINFO", "SUBSCRIBERPROFILE", "COMPONENTID", "COMPONENTPROFILE", "USERID", "USERPROFILE"]

        when: "syncCGByBan is called"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban, syncCgTables,callingSystemId)

        then: "JDBC updates are called for each table"
        1 * jdbcTemplate.update("UPDATE SUBSCRIBERINFO SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> updateCount
        1 * jdbcTemplate.update("UPDATE SUBSCRIBERPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> updateCount
        1 * jdbcTemplate.update("UPDATE COMPONENTID SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> updateCount
        1 * jdbcTemplate.update("UPDATE COMPONENTPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> updateCount
        1 * jdbcTemplate.update("UPDATE USERID SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> updateCount
        1 * jdbcTemplate.update("UPDATE USERPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> updateCount
        0 * _

        and: "Result indicates success"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG

        where: "Different BAN and system ID scenarios"
        scenarioName        | banNumber  | systemId   | updateCount
        "single update"     | "123456"   | "SYSTEM-A" | 1
        "multiple updates"  | "789012"   | "SYSTEM-B" | 5
        "large ban"         | "999999"   | "SYSTEM-C" | 10
    }

    def "should return error when BAN is null"() {
        given: "A null BAN"
        String ban = null
        String callingSystemId = "SYSTEM-TEST"
        List<String> syncCgTables = ["SUBSCRIBERINFO", "SUBSCRIBERPROFILE", "COMPONENTID", "COMPONENTPROFILE", "USERID", "USERPROFILE"]

        when: "syncCGByBan is called"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban,syncCgTables, callingSystemId)

        then: "No JDBC calls are made"
        0 * jdbcTemplate.update(_, _, _)

        and: "Result contains error for invalid data"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_INVALID_DATA
    }

    def "should return error when BAN is empty string"() {
        given: "An empty BAN"
        String ban = "   "
        String callingSystemId = "SYSTEM-TEST"
        List<String> syncCgTables = ["SUBSCRIBERINFO", "SUBSCRIBERPROFILE", "COMPONENTID", "COMPONENTPROFILE", "USERID", "USERPROFILE"]

        when: "syncCGByBan is called"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban,syncCgTables, callingSystemId)

        then: "No JDBC calls are made"
        0 * jdbcTemplate.update(_, _, _)

        and: "Result contains error for invalid data"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_INVALID_DATA
    }

    def "should handle partial success when some tables have no records"() {
        given: "A valid BAN and callingSystemId with mixed update counts"
        String ban = "555555"
        String callingSystemId = "SYSTEM-D"
        List<String> syncCgTables = ["SUBSCRIBERINFO", "SUBSCRIBERPROFILE", "COMPONENTID", "COMPONENTPROFILE", "USERID", "USERPROFILE"]

        when: "syncCGByBan is called"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban,syncCgTables, callingSystemId)

        then: "JDBC updates are called for each table with mixed results"
        1 * jdbcTemplate.update("UPDATE SUBSCRIBERINFO SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        1 * jdbcTemplate.update("UPDATE SUBSCRIBERPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 0
        1 * jdbcTemplate.update("UPDATE COMPONENTID SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        1 * jdbcTemplate.update("UPDATE COMPONENTPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 0
        1 * jdbcTemplate.update("UPDATE USERID SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        1 * jdbcTemplate.update("UPDATE USERPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 0
        0 * _

        and: "Result indicates success because at least one table was updated"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
    }

    def "should return not found error when no records are updated in any table"() {
        given: "A valid BAN and callingSystemId but no matching records"
        String ban = "000000"
        String callingSystemId = "SYSTEM-E"
        List<String> syncCgTables = ["SUBSCRIBERINFO", "SUBSCRIBERPROFILE", "COMPONENTID", "COMPONENTPROFILE", "USERID", "USERPROFILE"]

        when: "syncCGByBan is called"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban,syncCgTables, callingSystemId)

        then: "All JDBC updates return zero"
        6 * jdbcTemplate.update(_, _, _) >> 0
        0 * _

        and: "Result contains not found error and rollback flag"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_BAN_NOT_FOUND
    }

    def "should handle exception during JDBC update and set rollback flag"() {
        given: "A valid BAN and callingSystemId that triggers exception"
        String ban = "777777"
        String callingSystemId = "SYSTEM-F"
        RuntimeException dbException = new RuntimeException("Database connection failed")
        List<String> syncCgTables = ["SUBSCRIBERINFO", "SUBSCRIBERPROFILE", "COMPONENTID", "COMPONENTPROFILE", "USERID", "USERPROFILE"]

        when: "syncCGByBan is called and first update throws exception"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban,syncCgTables, callingSystemId)

        then: "First JDBC update throws exception"
        1 * jdbcTemplate.update(_, callingSystemId, ban) >> new RuntimeException("Database connection failed")

        and: "Result contains DB error and rollback flag"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_DB
        result.get("isTransactionRollback") == "Y"
        result.get(CommonDefs.COMMON_APP_INFO) != null
    }

    @Unroll
    def "should update with different callingSystemId values for #scenarioName"() {
        given: "Different callingSystemId values and a BAN"
        String ban = "444444"
        String callingSystemId = systemId
        List<String> syncCgTables = ["SUBSCRIBERINFO", "SUBSCRIBERPROFILE", "COMPONENTID", "COMPONENTPROFILE", "USERID", "USERPROFILE"]

        when: "syncCGByBan is called"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban,syncCgTables, callingSystemId)

        then: "All JDBC updates are called with the correct callingSystemId"
        6 * jdbcTemplate.update(_, callingSystemId, ban) >> 1
        0 * _

        and: "Result indicates success"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS

        where: "Different calling system IDs"
        scenarioName          | systemId
        "first system"        | "SYSTEM-1"
        "legacy system"       | "LEGACY-SYS"
        "third party system"  | "3RD-PARTY"
        "long system name"    | "VERY-LONG-SYSTEM-IDENTIFIER"
    }

    def "should handle all tables with records successfully"() {
        given: "A BAN where all tables have matching records"
        String ban = "123123"
        String callingSystemId = "SYSTEM-FULL"
        List<String> syncCgTables = ["SUBSCRIBERINFO", "SUBSCRIBERPROFILE", "COMPONENTID", "COMPONENTPROFILE", "USERID", "USERPROFILE"]

        when: "syncCGByBan is called"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban, syncCgTables,callingSystemId)

        then: "All tables are updated successfully"
        1 * jdbcTemplate.update("UPDATE SUBSCRIBERINFO SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        1 * jdbcTemplate.update("UPDATE SUBSCRIBERPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        1 * jdbcTemplate.update("UPDATE COMPONENTID SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        1 * jdbcTemplate.update("UPDATE COMPONENTPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        1 * jdbcTemplate.update("UPDATE USERID SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        1 * jdbcTemplate.update("UPDATE USERPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        0 * _

        and: "Result is successful"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
    }

    @Unroll
    def "should pass correct parameters to JDBC update for #scenarioName"() {
        given: "A BAN and callingSystemId"
        String ban = banValue
        String callingSystemId = systemIdValue
        List<String> syncCgTables = ["SUBSCRIBERINFO", "SUBSCRIBERPROFILE", "COMPONENTID", "COMPONENTPROFILE", "USERID", "USERPROFILE"]

        when: "syncCGByBan is called"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban,syncCgTables, callingSystemId)

        then: "Each table update receives exact parameters"
        1 * jdbcTemplate.update({ String sql ->
            sql == "UPDATE SUBSCRIBERINFO SET LAST_MODIFIED_BY = ? WHERE BAN = ?"
        }, callingSystemId, ban) >> 1
        1 * jdbcTemplate.update({ String sql ->
            sql == "UPDATE SUBSCRIBERPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?"
        }, callingSystemId, ban) >> 1
        1 * jdbcTemplate.update({ String sql ->
            sql == "UPDATE COMPONENTID SET LAST_MODIFIED_BY = ? WHERE BAN = ?"
        }, callingSystemId, ban) >> 1
        1 * jdbcTemplate.update({ String sql ->
            sql == "UPDATE COMPONENTPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?"
        }, callingSystemId, ban) >> 1
        1 * jdbcTemplate.update({ String sql ->
            sql == "UPDATE USERID SET LAST_MODIFIED_BY = ? WHERE BAN = ?"
        }, callingSystemId, ban) >> 1
        1 * jdbcTemplate.update({ String sql ->
            sql == "UPDATE USERPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?"
        }, callingSystemId, ban) >> 1
        0 * _

        and: "Result is successful"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS

        where: "Different parameters"
        scenarioName           | banValue   | systemIdValue
        "standard parameters" | "111111"   | "SYS-STD"
        "numeric ban"         | "222222"   | "SYS-NUM"
        "long identifiers"    | "333333"   | "VERY-LONG-IDENTIFIER"
    }

    // ====== Tests for partial syncCgTables passed in request ======

    def "should update only single table when single syncCgTable is passed in request"() {
        given: "A BAN and only subscriberinfo table in syncCgTables"
        String ban = "123456"
        String callingSystemId = "SYSTEM-SINGLE"
        List<String> syncCgTables = ["subscriberinfo"]

        when: "syncCGByBan is called with single table"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban, syncCgTables, callingSystemId)

        then: "Only subscriberinfo table is updated"
        1 * jdbcTemplate.update("UPDATE SUBSCRIBERINFO SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        0 * _

        and: "Result indicates success"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
    }

    def "should update only two tables when two syncCgTables are passed in request"() {
        given: "A BAN and two tables in syncCgTables"
        String ban = "234567"
        String callingSystemId = "SYSTEM-TWO"
        List<String> syncCgTables = ["subscriberinfo", "subscriberprofile"]

        when: "syncCGByBan is called with two tables"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban, syncCgTables, callingSystemId)

        then: "Only subscriberinfo and subscriberprofile tables are updated"
        1 * jdbcTemplate.update("UPDATE SUBSCRIBERINFO SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        1 * jdbcTemplate.update("UPDATE SUBSCRIBERPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        0 * _

        and: "Result indicates success"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
    }

    def "should update only three tables when three syncCgTables are passed in request"() {
        given: "A BAN and three tables in syncCgTables"
        String ban = "345678"
        String callingSystemId = "SYSTEM-THREE"
        List<String> syncCgTables = ["componentid", "componentprofile", "userid"]

        when: "syncCGByBan is called with three tables"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban, syncCgTables, callingSystemId)

        then: "Only componentid, componentprofile, and userid tables are updated"
        1 * jdbcTemplate.update("UPDATE COMPONENTID SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        1 * jdbcTemplate.update("UPDATE COMPONENTPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        1 * jdbcTemplate.update("UPDATE USERID SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        0 * _

        and: "Result indicates success"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
    }

    def "should return error when syncCgTables is null"() {
        given: "A BAN with null syncCgTables"
        String ban = "456789"
        String callingSystemId = "SYSTEM-NULL"
        List<String> syncCgTables = null

        when: "syncCGByBan is called with null tables"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban, syncCgTables, callingSystemId)

        then: "No JDBC calls are made"
        0 * jdbcTemplate.update(_, _, _)

        and: "Result contains error for invalid data"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_INVALID_DATA
    }

    def "should return error when syncCgTables is empty list"() {
        given: "A BAN with empty syncCgTables list"
        String ban = "567890"
        String callingSystemId = "SYSTEM-EMPTY"
        List<String> syncCgTables = []

        when: "syncCGByBan is called with empty tables list"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban, syncCgTables, callingSystemId)

        then: "No JDBC calls are made"
        0 * jdbcTemplate.update(_, _, _)

        and: "Result contains error for invalid data"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_INVALID_DATA
    }

    def "should skip unsupported table names in syncCgTables"() {
        given: "A BAN with mix of valid and invalid table names"
        String ban = "678901"
        String callingSystemId = "SYSTEM-MIX"
        List<String> syncCgTables = ["subscriberinfo", "invalidtable", "userprofile", "anotherbadtable"]

        when: "syncCGByBan is called with mixed valid/invalid tables"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban, syncCgTables, callingSystemId)

        then: "Only valid tables are updated, invalid ones are skipped"
        1 * jdbcTemplate.update("UPDATE SUBSCRIBERINFO SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        1 * jdbcTemplate.update("UPDATE USERPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        0 * _

        and: "Result indicates success"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
    }

    def "should return not found when only unsupported tables are passed"() {
        given: "A BAN with only unsupported table names"
        String ban = "789012"
        String callingSystemId = "SYSTEM-INVALID"
        List<String> syncCgTables = ["invalidtable1", "invalidtable2", "badtable"]

        when: "syncCGByBan is called with only invalid tables"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban, syncCgTables, callingSystemId)

        then: "No JDBC calls are made since all tables are invalid"
        0 * jdbcTemplate.update(_, _, _)

        and: "Result contains not found error"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_BAN_NOT_FOUND
    }

    @Unroll
    def "should update only specified tables for #scenarioName"() {
        given: "A BAN and specific tables passed in request"
        String ban = "890123"
        String callingSystemId = "SYSTEM-PARTIAL"

        when: "syncCGByBan is called with specific tables"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban, syncCgTables, callingSystemId)

        then: "Only specified tables are updated"
        expectedTableCount * jdbcTemplate.update(_, callingSystemId, ban) >> 1
        0 * _

        and: "Result indicates success"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS

        where: "Different table subsets"
        scenarioName                    | syncCgTables                                                      | expectedTableCount
        "single subscriberinfo"         | ["subscriberinfo"]                                                | 1
        "userid and userprofile"        | ["userid", "userprofile"]                                         | 2
        "component tables only"         | ["componentid", "componentprofile"]                               | 2
        "subscriber tables only"        | ["subscriberinfo", "subscriberprofile"]                           | 2
        "four tables"                   | ["subscriberinfo", "componentid", "userid", "userprofile"]        | 4
        "five tables"                   | ["subscriberinfo", "subscriberprofile", "componentid", "componentprofile", "userid"] | 5
    }

    def "should handle case insensitive table names in syncCgTables"() {
        given: "A BAN with mixed case table names"
        String ban = "901234"
        String callingSystemId = "SYSTEM-CASE"
        List<String> syncCgTables = ["SUBSCRIBERINFO", "SubscriberProfile", "componentID"]

        when: "syncCGByBan is called with mixed case table names"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban, syncCgTables, callingSystemId)

        then: "Tables are matched case-insensitively and updated"
        1 * jdbcTemplate.update("UPDATE SUBSCRIBERINFO SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        1 * jdbcTemplate.update("UPDATE SUBSCRIBERPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        1 * jdbcTemplate.update("UPDATE COMPONENTID SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        0 * _

        and: "Result indicates success"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
    }

    def "should return not found when single table passed has no records"() {
        given: "A BAN with single table that has no records"
        String ban = "012345"
        String callingSystemId = "SYSTEM-NORECORD"
        List<String> syncCgTables = ["subscriberinfo"]

        when: "syncCGByBan is called with single table"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban, syncCgTables, callingSystemId)

        then: "JDBC update returns zero"
        1 * jdbcTemplate.update("UPDATE SUBSCRIBERINFO SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 0
        0 * _

        and: "Result contains not found error"
        result != null
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_BAN_NOT_FOUND
    }

    def "should return success when at least one of partial tables has records"() {
        given: "A BAN with two tables where only one has records"
        String ban = "112233"
        String callingSystemId = "SYSTEM-PARTIAL-SUCCESS"
        List<String> syncCgTables = ["subscriberinfo", "userprofile"]

        when: "syncCGByBan is called with two tables"
        Map<String, Object> result = helperUnderTest.syncCGByBan(ban, syncCgTables, callingSystemId)

        then: "Only userprofile has records"
        1 * jdbcTemplate.update("UPDATE SUBSCRIBERINFO SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 0
        1 * jdbcTemplate.update("UPDATE USERPROFILE SET LAST_MODIFIED_BY = ? WHERE BAN = ?", callingSystemId, ban) >> 1
        0 * _

        and: "Result indicates success"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
    }
}
