package com.att.idp.idgraphuserregistrationms.client

import com.att.ril.mpsys.reconnectwrapperresponse.v1.ReconnectWrapperResponse
import com.att.ril.mpsys.registeruserresponse.v1.RegisterUserResponse
import com.att.ril.mpsys.syncdestinationresponse.v1.SyncDestinationResponse
import spock.lang.Specification

class MPSSoapHandlersTest extends Specification {

    // --- MPSReconnectWrapperSoapHandler ---

    def "MPSReconnectWrapperSoapHandler getApiName returns ReconnectWrapper"() {
        given:
        def handler = new MPSReconnectWrapperSoapHandler()

        when:
        def result = handler.getApiName()

        then:
        result == "ReconnectWrapper"
        0 * _
    }

    def "MPSReconnectWrapperSoapHandler getLogger returns non-null"() {
        given:
        def handler = new MPSReconnectWrapperSoapHandler()

        when:
        def result = handler.getLogger()

        then:
        result != null
        0 * _
    }

    def "MPSReconnectWrapperSoapHandler extractAppInfo returns appInfo from response"() {
        given:
        def handler = new MPSReconnectWrapperSoapHandler()
        ReconnectWrapperResponse response = new ReconnectWrapperResponse()
        response.setAppInfo("reconnect-info")

        when:
        def result = handler.extractAppInfo(response)

        then:
        result == "reconnect-info"
        0 * _
    }

    // --- MPSRegisterUserSoapHandler ---

    def "MPSRegisterUserSoapHandler getApiName returns RegisterUser"() {
        given:
        def handler = new MPSRegisterUserSoapHandler()

        when:
        def result = handler.getApiName()

        then:
        result == "RegisterUser"
        0 * _
    }

    def "MPSRegisterUserSoapHandler getLogger returns non-null"() {
        given:
        def handler = new MPSRegisterUserSoapHandler()

        when:
        def result = handler.getLogger()

        then:
        result != null
        0 * _
    }

    def "MPSRegisterUserSoapHandler extractAppInfo returns appInfo from response"() {
        given:
        def handler = new MPSRegisterUserSoapHandler()
        RegisterUserResponse response = new RegisterUserResponse()
        response.setAppInfo("register-info")

        when:
        def result = handler.extractAppInfo(response)

        then:
        result == "register-info"
        0 * _
    }

    // --- MPSSyncDestinationSoapHandler ---

    def "MPSSyncDestinationSoapHandler getApiName returns SyncDestination"() {
        given:
        def handler = new MPSSyncDestinationSoapHandler()

        when:
        def result = handler.getApiName()

        then:
        result == "SyncDestination"
        0 * _
    }

    def "MPSSyncDestinationSoapHandler getLogger returns non-null"() {
        given:
        def handler = new MPSSyncDestinationSoapHandler()

        when:
        def result = handler.getLogger()

        then:
        result != null
        0 * _
    }

    def "MPSSyncDestinationSoapHandler extractAppInfo returns appInfo from response"() {
        given:
        def handler = new MPSSyncDestinationSoapHandler()
        SyncDestinationResponse response = new SyncDestinationResponse()
        response.setAppInfo("sync-info")

        when:
        def result = handler.extractAppInfo(response)

        then:
        result == "sync-info"
        0 * _
    }
}
