package com.att.idp.idgraphuserregistrationms.request.validator

import com.att.idp.idgraphuserregistrationms.resource.request.RetriggerQARRequest
import com.att.idp.idgraphuserregistrationms.resource.response.RetriggerQARResponse
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Ignore
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap
import spock.lang.Unroll


class RetriggerQARRequestValidatorTest extends Specification {

	def retriggerQARRequestValidator=new RetriggerQARRequestValidator()

	RetriggerQARRequest retriggerQARRequest = null
	RetriggerQARResponse retriggerQARResponse = null
	private Map<String, String> headers = new HashMap<>()
	public HttpHeaders requestHeader = null
	MultivaluedHashMap requestHeaders =null

	def setup() throws Exception {
		retriggerQARRequest = new RetriggerQARRequest()
		retriggerQARResponse= new RetriggerQARResponse()
		requestHeader= Mock(HttpHeaders)
		requestHeaders = new MultivaluedHashMap<>(headers)


		retriggerQARRequest.ban = 'VD123456'
		retriggerQARRequest.accessId = 'qay_test'
		retriggerQARRequest.isExternalCall = 'Y'
		retriggerQARRequest.accountType = 'TITAN'

		ReflectionTestUtils.setField(retriggerQARRequestValidator, 'propValidCallers',
				'IDP|DATAMGT|ISAACWFE|OPUS|DAASOL')


	}

	def "test retrigger qar null request"() throws Exception {
		given:
		retriggerQARRequest = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		retriggerQARResponse = retriggerQARRequestValidator
				.retriggerQARReqValidator(requestHeader, retriggerQARRequest)
		then:
		retriggerQARResponse.appInfo == 'Input Request is NULL / Empty.'
	}
	def "query autogentemp req validator success without trace id test"() throws Exception {

		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'

		when:
		retriggerQARResponse  = retriggerQARRequestValidator.retriggerQARReqValidator(requestHeader, retriggerQARRequest)
		then:
		retriggerQARResponse.appInfo == 'Missing or Invalid IdpTraceId'
	}
	def "autogentempaid requestunknownattribues"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		Map<String,Object> allUnknownAttributes =new HashMap<>()
		retriggerQARRequest.setUnknownAttributes(allUnknownAttributes)
		allUnknownAttributes.put("test","test")
		when:
		retriggerQARResponse = retriggerQARRequestValidator.retriggerQARReqValidator(requestHeader, retriggerQARRequest)
		then:
		retriggerQARResponse.appInfo == 'Invalid Attributes passed in RetriggerQARRequest : {test=test}'

	}
	def "test retrigger qar success case"() {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		retriggerQARRequest.accessId = ''
		when:
		retriggerQARRequest.isExternalCall = ''
		retriggerQARResponse = retriggerQARRequestValidator
				.retriggerQARReqValidator(requestHeader, retriggerQARRequest)
		then:
		retriggerQARResponse == null
	}

	def "test retrigger qar invalid csid error"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>' '
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		retriggerQARRequest.accessId = ''

		when:
		retriggerQARResponse = retriggerQARRequestValidator
				.retriggerQARReqValidator(requestHeader, retriggerQARRequest)
		then:

		retriggerQARResponse.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}


	def "test retrigger qar csi error"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>null
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		retriggerQARResponse =retriggerQARRequestValidator
				.retriggerQARReqValidator(requestHeader, retriggerQARRequest)
		then:
		retriggerQARResponse.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}
	def "test retrigger qar is external call level"() {
		given:
		retriggerQARRequest.isExternalCall = 'A'
		retriggerQARRequest.accessId = ''
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		retriggerQARResponse = retriggerQARRequestValidator
				.retriggerQARReqValidator(requestHeader, retriggerQARRequest)
		then:
		retriggerQARResponse.appInfo == 'isExternalCall must be one of Y or N'
	}


	def "test retrigger qar null ban"() {
		given:
		retriggerQARRequest.ban = null
		retriggerQARRequest.accessId = null
		retriggerQARRequest.guid=null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		retriggerQARResponse = retriggerQARRequestValidator
				.retriggerQARReqValidator(requestHeader, retriggerQARRequest)
		then:
		retriggerQARResponse.appInfo == 'Either accessId or accountType and BAN or guid are required'
	}
	
	def "test retrigger qar empty ban"() {
		given:
		retriggerQARRequest.ban = ""
		retriggerQARRequest.accessId = ""
		retriggerQARRequest.guid = ""
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		retriggerQARResponse = retriggerQARRequestValidator
				.retriggerQARReqValidator(requestHeader, retriggerQARRequest)
		then:
		retriggerQARResponse.appInfo == 'Either accessId or accountType and BAN or guid are required'
	}

	def "test retrigger qar account type null"() {
		given:
		retriggerQARRequest.accountType = (null)
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		retriggerQARRequest.accessId = ''

		when:
		retriggerQARResponse =retriggerQARRequestValidator
				.retriggerQARReqValidator(requestHeader, retriggerQARRequest)
		then:
		retriggerQARResponse.appInfo == 'AccountType must be present for input Ban'
	}

	def autoGenTempAIDRequestValidatorExceptionTest() throws Exception {
		given:
		//requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		//Mockito.doThrow(new RuntimeException()).when(requestHeader).getHeaderString('X-ATT-ClientId')
		requestHeader.getHeaderString('X-ATT-ClientId')>> { throw ex }

		when:
		retriggerQARResponse = retriggerQARRequestValidator.retriggerQARReqValidator(requestHeader, retriggerQARRequest)

		then:
		retriggerQARResponse.appInfo== 'Exception thrown in RetriggerQARRequestValidator : No such property: ex for class: org.spockframework.mock.runtime.MockInvocation'
	}

	def "test both returnQARToken and returnQARTokenSHM passing in retriggerQAR"() {
		given:
		retriggerQARRequest.returnQARToken = 'Y'
		retriggerQARRequest.returnQARTokenSHM = 'Y'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		retriggerQARResponse = retriggerQARRequestValidator
				.retriggerQARReqValidator(requestHeader, retriggerQARRequest)
		then:
		retriggerQARResponse.appInfo == 'returnQARToken and returnQARTokenSHM are not supported in same request'
	}

	def "test  returnQARToken in retriggerQAR"() {
		given:
		retriggerQARRequest.returnQARToken = 'A'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		retriggerQARResponse = retriggerQARRequestValidator
				.retriggerQARReqValidator(requestHeader, retriggerQARRequest)
		then:
		retriggerQARResponse.appInfo == 'returnQARToken value must be one of Y or N'
	}

	def "test  returnQARTokenSHM in retriggerQAR"() {
		given:
		retriggerQARRequest.returnQARTokenSHM = 'A'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		retriggerQARResponse = retriggerQARRequestValidator
				.retriggerQARReqValidator(requestHeader, retriggerQARRequest)
		then:
		retriggerQARResponse.appInfo == 'returnQARTokenSHM value must be one of Y or N'
	}
	def "should return error if BAN is present and accessId is not empty"() {
		given:
		retriggerQARRequest.ban = 'VD123456'
		retriggerQARRequest.accessId = 'notEmpty'
		retriggerQARRequest.guid = null
		retriggerQARRequest.accountType = 'TITAN'
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		requestHeader.getHeaderString('idp-trace-id') >> 'traceId'

		when:
		def response = retriggerQARRequestValidator.retriggerQARReqValidator(requestHeader, retriggerQARRequest)

		then:
		response.appInfo == 'If BAN is present, either accessId or guid should not be allowed'
	}

	def "should return error if BAN is present and guid is not empty"() {
		given:
		retriggerQARRequest.ban = 'VD123456'
		retriggerQARRequest.accessId = ''
		retriggerQARRequest.guid = 'notEmpty'
		retriggerQARRequest.accountType = 'TITAN'
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		requestHeader.getHeaderString('idp-trace-id') >> 'traceId'

		when:
		def response = retriggerQARRequestValidator.retriggerQARReqValidator(requestHeader, retriggerQARRequest)

		then:
		response.appInfo == 'If BAN is present, either accessId or guid should not be allowed'
	}
	def "should return error if accountType is present with accessId or guid and ban is empty"() {
		given:
		retriggerQARRequest.accountType = 'TITAN'
		retriggerQARRequest.accessId = 'notEmpty'
		retriggerQARRequest.guid = ''
		retriggerQARRequest.ban = ''
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		requestHeader.getHeaderString('idp-trace-id') >> 'traceId'

		when:
		def response = retriggerQARRequestValidator.retriggerQARReqValidator(requestHeader, retriggerQARRequest)

		then:
		response.appInfo == 'AccountType is not allowed with accessId or guid'
	}
	@Unroll
	def "should normalize qarNotificationType for #scenarioName"() {
		given: "A RetriggerQARRequest with qarNotificationType"
		RetriggerQARRequest request = new RetriggerQARRequest()
		request.setQarNotificationType(inputValue)

		when: "validateQarNotificationType is called"
		retriggerQARRequestValidator.validateQarNotificationType(request)

		then: "qarNotificationType is set to expected value"
		request.getQarNotificationType() == expectedValue

		where: "Different input scenarios"
		scenarioName           | inputValue  | expectedValue
		"reminder1 lower case" | "reminder1" | "reminder1"
		"reminder2 upper case" | "REMINDER2" | "reminder2"
		"reminder3 mixed case" | "RemIndEr3" | "reminder3"
	}

}
