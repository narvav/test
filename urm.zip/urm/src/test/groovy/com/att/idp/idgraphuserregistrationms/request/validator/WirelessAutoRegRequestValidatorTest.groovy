package com.att.idp.idgraphuserregistrationms.request.validator

import com.att.idp.idgraphuserregistrationms.resource.request.WirelessAutoRegRequest
import com.att.idp.idgraphuserregistrationms.resource.response.WirelessAutoRegResponse
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap


class WirelessAutoRegRequestValidatorTest extends Specification {


	 def wirelessAutoRegReqValObj= new WirelessAutoRegRequestValidator()

	 WirelessAutoRegRequest requestObj = null
	 WirelessAutoRegResponse responseObj = null

	private Map<String, String> headers = new HashMap<>()
	public HttpHeaders requestHeader = null
	MultivaluedHashMap requestHeaders = null


	def setup() throws Exception {
		requestObj = new WirelessAutoRegRequest()
		responseObj = new WirelessAutoRegResponse()
		requestHeader = Mock(HttpHeaders)

		requestObj.callingSystemId = 'IDP'
		requestObj.isExternalCall = 'Y'
		requestObj.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
		requestObj.firstName = 'Rich'
		requestObj.lastName = 'Att'
		requestObj.serviceName = 'MOBILITY'
		requestObj.contactEmail = 'ergs4556@att.com'
		requestObj.sorId = '13'
		requestObj.sorInvariantId = '54627882667'


		ReflectionTestUtils.setField(wirelessAutoRegReqValObj, 'propValidCallers', 'IDP|DATAMGT')

	}


	def "wireless auto reg req val null req test"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		WirelessAutoRegResponse response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader,
				null)
		then:
		response.appInfo == 'Input Request is NULL / Empty.'

	}





	def "wireless auto reg req val null client id test"() throws Exception {

		//Mockito.doReturn(null).when(requestHeader).getHeaderString("idp-trace-id");
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>null
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		WirelessAutoRegResponse response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader,
				requestObj)
		then:
		response.appInfo == 'Missing or invalid X-ATT-ClientId in request header'

	}


	def "wireless auto reg req val empty client id test"() throws Exception {

		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>' '
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		WirelessAutoRegResponse response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader,
				requestObj)
		then:
		response.appInfo == 'Missing or invalid X-ATT-ClientId in request header'

		// if clientid is invalid
		when:
		requestHeader.getHeaderString('X-ATT-ClientId')>>'ABC'
		response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Missing or invalid X-ATT-ClientId in request header'

	}

	def "wireless auto reg req val success"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		WirelessAutoRegResponse response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader,
				requestObj)
		then:
		response == null

	}

	def "wireless auto reg without trace id test"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		//Mockito.doReturn(null).when(requestHeader).getHeaderString("idp-trace-id");
		//	requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'

		when:
		WirelessAutoRegResponse  response= wirelessAutoRegReqValObj
				.wirelessAutoRegRequestValidator(requestHeader, requestObj)

		then:
		response .appInfo == 'Missing or Invalid IdpTraceId'
	}
	def "verify existing member eligibility invalid attributes test"() throws Exception{
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		Map<String,Object> allUnknownAttributes =new HashMap<>()
		allUnknownAttributes['test'] = 'test'
		requestObj.unknownAttributes = allUnknownAttributes
		when:
		WirelessAutoRegResponse response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator( requestHeader,requestObj)
		then:
		response.appInfo == 'Invalid Attributes passed in WirelessAutoRegRequest : {test=test}'
	}
	def "wireless auto reg req val invalid sorid test"() throws Exception {

		// empty sorId
		given:
		requestObj.sorId = ''
		requestHeader.getHeaderString('X-ATT-ClientId')>>' '
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		WirelessAutoRegResponse response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader,
				requestObj)
		then:
		response.appInfo == 'Sor Id is missing'

		// invalid sorId
		when:
		requestObj.sorId = '11'
		response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Invalid sorId passed in input'

	}


	def "wireless auto reg req val invalid sor invariant id test"() throws Exception {

		// empty sorInvariantId
		given:
		requestObj.sorInvariantId = ''
		requestHeader.getHeaderString('X-ATT-ClientId')>>' '
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		WirelessAutoRegResponse response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader,
				requestObj)
		then:
		response.appInfo == 'Sor Invariant Id is missing'

		// invalid sorInvariantId
		when:
		requestObj.sorInvariantId = 'atyw6!!7899'
		response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'sorInvariantId should be alphaNumeric only'

	}


	def "wireless auto reg req val invalid service test"() throws Exception {

		// empty serviceName
		given:
		requestObj.serviceName = ''
		requestHeader.getHeaderString('X-ATT-ClientId')>>' '
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		WirelessAutoRegResponse response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader,
				requestObj)
		then:
		response.appInfo == 'ServiceName is missing'

		// invalid service
		when:
		requestObj.serviceName = 'MOSUB'
		response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Only MOBILITY service allowed in input'

	}


	def "wireless auto reg req val test"() throws Exception {

		// when firstName and ContactEmail is not set
		given:
		requestObj.contactEmail = null
		requestObj.firstName = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>' '
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		WirelessAutoRegResponse response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader,
							requestObj)
		then:
		response.appInfo == 'Either FirstName & LastName Or ContactEmail must be passed in input'

		// when lastName and ContactEmail is not set
		when:
		requestObj.contactEmail = null
		requestObj.lastName = null
		response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Either FirstName & LastName Or ContactEmail must be passed in input'

	}

	def "wireless auto reg external call test"() throws Exception {
		
		// when externalCall set as N
		given:
		requestObj.isExternalCall = 'N'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		WirelessAutoRegResponse response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader,
				requestObj)
		then:
		response == null

		// when externalCall set as null
		when:
		requestObj.isExternalCall = null
		response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader,
				requestObj)
		then:
		requestObj.isExternalCall == 'Y'

		// when invalid externalCall value is passed
		when:
		requestObj.isExternalCall = 'I'
		response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader,
				requestObj)
		then:
		response.appInfo == 'isExternalCall must be one of Y or N'
	}

	def "wireless auto reg req val exception test"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		requestObj = new WirelessAutoRegRequest()
		requestObj.callingSystemId = 'IDP'
		requestObj.isExternalCall = 'Y'
		requestObj.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
		requestObj.firstName = 'Rich'
		requestObj.lastName = 'Att'
		requestObj.serviceName = 'MOBILITY'
		requestObj.contactEmail = 'ergs4556@att.com'
		requestObj.sorId = '13'
		requestObj.sorInvariantId = '54627882667'

		and:
		wirelessAutoRegReqValObj = Spy(WirelessAutoRegRequestValidator) {
			wirelessAutoRegRequestValidator(_, _) >> { throw new RuntimeException("Test Exception") }
		}

		when:
		WirelessAutoRegResponse response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader, requestObj)

		then:
		thrown(RuntimeException.class)
	}

	def "wireless auto reg req val invalid isConnectedCar test"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'

		// Test with invalid isConnectedCar value
		requestObj.isConnectedCar = 'INVALID'
		when:
		WirelessAutoRegResponse response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'isConnectedCar must be one of Y or N'

		// Test with valid isConnectedCar value 'Y'
		when:
		requestObj.isConnectedCar = 'Y'
		response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader, requestObj)
		then:
		response == null

		// Test with valid isConnectedCar value 'N'
		when:
		requestObj.isConnectedCar = 'N'
		response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader, requestObj)
		then:
		response == null
	}

	def "wireless auto reg req val missing config test"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		requestObj = new WirelessAutoRegRequest()
		requestObj.callingSystemId = 'IDP'
		requestObj.isExternalCall = 'Y'
		requestObj.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
		requestObj.firstName = 'Rich'
		requestObj.lastName = 'Att'
		requestObj.serviceName = 'MOBILITY'
		requestObj.contactEmail = 'ergs4556@att.com'
		requestObj.sorId = '13'
		requestObj.sorInvariantId = '54627882667'

		ReflectionTestUtils.setField(wirelessAutoRegReqValObj, 'propValidCallers', '')

		when:
		WirelessAutoRegResponse response = wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(requestHeader, requestObj)

		then:
		response.appInfo == 'WirelessAutoReg CallingSystemIds config is not set'
	}
}

