package com.att.idp.QAIntegration.Report

import com.att.idp.QAIntegration.Config.GlobalConfig
import groovy.util.logging.Slf4j

import jakarta.mail.Authenticator
import jakarta.mail.Message
import jakarta.mail.Multipart
import jakarta.mail.PasswordAuthentication
import jakarta.mail.Session
import jakarta.mail.Transport
import jakarta.mail.internet.InternetAddress
import jakarta.mail.internet.MimeBodyPart
import jakarta.mail.internet.MimeMessage
import jakarta.mail.internet.MimeMultipart

@Slf4j
class QG7EmailSender {

    static void main(String[] args) {
        sendEmailReport()
    }

    static void sendEmailReport() {
        Map<String, String> emailConfig = GlobalConfig.getEmailConfig()

        if (!emailConfig || !emailConfig.toEmail) {
            log.warn("Email configuration not found or incomplete. Skipping email send.")
            return
        }

        // Check sendEmailMode
        String sendEmailMode = emailConfig.get("sendEmailMode")?.toLowerCase() ?: "onfailure"
        QG7TestResultCollector collector = QG7TestResultCollector.getInstance()
        int failedCount = collector.failedTests.get()

        boolean shouldSendEmail = false
        switch (sendEmailMode) {
            case "always":
                shouldSendEmail = true
                break
            case "never":
                shouldSendEmail = false
                break
            case "onfailure":
            default:
                shouldSendEmail = (failedCount > 0)
        }

        if (!shouldSendEmail) {
            log.info("Skipping email send. Mode='{}', failedCount={}", sendEmailMode, failedCount)
            return
        }

        try {
            Properties props = new Properties()
            props.put("mail.smtp.host", emailConfig.smtpHost ?: "smtp.it.att.com")
            props.put("mail.smtp.port", emailConfig.smtpPort ?: "587")
            props.put("mail.smtp.auth", "true")
            props.put("mail.smtp.starttls.enable", "true")

            Session session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(
                            emailConfig.username ?: "",
                            emailConfig.password ?: ""
                    )
                }
            })

            Message message = new MimeMessage(session)
            message.setFrom(new InternetAddress(emailConfig.fromEmail ?: "idgraph-automation@att.com"))
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailConfig.toEmail))

            if (emailConfig.ccEmail) {
                message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(emailConfig.ccEmail))
            }

            String env = collector.getEnvironment()
            int passed = collector.passedTests.get()
            int failed = collector.failedTests.get()
            int total = collector.totalTests.get()
            double passRate = collector.getPassRate()

            String status = failed > 0 ? "❌ FAILED" : "✅ PASSED"
            message.setSubject("IdGraphUserRegistrationMs QG7 Tests ${status} | ${env} | ${passed}/${total} (${String.format("%.1f", passRate)}%)")

            Multipart multipart = new MimeMultipart()

            MimeBodyPart htmlPart = new MimeBodyPart()
            File emailHtml = new File("target/CustomReport/Email.html")
            if (emailHtml.exists()) {
                htmlPart.setContent(emailHtml.text, "text/html; charset=utf-8")
            } else {
                htmlPart.setContent("<p>Test report not found. Please check the build logs.</p>", "text/html; charset=utf-8")
            }
            multipart.addBodyPart(htmlPart)

            File extentReport = new File("target/SparkReport/UserRegistrationMs-QG7-Report.html")
            if (extentReport.exists()) {
                MimeBodyPart attachmentPart = new MimeBodyPart()
                attachmentPart.attachFile(extentReport)
                attachmentPart.setFileName("IdGraphUserRegistrationMs-QG7-Report.html")
                multipart.addBodyPart(attachmentPart)
            }

            message.setContent(multipart)
            Transport.send(message)

            log.info("Email report sent successfully to: {}", emailConfig.toEmail)

        } catch (Exception e) {
            log.error("Failed to send email report: {}", e.message, e)
        }
    }
}
