package com.att.idp.component

import com.att.idp.idgraphuserregistrationms.client.MPSRegisterUserSoapHandler
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.hamcrest.CoreMatchers
import org.spockframework.spring.SpringBean
import org.springframework.transaction.PlatformTransactionManager
import org.springframework.transaction.TransactionStatus


class RegisterLSUserCompTest extends CompTestBase{

	private String uri = '/lsreg/registerUser'

	@SpringBean
	PlatformTransactionManager transactionManager = Stub(PlatformTransactionManager) {
		getTransaction(_) >> Stub(TransactionStatus)
	}

	@SpringBean
	MPSRegisterUserSoapHandler oMPSRegisterUserSoapHandler = Mock();

	private Map<String, String> getHeaders() {
		Map<String, String> headers = new HashMap<String, String>()
		headers['Content-Type'] = 'application/json'
		headers['X-ATT-ClientId'] ='IDP'
		headers['idp-trace-id'] = 'cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0'
		return headers
	}

	def "register l s user success"() {

		given:
		HashMap hmResponse = new HashMap<String, String>()
		hmResponse[CommonDefs.TRANSACTION_ID] = '47e8df49d3410d77'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['appInfo'] = 'Success'
		oMPSRegisterUserSoapHandler.invokeAPI(_) >> hmResponse
		String req = '{\r\n' + '    "ban": "000011199",\r\n' +
		'    "userId": "email3823916@att.net",\r\n' + '    "slid": "email3823916@adba.org",\r\n' +
				'    "regType": "NEW",\r\n' + '    "dateOfBirth": null\r\n' + '}'


		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(200).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
				.body("appStatusCode", CoreMatchers.equalTo("0"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}


	def "test register l s user null response from SOAP"() {

		given:
		String req = '{\r\n' + '    "ban": "000011199",\r\n' +
				'    "userId": "email3823916@att.net",\r\n' + '    "slid": "email3823916@adba.org",\r\n' +
				'    "regType": "NEW",\r\n' + '    "dateOfBirth": null\r\n' + '}'
		oMPSRegisterUserSoapHandler.invokeAPI(_) >> null

		expect:
		givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(500)
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_SYS_APPL"))
				.body("appStatusCode", CoreMatchers.equalTo("602"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))

	}


	def "register l s user invalid input"() {

		given:
		String req = '{\r\n' + '    "ban": " ",\r\n' +
				'    "userId": "email3823916@att.net",\r\n' + '    "slid": "email3823916@adba.org",\r\n' +
				'    "regType": "NEW",\r\n' + '    "dateOfBirth": null\r\n' + '}'


		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(400).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.containsString("Ban is missing."))
				.body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_100"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}

	def "test regesiter ls user null CallingSystemId"() {

		given:
		HashMap requestHeader = getHeaders()
		requestHeader['X-ATT-ClientId'] = null
		String req = '{\r\n' + '    "ban": "000011199",\r\n' +
				'    "userId": "email3823916@att.net",\r\n' + '    "slid": "email3823916@adba.org",\r\n' +
				'    "regType": "NEW",\r\n' + '    "dateOfBirth": null\r\n' + '}'

		expect:
		givenBaseSpec().headers(requestHeader).body(req).when().post(uri).then().statusCode(400)
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.containsString("Missing or invalid X-ATT-ClientId in request header"))
				.body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_100"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}

	def "test register ls user error response from Soap call "() {

		given:
		HashMap hmResponse = new HashMap<String, String>()
		hmResponse[MPSDefs.APP_STATUS_CODE] = '130'
		hmResponse[MPSDefs.APP_STATUS_MSG] = 'BAN_NOT_FOUND'
		hmResponse['appInfo'] = 'BAN not found in MPS'
		oMPSRegisterUserSoapHandler.invokeAPI(_) >> hmResponse
		String req = '{\r\n' + '    "ban": "000011199",\r\n' +
				'    "userId": "email3823916@att.net",\r\n' + '    "slid": "email3823916@adba.org",\r\n' +
				'    "regType": "NEW",\r\n' + '    "dateOfBirth": null\r\n' + '}'

		expect:
		givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then().statusCode(404)
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_BAN_NOT_FOUND"))
				.body("appStatusCode", CoreMatchers.equalTo("130"))
				.body("appInfo", CoreMatchers.containsString("BAN not found in MPS"))
				.body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_130"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}


}
