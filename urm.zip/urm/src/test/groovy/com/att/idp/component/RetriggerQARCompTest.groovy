package com.att.idp.component

import com.att.idp.idgraph.commons.integration.CGRestClientWrapper
import com.att.idp.idgraph.commons.integration.CLMRestClient
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetAssociatedMembersDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetInfoByMaskDBHelper
import com.att.idp.idgraphuserregistrationms.queue.message.helpers.RetriggerQARQueueHelper
import com.att.mpsys.common.helpers.FeatureManagerHelper
import org.hamcrest.CoreMatchers
import org.spockframework.spring.SpringBean
import org.springframework.transaction.PlatformTransactionManager
import org.springframework.transaction.TransactionStatus

import static org.hamcrest.Matchers.anyOf

class RetriggerQARCompTest extends CompTestBase {
	String uri = '/account/qar/retrigger'

	@SpringBean
	PlatformTransactionManager transactionManager = Stub(PlatformTransactionManager) {
		getTransaction(_) >> Stub(TransactionStatus)
	}

	@SpringBean
	GetAssociatedMembersDBHelper getAssociatedMembersDBHelperObj = Mock()

	@SpringBean
	CGRestClientWrapper cgRestClient = Mock()

	@SpringBean
	RetriggerQARQueueHelper retriggerQARQueueHelper = Mock()

	@SpringBean
	GetInfoByMaskDBHelper getInfoByMaskDBHelperObj = Mock()

	@SpringBean
	FeatureManagerHelper featureManager = Stub()

	@SpringBean
	CLMRestClient clmRestClient = Mock()

	private Map<String, String> getHeaders() {
		Map<String, String> headers = new HashMap<String, String>()
		headers['Content-Type'] = 'application/json'
		headers['X-ATT-ClientId'] ='IDP'
		headers['idp-trace-id'] = 'cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0'
		return headers
	}

	def "retrigger q a r success"() {
		given:
		HashMap associatedMembers = readJsonFileToMap("mockResponse/AssociatedMemberRetriggerResp.json") as HashMap
		// Add required status fields for successful response
		associatedMembers.put("appStatusMsg", "SUCCESS")
		associatedMembers.put("appStatusCode", "0")
		associatedMembers.put("appCategoryCode", "0")

		HashMap cgResponse = readJsonFileToMap("mockResponse/CGSyncResponse.json") as HashMap;
		HashMap asyncCallResponse = readJsonFileToMap("mockResponse/DataForAsyncCallResponse.json") as HashMap;
		HashMap resultMap = new HashMap();
		resultMap.put("appStatusMsg", "SUCCESS");
		resultMap.put("appStatusCode", "0");
		resultMap.put("appInfo", "RetriggerQAR Message sent successfully from sendmessagetoQueue");
		resultMap.put("appCategoryCode","0")
		String req = '{ "accountType": "TITAN", "ban": "VD0015088" }'

		getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> associatedMembers
		cgRestClient.getCGSyncCall(_ as HashMap) >> cgResponse
		retriggerQARQueueHelper.prepareDataForAsyncCall(_ as Map, _ as Map) >> asyncCallResponse
		retriggerQARQueueHelper.makeAsyncCall(_ as ArrayList, _ as Map) >> resultMap


		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(200).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
				.body("appStatusCode", CoreMatchers.equalTo("0"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}

	def "retrigger q a r record not found"() {
		given:
		HashMap associatedMembers = new HashMap();
		associatedMembers.put("appStatusMsg","REC_NOT_FOUND")
		associatedMembers.put("appCategoryCode","0")
		associatedMembers.put("appInfo","REC_NOT_FOUND")
		associatedMembers.put("appStatusCode","285")

		getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>>associatedMembers;
		String req = '{ "accountType": "TITAN", "ban": "VD0015088" }'
		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(404).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_USER_NOT_FOUND"))
				.body("appStatusCode", CoreMatchers.equalTo("121"))
				.body("appInfo", CoreMatchers.equalTo("Input ban is not associated to any user."))
				.body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_121"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}

	def "retrigger q a r success on CG error"() {
		given:
		HashMap associatedMembers = readJsonFileToMap("mockResponse/AssociatedMemberRetriggerResp.json") as HashMap
		HashMap asyncCallResponse = readJsonFileToMap("mockResponse/DataForAsyncCallResponse.json") as HashMap;
		HashMap resultMap = new HashMap();
		resultMap.put("appStatusMsg", "SUCCESS");
		resultMap.put("appStatusCode", "0");
		resultMap.put("appInfo", "RetriggerQAR Message sent successfully from sendmessagetoQueue");
		resultMap.put("appCategoryCode","0")
		String req = '{ "accountType": "TITAN", "ban": "VD0015088" }'

		Map cgresultMap = new HashMap();
		cgresultMap.put("appStatusMsg", "ERR_INVALID_DATA");
		cgresultMap.put("appStatusCode", "3");
		cgresultMap.put("appStatusCode", "100");
		cgresultMap.put("appInfo", "Customer account profile data not found");

		getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>>associatedMembers;
		cgRestClient.getCGSyncCall(_ as HashMap)>> cgresultMap
		retriggerQARQueueHelper.prepareDataForAsyncCall(_ as Map,_ as Map)>>asyncCallResponse
		retriggerQARQueueHelper.makeAsyncCall(_ as ArrayList,_ as Map)>>resultMap


		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(200).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
				.body("appStatusCode", CoreMatchers.equalTo("0"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}


	def "retrigger q a r ban null error "() {
		given:
		String req = '{ "accountType": "TITAN", "ban": "" }'

		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(400).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.equalTo("BAN length is invalid"))
				.body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_100"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}

	def "retrigger q a r AccessId null error "() {
		given:
		String req = '{ "accountType": "TITAN", "accessId": "" }'

		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(400).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.equalTo("AccessId length is invalid"))
				.body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_100"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}

	def "retrigger q a r accessId valid account not found"() {
		given:
		HashMap slidInfo = readJsonFileToMap("mockResponse/SlidInfoResponse.json") as HashMap
		String req = '{ "accountType": "TITAN", "accessId": "qay2002dt2372cs40010" }'

		getInfoByMaskDBHelper.getInfoByMask(_ as HashMap)>>slidInfo;

		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(400).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo",CoreMatchers.equalTo("AccountType is not allowed with accessId or guid"))
				.body("error.errorId",CoreMatchers.equalTo("MS_MPSYS_BE_100"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}


	def "retrigger q a r on prepare data sync error"() {
		given:
		HashMap associatedMembers = readJsonFileToMap("mockResponse/AssociatedMemberRetriggerResp.json") as HashMap
		HashMap cgResponse = readJsonFileToMap("mockResponse/CGSyncResponse.json") as HashMap;
		String req = '{ "accountType": "TITAN", "ban": "VD0015088" }'
		getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>>associatedMembers;
		cgRestClient.getCGSyncCall(_ as HashMap) >> cgResponse
		retriggerQARQueueHelper.prepareDataForAsyncCall(_ as Map,_ as Map)>>null

		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(500).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_SYS_APPL"))
				.body("appStatusCode", CoreMatchers.equalTo("602"))
				.body("appInfo", CoreMatchers.equalTo("Null Response returned from prepareDataForAsyncCall()"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}

	def "retrigger q a r sync call"() {
		given:
		HashMap associatedMembers = readJsonFileToMap("mockResponse/AssociatedMemberRetriggerResp.json") as HashMap
		HashMap cgResponse = readJsonFileToMap("mockResponse/CGSyncResponse.json") as HashMap;
		HashMap asyncCallResponse = readJsonFileToMap("mockResponse/DataForAsyncCallResponse.json") as HashMap;
		String req = '{ "accountType": "TITAN", "ban": "VD0015088" }'

		getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>>associatedMembers;
		cgRestClient.getCGSyncCall(_ as HashMap)>> cgResponse
		retriggerQARQueueHelper.prepareDataForAsyncCall(_ as Map,_ as Map)>>asyncCallResponse
		retriggerQARQueueHelper.makeAsyncCall(_ as ArrayList,_ as Map)>>null

		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(500).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_SYS_APPL"))
				.body("appStatusCode", CoreMatchers.equalTo("602"))
				.body("appInfo", CoreMatchers.equalTo("Null Response returned from makeAsyncCall()"))
				.body("error.errorId",CoreMatchers.equalTo("MS_MPSYS_BE_602"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}


	/*def "retrigger q a r success with accessId"() {
		given:
		HashMap slidInfo = readJsonFileToMap("mockResponse/SlidInfoResponse.json")
		HashMap cgResponse = readJsonFileToMap("mockResponse/CGSyncResponse.json") as HashMap;
		HashMap asyncCallResponse = readJsonFileToMap("mockResponse/DataForAsyncCallResponse.json") as HashMap;
		HashMap resultMap = new HashMap();
		resultMap.put("appStatusMsg", "SUCCESS");
		resultMap.put("appStatusCode", "0");
		resultMap.put("appInfo", "RetriggerQAR Message sent successfully from sendmessagetoQueue");
		resultMap.put("appCategoryCode","0")
		String req = '{ "accountType": "TITAN", "accessId": "qay2002dt2372cs40010" }'

		getInfoByMaskDBHelperObj.getInfoByMask(_ as HashMap)>>slidInfo;
		cgRestClient.getCGSyncCall(_ as HashMap)>> cgResponse
		retriggerQARQueueHelper.prepareDataForAsyncCall(_ as Map,_ as Map)>>asyncCallResponse
		retriggerQARQueueHelper.makeAsyncCall(_ as ArrayList,_ as Map)>>resultMap


		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(200).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
				.body("appStatusCode", CoreMatchers.equalTo("0"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}*/


}
