package com.att.idp.idgraphuserregistrationms.integration.spec

import groovy.json.JsonSlurper
import io.restassured.RestAssured
import io.restassured.response.Response
import spock.lang.Specification

import java.net.URI
import java.util.Locale

/**
 * QG7 Integration Test - Heartbeat endpoint verification
 *
 * This test verifies the deployed IDGraphUserRegistrationMs service is alive and healthy.
 * It runs against the live deployed service with no mocks.
 *
 * OMNI Compliance:
 * - Spec suffix: *ITSpec.groovy (testing-foundation.md E1)
 * - Spock structure: then: 0 * _, assertions in and: (testing-foundation.md E2)
 * - No mocks: Real HTTP calls only (QG7 standard)
 * - Constants for paths (java-coding-standards.md D6)
 */
class UserRegistrationHeartbeatITSpec extends Specification {

    // Endpoint path defined as a constant — never inline (java-coding-standards.md D6)
    static final String HEARTBEAT_PATH = "/msapi/actuator/heartbeat"
    static final String EXPECTED_JSON_CONTENT_TYPE = "application/json"

    private static String resolveBaseUrl(String rawBaseUrl) {
        assert rawBaseUrl != null && !rawBaseUrl.trim().isEmpty() : "BASE_URL system property must be set"

        String normalized = rawBaseUrl.replace('\u00A0', ' ').trim()
        def matcher = normalized =~ /(https?:\/\/[^\s]+)/
        assert matcher.find() : "BASE_URL must include a valid http(s) URL, got: ${rawBaseUrl}"

        String extracted = matcher.group(1).replaceAll('/+$', '')
        URI uri = new URI(extracted)
        assert uri.scheme != null && uri.host != null : "BASE_URL must include scheme and host, got: ${extracted}"

        return extracted
    }

    def "Heartbeat returns 200 and status UP"() {
        given: "A deployed service base URL"
        String baseUrl = resolveBaseUrl(System.getProperty("BASE_URL"))
        String url = baseUrl + HEARTBEAT_PATH

        when: "GET heartbeat is called against the deployed service"
        Response response = RestAssured.given()
                .relaxedHTTPSValidation()
                .accept(EXPECTED_JSON_CONTENT_TYPE)
                .get(url)
        String responseBody = response.body() != null ? response.body().asString() : ""
        String contentType = response.contentType()
        String normalizedContentType = contentType != null ? contentType.toLowerCase(Locale.ROOT) : ""

        if (!normalizedContentType.contains(EXPECTED_JSON_CONTENT_TYPE)) {
            throw new AssertionError(
                    "Expected JSON content-type for ${url} but got '${contentType}'. " +
                            "HTTP status=${response.statusCode()}, body starts with='${responseBody.take(200)}'")
        }

        Map body = new JsonSlurper().parseText(responseBody) as Map

        then: "No mock interactions — this is a real HTTP call, no mocks are defined"
        0 * _

        and: "Pod is alive and reporting healthy"
        assert response != null : "Response must not be null"
        assert response.statusCode() == 200 : "Expected HTTP 200 but got: ${response.statusCode()}"
        assert normalizedContentType.contains(EXPECTED_JSON_CONTENT_TYPE) :
                "Expected content-type to include '${EXPECTED_JSON_CONTENT_TYPE}' but got '${contentType}'"
        assert body["status"] == "UP" : "Expected status 'UP' but got: ${body['status']}"
    }
}
