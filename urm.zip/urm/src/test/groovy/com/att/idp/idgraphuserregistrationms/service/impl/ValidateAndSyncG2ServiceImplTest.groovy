package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.helper.ValidateAndSyncG2Helper
import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.idp.idgraphuserregistrationms.resource.response.SyncUserProfileResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.junit.jupiter.api.Assertions
import spock.lang.Specification

import jakarta.ws.rs.core.MultivaluedMap


class ValidateAndSyncG2ServiceImplTest extends Specification {

    def validateAndSyncG2ServiceImplObj =new ValidateAndSyncG2ServiceImpl()

    ValidateAndSyncG2Helper validateAndSyncG2HelperObj=Mock(ValidateAndSyncG2Helper)

    SyncUserProfileRequest validateAndSuncG2Request = null

    public MultivaluedMap<String, String> requestHeader = null


    def setup() throws Exception {
        validateAndSyncG2ServiceImplObj.validateAndSyncG2Helper = validateAndSyncG2HelperObj
        validateAndSuncG2Request = new SyncUserProfileRequest()
        validateAndSuncG2Request.callingSystemId = 'IDP'
        validateAndSuncG2Request.ban = '112222222'
        validateAndSuncG2Request.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
        validateAndSuncG2Request.agentId = '12345'
        validateAndSuncG2Request.transactionName = 'validateAndSyncG2'
    }


    def "test validateandsyncg2 null case"() {
        when:
        SyncUserProfileResponse response = validateAndSyncG2ServiceImplObj.validateAndSyncG2(validateAndSuncG2Request,requestHeader)

        then:
        response.appInfo == 'Null response from validateAndSyncG2Helper.validateAndSyncG2'
        HashMap hmResponse = new HashMap()

        when:
        hmResponse[MPSDefs.APP_STATUS_CODE] = null
        validateAndSyncG2HelperObj.validateAndSyncG2(_)>>hmResponse

        and:
        response = validateAndSyncG2ServiceImplObj.validateAndSyncG2(validateAndSuncG2Request, requestHeader)

        then:
        response.appInfo == 'Null response from validateAndSyncG2Helper.validateAndSyncG2'
    }


    def "test validateandsyncg2 success case"() {
        given:
        HashMap hmResponse = new HashMap()
        hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
        hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
        hmResponse['appInfo'] = 'Success'
        validateAndSyncG2HelperObj.validateAndSyncG2(_)>>hmResponse

        when:
        SyncUserProfileResponse response = validateAndSyncG2ServiceImplObj.validateAndSyncG2(validateAndSuncG2Request, requestHeader)

        then:
        response != null
        response.idpTraceId != null
        response.transactionName == 'validateAndSyncG2'
    }
}
