package com.att.idp.idgraphuserregistrationms.resource.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.request.validator.EmailAppPasswordRequestValidator
import com.att.idp.idgraphuserregistrationms.resource.response.EmailAppPasswordResponse
import com.att.idp.idgraphuserregistrationms.service.ListEmailAppPasswordService
import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.Response
import spock.lang.Specification

import java.sql.SQLException

class EmailAppPasswordResourceImplTest extends Specification {

    EmailAppPasswordResourceImpl resource
    EmailAppPasswordRequestValidator mockValidator
    ListEmailAppPasswordService mockListEmailAppPasswordService
    HttpHeaders mockHeaders

    void setup() {
        mockValidator = Mock(EmailAppPasswordRequestValidator)
        mockListEmailAppPasswordService = Mock(ListEmailAppPasswordService)
        mockHeaders = Mock(HttpHeaders)
        resource = new EmailAppPasswordResourceImpl(mockValidator, mockListEmailAppPasswordService, null, null, null)
    }

    def "should return validation error response when validator returns non-null"() {
        given:
        EmailAppPasswordResponse validationError = new EmailAppPasswordResponse()
        validationError.setAppCategoryCode("3")

        when:
        def response = resource.listEmailAppPassword("user1", "att.net", null, mockHeaders)

        then:
        1 * mockValidator.emailPasswordReqValidator(_, _, _, _) >> validationError
        0 * mockListEmailAppPasswordService.listEmailAppPassword(_, _, _, _)

        and:
        response != null
        response.status == Response.Status.BAD_REQUEST.statusCode
    }

    def "should return not found response when service returns error"() {
        given:
        EmailAppPasswordResponse notFoundResponse = new EmailAppPasswordResponse()
        notFoundResponse.setAppCategoryCode("3")
        notFoundResponse.setAppStatusCode("285")

        when:
        def response = resource.listEmailAppPassword("user1", "att.net", null, mockHeaders)

        then:
        1 * mockValidator.emailPasswordReqValidator(_, _, _, _) >> null
        1 * mockListEmailAppPasswordService.listEmailAppPassword(_, _, _, _) >> notFoundResponse

        and:
        response != null
        response.status == Response.Status.BAD_REQUEST.statusCode
    }

    def "should return not found when service returns empty password list"() {
        given:
        EmailAppPasswordResponse notFoundResponse = new EmailAppPasswordResponse()
        notFoundResponse.setAppCategoryCode("3")
        notFoundResponse.setAppStatusCode("285")
        notFoundResponse.setAppInfo("User not found")

        when:
        def response = resource.listEmailAppPassword("user1", "att.net", null, mockHeaders)

        then:
        1 * mockValidator.emailPasswordReqValidator(_, _, _, _) >> null
        1 * mockListEmailAppPasswordService.listEmailAppPassword(_, _, _, _) >> notFoundResponse

        and:
        response != null
    }

    def "should handle InvalidInputDataException"() {
        when:
        resource.listEmailAppPassword("user1", "att.net", null, mockHeaders)

        then:
        1 * mockValidator.emailPasswordReqValidator(_, _, _, _) >> { throw new InvalidInputDataException("bad input") }
        0 * mockListEmailAppPasswordService.listEmailAppPassword(_, _, _, _)

        and:
        InvalidInputDataException ex = thrown()
        ex.message == "bad input"
    }

    def "should handle SQLException root cause"() {
        given:
        def sqlException = new SQLException("DB error")
        mockHeaders.getHeaderString(_) >> "trace-7"

        when:
        def response = resource.listEmailAppPassword("user1", "att.net", null, mockHeaders)

        then:
        1 * mockValidator.emailPasswordReqValidator(_, _, _, _) >> null
        1 * mockListEmailAppPasswordService.listEmailAppPassword(_, _, _, _) >> { throw new RuntimeException("wrapper", sqlException) }

        and:
        response != null
    }

    def "should handle generic exception"() {
        given:
        mockHeaders.getHeaderString(_) >> "trace-8"

        when:
        def response = resource.listEmailAppPassword("user1", "att.net", null, mockHeaders)

        then:
        1 * mockValidator.emailPasswordReqValidator(_, _, _, _) >> null
        1 * mockListEmailAppPasswordService.listEmailAppPassword(_, _, _, _) >> { throw new NullPointerException("npe") }

        and:
        response != null
    }
}
