package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import spock.lang.Specification

class GetLockOutsDBHelperTest extends Specification {
	String stTransactionId = null
    Logger logger = null
    HashMap inpParamHash = CommonUtil.hashMap

    String stAppStatusMsg
    String stAppInfo

    def testObj = new GetLockOutsDBHelper()

    JdbcTemplate jdbcTemplate = Mock(JdbcTemplate)
    ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)

    HashMap hmResult
    HashMap MemServices = CommonUtil.hashMap

    List<Object> objectList = null
    private static String dateFormat = 'MMDDYYYY HH24:mi:ss'
    List alQueryResponse = new ArrayList()
    HashMap hmQueryResponse = CommonUtil.hashMap

    static String queryLockOutSql


    def setup() {
    testObj.jdbcTemplate=jdbcTemplate
    testObj.errorMetricHandler=errorMetricHandler
		queryLockOutSql = 'select l.lockout_id, l.lockout_name, c.set_number, c.attempts_allowed, c.lock_type, c.lockout_minutes, c.reinitialize_interval_minutes '+
				' from LOCKOUT l, LOCKOUTCONFIG c ' + ' where l.lockout_id = c.lockout_id '+
				' order by l.lockout_id ASC, c.set_number ASC '

        objectList = new ArrayList<Object>()

        logger = LoggerFactory.getLogger('AddAssociation')
        //System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')

        hmQueryResponse['lockout_id'] = 'Test1234'
        hmQueryResponse['lockout_name'] = 'TestAccouint'
        hmQueryResponse['set_number'] = '12345'
        hmQueryResponse['attempts_allowed'] = '2'
        hmQueryResponse['lock_type'] = 'hard'
		hmQueryResponse['lockout_minutes'] = '20'
		hmQueryResponse['reinitialize_interval_minutes'] = '30'

	}


    def "get lockouts"() {
        given:
        alQueryResponse.add(hmQueryResponse)
      jdbcTemplate.queryForList(new String(queryLockOutSql)) >> alQueryResponse
		HashMap hm = CommonUtil.hashMap
		hm['Test1234'] = alQueryResponse
        when:
        hmResult = testObj.lockOuts
        then:
        hmResult == hm

    }


    def "get lockouts empty"() {
        given:
      jdbcTemplate.queryForList(new String(queryLockOutSql)) >> alQueryResponse
        hmResult = testObj.lockOuts
		stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]
        then:
        stAppStatusMsg == 'REC_NOT_FOUND'

    }

}
