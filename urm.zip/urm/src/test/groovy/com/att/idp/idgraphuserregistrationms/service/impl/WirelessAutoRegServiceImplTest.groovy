package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.helper.WirelessAutoRegHelper
import com.att.idp.idgraphuserregistrationms.resource.request.WirelessAutoRegRequest
import com.att.idp.idgraphuserregistrationms.resource.response.WirelessAutoRegResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.mockito.junit.jupiter.MockitoExtension
import spock.lang.Specification

import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap


class WirelessAutoRegServiceImplTest extends Specification {
	

	def wirelessAutoRegServiceImplObj =new WirelessAutoRegServiceImpl()
	 WirelessAutoRegHelper wirelessAutoRegHelperObj=Mock(WirelessAutoRegHelper)

	private WirelessAutoRegRequest requestObj = null

	public MultivaluedMap<String, String> requestHeader = null
	private Map<String, String> headers = new HashMap<>()


	def setup() throws Exception {
		wirelessAutoRegServiceImplObj.wirelessAutoRegHelper = wirelessAutoRegHelperObj
		requestObj = new WirelessAutoRegRequest()
		requestHeader = new MultivaluedHashMap<>(headers)
		requestObj.firstName = 'Rich'
		requestObj.lastName = 'Att'
		requestObj.contactEmail = 'rich3245@att.com'
		requestObj.serviceName = 'MOBILITY'
		requestObj.sorId = '11'
		requestObj.sorInvariantId = '13535727257'
		requestObj.callingSystemId = 'IDP'
		requestObj.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
	}


	def "test wireless auto reg null response"() {
		

		when:
		WirelessAutoRegResponse response = wirelessAutoRegServiceImplObj.wirelessAutoReg(requestObj, requestHeader)

		then:
		response.appInfo == 'Null response from wirelessAutoRegHelper.registerWirelessUser'
		Map<String, Object> hmResponse = new HashMap()

		when:
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_163748566777'
		hmResponse[MPSDefs.APP_STATUS_CODE] = null
		wirelessAutoRegHelperObj.registerWirelessUser(_)>>hmResponse
		response = wirelessAutoRegServiceImplObj.wirelessAutoReg(requestObj, requestHeader)

		then:
		response.appInfo == 'Null response from wirelessAutoRegHelper.registerWirelessUser'

	}


	def "test wireless auto reg success"() {

		given:
		Map<String, Object> hmResponse = new HashMap()
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_163748566777'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['appInfo'] = 'Success'

		hmResponse['ErrorEnum'] = CommonDefs.COMMON_SUCCESS_MSG
		wirelessAutoRegHelperObj.registerWirelessUser(_)>>hmResponse

		when:
		WirelessAutoRegResponse response = wirelessAutoRegServiceImplObj.wirelessAutoReg(requestObj, requestHeader)

		then:
		response.appStatusCode == '0'
	}

	def "test wireless auto reg transaction rollback"() {
		given:
		Map<String, Object> hmResponse = new HashMap()
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_163748566777'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['isTransactionRollback'] = 'true'
		wirelessAutoRegHelperObj.registerWirelessUser(_) >> hmResponse

		when:
		wirelessAutoRegServiceImplObj.wirelessAutoReg(requestObj, requestHeader)

		then:
		thrown(InvalidInputDataException.class )
	}
}
