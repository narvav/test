package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.AccountAutoRegDBHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Specification

import jakarta.ws.rs.core.Response

class AutoGenTempAIDHelperTest extends Specification {
	
	HashMap hmInput = new HashMap()
    HashMap hmSor = new HashMap()
    List lst = new ArrayList()
    HashMap hmResult = null
    HashMap hmSuccessResponse = new HashMap()
    HashMap hmErrorResponse = new HashMap()
    String transId = 'AGTAIDHtest123'
    Response response = null
    private Logger logger = null
    private String stAppInfo
    HashMap hmResponse = null
	
	UserProfileAutoregUtility oUserProfileAutoregUtility = Mock (UserProfileAutoregUtility)

   AccountAutoRegDBHelper accountAutoRegDBHelper = Mock (AccountAutoRegDBHelper)
   
   def autogenTempAIDHelper = new AutoGenTempAIDHelper()

        def setup() {
        
        autogenTempAIDHelper.oUserProfileAutoregUtility=oUserProfileAutoregUtility
        autogenTempAIDHelper.accountAutoRegDBHelper=accountAutoRegDBHelper
        
        logger = LoggerFactory.getLogger(AutoGenTempAIDHelperTest.class)

        hmSuccessResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        hmErrorResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_LENGTH_NUM, 'Error')

        hmInput[CommonDefs.DB_FIRSTNAME] = 'test'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.IS_EXTERNAL_CALL] = 'Y'
        hmInput[CommonDefs.TRANSACTION_NAME] = 'AutogenTempAccessId'
        hmInput[CommonDefs.TRANSACTION_ID] = transId
        hmInput[CommonDefs.DB_LASTNAME] = 'testing'
        hmInput[CommonDefs.CONTACT_EMAIL] = 'test@testing.com'
        hmInput[CommonDefs.AGENT_ID] = 'tt1234'
        hmInput['contactEmailRTValidFlag'] = 'Y'

        hmSor['sorName'] = 'LS'
        hmSor['sorInvariantId'] = '1234567890123'
        lst.clear()
        lst.add(hmSor)
        hmInput['sorInvariantIdList'] = lst
    }


    def "test utility error"()  {
        given:
        oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap)>>null
        hmResult = autogenTempAIDHelper.autogenTempAccessId(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'oUserProfileAutoregUtility.generateAutoGenAccessId returned empty response.'
    }


    def "test utility error2"()  {
        given:
        //oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap) >> hmErrorResponse
        oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap) >> hmErrorResponse
        hmResult = autogenTempAIDHelper.autogenTempAccessId(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_STATUS_CODE]
        then:
        stAppInfo == '104'
    }


    def "test utility add user error"()  {
        given:
        hmSuccessResponse['validSLID'] = 'qay_test'
        oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap) >> hmSuccessResponse
        oUserProfileAutoregUtility.callAddUser(_ as HashMap,_ as String) >> hmErrorResponse
        hmResult = autogenTempAIDHelper.autogenTempAccessId(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_STATUS_CODE]
        then:
        stAppInfo == '104'
    }


    def "test account reg error"()  {
        given:
        hmSuccessResponse['validSLID'] = 'qay_test'
        oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap) >> hmSuccessResponse
        hmSuccessResponse['guid'] = '12345678'
        oUserProfileAutoregUtility.callAddUser(_ as HashMap,_ as String) >> hmSuccessResponse
        accountAutoRegDBHelper.updateAccountAutoReg(_ as HashMap)>> hmErrorResponse
        hmResult = autogenTempAIDHelper.autogenTempAccessId(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_STATUS_CODE]
        then:
        stAppInfo == '104'
    }


    def "test auto gen temp a i d success"() 
	{
        given:
        hmSuccessResponse['validSLID'] = 'qay_test'
        oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap) >> hmSuccessResponse
		hmSuccessResponse['guid'] = '12345678'
		oUserProfileAutoregUtility.callAddUser(_ as HashMap,_ as String) >> hmSuccessResponse
		accountAutoRegDBHelper.updateAccountAutoReg(_ as HashMap)>> hmSuccessResponse
		hmResult = autogenTempAIDHelper.autogenTempAccessId(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
    }


    def "test auto gen temp a i d exception"()
	{
        given:
        oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap) >> { throw new RuntimeException('null') }
        hmResult = autogenTempAIDHelper.autogenTempAccessId(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppInfo == 'ERR_SYS_APPL'
    }
	

}

