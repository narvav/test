package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.helper.DeleteEmailAppPasswordHelper
import com.att.idp.idgraphuserregistrationms.resource.request.DeleteEmailAppPasswordRequest
import com.att.idp.idgraphuserregistrationms.resource.response.EmailAppPasswordResponse
import com.att.idp.idgraphuserregistrationms.utils.ProfileOrchestrationConstants
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.MPSDefs
import jakarta.ws.rs.core.HttpHeaders
import spock.lang.Specification

class DeleteEmailAppPasswordServiceImplSpec extends Specification {

    DeleteEmailAppPasswordHelper deleteEmailAppPasswordHelper
    DeleteEmailAppPasswordServiceImpl serviceUnderTest
    HttpHeaders mockHttpHeaders

    void setup() {
        deleteEmailAppPasswordHelper = Mock(DeleteEmailAppPasswordHelper)
        mockHttpHeaders = Mock(HttpHeaders)
        serviceUnderTest = new DeleteEmailAppPasswordServiceImpl(deleteEmailAppPasswordHelper)
    }

    def "should call helper and return success response with guid and idpTraceId sourced from request"() {
        given:
        DeleteEmailAppPasswordRequest request = new DeleteEmailAppPasswordRequest()
        request.guid = "12345"
        request.passwordName = "imap"
        request.idpTraceId = "trace123:trace123:0:0"

        HashMap helperResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)

        when:
        EmailAppPasswordResponse response = serviceUnderTest.deleteEmailAppPassword(request, mockHttpHeaders)

        then:
        1 * deleteEmailAppPasswordHelper.deleteEmailAppPassword({ Map<String, Object> input ->
            input.get("guid") == "12345" && input.get("passwordName") == "imap"
        }, mockHttpHeaders) >> helperResponse
        0 * _

        and:
        response != null
        response.guid == "12345"
        response.idpTraceId == "trace123:trace123:0:0"
    }

    def "should resolve guidForResp from DB_MEMBER_NUM when helper sets it on hmInput"() {
        given:
        DeleteEmailAppPasswordRequest request = new DeleteEmailAppPasswordRequest()
        request.memberId = "testUser"
        request.domain = "att.net"
        request.passwordName = "imap"
        request.idpTraceId = "trace-member"
        String resolvedMemberNum = "99999"

        HashMap helperResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)

        when:
        EmailAppPasswordResponse response = serviceUnderTest.deleteEmailAppPassword(request, mockHttpHeaders)

        then:
        1 * deleteEmailAppPasswordHelper.deleteEmailAppPassword(_, mockHttpHeaders) >> { Map<String, Object> hmInput, HttpHeaders hdr ->
            hmInput.put(MPSDefs.DB_MEMBER_NUM, resolvedMemberNum)
            return helperResponse
        }
        0 * _

        and:
        response != null
        response.guid == resolvedMemberNum
        response.idpTraceId == "trace-member"
    }

    def "should throw InvalidInputDataException when helper response contains isTransactionRollback"() {
        given:
        DeleteEmailAppPasswordRequest request = new DeleteEmailAppPasswordRequest()
        request.guid = "12345"
        request.passwordName = "imap"
        request.idpTraceId = "trace-rollback"

        HashMap helperResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        helperResponse.put("isTransactionRollback", "Y")

        when:
        serviceUnderTest.deleteEmailAppPassword(request, mockHttpHeaders)

        then:
        1 * deleteEmailAppPasswordHelper.deleteEmailAppPassword(_, mockHttpHeaders) >> helperResponse
        0 * _

        and:
        thrown(InvalidInputDataException)
    }

    def "should return error response when helper returns not-found status code 121 and idpTraceId overrides header value"() {
        given:
        DeleteEmailAppPasswordRequest request = new DeleteEmailAppPasswordRequest()
        request.memberId = "unknownUser"
        request.domain = "att.net"
        request.idpTraceId = "trace-from-request"

        HashMap helperResponse = new HashMap()
        helperResponse.put(CommonDefs.COMMON_APP_INFO, "User not found")
        helperResponse.put(MPSDefs.APP_STATUS_CODE, "121")
        helperResponse.put(ProfileOrchestrationConstants.IDP_TRACE_ID, "trace-from-header")

        when:
        EmailAppPasswordResponse response = serviceUnderTest.deleteEmailAppPassword(request, mockHttpHeaders)

        then:
        1 * deleteEmailAppPasswordHelper.deleteEmailAppPassword(_, mockHttpHeaders) >> helperResponse
        0 * _

        and:
        response != null
        response.errors != null
        response.idpTraceId == "trace-from-request"
    }

    def "should use request guid as guidForResp fallback when DB_MEMBER_NUM is absent in hmInput"() {
        given:
        DeleteEmailAppPasswordRequest request = new DeleteEmailAppPasswordRequest()
        request.guid = "guid-fallback"
        request.passwordName = "testPwd"
        request.idpTraceId = "trace-fallback"

        HashMap helperResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)

        when:
        EmailAppPasswordResponse response = serviceUnderTest.deleteEmailAppPassword(request, mockHttpHeaders)

        then:
        1 * deleteEmailAppPasswordHelper.deleteEmailAppPassword(_, mockHttpHeaders) >> helperResponse
        0 * _

        and:
        response != null
        response.guid == "guid-fallback"
        response.idpTraceId == "trace-fallback"
    }

    def "should handle null idpTraceId in request"() {
        given:
        DeleteEmailAppPasswordRequest request = new DeleteEmailAppPasswordRequest()
        request.guid = "12345"
        request.passwordName = "imap"

        HashMap helperResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)

        when:
        EmailAppPasswordResponse response = serviceUnderTest.deleteEmailAppPassword(request, mockHttpHeaders)

        then:
        1 * deleteEmailAppPasswordHelper.deleteEmailAppPassword(_, mockHttpHeaders) >> helperResponse
        0 * _

        and:
        response != null
        response.idpTraceId == null
    }

}
