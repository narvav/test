package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.helper.QueryUnifiedTOSHelper
import com.att.idp.idgraphuserregistrationms.resource.request.QueryUnifiedTOSRequest
import com.att.idp.idgraphuserregistrationms.resource.response.QueryUnifiedTOSResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import spock.lang.Specification

import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap

class QueryUnifiedTOSServiceImplTest extends Specification {

	def queryUnifiedTOSServiceImplObj=new QueryUnifiedTOSServiceImpl()

	QueryUnifiedTOSHelper queryUnifiedTOSHelperObj=Mock(QueryUnifiedTOSHelper)

	QueryUnifiedTOSRequest requestObj = null
	public MultivaluedMap<String, String> requestHeader = null
	private Map<String, String> headers = new HashMap<>()

	def setup() throws Exception {
		queryUnifiedTOSServiceImplObj.queryUnifiedTOSHelper = queryUnifiedTOSHelperObj
		requestObj = new QueryUnifiedTOSRequest()
		requestHeader = new MultivaluedHashMap<>(headers)
		requestObj.agentId = '1234'
		requestObj.ban = '12345'
		requestObj.callingSystemId = 'IDP'
		requestObj.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
	}

	def "test queryunifiedtos null response"() {

		when:
		QueryUnifiedTOSResponse response = queryUnifiedTOSServiceImplObj.queryUnifiedTOS(requestObj, requestHeader)

		then:
		response.appInfo == 'Null response from queryUnifiedTOSHelper.queryUnifiedTOS'
		Map<String, Object> hmResponse = new HashMap()

		when:
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_163748566777'
		hmResponse[MPSDefs.APP_STATUS_CODE] = null
		queryUnifiedTOSHelperObj.queryUnifiedTOS(_ as Map<String, Object>) >> hmResponse
		response = queryUnifiedTOSServiceImplObj.queryUnifiedTOS(requestObj, requestHeader)

		then:
		response.appInfo == 'Null response from queryUnifiedTOSHelper.queryUnifiedTOS'

	}

	def "test queryunifiedtos success"() {
		given:
		Map<String, Object> hmResponse = new HashMap()
		HashMap provisionedServiceHm = new HashMap<>()
		provisionedServiceHm['serviceId'] = '8'
		provisionedServiceHm['serviceName'] = 'HSIA'
		ArrayList provisionedServices = new ArrayList<>()
		provisionedServices.add(provisionedServiceHm)
		HashMap memberServiceHm = new HashMap<>()
		memberServiceHm['serviceId'] = '8'
		memberServiceHm['serviceName'] = 'HSIA'
		memberServiceHm['serviceStatus'] = 'Enabled'
		ArrayList memberServicesList = new ArrayList<>()
		memberServicesList.add(memberServiceHm)

		Map<String, Object> tosFlags = new HashMap<>()
		tosFlags[CommonDefs.E911_TOS_ACCEPTANCE] = 'Y'
		tosFlags[CommonDefs.E911_TOS_ACCEPTANCE] = ''
		tosFlags[CommonDefs.HSIA_TOS_ACCEPTANCE] = 'Y'
		tosFlags[CommonDefs.HSIA_TOS_DATE] = ''
		tosFlags[CommonDefs.IPTV_TOS_ACCEPTANCE] = 'Y'
		tosFlags[CommonDefs.IPTV_TOS_DATE] = ''
		tosFlags[CommonDefs.WDM_TOS_ACCEPTANCE] = 'N'
		tosFlags[CommonDefs.WDM_TOS_DATE] = ''
		tosFlags[CommonDefs.WVM_TOS_ACCEPTANCE] = 'N'
		tosFlags[CommonDefs.WVM_TOS_DATE] = ''
		hmResponse['tosFlags'] = tosFlags
		hmResponse['provisionedServices'] = provisionedServices
		hmResponse['memberServicesList'] = memberServicesList
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_163748566777'

		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse[CommonDefs.ACCOUNT_TYPE] = 'B'
		hmResponse[CommonDefs.ACCOUNT_SUB_TYPE] = 'S'
		hmResponse[CommonDefs.BAN] = '1234'
		hmResponse[CommonDefs.BAN_LINKED_PMID] = '2324'
		hmResponse[CommonDefs.DATE_OF_BIRTH] = '123345'
		hmResponse[CommonDefs.FORCE_MID_DOMAIN] = 'asd'
		hmResponse[CommonDefs.FORCE_MID_HANDLE] = 'asfd'
		hmResponse[CommonDefs.KEY_ORDER_DUE_DATE] = '2423532'
		hmResponse[CommonDefs.KEY_ORDER_TAKEN_DATE] = '2324'
		hmResponse[CommonDefs.RG_ACTIVATED] = 'Y'
		hmResponse[CommonDefs.TN_ACTIVATED] = 'Y'
		hmResponse['appInfo'] = 'Success'

		hmResponse['ErrorEnum'] = CommonDefs.COMMON_SUCCESS_MSG
		queryUnifiedTOSHelperObj.queryUnifiedTOS(_ as Map<String, Object>) >> hmResponse

		when:
		QueryUnifiedTOSResponse response = queryUnifiedTOSServiceImplObj.queryUnifiedTOS(requestObj, requestHeader)

		then:
		response.appStatusCode == '0'
	}


	def "test queryUnifiedTOS with null response"() {
		given:
		Map<String, Object> hmResponse = new HashMap()
		queryUnifiedTOSHelperObj.queryUnifiedTOS(_ as Map<String, Object>) >> hmResponse

		when:
		QueryUnifiedTOSResponse response = queryUnifiedTOSServiceImplObj.queryUnifiedTOS(requestObj, requestHeader)

		then:
		response.appInfo == 'Null response from queryUnifiedTOSHelper.queryUnifiedTOS'
	}

	def "test queryUnifiedTOS with success response"() {
		given:
		Map<String, Object> hmResponse = new HashMap()
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_163748566777'
		hmResponse['idp-trace-id'] = requestObj.idpTraceId
		hmResponse['appInfo'] = 'Success'
		queryUnifiedTOSHelperObj.queryUnifiedTOS(_ as Map<String, Object>) >> hmResponse

		when:
		QueryUnifiedTOSResponse response = queryUnifiedTOSServiceImplObj.queryUnifiedTOS(requestObj, requestHeader)

		then:
		response.appStatusCode == '0'
		response.appInfo == 'Success'
	}
}
