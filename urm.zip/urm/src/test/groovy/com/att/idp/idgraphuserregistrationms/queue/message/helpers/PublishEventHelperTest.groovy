package com.att.idp.idgraphuserregistrationms.queue.message.helpers;

import com.att.idp.idgraph.events.service.EventPublisher
import com.att.idp.idgraphuserregistrationms.queue.message.sender.JMSQueueSender
import com.att.idp.idgraphuserregistrationms.utils.ProfileOrchestrationConstants
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.CommonUtil
import spock.lang.Specification
import spock.lang.Unroll

/**
 * Spock tests for PublishEventHelper covering all flag combinations and edge cases.
 * Test class name ends with Test per project convention.
 */
class PublishEventHelperTest extends Specification {

    // Dependencies with concrete types
    JMSQueueSender jmsQueueSender
    FeatureManagerHelper featureManager
    EventPublisher eventPublisher

    // Class under test
    PublishEventHelper publishEventHelper

    // Common inputs with concrete types
    Map<String, Object> hmDbusInput
    Map<String, Object> hmInput

    def setup() {
        // Initialize mocks
        jmsQueueSender = Mock(JMSQueueSender)
        featureManager = Mock(FeatureManagerHelper)
        eventPublisher = Mock(EventPublisher)

        // Construct helper with explicit topic name (injected via constructor)
        String externalEventsNotificationsTopicName = "topic.external.events.notifications"
        publishEventHelper = new PublishEventHelper(jmsQueueSender, featureManager, eventPublisher, externalEventsNotificationsTopicName)

        // Initialize common maps
        hmDbusInput = CommonUtil.getHashMap()
        hmInput = CommonUtil.getHashMap()

        // Populate minimal required fields used by helper
        hmDbusInput.put(CommonDefs.TRANSACTION_NAME, "RegisterUser")
        hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, "mainHashKey-123")
        hmDbusInput.put(CommonDefs.MS_OPERTAION, "TestOperation")
        hmInput.put(ProfileOrchestrationConstants.IDPTRACEID, "trace-abc-123")
    }

    @Unroll
    def "should publish only to MQ when both flags are MQ for #scenarioName"() {
        given: "Feature flags are set to MQ/MQ and JMSQueueSender returns success"
        String featureAEHFlagName = "AEH_FLAG"
        String featureCLMFlagName = "CLM_FLAG"
        Map<String, Object> successResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success")

        // Mock feature flags
        1 * featureManager.getValue(featureAEHFlagName) >> "MQ"
        1 * featureManager.getValue(featureCLMFlagName) >> "MQ"

        // JMS is called once with original input and returns success
        1 * jmsQueueSender.send({ Map<String, Object> m -> m.get(CommonDefs.TRANSACTION_NAME) == hmDbusInput.get(CommonDefs.TRANSACTION_NAME) }) >> successResponse
        0 * eventPublisher._

        when: "publishEvent is invoked"
        Map<String, Object> result = publishEventHelper.publishEvent(featureAEHFlagName, featureCLMFlagName, hmDbusInput, hmInput)

        then: "Result indicates success from MQ path"
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CommonDefs.COMMON_SUCCESS_NUM)
        String appInfo = (String) result.get(CommonDefs.COMMON_APP_INFO)
        appInfo != null
        appInfo.toUpperCase().contains("SUCCESS")

        where: "Scenario name"
        scenarioName | _
        "MQ only - base" | null
    }

    @Unroll
    def "should publish only to AEH when both flags are AEH for #scenarioName"() {
        given: "Feature flags are AEH/AEH and EventPublisher succeeds"
        String featureAEHFlagName = "AEH_FLAG"
        String featureCLMFlagName = "CLM_FLAG"

        // Mock feature flags
        1 * featureManager.getValue(featureAEHFlagName) >> "AEH"
        1 * featureManager.getValue(featureCLMFlagName) >> "AEH"

        // EventPublisher called once with binding and key, returns true
        1 * eventPublisher.send("externalEventsNotifications", "mainHashKey-123", { Map<String, Object> m ->
            // AEH input enriched by helper
            m.get("msName") == "IDGraphUserRegistrationMS-" &&
            m.get("eventType") == hmDbusInput.get(CommonDefs.TRANSACTION_NAME) &&
            m.get(CommonDefs.TRANSACTION_ID) == hmInput.get(ProfileOrchestrationConstants.IDPTRACEID)
        }) >> true
        0 * jmsQueueSender._

        when: "publishEvent is called"
        Map<String, Object> result = publishEventHelper.publishEvent(featureAEHFlagName, featureCLMFlagName, hmDbusInput, hmInput)

        then: "Result is success reflecting AEH path"
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CommonDefs.COMMON_SUCCESS_NUM)
        String appInfo = (String) result.get(CommonDefs.COMMON_APP_INFO)
        appInfo != null
        appInfo.contains("Successfully published")

        where: "Scenario name"
        scenarioName | _
        "AEH only - base" | null
    }

    @Unroll
    def "should return failure when AEH publish returns false for #scenarioName"() {
        given: "AEH/AEH flags with EventPublisher returning false"
        String featureAEHFlagName = "AEH_FLAG"
        String featureCLMFlagName = "CLM_FLAG"

        1 * featureManager.getValue(featureAEHFlagName) >> "AEH"
        1 * featureManager.getValue(featureCLMFlagName) >> "AEH"

        // Publisher returns false indicating publish failure
        1 * eventPublisher.send("externalEventsNotifications", "mainHashKey-123", { Map<String, Object> m -> true }) >> false
        0 * jmsQueueSender._

        when:
        Map<String, Object> result = publishEventHelper.publishEvent(featureAEHFlagName, featureCLMFlagName, hmDbusInput, hmInput)

        then: "System application error returned"
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_SYS_APPL_NUM)
        String appInfo = (String) result.get(CommonDefs.COMMON_APP_INFO)
        appInfo != null
        appInfo.toLowerCase().contains("failed to publish")

        where:
        scenarioName | _
        "AEH failure - base" | null
    }

    @Unroll
    def "should handle exception when AEH publish throws for #scenarioName"() {
        given: "AEH/AEH flags with EventPublisher throwing an exception"
        String featureAEHFlagName = "AEH_FLAG"
        String featureCLMFlagName = "CLM_FLAG"

        1 * featureManager.getValue(featureAEHFlagName) >> "AEH"
        1 * featureManager.getValue(featureCLMFlagName) >> "AEH"

        // Use Spock idiom to throw from void/interaction in then block style
        1 * eventPublisher.send("externalEventsNotifications", "mainHashKey-123", { Map<String, Object> m -> true }) >> { throw new RuntimeException("AEH failure") }
        0 * jmsQueueSender._

        when:
        Map<String, Object> result = publishEventHelper.publishEvent(featureAEHFlagName, featureCLMFlagName, hmDbusInput, hmInput)

        then: "Result captures system error with message"
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_SYS_APPL_NUM)
        String appInfo = (String) result.get(CommonDefs.COMMON_APP_INFO)
        appInfo != null
        appInfo.contains("Error while sending event to AEH")

        where:
        scenarioName | _
        "AEH exception - base" | null
    }

    @Unroll
    def "should publish to BOTH when both flags are BOTH for #scenarioName"() {
        given: "BOTH/BOTH flags with both paths succeeding"
        String featureAEHFlagName = "AEH_FLAG"
        String featureCLMFlagName = "CLM_FLAG"
        Map<String, Object> mqSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success MQ")

        1 * featureManager.getValue(featureAEHFlagName) >> "BOTH"
        1 * featureManager.getValue(featureCLMFlagName) >> "BOTH"

        // AEH path
        1 * eventPublisher.send("externalEventsNotifications", "mainHashKey-123", { Map<String, Object> m -> true }) >> true
        // MQ path
        1 * jmsQueueSender.send({ Map<String, Object> m -> m.get(CommonDefs.TRANSACTION_NAME) == hmDbusInput.get(CommonDefs.TRANSACTION_NAME) }) >> mqSuccess

        when:
        Map<String, Object> result = publishEventHelper.publishEvent(featureAEHFlagName, featureCLMFlagName, hmDbusInput, hmInput)

        then: "Merged success response returned"
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CommonDefs.COMMON_SUCCESS_NUM)
        String appInfo = (String) result.get(CommonDefs.COMMON_APP_INFO)
        appInfo != null
        appInfo.toLowerCase().contains("successfully published event to both aeh and mq")

        where:
        scenarioName | _
        "BOTH success - base" | null
    }

    @Unroll
    def "should merge failure messages when BOTH and one path fails for #scenarioName"() {
        given: "BOTH/BOTH flags with AEH success and MQ failure"
        String featureAEHFlagName = "AEH_FLAG"
        String featureCLMFlagName = "CLM_FLAG"
        Map<String, Object> mqFailure = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "MQ failed to send message")

        1 * featureManager.getValue(featureAEHFlagName) >> "BOTH"
        1 * featureManager.getValue(featureCLMFlagName) >> "BOTH"

        // AEH success
        1 * eventPublisher.send("externalEventsNotifications", "mainHashKey-123", { Map<String, Object> m -> true }) >> true
        // MQ failure
        1 * jmsQueueSender.send(_ as Map<String, Object>) >> mqFailure

        when:
        Map<String, Object> result = publishEventHelper.publishEvent(featureAEHFlagName, featureCLMFlagName, hmDbusInput, hmInput)

        then: "Merged failure response returned"
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_SYS_APPL_NUM)
        String appInfo = (String) result.get(CommonDefs.COMMON_APP_INFO)
        appInfo != null
        appInfo.contains("MQ failed to send message")

        where:
        scenarioName | _
        "BOTH partial failure - base" | null
    }

    @Unroll
    def "should route notification events to AEH and others to MQ when flags MQ/AEH for #scenarioName"() {
        given: "Flags MQ/AEH with mixed events"
        String featureAEHFlagName = "AEH_FLAG"
        String featureCLMFlagName = "CLM_FLAG"

        // Prepare mixed events: one NotificationEvent, one OtherEvent
        List<Map<?, ?>> eventsData = new ArrayList<>()
        Map<String, Object> notifEvent = new HashMap<>()
        notifEvent.put(CommonDefs.EVENTNAME, CommonDefs.CONTEXT_NotificationEvent)
        Map<String, Object> otherEvent = new HashMap<>()
        otherEvent.put(CommonDefs.EVENTNAME, "SomeOtherEvent")
        eventsData.add(notifEvent)
        eventsData.add(otherEvent)
        hmDbusInput.put(CommonDefs.EVENTS_DATA, eventsData)

        1 * featureManager.getValue(featureAEHFlagName) >> "MQ"
        1 * featureManager.getValue(featureCLMFlagName) >> "AEH"

        // MQ should receive only other events
        1 * jmsQueueSender.send({ Map<String, Object> m ->
            List<Map<?, ?>> list = (List<Map<?, ?>>) m.get(CommonDefs.EVENTS_DATA)
            list.size() == 1 && "SomeOtherEvent" == list.get(0).get(CommonDefs.EVENTNAME)
        }) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "MQ success")

        // AEH should receive only notification events
        1 * eventPublisher.send("externalEventsNotifications", "mainHashKey-123", { Map<String, Object> m ->
            List<Map<?, ?>> list = (List<Map<?, ?>>) m.get(CommonDefs.EVENTS_DATA)
            list.size() == 1 && CommonDefs.CONTEXT_NotificationEvent == list.get(0).get(CommonDefs.EVENTNAME) &&
            m.get(CommonDefs.TRANSACTION_ID) == hmInput.get(ProfileOrchestrationConstants.IDPTRACEID)
        }) >> true

        when:
        Map<String, Object> result = publishEventHelper.publishEvent(featureAEHFlagName, featureCLMFlagName, hmDbusInput, hmInput)

        then: "Merged success response returned"
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CommonDefs.COMMON_SUCCESS_NUM)
        String appInfo = (String) result.get(CommonDefs.COMMON_APP_INFO)
        appInfo != null
        appInfo.toLowerCase().contains("successfully published event")

        where:
        scenarioName | _
        "MQ/AEH mixed routing" | null
    }

    @Unroll
    def "should route notification events to MQ and others to AEH when flags AEH/MQ for #scenarioName"() {
        given: "Flags AEH/MQ with mixed events"
        String featureAEHFlagName = "AEH_FLAG"
        String featureCLMFlagName = "CLM_FLAG"

        List<Map<?, ?>> eventsData = new ArrayList<>()
        Map<String, Object> notifEvent = new HashMap<>()
        notifEvent.put(CommonDefs.EVENTNAME, CommonDefs.CONTEXT_NotificationEvent)
        Map<String, Object> otherEvent = new HashMap<>()
        otherEvent.put(CommonDefs.EVENTNAME, "DifferentEvent")
        eventsData.add(notifEvent)
        eventsData.add(otherEvent)
        hmDbusInput.put(CommonDefs.EVENTS_DATA, eventsData)

        1 * featureManager.getValue(featureAEHFlagName) >> "AEH"
        1 * featureManager.getValue(featureCLMFlagName) >> "MQ"

        // MQ receives notification events only
        1 * jmsQueueSender.send({ Map<String, Object> m ->
            List<Map<?, ?>> list = (List<Map<?, ?>>) m.get(CommonDefs.EVENTS_DATA)
            list.size() == 1 && CommonDefs.CONTEXT_NotificationEvent == list.get(0).get(CommonDefs.EVENTNAME)
        }) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "MQ success")

        // AEH receives other events only
        1 * eventPublisher.send("externalEventsNotifications", "mainHashKey-123", { Map<String, Object> m ->
            List<Map<?, ?>> list = (List<Map<?, ?>>) m.get(CommonDefs.EVENTS_DATA)
            list.size() == 1 && "DifferentEvent" == list.get(0).get(CommonDefs.EVENTNAME)
        }) >> true

        when:
        Map<String, Object> result = publishEventHelper.publishEvent(featureAEHFlagName, featureCLMFlagName, hmDbusInput, hmInput)

        then:
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CommonDefs.COMMON_SUCCESS_NUM)
        String appInfo = (String) result.get(CommonDefs.COMMON_APP_INFO)
        appInfo != null
        appInfo.toLowerCase().contains("successfully published")

        where:
        scenarioName | _
        "AEH/MQ mixed routing" | null
    }

    @Unroll
    def "should publish to MQ and optionally AEH when flags MQ/BOTH for #scenarioName"() {
        given: "Flags MQ/BOTH and notification events present"
        String featureAEHFlagName = "AEH_FLAG"
        String featureCLMFlagName = "CLM_FLAG"

        List<Map<?, ?>> eventsData = new ArrayList<>()
        Map<String, Object> notifEvent = new HashMap<>()
        notifEvent.put(CommonDefs.EVENTNAME, CommonDefs.CONTEXT_NotificationEvent)
        eventsData.add(notifEvent)
        hmDbusInput.put(CommonDefs.EVENTS_DATA, eventsData)

        1 * featureManager.getValue(featureAEHFlagName) >> "MQ"
        1 * featureManager.getValue(featureCLMFlagName) >> "BOTH"

        // MQ receives full input
        1 * jmsQueueSender.send(_ as Map<String, Object>) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "MQ success")
        // AEH receives notification events
        1 * eventPublisher.send("externalEventsNotifications", "mainHashKey-123", _ as Map<String, Object>) >> true

        when:
        Map<String, Object> result = publishEventHelper.publishEvent(featureAEHFlagName, featureCLMFlagName, hmDbusInput, hmInput)

        then:
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CommonDefs.COMMON_SUCCESS_NUM)

        where:
        scenarioName | _
        "MQ/BOTH routing" | null
    }

    @Unroll
    def "should return invalid flag error for unknown combinations for #scenarioName"() {
        given: "Unknown flag combination triggers error"
        String featureAEHFlagName = "AEH_FLAG"
        String featureCLMFlagName = "CLM_FLAG"

        1 * featureManager.getValue(featureAEHFlagName) >> invalidAEH
        1 * featureManager.getValue(featureCLMFlagName) >> invalidCLM
        0 * jmsQueueSender._
        0 * eventPublisher._

        when:
        Map<String, Object> result = publishEventHelper.publishEvent(featureAEHFlagName, featureCLMFlagName, hmDbusInput, hmInput)

        then:
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_INVALID_DATA_NUM)
        String appInfo = (String) result.get(CommonDefs.COMMON_APP_INFO)
        appInfo != null
        appInfo.toLowerCase().contains("invalid feature flag values")


        where:
        scenarioName              | invalidAEH | invalidCLM
        "Invalid flags - case 1"  | "AEH"       | "BOTH"
        "Invalid flags - case 2"  | "BOTH"        | "MQ"
        "Invalid flags - case 3"  | "BOTH"       | "AEH"
    }

    @Unroll
    def "should return input validation error for AEH path with missing fields for #scenarioName"() {
        given: "AEH/AEH flags with missing msOperation or transactionId in AEH input"
        String featureAEHFlagName = "AEH_FLAG"
        String featureCLMFlagName = "CLM_FLAG"

        // Force AEH/AEH path
        1 * featureManager.getValue(featureAEHFlagName) >> "AEH"
        1 * featureManager.getValue(featureCLMFlagName) >> "AEH"

        // Provide input that will lead to validation error: remove required fields after enrichment
        // We simulate by clearing hmInput IDPTRACEID to make TRANSACTION_ID empty
        if (missingTxId) {
            hmInput.put(ProfileOrchestrationConstants.IDPTRACEID, "")
        }
        // Also simulate missing msOperation by erasing from map post-enrichment via Reflection (not accessible directly)
        // Instead, we rely on validateInputForAEH being called with AEH map missing msOperation; create a wrapper to intercept
        // Here, we temporarily set TRANSACTION_NAME but missing fields will cause error

        // EventPublisher should not be called when validation fails
        0 * eventPublisher._
        0 * jmsQueueSender._

        when:
        Map<String, Object> result = publishEventHelper.publishEvent(featureAEHFlagName, featureCLMFlagName, hmDbusInput, hmInput)

        then:
        // Expect invalid/empty data errors (depending on which field is missing)
        result.get(CommonDefs.COMMON_APP_STATUS_CODE).toString() in [String.valueOf(CErrorDefs.ERR_INVALID_DATA_NUM), String.valueOf(CErrorDefs.ERR_EMPTY_NUM)]

        where:
        scenarioName                 | missingTxId
        "Missing transactionId"      | true
    }

    @Unroll
    def "should throw error when important fields are missing #scenarioName"() {
        given: "BOTH/BOTH flags with missing important fields"
        String featureAEHFlagName = "AEH_FLAG"
        String featureCLMFlagName = "CLM_FLAG"

        Map<String, Object> hmDbusInput = CommonUtil.getHashMap()
        Map<String, Object> hmInput = CommonUtil.getHashMap()

        if(!missingInput) {
            hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, "mainHashKey-123")
            if(transactionId != null) {
                hmInput.put(ProfileOrchestrationConstants.IDPTRACEID, transactionId)
            }
            if(msOperation != null) {
                hmDbusInput.put(CommonDefs.MS_OPERTAION, msOperation)
            }
        }

        Map<String, Object> mqSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success MQ")

        1 * featureManager.getValue(featureAEHFlagName) >> "AEH"
        1 * featureManager.getValue(featureCLMFlagName) >> "AEH"
        when:
        Map<String, Object> result = publishEventHelper.publishEvent(featureAEHFlagName, featureCLMFlagName, hmDbusInput, hmInput)

        then: "Merged success response returned"
        if(msOperation == null) {
            result.get(CommonDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_EMPTY_NUM)
            String appInfo = (String) result.get(CommonDefs.COMMON_APP_INFO)
            appInfo != null
            appInfo.toLowerCase().contains("msOperation cannot be null or empty for AEH")
        }
        if(transactionId == null) {
            result.get(CommonDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_EMPTY_NUM)
            String appInfo = (String) result.get(CommonDefs.COMMON_APP_INFO)
            appInfo != null
            appInfo.toLowerCase().contains("TransactionId cannot be null or empty for AEH")
        }
        if(missingInput) {
            result.get(CommonDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_INVALID_DATA_NUM)
            String appInfo = (String) result.get(CommonDefs.COMMON_APP_INFO)
            appInfo != null
            appInfo.toLowerCase().contains("Input for AEH is NULL")
        }


        where:
        scenarioName              | transactionId | msOperation | missingInput
        "Missing TransactionId"  |   null     | "sample-msOperation" | false
        "Missing ms operation"  | "sample-transactionId" | null | false
        "Missing Input"  | "sample-transactionId" | "sample-msOperation" | true
    }
}

