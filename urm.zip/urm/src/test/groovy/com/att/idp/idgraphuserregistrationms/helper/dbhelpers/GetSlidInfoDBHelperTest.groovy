package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import com.att.mpsys.common.utils.*
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import spock.lang.Specification

class GetSlidInfoDBHelperTest extends Specification {

    def testObj = new GetSlidInfoDBHelper()

    JdbcTemplate jdbcTemplate = Mock(JdbcTemplate)
    ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)

    GetInfoByMaskDBHelper oGetInfoByMaskDBHelper = Mock(GetInfoByMaskDBHelper)

    GetMemberServicesDBHelper oGetMemberServicesDBHelper = Mock(GetMemberServicesDBHelper)

    public Logger logger = null
    private HashMap<String, Object> hmDBInput = null
    private HashMap<String, Object> hmInpMemberInfo = null
    private ArrayList<Object> alSlidMaskInInp = null
    private HashMap<String, Object> resultHashError = null
    private HashMap<String, Object> resultHashSuccess = null
    private ArrayList alSLIDLocks = null

    private Map<String, Object> hmQueryResponse = CommonUtil.hashMap
    private List alQueryResponse = CommonUtil.arrayList
    private List<Object> objectList = CommonUtil.arrayList
    private HashMap<String, Object> hmResult = null


    def setup() throws Exception {
        testObj.jdbcTemplate = jdbcTemplate
        testObj.errorMetricHandler = errorMetricHandler
        testObj.oGetInfoByMaskDBHelper = oGetInfoByMaskDBHelper
        testObj.oGetMemberServicesDBHelper = oGetMemberServicesDBHelper
        logger = LoggerFactory.getLogger('GetSlidInfoDBHelperTest')
        resultHashSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
                CErrorDefs.COMMON_SUCCESS_MSG)
        resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, 'Error Returned')

        hmDBInput = CommonUtil.hashMap
        hmInpMemberInfo = CommonUtil.hashMap
        alSlidMaskInInp = CommonUtil.arrayList

        alSlidMaskInInp.add('SS')
        alSlidMaskInInp.add('SR')
        alSlidMaskInInp.add('SLO')
        alSlidMaskInInp.add('CI')
        alSlidMaskInInp.add('SQ')
        alSlidMaskInInp.add('SSC')
        alSlidMaskInInp.add('AD')
        alSlidMaskInInp.add('SLAD')
        alSlidMaskInInp.add('QFLO')
        alSlidMaskInInp.add('QMSA')
        alSlidMaskInInp.add('QMFP')

        hmInpMemberInfo[CommonDefs.HANDLE] = 'qayma123'
        hmInpMemberInfo[CommonDefs.DOMAIN] = 'att.net'

        hmDBInput[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmDBInput['slid'] = 'qayma123'
        hmDBInput['slid_member_num'] = '12345'
        hmDBInput['slidMask'] = alSlidMaskInInp
        hmDBInput[MPSDefs.QUERY_LINKED_USERS_FLAG] = 'Y'
        hmDBInput[MPSDefs.QUERY_FRAUD_LOCK_FLAG] = 'Y'
        hmDBInput[MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG] = 'Y'
        hmDBInput['queryMemberFraudPassword'] = '12345'
        hmDBInput[MPSDefs.MEMBER_INFO] = hmInpMemberInfo
    }

    def "get slid info null input error"() {
        when:
        hmResult = testObj.getSlidInfo(null)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Input hash is empty'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_EMPTY'
    }

    def "get slid info no slid error"() {
        given:
        hmDBInput['slid'] = null
        hmDBInput['slid_member_num'] = null
        when:
        hmResult = testObj.getSlidInfo(hmDBInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'slid as well as slid_member_num can not be null or empty in input'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_EMPTY'
    }

    def "get slid info get info by mask null response"() {
        given:
        hmDBInput[MPSDefs.QUERY_FRAUD_LOCK_FLAG] = 'N'
        hmDBInput[MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG] = 'N'
        oGetInfoByMaskDBHelper.getInfoByMask(_) >> null
        when:
        hmResult = testObj.getSlidInfo(hmDBInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Response from GetInfoByMaskDBHelper.getInfoByMask() is null / empty'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "get slid info get info by mask error response"() {
        given:
        oGetInfoByMaskDBHelper.getInfoByMask(_) >> resultHashError
        when:
        hmResult = testObj.getSlidInfo(hmDBInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Error Returned'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "get slid info get member services null response"() {
        given:
        oGetInfoByMaskDBHelper.getInfoByMask(_) >> resultHashSuccess
        oGetMemberServicesDBHelper.getMemberServices(_) >> null
        when:
        hmResult = testObj.getSlidInfo(hmDBInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'GetMemberServicesDBHelper.getMemberServices helper returned null.'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "get slid info get member services error response"() {
        given:
        oGetInfoByMaskDBHelper.getInfoByMask(_) >> resultHashSuccess
        oGetMemberServicesDBHelper.getMemberServices(_) >> resultHashError

        when:
        hmResult = testObj.getSlidInfo(hmDBInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Error Returned'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "get slid info no record found success"() {
        given:
        resultHashError[CErrorDefs.COMMON_APP_STATUS_CODE] = '303'
        oGetInfoByMaskDBHelper.getInfoByMask(_) >> resultHashSuccess
        oGetMemberServicesDBHelper.getMemberServices(_) >> resultHashError

        when:
        hmResult = testObj.getSlidInfo(hmDBInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Success'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "get slid info no lu slid mask success"() {
        given:
        HashMap<String, Object> memberServiceHashSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
                CErrorDefs.COMMON_SUCCESS_MSG)
        oGetInfoByMaskDBHelper.getInfoByMask(_) >> resultHashSuccess
        oGetMemberServicesDBHelper.getMemberServices(_) >> memberServiceHashSuccess

        when:
        hmResult = testObj.getSlidInfo(hmDBInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Success'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "get slid info with l u slid mask no linked user success"() {
        given:
        alSlidMaskInInp.add('LU')
        hmDBInput['slid_member_num'] = null
        resultHashSuccess[MPSDefs.DB_MEMBER_NUM] = '12345'
        objectList.add('12345')
        oGetInfoByMaskDBHelper.getInfoByMask(_) >> resultHashSuccess
        oGetMemberServicesDBHelper.getMemberServices(_) >> resultHashSuccess
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        when:
        hmResult = testObj.getSlidInfo(hmDBInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Success'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "get slid info with linked user null response"() {
        given:
        HashMap<String, Object> hmQuerySecondResponse = CommonUtil.hashMap
        hmQueryResponse[MPSDefs.DB_MEMBER_NUM] = '123465'

        ArrayList<Object> alLinkedQueryMask = new ArrayList<Object>()
        alLinkedQueryMask.add('SQ')
        alLinkedQueryMask.add('UP')

        hmQuerySecondResponse[MPSDefs.DB_MEMBER_NUM] = '12345'
        alQueryResponse.add(hmQueryResponse)
        alQueryResponse.add(hmQuerySecondResponse)
        alSlidMaskInInp.add('LU')
        hmDBInput['slid_member_num'] = null
        resultHashSuccess[MPSDefs.DB_MEMBER_NUM] = '12345'
        objectList.add('12345')

        HashMap<String, Object> hmLinkedInfoInp = CommonUtil.hashMap
        hmLinkedInfoInp['dataMask'] = alLinkedQueryMask
        hmLinkedInfoInp[MPSDefs.DB_MEMBER_NUM] = '123465'
        hmLinkedInfoInp[MPSDefs.SOURCE_CALLER] = 'getSlidInfo'
        hmLinkedInfoInp[MPSDefs.QUERY_LINKED_USERS_FLAG] = 'Y'
        oGetInfoByMaskDBHelper.getInfoByMask(_) >> resultHashSuccess
        oGetMemberServicesDBHelper.getMemberServices(_) >> resultHashSuccess
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        oGetInfoByMaskDBHelper.getInfoByMask(_) >> null

        when:
        hmResult = testObj.getSlidInfo(hmDBInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "get slid info with linked user error response"() {
        given:
        HashMap<String, Object> hmQuerySecondResponse = CommonUtil.hashMap
        hmQueryResponse[MPSDefs.DB_MEMBER_NUM] = '123465'

        ArrayList<Object> alLinkedQueryMask = new ArrayList<Object>()
        alLinkedQueryMask.add('SQ')
        alLinkedQueryMask.add('UP')

        hmQuerySecondResponse[MPSDefs.DB_MEMBER_NUM] = '12345'
        alQueryResponse.add(hmQueryResponse)
        alQueryResponse.add(hmQuerySecondResponse)
        alSlidMaskInInp.add('LU')
        hmDBInput['slid_member_num'] = null
        resultHashSuccess[MPSDefs.DB_MEMBER_NUM] = '12345'
        resultHashSuccess[MPSDefs.DB_MEMBERLOCKOUT] = alSLIDLocks
        objectList.add('12345')

        HashMap<String, Object> hmLinkedInfoInp = CommonUtil.hashMap
        hmLinkedInfoInp['dataMask'] = alLinkedQueryMask
        hmLinkedInfoInp[MPSDefs.DB_MEMBER_NUM] = '123465'
        hmLinkedInfoInp[MPSDefs.SOURCE_CALLER] = 'getSlidInfo'
        hmLinkedInfoInp[MPSDefs.QUERY_LINKED_USERS_FLAG] = 'Y'
        oGetInfoByMaskDBHelper.getInfoByMask(_) >> resultHashSuccess
        oGetMemberServicesDBHelper.getMemberServices(_) >> resultHashSuccess
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        oGetInfoByMaskDBHelper.getInfoByMask(_) >> resultHashError
        when:
        hmResult = testObj.getSlidInfo(hmDBInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "get slid info with linked user success response"() {
        given:
        HashMap<String, Object> hmQuerySecondResponse = CommonUtil.hashMap
        hmQueryResponse[MPSDefs.DB_MEMBER_NUM] = '123465'

        ArrayList<Object> alLinkedQueryMask = new ArrayList<Object>()
        alLinkedQueryMask.add('SQ')
        alLinkedQueryMask.add('UP')

        alSLIDLocks = CommonUtil.arrayList
        alSLIDLocks.add('LOCK')

        hmQuerySecondResponse[MPSDefs.DB_MEMBER_NUM] = '12345'
        alQueryResponse.add(hmQueryResponse)
        alQueryResponse.add(hmQuerySecondResponse)
        alSlidMaskInInp.add('LU')
        hmDBInput['slid_member_num'] = null
        resultHashSuccess[MPSDefs.DB_MEMBER_NUM] = '12345'
        resultHashSuccess[MPSDefs.DB_MEMBERLOCKOUT] = alSLIDLocks
        objectList.add('12345')

        HashMap<String, Object> getInfoHashSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
                CErrorDefs.COMMON_SUCCESS_MSG)
        HashMap<String, Object> getMemberServiceHashSuccess = CommonErrorMap
                .makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)

        HashMap<String, Object> hmLinkedInfoInp = CommonUtil.hashMap
        hmLinkedInfoInp['dataMask'] = alLinkedQueryMask
        hmLinkedInfoInp[MPSDefs.DB_MEMBER_NUM] = '123465'
        hmLinkedInfoInp[MPSDefs.SOURCE_CALLER] = 'getSlidInfo'
        hmLinkedInfoInp[MPSDefs.QUERY_LINKED_USERS_FLAG] = 'Y'
        oGetInfoByMaskDBHelper.getInfoByMask(_) >> resultHashSuccess
        oGetMemberServicesDBHelper.getMemberServices(_) >> getMemberServiceHashSuccess
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        oGetInfoByMaskDBHelper.getInfoByMask(_) >> getInfoHashSuccess

        when:
        hmResult = testObj.getSlidInfo(hmDBInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "get slid info exception"() {
        given:
        alSlidMaskInInp.add('LU')
        hmDBInput['slid_member_num'] = null
        resultHashSuccess[MPSDefs.DB_MEMBER_NUM] = '12345'
        objectList.add('12345')
        oGetInfoByMaskDBHelper.getInfoByMask(_) >> resultHashSuccess
        oGetMemberServicesDBHelper.getMemberServices(_) >> resultHashSuccess
        jdbcTemplate.queryForList(_,_) >> null

        when:
        hmResult = testObj.getSlidInfo(hmDBInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SYSTEM ERROR'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }
}
