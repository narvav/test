package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.MPSDefs
import org.springframework.jdbc.core.JdbcTemplate
import spock.lang.Specification
import spock.lang.Unroll

class SyncCCRHelperTest extends Specification {

    GetMemberServicesDBHelper getMemberServicesDBHelper
    JdbcTemplate jdbcTemplate
    SyncCCRHelper helperUnderTest

    def setup() {
        getMemberServicesDBHelper = Mock(GetMemberServicesDBHelper)
        jdbcTemplate = Mock(JdbcTemplate)
        helperUnderTest = new SyncCCRHelper(getMemberServicesDBHelper, jdbcTemplate)
    }

    @Unroll
    def "should return error map when getMemberServices returns null for #scenarioName"() {
        given: "A request map and getMemberServices returns null"
        HashMap<String, Object> hmInput = new HashMap<>()
        hmInput.put("memberName", memberName)
        hmInput.put("domainName", domainName)

        when: "getMemberServiceByHandle is called"
        Map<String, Object> result = helperUnderTest.getMemberServiceByHandle(hmInput)

        then: "getMemberServices is called with correct input and returns null"
        getMemberServicesDBHelper.getMemberServices({ HashMap<String, Object> map ->
            map.get("memberName") == memberName &&
                    map.get("domainName") == domainName
        } as HashMap) >> null


        and: "Result contains error code and message"
        result != null
        result.get("appStatusCode") == CErrorDefs.ERR_SYS_APPL
        result.get("appStatusMsg") == CErrorDefs.ERR_SYS_APPL_MSG

        where: "Different input scenarios"
        scenarioName   | memberName | domainName
        "valid input"  | "user123"  | "att.com"
        "empty domain" | "user456"  | ""
        "empty member" | ""         | "att.com"
    }

    @Unroll
    def "should update tables successfully for #scenarioName"() {
        given: "A request with handle/domain and supported tables"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setHandle(handle)
        request.setDomain(domain)
        request.setCallingSystemId(callingSystemId)
        request.setSyncCCRMemberTables(tables)

        Map<String, Object> memberResult = new HashMap<>()
        memberResult.put(CErrorDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        memberResult.put(MPSDefs.DB_MEMBER_NUM, memberNum)


        when: "syncCCR is called"
        Map<String, Object> result = helperUnderTest.syncCCR(request)

        then: "Member lookup and jdbc updates occur as expected"
        getMemberServicesDBHelper.getMemberServices(_) >> memberResult

        jdbcTemplate.update(_, _, _) >> updateCount


        and: "Result indicates success"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG

        where: "Scenarios of different tables"
        scenarioName      | handle    | domain    | callingSystemId | tables                                           | memberNum | updateCount
        "single table"    | "user123" | "att.com" | "SYS1"          | ["member"]                                       | "10001"   | 1
        "multiple tables" | "user456" | "att.com" | "SYS2"          | ["member", "memberservice", "memberservicerole"] | "10002"   | 2
    }

    def "should return not found when no records updated"() {
        given: "A request with valid member but updates affect zero rows"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setGuid("99999")
        request.setCallingSystemId("SYS0")
        request.setSyncCCRMemberTables(["member", "memberservice"]) // supported tables

        when: "syncCCR is called"
        Map<String, Object> result = helperUnderTest.syncCCR(request)

        then: "Member lookup succeeds and updates return zero"

        jdbcTemplate.update("UPDATE MEMBER SET LAST_MODIFIED_BY = ? WHERE MEMBER_NUM = ?", "SYS0", "99999") >> 1
        jdbcTemplate.update("UPDATE MEMBERSERVICE SET LAST_MODIFIED_BY = ? WHERE MEMBER_NUM = ?", "SYS0", "99999") >> 1

        and:
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
    }

    def "should return DB error when exception occurs during update"() {
        given: "A request that triggers exception in JDBC update"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setHandle("userEx")
        request.setDomain("att.com")
        request.setCallingSystemId("SYSX")
        request.setSyncCCRMemberTables(["member"]) // supported

        Map<String, Object> memberResult = new HashMap<>()
        memberResult.put(CErrorDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        memberResult.put(MPSDefs.DB_MEMBER_NUM, "77777")

        when: "syncCCR is executed and JDBC throws"
        Map<String, Object> result = helperUnderTest.syncCCR(request)

        then: "Member lookup and JDBC exception handling"
        getMemberServicesDBHelper.getMemberServices(_) >> memberResult
        jdbcTemplate.update("UPDATE MEMBER SET LAST_MODIFIED_BY = ? WHERE MEMBER_NUM = ?", "SYSX", "77777") >> { throw new RuntimeException("SQL error") }

        and: "Result indicates DB error category and info"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_DB
        result.get(CommonDefs.COMMON_APP_INFO) == "Error occurred while syncing CCR member tables."
    }

    def "should return  success even if some of table are updated and some are record not found"() {
        given: "A request with valid member but updates affect zero rows"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setGuid("99999")
        request.setCallingSystemId("SYS0")
        request.setSyncCCRMemberTables(["member", "memberservice"]) // supported tables

        when: "syncCCR is called"
        Map<String, Object> result = helperUnderTest.syncCCR(request)

        then: "Member lookup succeeds and updates return zero"

        jdbcTemplate.update("UPDATE MEMBER SET LAST_MODIFIED_BY = ? WHERE MEMBER_NUM = ?", "SYS0", "99999") >> 1
        jdbcTemplate.update("UPDATE MEMBERSERVICE SET LAST_MODIFIED_BY = ? WHERE MEMBER_NUM = ?", "SYS0", "99999") >> 0

        and:
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
    }


    def "should throw error when getMemberService returns null as response"() {
        given:
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setGuid("handle-abc")
        request.setCallingSystemId("UST")
        request.setSyncCCRMemberTables(["member"])


        when: "syncCCR is called"
        Map<String, Object> result = helperUnderTest.syncCCR(request)

        then: "Member lookup and jdbc updates occur as expected"
        getMemberServicesDBHelper.getMemberServices(_) >> null

        and: "Result indicates success"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_USER_NOT_FOUND
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CErrorDefs.ERR_USER_NOT_FOUND_MSG

    }


    def "should throw error when getMemberService returns record not found"() {
        given:
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setHandle("handle-abc")
        request.setDomain("att.com")
        request.setCallingSystemId("UST")
        request.setSyncCCRMemberTables(["member"])

        Map<String, Object> expectedSuccess = CommonErrorMap.makeCategoryMap(MPSDefs.REC_NOT_FOUND_NUM, CErrorDefs.ERR_REC_NOT_FOUND_MSG)

        when: "syncCCR is called"
        Map<String, Object> result = helperUnderTest.syncCCR(request)

        then: "Member lookup and jdbc updates occur as expected"
        getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> expectedSuccess

        and: "Result indicates success"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == MPSDefs.ERR_USER_NOT_FOUND
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == MPSDefs.ERR_USER_NOT_FOUND_MSG

    }

    def "should throw error when getMemberService returns DB Error"() {
        given:
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setHandle("handle-abc")
        request.setDomain("att.com")
        request.setCallingSystemId("UST")
        request.setSyncCCRMemberTables(["member"])

        Map<String, Object> expectedSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_DB_NUM, CErrorDefs.ERR_DB_MSG)

        when: "syncCCR is called"
        Map<String, Object> result = helperUnderTest.syncCCR(request)

        then: "Member lookup and jdbc updates occur as expected"
        getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> expectedSuccess

        and: "Result indicates success"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_DB
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CErrorDefs.ERR_DB_MSG

    }

    @Unroll
    def "should return system application error map when getMemberServices throws exception for #scenarioName"() {
        given: "A request map and getMemberServices throws exception"
        HashMap<String, Object> hmInput = new HashMap<>()
        hmInput.put("memberName", memberName)
        hmInput.put("domainName", domainName)
        RuntimeException dbException = new RuntimeException("DB failure")

        when: "getMemberServiceByHandle is called"
        Map<String, Object> result = helperUnderTest.getMemberServiceByHandle(hmInput)

        then: "getMemberServices throws exception"
        getMemberServicesDBHelper.getMemberServices({ HashMap<String, Object> map ->
            map.get("memberName") == memberName &&
                    map.get("domainName") == domainName
        } as HashMap) >> { throw dbException }

        and: "Result contains system application error code and message"
        result != null
        result.get("appStatusCode") == CErrorDefs.ERR_SYS_APPL
        result.get("appStatusMsg") == CErrorDefs.ERR_SYS_APPL_MSG

        where: "Different input scenarios"
        scenarioName   | memberName | domainName
        "valid input"  | "user123"  | "att.com"
        "empty domain" | "user456"  | ""
        "empty member" | ""         | "att.com"
    }
}
