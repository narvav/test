package com.att.idp.idgraphuserregistrationms.resource.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.service.ListEmailAppPasswordService
import com.att.idp.idgraphuserregistrationms.resource.request.CreateEmailAppPasswordRequest
import com.att.idp.idgraphuserregistrationms.resource.request.DeleteEmailAppPasswordRequest
import com.att.idp.idgraphuserregistrationms.resource.response.CreateEmailAppPasswordResponse
import com.att.idp.idgraphuserregistrationms.service.CreateEmailAppPasswordService
import com.att.idp.idgraphuserregistrationms.service.DeleteEmailAppPasswordService
import com.att.idp.idgraphuserregistrationms.request.validator.CreateEmailAppPasswordRequestValidator
import com.att.idp.idgraphuserregistrationms.request.validator.EmailAppPasswordRequestValidator
import com.att.idp.idgraphuserregistrationms.resource.response.EmailAppPasswordResponse
import com.att.idp.idgraphuserregistrationms.utils.ProfileOrchestrationConstants
import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedMap
import jakarta.ws.rs.core.Response
import spock.lang.Specification
import spock.lang.Unroll

import com.att.idp.core.exception.ServiceError
import java.sql.SQLException

/**
 * Unit tests for EmailAppPasswordResourceImpl class.
 * Tests cover successful retrieval, validation failures, database errors, and exception handling.
 */
class EmailAppPasswordResourceImplSpec extends Specification {

    EmailAppPasswordRequestValidator emailAppPasswordRequestValidator
    ListEmailAppPasswordService listEmailAppPasswordService
    DeleteEmailAppPasswordService deleteEmailAppPasswordService
    CreateEmailAppPasswordRequestValidator createEmailAppPasswordRequestValidator
    CreateEmailAppPasswordService createEmailAppPasswordService
    EmailAppPasswordResourceImpl emailAppPasswordResourceImpl
    HttpHeaders httpHeaders

    def setup() {
        emailAppPasswordRequestValidator = Mock(EmailAppPasswordRequestValidator)
        listEmailAppPasswordService = Mock(ListEmailAppPasswordService)
        createEmailAppPasswordRequestValidator = Mock(CreateEmailAppPasswordRequestValidator)
        createEmailAppPasswordService = Mock(CreateEmailAppPasswordService)
        deleteEmailAppPasswordService = Mock(DeleteEmailAppPasswordService)
        httpHeaders = Mock(HttpHeaders)

        emailAppPasswordResourceImpl = new EmailAppPasswordResourceImpl(
            emailAppPasswordRequestValidator,
            listEmailAppPasswordService,
            deleteEmailAppPasswordService,
            createEmailAppPasswordRequestValidator,
            createEmailAppPasswordService
        )
    }

    def "listEmailAppPassword throws InvalidInputDataException when validator throws exception"() {
        given:
        String memberId = "invalidMember"
        String domain = "invalidDomain"
        String guid = null
        String traceId = "trace-error"

        InvalidInputDataException expectedException = new InvalidInputDataException("Invalid input data")
        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId

        when:
        emailAppPasswordResourceImpl.listEmailAppPassword(memberId, domain, guid, httpHeaders)

        then:
        1 * emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders) >> {
            throw expectedException
        }
        0 * listEmailAppPasswordService.listEmailAppPassword(_, _, _, _)

        and:
        InvalidInputDataException ex = thrown()
        ex.message == "Invalid input data"
    }

    def "listEmailAppPassword returns validation error when validator returns non-null"() {
        given:
        String memberId = "testMember"
        String domain = "testDomain"
        String guid = null
        EmailAppPasswordResponse validationError = new EmailAppPasswordResponse()
        validationError.setAppCategoryCode("3")
        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> "trace-val"

        when:
        Response result = emailAppPasswordResourceImpl.listEmailAppPassword(memberId, domain, guid, httpHeaders)

        then:
        1 * emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders) >> validationError
        0 * listEmailAppPasswordService.listEmailAppPassword(_, _, _, _)

        and:
        result != null
        result.status == Response.Status.BAD_REQUEST.statusCode
    }

    def "listEmailAppPassword calls service and returns its response"() {
        given:
        String memberId = "testMember"
        String domain = "testDomain"
        String guid = null
        String traceId = "trace-success"
        EmailAppPasswordResponse serviceResponse = new EmailAppPasswordResponse()
        serviceResponse.setAppCategoryCode("0")
        serviceResponse.setIdpTraceId(traceId)
        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId

        when:
        Response result = emailAppPasswordResourceImpl.listEmailAppPassword(memberId, domain, guid, httpHeaders)

        then:
        1 * emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders) >> null
        1 * listEmailAppPasswordService.listEmailAppPassword(memberId, domain, guid, httpHeaders) >> serviceResponse
        0 * _

        and:
        result != null
        (result.entity as EmailAppPasswordResponse).idpTraceId == traceId
    }

    def "listEmailAppPassword handles SQLException and returns database error response"() {
        given:
        String memberId = "testMember"
        String domain = "testDomain"
        String guid = null
        String traceId = "trace-sqlerror"

        SQLException sqlException = new SQLException("Database connection failed")
        RuntimeException wrapperException = new RuntimeException("Wrapper", sqlException)

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId

        when:
        Response result = emailAppPasswordResourceImpl.listEmailAppPassword(memberId, domain, guid, httpHeaders)

        then:
        1 * emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders) >> null
        1 * listEmailAppPasswordService.listEmailAppPassword(_, _, _, _) >> { throw wrapperException }

        and:
        result != null
        result.status != Response.Status.OK.statusCode || result.entity != null
    }

    def "listEmailAppPassword handles generic exception and returns system error response"() {
        given:
        String memberId = "testMember"
        String domain = "testDomain"
        String guid = null
        String traceId = "trace-generr"

        RuntimeException genericException = new RuntimeException("Unexpected system error")

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId

        when:
        Response result = emailAppPasswordResourceImpl.listEmailAppPassword(memberId, domain, guid, httpHeaders)

        then:
        1 * emailAppPasswordRequestValidator.emailPasswordReqValidator(memberId, domain, guid, httpHeaders) >> null
        1 * listEmailAppPasswordService.listEmailAppPassword(_, _, _, _) >> { throw genericException }

        and:
        result != null
    }

    def "deleteEmailAppPassword throws InvalidInputDataException when validator throws exception"() {
        given:
        DeleteEmailAppPasswordRequest request = new DeleteEmailAppPasswordRequest()
        request.memberId = "invalidMember"
        request.domain = "invalidDomain"
        request.passwordName = "testPwd"
        String traceId = "trace-delete-error"
        InvalidInputDataException expectedException = new InvalidInputDataException("Invalid input data")
        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId

        when:
        emailAppPasswordResourceImpl.deleteEmailAppPassword(request, httpHeaders)

        then:
        1 * emailAppPasswordRequestValidator.deleteEmailPasswordReqValidator(request, httpHeaders) >> {
            throw expectedException
        }
        1 * httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        0 * deleteEmailAppPasswordService.deleteEmailAppPassword(_, _)
        0 * _

        and:
        InvalidInputDataException ex = thrown()
        ex.message == "Invalid input data"
    }

    def "deleteEmailAppPassword returns validation error response when validator returns non-null"() {
        given:
        DeleteEmailAppPasswordRequest request = new DeleteEmailAppPasswordRequest()
        request.memberId = "testMember"
        request.domain = "testDomain"
        String traceId = "trace-delete-validation"
        EmailAppPasswordResponse validationErrorResponse = new EmailAppPasswordResponse()
        validationErrorResponse.setAppCategoryCode("3")
        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId

        when:
        Response result = emailAppPasswordResourceImpl.deleteEmailAppPassword(request, httpHeaders)

        then:
        1 * emailAppPasswordRequestValidator.deleteEmailPasswordReqValidator(request, httpHeaders) >> validationErrorResponse
        1 * httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        0 * deleteEmailAppPasswordService.deleteEmailAppPassword(_, _)
        0 * _

        and:
        result != null
        result.status == Response.Status.BAD_REQUEST.statusCode
    }

    def "deleteEmailAppPassword succeeds using guid path and sets guid on response"() {
        given:
        DeleteEmailAppPasswordRequest request = new DeleteEmailAppPasswordRequest()
        request.guid = "guid-12345"
        request.passwordName = "myPassword"
        String traceId = "trace-delete-guid"
        EmailAppPasswordResponse deleteResp = new EmailAppPasswordResponse()
        deleteResp.setAppCategoryCode("0")
        deleteResp.guid = "guid-12345"
        deleteResp.idpTraceId = traceId

        when:
        Response result = emailAppPasswordResourceImpl.deleteEmailAppPassword(request, httpHeaders)

        then:
        1 * emailAppPasswordRequestValidator.deleteEmailPasswordReqValidator(request, httpHeaders) >> null
        1 * httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        1 * deleteEmailAppPasswordService.deleteEmailAppPassword(request, httpHeaders) >> deleteResp
        0 * _

        and:
        result != null
        (result.entity as EmailAppPasswordResponse).guid == "guid-12345"
        (result.entity as EmailAppPasswordResponse).idpTraceId == traceId
    }

    def "deleteEmailAppPassword succeeds using memberId and domain path"() {
        given:
        DeleteEmailAppPasswordRequest request = new DeleteEmailAppPasswordRequest()
        request.memberId = "testMember"
        request.domain = "testDomain"
        request.passwordName = "myPassword"
        String traceId = "trace-delete-memberid"
        EmailAppPasswordResponse deleteResp = new EmailAppPasswordResponse()
        deleteResp.setAppCategoryCode("0")
        deleteResp.idpTraceId = traceId

        when:
        Response result = emailAppPasswordResourceImpl.deleteEmailAppPassword(request, httpHeaders)

        then:
        1 * emailAppPasswordRequestValidator.deleteEmailPasswordReqValidator(request, httpHeaders) >> null
        1 * httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        1 * deleteEmailAppPasswordService.deleteEmailAppPassword(request, httpHeaders) >> deleteResp
        0 * _

        and:
        result != null
        (result.entity as EmailAppPasswordResponse).idpTraceId == traceId
    }

    def "deleteEmailAppPassword returns error response when service returns not found"() {
        given:
        DeleteEmailAppPasswordRequest request = new DeleteEmailAppPasswordRequest()
        request.memberId = "testMember"
        request.domain = "testDomain"
        request.passwordName = "myPassword"
        String traceId = "trace-delete-notfound"
        EmailAppPasswordResponse notFoundResp = new EmailAppPasswordResponse()
        notFoundResp.setAppCategoryCode("3")
        notFoundResp.errors = Stub(ServiceError)
        notFoundResp.idpTraceId = traceId

        when:
        Response result = emailAppPasswordResourceImpl.deleteEmailAppPassword(request, httpHeaders)

        then:
        1 * emailAppPasswordRequestValidator.deleteEmailPasswordReqValidator(request, httpHeaders) >> null
        1 * httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        1 * deleteEmailAppPasswordService.deleteEmailAppPassword(request, httpHeaders) >> notFoundResp
        0 * _

        and:
        result != null
        (result.entity as EmailAppPasswordResponse).errors != null
        (result.entity as EmailAppPasswordResponse).idpTraceId == traceId
    }

    def "deleteEmailAppPassword handles SQLException and returns error response"() {
        given:
        DeleteEmailAppPasswordRequest request = new DeleteEmailAppPasswordRequest()
        request.memberId = "testMember"
        request.domain = "testDomain"
        request.passwordName = "myPassword"
        String traceId = "trace-delete-sqlerror"
        SQLException sqlException = new SQLException("Database connection failed")
        RuntimeException wrapperException = new RuntimeException("Wrapper", sqlException)
        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId

        when:
        Response result = emailAppPasswordResourceImpl.deleteEmailAppPassword(request, httpHeaders)

        then:
        1 * emailAppPasswordRequestValidator.deleteEmailPasswordReqValidator(request, httpHeaders) >> null
        1 * deleteEmailAppPasswordService.deleteEmailAppPassword(_, _) >> { throw wrapperException }
        _ * httpHeaders.getHeaderString(_) >> traceId
        0 * _

        and:
        result != null
        (result.entity as EmailAppPasswordResponse).errors != null
    }

    def "deleteEmailAppPassword handles generic exception and returns error response"() {
        given:
        DeleteEmailAppPasswordRequest request = new DeleteEmailAppPasswordRequest()
        request.memberId = "testMember"
        request.domain = "testDomain"
        request.passwordName = "myPassword"
        String traceId = "trace-delete-generr"
        RuntimeException genericException = new RuntimeException("Unexpected system error")
        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId

        when:
        Response result = emailAppPasswordResourceImpl.deleteEmailAppPassword(request, httpHeaders)

        then:
        1 * emailAppPasswordRequestValidator.deleteEmailPasswordReqValidator(request, httpHeaders) >> null
        1 * deleteEmailAppPasswordService.deleteEmailAppPassword(_, _) >> { throw genericException }
        _ * httpHeaders.getHeaderString(_) >> traceId
        0 * _

        and:
        result != null
        (result.entity as EmailAppPasswordResponse).errors != null
    }

    @Unroll
    def "deleteEmailAppPassword handles edge case when #scenarioName"() {
        given:
        DeleteEmailAppPasswordRequest request = new DeleteEmailAppPasswordRequest()
        request.memberId = memberId
        request.domain = domain
        request.guid = guid
        request.passwordName = passwordName
        String traceId = "trace-delete-edge"
        EmailAppPasswordResponse serviceResponse = new EmailAppPasswordResponse()
        serviceResponse.setAppCategoryCode("3")
        serviceResponse.errors = Stub(ServiceError)
        serviceResponse.idpTraceId = traceId
        serviceResponse.guid = expectedGuid

        when:
        Response result = emailAppPasswordResourceImpl.deleteEmailAppPassword(request, httpHeaders)

        then:
        1 * emailAppPasswordRequestValidator.deleteEmailPasswordReqValidator(request, httpHeaders) >> null
        1 * httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        1 * deleteEmailAppPasswordService.deleteEmailAppPassword(request, httpHeaders) >> serviceResponse
        0 * _

        and:
        result != null
        EmailAppPasswordResponse entity = result.entity as EmailAppPasswordResponse
        entity.errors != null
        entity.idpTraceId == traceId
        entity.guid == expectedGuid

        where:
        scenarioName                        | memberId      | domain        | guid        | passwordName | expectedGuid
        "guid path, no passwordName"        | null          | null          | "guid-1111" | null         | "guid-1111"
        "memberId and domain with password" | "testMember"  | "testDomain"  | null        | "pwd2"       | null
        "memberId and domain no password"   | "testMember"  | "testDomain"  | null        | null         | null
    }


    def "createEmailAppPassword throws InvalidInputDataException when validator throws exception"() {
        given:
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId("testUser")
        request.setDomain("att.net")
        request.setPasswordName("imap")
        String traceId = "trace-create-error"

        InvalidInputDataException expectedException = new InvalidInputDataException("Invalid input data")
        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        MultivaluedMap mockRequestHeaders = Mock(MultivaluedMap)
        httpHeaders.getRequestHeaders() >> mockRequestHeaders

        when:
        emailAppPasswordResourceImpl.createEmailAppPassword(request, httpHeaders)

        then:
        1 * createEmailAppPasswordRequestValidator.createEmailAppPasswordReqValidator(request, httpHeaders) >> {
            throw expectedException
        }
        0 * createEmailAppPasswordService.createEmailAppPassword(_, _)

        and:
        InvalidInputDataException ex = thrown()
        ex.message == "Invalid input data"
    }

    def "createEmailAppPassword returns validation error response when validator returns non-null"() {
        given:
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId("testUser")
        request.setDomain("att.net")
        request.setPasswordName("imap")
        String traceId = "trace-create-validation"

        CreateEmailAppPasswordResponse validationErrorResponse = new CreateEmailAppPasswordResponse()
        validationErrorResponse.setAppCategoryCode("3")
        validationErrorResponse.setAppStatusCode("100")

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        MultivaluedMap mockRequestHeaders = Mock(MultivaluedMap)
        httpHeaders.getRequestHeaders() >> mockRequestHeaders

        when:
        Response result = emailAppPasswordResourceImpl.createEmailAppPassword(request, httpHeaders)

        then:
        1 * createEmailAppPasswordRequestValidator.createEmailAppPasswordReqValidator(request, httpHeaders) >> validationErrorResponse
        0 * createEmailAppPasswordService.createEmailAppPassword(_, _)

        and:
        result != null
        result.status == Response.Status.BAD_REQUEST.statusCode
    }

    def "createEmailAppPassword calls service and returns success response"() {
        given:
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId("testUser")
        request.setDomain("att.net")
        request.setPasswordName("imap")
        request.setIdpTraceId("trace-create-success")
        String traceId = "trace-create-success"

        CreateEmailAppPasswordResponse serviceResponse = new CreateEmailAppPasswordResponse()
        serviceResponse.setAppCategoryCode("0")
        serviceResponse.setAppStatusCode("0")
        serviceResponse.setPassword("generatedPassword")

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        MultivaluedMap mockRequestHeaders = Mock(MultivaluedMap)
        httpHeaders.getRequestHeaders() >> mockRequestHeaders

        when:
        Response result = emailAppPasswordResourceImpl.createEmailAppPassword(request, httpHeaders)

        then:
        1 * createEmailAppPasswordRequestValidator.createEmailAppPasswordReqValidator(request, httpHeaders) >> null
        1 * createEmailAppPasswordService.createEmailAppPassword(request, mockRequestHeaders) >> serviceResponse

        and:
        result != null
        result.status == Response.Status.OK.statusCode
    }

    def "createEmailAppPassword handles SQLException and returns database error response"() {
        given:
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId("testUser")
        request.setDomain("att.net")
        request.setPasswordName("imap")
        request.setIdpTraceId("trace-create-sqlerror")
        String traceId = "trace-create-sqlerror"

        SQLException sqlException = new SQLException("Database connection failed")
        RuntimeException wrapperException = new RuntimeException("Wrapper", sqlException)

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        MultivaluedMap mockRequestHeaders = Mock(MultivaluedMap)
        httpHeaders.getRequestHeaders() >> mockRequestHeaders

        when:
        Response result = emailAppPasswordResourceImpl.createEmailAppPassword(request, httpHeaders)

        then:
        1 * createEmailAppPasswordRequestValidator.createEmailAppPasswordReqValidator(request, httpHeaders) >> null
        1 * createEmailAppPasswordService.createEmailAppPassword(_, _) >> { throw wrapperException }

        and:
        result != null
        result.status != Response.Status.OK.statusCode || result.entity != null
    }

    def "createEmailAppPassword handles generic exception and returns system error response"() {
        given:
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId("testUser")
        request.setDomain("att.net")
        request.setPasswordName("imap")
        request.setIdpTraceId("trace-create-generr")
        String traceId = "trace-create-generr"

        RuntimeException genericException = new RuntimeException("Unexpected system error")

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        MultivaluedMap mockRequestHeaders = Mock(MultivaluedMap)
        httpHeaders.getRequestHeaders() >> mockRequestHeaders

        when:
        Response result = emailAppPasswordResourceImpl.createEmailAppPassword(request, httpHeaders)

        then:
        1 * createEmailAppPasswordRequestValidator.createEmailAppPasswordReqValidator(request, httpHeaders) >> null
        1 * createEmailAppPasswordService.createEmailAppPassword(_, _) >> { throw genericException }

        and:
        result != null
    }

    def "createEmailAppPassword includes trace ID in response"() {
        given:
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId("testUser")
        request.setDomain("att.net")
        request.setPasswordName("imap")
        request.setIdpTraceId("unique-trace-id-999")
        String traceId = "unique-trace-id-999"

        CreateEmailAppPasswordResponse serviceResponse = new CreateEmailAppPasswordResponse()
        serviceResponse.setAppCategoryCode("0")
        serviceResponse.setAppStatusCode("0")
        serviceResponse.setPassword("testPassword")
        serviceResponse.setIdpTraceId(traceId)

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        MultivaluedMap mockRequestHeaders = Mock(MultivaluedMap)
        httpHeaders.getRequestHeaders() >> mockRequestHeaders

        when:
        Response result = emailAppPasswordResourceImpl.createEmailAppPassword(request, httpHeaders)

        then:
        1 * createEmailAppPasswordRequestValidator.createEmailAppPasswordReqValidator(request, httpHeaders) >> null
        1 * createEmailAppPasswordService.createEmailAppPassword(request, mockRequestHeaders) >> serviceResponse

        and:
        result != null
        CreateEmailAppPasswordResponse responseEntity = result.entity as CreateEmailAppPasswordResponse
        responseEntity.idpTraceId == traceId
    }

    def "createEmailAppPassword handles null request gracefully"() {
        given:
        CreateEmailAppPasswordRequest request = null
        String traceId = "trace-create-null"

        CreateEmailAppPasswordResponse validationErrorResponse = new CreateEmailAppPasswordResponse()
        validationErrorResponse.setAppCategoryCode("3")
        validationErrorResponse.setAppStatusCode("100")

        httpHeaders.getHeaderString(ProfileOrchestrationConstants.IDP_TRACE_ID) >> traceId
        MultivaluedMap mockRequestHeaders = Mock(MultivaluedMap)
        httpHeaders.getRequestHeaders() >> mockRequestHeaders

        when:
        Response result = emailAppPasswordResourceImpl.createEmailAppPassword(request, httpHeaders)

        then:
        1 * createEmailAppPasswordRequestValidator.createEmailAppPasswordReqValidator(request, httpHeaders) >> validationErrorResponse
        0 * createEmailAppPasswordService.createEmailAppPassword(_, _)

        and:
        result != null
    }
}
