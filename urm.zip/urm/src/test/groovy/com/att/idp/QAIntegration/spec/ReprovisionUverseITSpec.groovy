package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.GlobalConfig
import com.att.idp.QAIntegration.Helpers.ApiHelpers
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Tag
import spock.lang.Unroll

@Slf4j
@Tag("Regression")
@Tag("IdGraphUserRegistrationMs")
@IgnoreIf({ !GlobalConfig.isTestCaseEnabled("ReprovisionUverseITSpec") })
class ReprovisionUverseITSpec extends TestBase {

    @Unroll
    def "ReprovisionUverse negative - #scenario.name"() {
        setup:
        TestBase.setTestName("ReprovisionUverse Negative — ${scenario.name}")
        TestBase.logStep("POST ${GlobalConfig.Endpoints.REPROVISION_UVERSE} — ${scenario.name}")

        Map<String, Object> payload = [:]
        if (scenario.accessId != null) payload.accessId = scenario.accessId
        if (scenario.domain != null) payload.domain = scenario.domain

        when: "ReprovisionUverse API is called with invalid parameters"
        Response response = ApiHelpers.reprovisionUverse(payload, "IDP")

        then: "No mock interactions — real HTTP call"
        0 * _

        and: "API returns expected error response"
        def expectedStatuses = scenario.expectedStatus instanceof List ? scenario.expectedStatus : [scenario.expectedStatus]
        assert response.statusCode() in expectedStatuses :
                "Expected HTTP ${expectedStatuses} but got: ${response.statusCode()}"

        where:
        scenario << getNegativeScenarios()
    }

    static List getNegativeScenarios() {
        GlobalConfig.getTestData()?.reprovisionUverse?.negative ?: []
    }
}
