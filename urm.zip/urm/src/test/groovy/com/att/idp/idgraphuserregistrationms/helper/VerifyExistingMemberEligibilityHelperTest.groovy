package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.*
import com.att.idp.idgraphuserregistrationms.helper.voltage.ProofingEncryptionHelper
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import com.att.mpsys.common.utils.*

class VerifyExistingMemberEligibilityHelperTest extends Specification {

	def testObj=new VerifyExistingMemberEligibilityHelper();

    AccountInfoDBHelper accountInfoDBHelperObj = Mock(AccountInfoDBHelper)

    GetProvisionedServicesDBHelper getProvisionedServicesDBHelperObj = Mock(GetProvisionedServicesDBHelper)

    GetMemberServicesDBHelper getMemberServicesDBHelperObj = Mock(GetMemberServicesDBHelper)

	SubAccountsDBHelper subAccountsDBHelperObj = Mock(SubAccountsDBHelper)

	GetAssociatedMembersDBHelper getAssociatedMembersDBHelperObj = Mock(GetAssociatedMembersDBHelper)

	ProofingEncryptionHelper proofingEncryptionHelperObj = Mock(ProofingEncryptionHelper)

	LockoutHelper oLockoutHelper = Mock(LockoutHelper)
	
    public static final Logger logger = LoggerFactory.getLogger(VerifyExistingMemberEligibilityHelperTest.class)

    private Map<String, Object> hmResult

    private String stAppStatusMsg

    private String stAppInfo

    private HashMap hmInput = CommonUtil.hashMap
    private HashMap hmRecordNotFoundErr = CommonUtil.hashMap
    private HashMap hmAccountInfo = CommonUtil.hashMap

    private HashMap hmInstanceValue = CommonUtil.hashMap
    private HashMap hmInstanceValue2 = CommonUtil.hashMap
    private HashMap hmInstance = CommonUtil.hashMap
    private HashMap hmInstance2 = CommonUtil.hashMap
    private HashMap hmservice = CommonUtil.hashMap
    private HashMap hmProvisionResponse = CommonUtil.hashMap
    private HashMap hmMemberServciesByBan = CommonUtil.hashMap
    private HashMap hmLockOutResponse = CommonUtil.hashMap
    HashMap<String, Object> sub1 = new HashMap<String, Object>()
    HashMap<String, Object> sub2 = new HashMap<String, Object>()
    HashMap<String, Object> sub3 = new HashMap<String, Object>()
    HashMap<String, Object> sub4 = new HashMap<String, Object>()
    HashMap<String, Object> sub5 = new HashMap<String, Object>()
    HashMap<String, Object> sub6 = new HashMap<String, Object>()
    HashMap<String, Object> sub7 = new HashMap<String, Object>()
    HashMap<String, Object> sub8 = new HashMap<String, Object>()
    HashMap<String, Object> sub9 = new HashMap<String, Object>()
    HashMap<String, Object> sub10 = new HashMap<String, Object>()
    HashMap<String, Object> sub11 = new HashMap<String, Object>()


    private HashMap<String, Object> hmInvalidDataErr

    private HashMap hmMemByHandle = CommonUtil.hashMap
    ArrayList<HashMap<String, Object>> alSubs = new ArrayList<>()
    HashMap hmaccountInfoHash = new HashMap<>()
    HashMap<String, Object> hmSubResult = null


    def setup() {

       testObj.accountInfoDBHelper=accountInfoDBHelperObj
       testObj.getProvisionedServicesDBHelper=getProvisionedServicesDBHelperObj
       testObj.getMemberServicesDBHelper=getMemberServicesDBHelperObj
       testObj.subAccountsDBHelper=subAccountsDBHelperObj
       testObj.getAssociatedMembersDBHelper=getAssociatedMembersDBHelperObj
       testObj.proofingEncryptionHelperObj=proofingEncryptionHelperObj
       testObj.oLockoutHelper=oLockoutHelper
        
        
        hmInput[CommonDefs.TRANSACTION_NAME] = 'VerifyExistingMemberEligibility'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.BAN] = '001146267'
        hmInput[CommonDefs.HANDLE] = 'prodigy.net'
        hmInput[CommonDefs.DOMAIN] = 'att.net'

        hmMemByHandle['parent_name'] = 'qayma0079827'
        hmMemByHandle['account_type'] = 'R'
        hmMemByHandle['agg_service_status'] = '0'
        hmMemByHandle['parent_name'] = 'qayma0079827'
        hmMemByHandle['bulk_billing_ind'] = 'Y'
        hmMemByHandle['last_member_status_name'] = 'Enbaled'
        hmMemByHandle['sor_name'] = 'ACE'
        hmMemByHandle['member_state'] = 'INUSE'
        hmMemByHandle['delete_request_date'] = new java.util.Date()
        hmMemByHandle['appStatusCode'] = '0'
        hmMemByHandle['group_num'] = '20002094'
        hmMemByHandle['member_name'] = 'qayma0079827'

        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'PORTAL'

        HashMap<String, Object> portalService = new HashMap<String, Object>()

        portalService['group_status_name'] = 'Suspended'
        portalService['member_status_name'] = 'Suspended'
        portalService['portal_provider'] = 'AT&T NAP'
        portalService['delete_request_date'] = '09252020 04:48:26'

        HashMap<String, Object> services = new HashMap<String, Object>()
        services[MPSDefs.PORTAL_SERVICE] = portalService
        hmMemByHandle[MPSDefs.SERVICES] = services

        hmAccountInfo['account_type'] = 'R'
        hmAccountInfo['account_subtype'] = '9'
        hmAccountInfo['ban'] = '001146267'
        hmAccountInfo['account_type'] = 'R'

        ArrayList<HashMap> alaccountInfo = new ArrayList<HashMap>()
        alaccountInfo.add(hmAccountInfo)

        hmaccountInfoHash['accountInfo'] = alaccountInfo
        hmaccountInfoHash['appStatusCode'] = '0'

        sub1['last_member_status_name'] = null
        sub1['sor_name'] = null
        sub1['agg_service_status'] = '0'
        sub1['group_num'] = '20002094'
        sub1['agg_access_status'] = '0'
        sub1['agg_access_status'] = null
        sub1['sor_id'] = null

        sub2.putAll(sub1)
        sub3.putAll(sub1)
        sub4.putAll(sub1)
        sub5.putAll(sub1)
        sub6.putAll(sub1)
        sub7.putAll(sub1)
        sub8.putAll(sub1)
        sub9.putAll(sub1)
        sub10.putAll(sub1)
        sub11.putAll(sub1)

        alSubs.add(sub1)
        alSubs.add(sub2)
        alSubs.add(sub3)
        alSubs.add(sub4)
        alSubs.add(sub5)
        alSubs.add(sub6)
        alSubs.add(sub7)
        alSubs.add(sub8)
        alSubs.add(sub9)

        HashMap<String, Object> hmPortalService = new HashMap<String, Object>()

        hmPortalService['portal_provider'] = CommonDefs.PORTAL_PROVIDER_ATT_NAP
        hmPortalService['member_status_name'] = 'Enabled'
        hmPortalService['group_status_name'] = 'Enabled'
        hmPortalService['member_status_name'] = 'Enabled'
        hmPortalService['group_status_name'] = 'Enabled'
        hmPortalService['member_state'] = 'INUSE'
        hmPortalService['member_num'] = '20002096'

        HashMap<String, Object> hmService = new HashMap<String, Object>()
        hmService['PORTAL'] = hmPortalService

        sub1['services'] = hmService
        sub2['services'] = hmService
        sub3['services'] = hmService
        sub4['services'] = hmService
        sub5['services'] = hmService
        sub6['services'] = hmService
        sub7['services'] = hmService
        sub8['services'] = hmService
        sub9['services'] = hmService
        sub10['services'] = hmService
        sub11['services'] = hmService

        hmSubResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')

        hmSubResult['subaccounts'] = alSubs

        hmRecordNotFoundErr = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
				CErrorDefs.ERR_REC_NOT_FOUND)
        hmInvalidDataErr = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, CErrorDefs.ERR_INVALID_DATA)

        ReflectionTestUtils.setField(testObj, 'sSPIEncryptionType', 'V')
        ReflectionTestUtils.setField(testObj, 'propLsMinAge', '18')
        ReflectionTestUtils.setField(testObj, 'propSubEligibleServices', 'A|1544|I|I2|PORTAL|VOIP|HSIA')
        ReflectionTestUtils.setField(testObj, 'propLSRegBlockSORs', 'WN')
        ReflectionTestUtils.setField(testObj, 'propResidentialAccountSubTypes', 'R|H|S')


    }


    def "veme null input hash case"() {

        given:
        hmResult = testObj.verifyExistingMemberEligibility(null)

        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        when:
        logger.info('vemeNullInputHashCase:' + hmResult)

        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
    }


    def "verify existing member eligibility b a n not found error case"() {

        given:
        hmInput[CommonDefs.BAN] = '1234'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmRecordNotFoundErr
        hmResult = testObj.verifyExistingMemberEligibility(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppStatusMsg == 'ERR_BAN_NOT_FOUND'

    }

    def "verify existing member eligibility get account info n u l l case"() {

        given:
        hmInput[CommonDefs.BAN] = '1234'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> null
        hmResult = testObj.verifyExistingMemberEligibility(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Null or empty response AccountInfoDBHelper'

    }


    def "verify existing member eligibility with d b suspended main m i d"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        hmInput[CommonDefs.HANDLE] = 'superseded_main_mid'
        hmInput[CommonDefs.DOMAIN] = 'att.net'

        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash
        hmAccountInfo['superseded_main_mid'] = 'superseded_main_mid@att.net'

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'

    }


    def "verify existing member eligibility provisioned services"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['service_eligibility'] = 'Y'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoip = new HashMap<String, Object>()
        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace

        // hmVoip.put("VOIP", hmVoipInstaceMain);

		HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['VOIP'] = hmVoipInstaceMain

        hmProvisionResponse['services'] = hmServices

		getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse
        hmResult = testObj.verifyExistingMemberEligibility(hmInput)
        logger.info('verifyExistingMemberEligibilityProvisionedServices' + hmResult)

        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_TERMS_AND_CONDITION_NOT_ACCEPTED'

    }


    def "verify existing member eligibility provisioned services null case"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['service_eligibility'] = 'Y'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoip = new HashMap<String, Object>()
        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['VOIP'] = hmVoipInstaceMain

        hmProvisionResponse['services'] = hmServices

		getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> null	
        hmResult = testObj.verifyExistingMemberEligibility(hmInput)
        logger.info('verifyExistingMemberEligibilityProvisionedServices' + hmResult)

        stAppInfo=(String) hmResult[CommonDefs.COMMON_APP_INFO]
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppInfo == 'Null or empty response GetProvisionedServicesDBHelper'

    }


    def "verify existing member eligibility member services"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'OK'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'
        hmMemberServciesByBan['appStatusMsg'] = 'OK'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoip = new HashMap<String, Object>()
        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices
        logger.info('verifyExistingMemberEligibilityMemberServices' + hmProvisionResponse)

	    getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse	

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemberServciesByBan	

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)
        logger.info('verifyExistingMemberEligibilityMemberServices' + hmResult)

        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_MEMBER_ID_FORCE'

    }


    def "verify existing member eligibility member services null case"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'OK'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'
        hmMemberServciesByBan['appStatusMsg'] = 'OK'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoip = new HashMap<String, Object>()
        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices
        logger.info('verifyExistingMemberEligibilityMemberServices' + hmProvisionResponse)

        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse	
        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> null	

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)
        logger.info('verifyExistingMemberEligibilityMemberServices' + hmResult)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Null or empty response GetMemberServicesDBHelper'

    }


    def "verify existing member eligibility with age less than eighteen"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash
        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'OK'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'
        hmMemberServciesByBan['appStatusMsg'] = 'OK'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        hmMemberServciesByBan['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices
        logger.info('verifyExistingMemberEligibilityMemberServices' + hmProvisionResponse)
 
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse	

        HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>()

        hmTITANInstace['instance_id'] = 'tid13977'
        hmTITANInstace['group_status_name'] = 'Enabled'
        hmTITANInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>()

        hmTITANInstaceMain['tid13977'] = hmTITANInstace
        hmTITANInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmTitanServices = new HashMap<String, Object>()

        hmTitanServices['TITAN'] = hmTITANInstaceMain
        
        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemberServciesByBan	

        HashMap<String, Object> hmAssociatedMember = new HashMap<String, Object>()
        List<HashMap<String, Object>> alAssociatedMember = new ArrayList<HashMap<String, Object>>()

        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember['sor_invariant_id'] = '1234566'
        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember[MPSDefs.SERVICES] = hmTitanServices

        alAssociatedMember.add(hmAssociatedMember)

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                'Success')
        hmAssocResponse['associatedMembers'] = alAssociatedMember

		getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>> hmAssocResponse	
        HashMap<String, Object> hmProofingEncryption_HResponse = CommonErrorMap
				.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')

        hmProofingEncryption_HResponse[MPSDefs.DB_BIRTHDATE_VENC] = '11112010'

		proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap)>> hmProofingEncryption_HResponse

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)
        logger.info('verifyExistingMemberEligibilityWithAgeLessThanEighteen' + hmResult)

        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_AGE_MIN_VIOLATION'

    }


    def "verify existing member eligitbility with max subs exceeded limit"() throws Exception {

        given:
        alSubs.add(sub10)
        alSubs.add(sub11)
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'OK'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'
        hmMemberServciesByBan['appStatusMsg'] = 'OK'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        hmMemberServciesByBan['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices
        logger.info('verifyExistingMemberEligibilityMemberServices' + hmProvisionResponse)

        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse	

        HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>()

        hmTITANInstace['instance_id'] = 'tid13977'
        hmTITANInstace['group_status_name'] = 'Enabled'
        hmTITANInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>()

        hmTITANInstaceMain['tid13977'] = hmTITANInstace
        hmTITANInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmTitanServices = new HashMap<String, Object>()

        hmTitanServices['TITAN'] = hmTITANInstaceMain
        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemberServciesByBan

        HashMap<String, Object> hmAssociatedMember = new HashMap<String, Object>()
        List<HashMap<String, Object>> alAssociatedMember = new ArrayList<HashMap<String, Object>>()

        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember['sor_invariant_id'] = '1234566'
        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember[MPSDefs.SERVICES] = hmTitanServices

        alAssociatedMember.add(hmAssociatedMember)

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                'Success')
        hmAssocResponse['associatedMembers'] = alAssociatedMember
        
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>> hmAssocResponse
        HashMap<String, Object> hmProofingEncryption_HResponse = CommonErrorMap
				.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')

        hmProofingEncryption_HResponse[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
     
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap)>> hmProofingEncryption_HResponse

        HashMap<String, Object> sub10 = new HashMap<String, Object>()
        HashMap<String, Object> sub11 = new HashMap<String, Object>()

        sub10['last_member_status_name'] = null
        sub10['sor_name'] = null
        sub10['agg_service_status'] = '0'
        sub10['group_num'] = '20002094'
        sub10['agg_access_status'] = '0'
        sub10['agg_access_status'] = null
        sub10['sor_id'] = null

        sub11.putAll(sub10)

        alSubs.add(sub10)
        alSubs.add(sub11)

		subAccountsDBHelperObj.getAllSubInfo(_ as HashMap)>> hmSubResult

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)
        logger.info('verifyExistingMemberEligitbilityWithMaxSubsExceededLimit:' + hmResult)

        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_SUB_LIMIT_EXCEEDED'
    }


    def "verify parent d b portal a t t n a p test"() throws Exception {

        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'OK'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'
        hmMemberServciesByBan['appStatusMsg'] = 'OK'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        hmMemberServciesByBan['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices
        logger.info('verifyExistingMemberEligibilityMemberServices' + hmProvisionResponse)

        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse

        HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>()

        hmTITANInstace['instance_id'] = 'tid13977'
        hmTITANInstace['group_status_name'] = 'Enabled'
        hmTITANInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>()

        hmTITANInstaceMain['tid13977'] = hmTITANInstace
        hmTITANInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmTitanServices = new HashMap<String, Object>()

        hmTitanServices['TITAN'] = hmTITANInstaceMain

        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemByHandle	

        HashMap<String, Object> hmAssociatedMember = new HashMap<String, Object>()
        List<HashMap<String, Object>> alAssociatedMember = new ArrayList<HashMap<String, Object>>()

        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember['sor_invariant_id'] = '1234566'
        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember[MPSDefs.SERVICES] = hmTitanServices

        alAssociatedMember.add(hmAssociatedMember)

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                'Success')
        hmAssocResponse['associatedMembers'] = alAssociatedMember

        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>> hmAssocResponse
        HashMap<String, Object> hmProofingEncryption_HResponse = CommonErrorMap
				.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')

        hmProofingEncryption_HResponse[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'

        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap)>> hmProofingEncryption_HResponse
        HashMap<String, Object> hmSubResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                'Success')

        subAccountsDBHelperObj.getAllSubInfo(_ as HashMap)>> hmSubResponse

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)
        logger.info('verifyParentDBPortalATTNAPTest:' + hmResult)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_PORTAL_NAP_YAHOO'

    }


    def "verify sub ac parent portal provider a t t n a p test"() throws Exception {

        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'OK'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'
        hmMemberServciesByBan['appStatusMsg'] = 'OK'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        hmMemberServciesByBan['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices
        logger.info('verifyExistingMemberEligibilityMemberServices' + hmProvisionResponse)

        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse

        HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>()

        hmTITANInstace['instance_id'] = 'tid13977'
        hmTITANInstace['group_status_name'] = 'Enabled'
        hmTITANInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>()

        hmTITANInstaceMain['tid13977'] = hmTITANInstace
        hmTITANInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmTitanServices = new HashMap<String, Object>()

        hmTitanServices['TITAN'] = hmTITANInstaceMain

        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'

        HashMap<String, Object> portalService = new HashMap<String, Object>()
        portalService['group_status_name'] = 'Suspended'
        portalService['member_status_name'] = 'Suspended'
        portalService['portal_provider'] = 'AT&T NAP'
        portalService['delete_request_date'] = '09252020 04:48:26'

        HashMap<String, Object> services = new HashMap<String, Object>()
        services[MPSDefs.PORTAL_SERVICE] = portalService
        hmMemByHandle[MPSDefs.SERVICES] = services

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemByHandle

        HashMap<String, Object> hmAssociatedMember = new HashMap<String, Object>()
        List<HashMap<String, Object>> alAssociatedMember = new ArrayList<HashMap<String, Object>>()

        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember['sor_invariant_id'] = '1234566'
        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember[MPSDefs.SERVICES] = hmTitanServices

        alAssociatedMember.add(hmAssociatedMember)

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                'Success')
        hmAssocResponse['associatedMembers'] = alAssociatedMember

        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>> hmAssocResponse
        HashMap<String, Object> hmProofingEncryption_HResponse = CommonErrorMap
				.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')

        hmProofingEncryption_HResponse[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'

        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap)>> hmProofingEncryption_HResponse
    
        subAccountsDBHelperObj.getAllSubInfo(_ as HashMap)>> hmSubResult

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)
        logger.info('verifySubAcParentPortalProviderATTNAPTest:' + hmResult)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_PORTAL_NAP_YAHOO'

    }


    def "verify delete request date populated test"() throws Exception {

        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'OK'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'
        hmMemberServciesByBan['appStatusMsg'] = 'OK'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        hmMemberServciesByBan['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices
        logger.info('verifyExistingMemberEligibilityMemberServices' + hmProvisionResponse)

        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse

        HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>()

        hmTITANInstace['instance_id'] = 'tid13977'
        hmTITANInstace['group_status_name'] = 'Enabled'
        hmTITANInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>()

        hmTITANInstaceMain['tid13977'] = hmTITANInstace
        hmTITANInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmTitanServices = new HashMap<String, Object>()

        hmTitanServices['TITAN'] = hmTITANInstaceMain

        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'

        HashMap<String, Object> portalService = new HashMap<String, Object>()
        portalService['group_status_name'] = 'Suspended'
        portalService['member_status_name'] = 'Suspended'
        portalService['portal_provider'] = 'AT&T YAHOO'
        portalService['delete_request_date'] = '09252020 04:48:26'

        HashMap<String, Object> services = new HashMap<String, Object>()
        services[MPSDefs.PORTAL_SERVICE] = portalService
        hmMemByHandle[MPSDefs.SERVICES] = services
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'

        hmMemByHandle['delete_request_date'] = new java.util.Date().toString()

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemByHandle

        HashMap<String, Object> hmAssociatedMember = new HashMap<String, Object>()
        List<HashMap<String, Object>> alAssociatedMember = new ArrayList<HashMap<String, Object>>()

        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember['sor_invariant_id'] = '1234566'
        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember[MPSDefs.SERVICES] = hmTitanServices

        alAssociatedMember.add(hmAssociatedMember)

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                'Success')
        hmAssocResponse['associatedMembers'] = alAssociatedMember

        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>> hmAssocResponse
        HashMap<String, Object> hmProofingEncryption_HResponse = CommonErrorMap
				.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')

        hmProofingEncryption_HResponse[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'

        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap)>> hmProofingEncryption_HResponse

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_DELETE_REQUESTED'

    }
	
	
//	@Test
//	public void verifySuccess() throws Exception {
//
//		hmInput.put(CommonDefs.BAN, "001146267");
//		Mockito.when(getMPSDB_AccountInfo_H.getAccountInfo("001146267", log)).thenReturn(hmaccountInfoHash);
//
//		hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, "Success");
//		hmProvisionResponse.put("appStatusMsg", "OK");
//		hmProvisionResponse.put("sqlMsg", "SUCCESS");
//		hmProvisionResponse.put("appStatusMsg", "OK");
//
//		hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, "Success");
//		hmMemberServciesByBan.put("appStatusMsg", "OK");
//		hmMemberServciesByBan.put("sqlMsg", "SUCCESS");
//		hmMemberServciesByBan.put("appStatusMsg", "OK");
//		hmMemByHandle.put("ban", "001146268");
//		hmMemberServciesByBan.put(MPSDefs.DB_MEMBER_NAME, "qay_atto0444");
//		hmMemberServciesByBan.put(MPSDefs.DB_DOMAIN_NAME, "att.net");
//		hmMemberServciesByBan.put(MPSDefs.DB_BAN, "001146268");
//		hmMemberServciesByBan.put("birthdate_venc", "kUi}q|uPPKNB.u_");
//		HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>();
//
//		hmVoipInstace.put("instance_id", "tid13977");
//		hmVoipInstace.put("group_status_name", "Enabled");
//		hmVoipInstace.put("sor_invariant_id", "LS3CMP0012520");
//
//		HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>();
//
//		hmVoipInstaceMain.put("tid13977", hmVoipInstace);
//		hmVoipInstaceMain.put(MPSDefs.SERVICE_STATUS, MPSDefs.TERMINATED);
//
//		HashMap<String, Object> hmServices = new HashMap<String, Object>();
//		hmServices.put("HSIA", hmVoipInstaceMain);
//		hmServices.put("group_status_name", "Enabled");
//		hmServices.put(MPSDefs.DB_BAN, "001146268");
//		hmMemberServciesByBan.put("services", hmServices);
//		log.info("verifyExistingMemberEligibilityMemberServices" + hmProvisionResponse);
//
//		Mockito.when(
//				getMPSDB_GetProvisionedServices_H.getProvisionedServices(Mockito.any(HashMap.class), Mockito.eq(log)))
//				.thenReturn(hmProvisionResponse);
//
//
//		HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>();
//
//		hmTITANInstace.put("instance_id", "tid13977");
//		hmTITANInstace.put("group_status_name", "Enabled");
//		hmTITANInstace.put("sor_invariant_id", "LS3CMP0012520");
//
//		HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>();
//
//		hmTITANInstaceMain.put("tid13977", hmTITANInstace);
//		hmTITANInstaceMain.put(MPSDefs.SERVICE_STATUS, MPSDefs.ENABLED);
//
//		HashMap<String, Object> hmTitanServices = new HashMap<String, Object>();
//
//		hmTitanServices.put("TITAN", hmTITANInstaceMain);
//
//		hmMemByHandle.put("birthdate_venc", "kUi}q|uPPKNB.u_");
//
//		HashMap<String, Object> portalService = new HashMap<String, Object>();
//		portalService.put("group_status_name", "Suspended");
//		portalService.put("member_status_name", "Suspended");
//		portalService.put("portal_provider", "AT&T YAHOO");
//		// portalService.put("delete_request_date", "09252020 04:48:26");
//		HashMap<String, Object> hsiaService = new HashMap<String, Object>();
//		hsiaService.put("group_status_name", "Enabled");
//		hsiaService.put(MPSDefs.SERVICE_STATUS, "Enabled");
//		hsiaService.put("portal_provider", "AT&T YAHOO");
//		
//		HashMap<String, Object> iptvService = new HashMap<String, Object>();
//		iptvService.put("group_status_name", "Enabled");
//		iptvService.put(MPSDefs.SERVICE_STATUS, "Enabled");
//		iptvService.put("portal_provider", "AT&T YAHOO");
//
//		HashMap<String, Object> services = new HashMap<String, Object>();
//		services.put(MPSDefs.PORTAL_SERVICE, portalService);
//		services.put(MPSDefs.HSIA_SERVICE, hsiaService);
//		services.put(MPSDefs.IPTV_SERVICE, iptvService);
//		hmMemByHandle.put(MPSDefs.SERVICES, services);
//		hmMemByHandle.put(MPSDefs.DB_SOR_NAME, "LS");
//		hmMemByHandle.put(MPSDefs.DB_SLID_MEMBER_NUM, "12345666");
//		hmMemByHandle.put("delete_request_date", null);
//
//		Mockito.when(getMPSDB_GetMemberServices_H.getMemberServices(Mockito.any(HashMap.class), Mockito.eq(log)))
//				.thenReturn(hmMemByHandle);
//
//		HashMap<String, Object> hmAssociatedMember = new HashMap<String, Object>();
//		List<HashMap<String, Object>> alAssociatedMember = new ArrayList<HashMap<String, Object>>();
//
//		hmAssociatedMember.put(MPSDefs.DB_SLID_MEMBER_NUM, "1234566");
//		hmAssociatedMember.put("sor_invariant_id", "1234566");
//		hmAssociatedMember.put(MPSDefs.DB_SLID_MEMBER_NUM, "1234566");
//		hmAssociatedMember.put(MPSDefs.SERVICES, hmTitanServices);
//
//		alAssociatedMember.add(hmAssociatedMember);
//
//		HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
//				"Success");
//		hmAssocResponse.put("associatedMembers", alAssociatedMember);
//
//		Mockito.when(getMPSDB_GetAssociatedMembers_H.getAssociatedMembers(Mockito.any(HashMap.class), Mockito.eq(log)))
//				.thenReturn(hmAssocResponse);
//		HashMap<String, Object> hmProofingEncryption_HResponse = CommonErrorMap
//				.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, "Success");
//
//		hmProofingEncryption_HResponse.put(MPSDefs.DB_BIRTHDATE_VENC, "11112000");
//
//		Mockito.when(proofingEncryption_H.getDecryptedValues(Mockito.any(HashMap.class), Mockito.eq(log)))
//				.thenReturn(hmProofingEncryption_HResponse);
//		Mockito.when(getMPSDB_SubAccounts_H.getAllSubInfo(Mockito.any(HashMap.class), Mockito.eq(log)))
//		.thenReturn(hmSubResult);
//
//		// 2208 Allow SMB customers to accept HSIA and VOIP T&Cs independently and register - prod issue
//		hmResult = testObj.verifyExistingMemberEligibility(null);
//		log.info("verifySmallBusinessAccountIsAllowedForLSReg:" + hmResult);
//		stAppStatusMsg = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG);
//		assertEquals("SUCCESS", stAppStatusMsg);
//
//	}


    def "verify small business account is allowed for l s reg"() throws Exception {

        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'OK'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'
        hmMemberServciesByBan['appStatusMsg'] = 'OK'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        hmMemberServciesByBan['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices
        logger.info('verifyExistingMemberEligibilityMemberServices' + hmProvisionResponse)

        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse

        HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>()

        hmTITANInstace['instance_id'] = 'tid13977'
        hmTITANInstace['group_status_name'] = 'Enabled'
        hmTITANInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>()

        hmTITANInstaceMain['tid13977'] = hmTITANInstace
        hmTITANInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmTitanServices = new HashMap<String, Object>()

        hmTitanServices['TITAN'] = hmTITANInstaceMain

        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'

        HashMap<String, Object> portalService = new HashMap<String, Object>()
        portalService['group_status_name'] = 'Suspended'
        portalService['member_status_name'] = 'Suspended'
        portalService['portal_provider'] = 'AT&T YAHOO'
        // portalService.put("delete_request_date", "09252020 04:48:26");

		HashMap<String, Object> services = new HashMap<String, Object>()
        services[MPSDefs.PORTAL_SERVICE] = portalService
        hmMemByHandle[MPSDefs.SERVICES] = services
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_SLID_MEMBER_NUM] = '12345666'
        hmMemByHandle['delete_request_date'] = null

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemByHandle

        HashMap<String, Object> hmAssociatedMember = new HashMap<String, Object>()
        List<HashMap<String, Object>> alAssociatedMember = new ArrayList<HashMap<String, Object>>()

        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember['sor_invariant_id'] = '1234566'
        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember[MPSDefs.SERVICES] = hmTitanServices

        alAssociatedMember.add(hmAssociatedMember)

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                'Success')
        hmAssocResponse['associatedMembers'] = alAssociatedMember
        
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>> hmAssocResponse	
        HashMap<String, Object> hmProofingEncryption_HResponse = CommonErrorMap
				.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')

        hmProofingEncryption_HResponse[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'

	    proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap)>> hmProofingEncryption_HResponse
	    subAccountsDBHelperObj.getAllSubInfo(_ as HashMap)>> hmSubResult

        // 2208 Allow SMB customers to accept HSIA and VOIP T&Cs independently and register - prod issue
		hmResult = testObj.verifyExistingMemberEligibility(hmInput)
        logger.info('verifySmallBusinessAccountIsAllowedForLSReg:' + hmResult)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'SUCCESS'

    }


    def "verify input handle linked to different than titan slid"() throws Exception {

        given:
        hmInput[CommonDefs.BAN] = '001146267'
        hmAccountInfo['account_subtype'] = 'R'

        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'OK'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'
        hmMemberServciesByBan['appStatusMsg'] = 'OK'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        hmMemberServciesByBan['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices
        logger.info('verifyExistingMemberEligibilityMemberServices' + hmProvisionResponse)

        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse

        HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>()

        hmTITANInstace['instance_id'] = 'tid13977'
        hmTITANInstace['group_status_name'] = 'Enabled'
        hmTITANInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>()

        hmTITANInstaceMain['tid13977'] = hmTITANInstace
        hmTITANInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmTitanServices = new HashMap<String, Object>()

        hmTitanServices['TITAN'] = hmTITANInstaceMain

        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'

        HashMap<String, Object> portalService = new HashMap<String, Object>()
        portalService['group_status_name'] = 'Suspended'
        portalService['member_status_name'] = 'Suspended'
        portalService['portal_provider'] = 'AT&T YAHOO'
        // portalService.put("delete_request_date", "09252020 04:48:26");

		HashMap<String, Object> services = new HashMap<String, Object>()
        services[MPSDefs.PORTAL_SERVICE] = portalService
        hmMemByHandle[MPSDefs.SERVICES] = services
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_SLID_MEMBER_NUM] = '12345666'
        hmMemByHandle['delete_request_date'] = null

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemByHandle

        HashMap<String, Object> hmAssociatedMember = new HashMap<String, Object>()
        List<HashMap<String, Object>> alAssociatedMember = new ArrayList<HashMap<String, Object>>()

        hmAssociatedMember[MPSDefs.DB_MEMBER_NUM] = '1234566'
        hmAssociatedMember['sor_invariant_id'] = '1234566'
        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember[MPSDefs.SERVICES] = hmTitanServices

        alAssociatedMember.add(hmAssociatedMember)

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                'Success')
        hmAssocResponse['associatedMembers'] = alAssociatedMember
        
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>> hmAssocResponse
        HashMap<String, Object> hmProofingEncryption_HResponse = CommonErrorMap
				.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')

        hmProofingEncryption_HResponse[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'

	    proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap)>> hmProofingEncryption_HResponse

        subAccountsDBHelperObj.getAllSubInfo(_ as HashMap)>> hmSubResult

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)
        logger.info('verifyInputHandleLinkedToDifferentThanTitanSlid' + hmResult)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'SUCCESS'

    }


    def "verify input ban has active l s services"() throws Exception {

        given:
        hmInput[CommonDefs.BAN] = '001146267'
        hmAccountInfo['account_subtype'] = 'R'

        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'OK'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'
        hmMemberServciesByBan['appStatusMsg'] = 'OK'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        hmMemberServciesByBan['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices
        logger.info('verifyExistingMemberEligibilityMemberServices' + hmProvisionResponse)
        
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse

        HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>()

        hmTITANInstace['instance_id'] = 'tid13977'
        hmTITANInstace['group_status_name'] = 'Enabled'
        hmTITANInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>()

        hmTITANInstaceMain['tid13977'] = hmTITANInstace
        hmTITANInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmTitanServices = new HashMap<String, Object>()

        hmTitanServices['TITAN'] = hmTITANInstaceMain

        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'

        HashMap<String, Object> portalService = new HashMap<String, Object>()
        portalService['group_status_name'] = 'Suspended'
        portalService['member_status_name'] = 'Suspended'
        portalService['portal_provider'] = 'AT&T YAHOO'
        // portalService.put("delete_request_date", "09252020 04:48:26");

		HashMap<String, Object> services = new HashMap<String, Object>()
        services[MPSDefs.PORTAL_SERVICE] = portalService
        hmMemByHandle[MPSDefs.SERVICES] = services
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmMemByHandle['delete_request_date'] = null
        
        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemByHandle

        HashMap<String, Object> hmAssociatedMember = new HashMap<String, Object>()
        List<HashMap<String, Object>> alAssociatedMember = new ArrayList<HashMap<String, Object>>()

        hmAssociatedMember[MPSDefs.DB_MEMBER_NUM] = '1234566'
        hmAssociatedMember['sor_invariant_id'] = '1234566'
        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember[MPSDefs.SERVICES] = hmTitanServices

        alAssociatedMember.add(hmAssociatedMember)

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                'Success')
        hmAssocResponse['associatedMembers'] = alAssociatedMember

        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>> hmAssocResponse
        HashMap<String, Object> hmProofingEncryption_HResponse = CommonErrorMap
				.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')

        hmProofingEncryption_HResponse[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'

        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap)>> hmProofingEncryption_HResponse

        subAccountsDBHelperObj.getAllSubInfo(_ as HashMap)>> hmSubResult

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)
        logger.info('hmResult' + hmResult)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'SUCCESS'
    }


    def "verify existing m e get associated d b helper return n u l l"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'OK'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'
        hmMemberServciesByBan['appStatusMsg'] = 'OK'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        hmMemberServciesByBan['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices

        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse

        HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>()

        hmTITANInstace['instance_id'] = 'tid13977'
        hmTITANInstace['group_status_name'] = 'Enabled'
        hmTITANInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>()

        hmTITANInstaceMain['tid13977'] = hmTITANInstace
        hmTITANInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmTitanServices = new HashMap<String, Object>()

        hmTitanServices['TITAN'] = hmTITANInstaceMain

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemberServciesByBan	

        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>> null

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Null or empty response GetAssociatedMembersDBHelper.getAssociatedMembers'

    }


    def "verify existing m e system error from proofing encryption h"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'OK'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'
        hmMemberServciesByBan['appStatusMsg'] = 'OK'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        hmMemberServciesByBan['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices

        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse

        HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>()

        hmTITANInstace['instance_id'] = 'tid13977'
        hmTITANInstace['group_status_name'] = 'Enabled'
        hmTITANInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>()

        hmTITANInstaceMain['tid13977'] = hmTITANInstace
        hmTITANInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmTitanServices = new HashMap<String, Object>()

        hmTitanServices['TITAN'] = hmTITANInstaceMain

        HashMap<String, Object> hmAssociatedMember = new HashMap<String, Object>()
        List<HashMap<String, Object>> alAssociatedMember = new ArrayList<HashMap<String, Object>>()

        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember['sor_invariant_id'] = '1234566'
        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember[MPSDefs.SERVICES] = hmTitanServices

        alAssociatedMember.add(hmAssociatedMember)

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                'Success')
        hmAssocResponse['associatedMembers'] = alAssociatedMember

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemberServciesByBan

        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>> hmAssocResponse

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

       // when:
       // stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
       // then:
       // stAppInfo == 'SYSTEM ERROR'

    }


    def "verify existing m e system error from sub account d b helper"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'OK'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'
        hmMemberServciesByBan['appStatusMsg'] = 'OK'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        hmMemberServciesByBan['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices

        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse

        HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>()

        hmTITANInstace['instance_id'] = 'tid13977'
        hmTITANInstace['group_status_name'] = 'Enabled'
        hmTITANInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>()

        hmTITANInstaceMain['tid13977'] = hmTITANInstace
        hmTITANInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmTitanServices = new HashMap<String, Object>()

        hmTitanServices['TITAN'] = hmTITANInstaceMain

        HashMap<String, Object> hmAssociatedMember = new HashMap<String, Object>()
        List<HashMap<String, Object>> alAssociatedMember = new ArrayList<HashMap<String, Object>>()

        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember['sor_invariant_id'] = '1234566'
        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember[MPSDefs.SERVICES] = hmTitanServices

        alAssociatedMember.add(hmAssociatedMember)

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                'Success')
        hmAssocResponse['associatedMembers'] = alAssociatedMember

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemberServciesByBan

        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>> hmAssocResponse	

        HashMap<String, Object> hmProofingEncryption_HResponse = CommonErrorMap
				.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')

        hmProofingEncryption_HResponse[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'

        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap)>> hmProofingEncryption_HResponse

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Null or empty response SubAccountsDBHelper.getAllSubInfo'

    }


    def "verify member not parent"() throws Exception {

        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'SUCCESS'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        hmMemberServciesByBan[MPSDefs.DB_PARENT_CHILD_IND] = 'S'
        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices

        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse

        HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>()

        hmTITANInstace['instance_id'] = 'tid13977'
        hmTITANInstace['group_status_name'] = 'Enabled'
        hmTITANInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>()

        hmTITANInstaceMain['tid13977'] = hmTITANInstace
        hmTITANInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmTitanServices = new HashMap<String, Object>()

        hmTitanServices['TITAN'] = hmTITANInstaceMain

        HashMap<String, Object> hmAssociatedMember = new HashMap<String, Object>()
        List<HashMap<String, Object>> alAssociatedMember = new ArrayList<HashMap<String, Object>>()

        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember['sor_invariant_id'] = '1234566'
        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember[MPSDefs.SERVICES] = hmTitanServices

        alAssociatedMember.add(hmAssociatedMember)

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                'Success')
        hmAssocResponse['associatedMembers'] = alAssociatedMember

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemberServciesByBan

        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>> hmAssocResponse

        HashMap<String, Object> hmProofingEncryption_HResponse = CommonErrorMap
				.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')


        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Member is NOT a parent'

    }


    def "test null responsefrom sub account d b helper"() throws Exception {

        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'SUCCESS'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        hmMemberServciesByBan[MPSDefs.DB_PARENT_CHILD_IND] = 'P'

        ArrayList alLockoutInfo= new ArrayList<>()
        hmMemberServciesByBan[MPSDefs.DB_MEMBERLOCKOUT] = alLockoutInfo

        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices

        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse	

        HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>()

        hmTITANInstace['instance_id'] = 'tid13977'
        hmTITANInstace['group_status_name'] = 'Enabled'
        hmTITANInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>()

        hmTITANInstaceMain['tid13977'] = hmTITANInstace
        hmTITANInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmTitanServices = new HashMap<String, Object>()

        hmTitanServices['TITAN'] = hmTITANInstaceMain

        HashMap<String, Object> hmAssociatedMember = new HashMap<String, Object>()
        List<HashMap<String, Object>> alAssociatedMember = new ArrayList<HashMap<String, Object>>()

        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember['sor_invariant_id'] = '1234566'
        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember[MPSDefs.SERVICES] = hmTitanServices

        alAssociatedMember.add(hmAssociatedMember)

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                'Success')
        hmAssocResponse['associatedMembers'] = alAssociatedMember

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemberServciesByBan
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>> hmAssocResponse	

        HashMap<String, Object> hmProofingEncryption_HResponse = CommonErrorMap
				.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Null or empty response SubAccountsDBHelper.getAllSubInfo'

    }


    def "test error from lock out helper"() throws Exception {

        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'SUCCESS'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        hmMemberServciesByBan[MPSDefs.DB_PARENT_CHILD_IND] = 'P'

        ArrayList alLockoutInfo= CommonUtil.arrayList
        HashMap hmLockOutDetails= CommonUtil.hashMap
        hmLockOutDetails[MPSDefs.DB_LOCKOUT_ID] = '12'
        hmLockOutDetails[MPSDefs.DB_SET_NUMBER] = '123'
        hmLockOutDetails[MPSDefs.DB_MEMBER_NUM] = '1234566'
        hmLockOutDetails[MPSDefs.DB_ACCOUNT_ID] = '156527'
        alLockoutInfo.add(hmLockOutDetails)

        hmMemberServciesByBan[MPSDefs.DB_MEMBERLOCKOUT] = alLockoutInfo

        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices

        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse

        HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>()

        hmTITANInstace['instance_id'] = 'tid13977'
        hmTITANInstace['group_status_name'] = 'Enabled'
        hmTITANInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>()

        hmTITANInstaceMain['tid13977'] = hmTITANInstace
        hmTITANInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmTitanServices = new HashMap<String, Object>()

        hmTitanServices['TITAN'] = hmTITANInstaceMain

        HashMap<String, Object> hmAssociatedMember = new HashMap<String, Object>()
        List<HashMap<String, Object>> alAssociatedMember = new ArrayList<HashMap<String, Object>>()

        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember['sor_invariant_id'] = '1234566'
        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember[MPSDefs.SERVICES] = hmTitanServices

        alAssociatedMember.add(hmAssociatedMember)

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                'Success')
        hmAssocResponse['associatedMembers'] = alAssociatedMember

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemberServciesByBan
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>> hmAssocResponse	

        hmLockOutResponse=CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')

        oLockoutHelper.queryLockout(_ as HashMap)>> hmLockOutResponse	

        HashMap<String, Object> hmProofingEncryption_HResponse = CommonErrorMap
				.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SYSTEM ERROR'

    }


    def "test handle locked error"() throws Exception {

        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String)>> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProvisionResponse['appStatusMsg'] = 'OK'
        hmProvisionResponse['sqlMsg'] = 'SUCCESS'
        hmProvisionResponse['appStatusMsg'] = 'OK'

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan['appStatusMsg'] = 'SUCCESS'
        hmMemberServciesByBan['sqlMsg'] = 'SUCCESS'

        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        hmMemberServciesByBan[MPSDefs.DB_PARENT_CHILD_IND] = 'P'

        ArrayList alLockoutInfo= CommonUtil.arrayList
        HashMap hmLockOutDetails= CommonUtil.hashMap
        hmLockOutDetails[MPSDefs.DB_LOCKOUT_ID] = '12'
        hmLockOutDetails[MPSDefs.DB_SET_NUMBER] = '123'
        hmLockOutDetails[MPSDefs.DB_MEMBER_NUM] = '1234566'
        hmLockOutDetails[MPSDefs.DB_ACCOUNT_ID] = '156527'
        alLockoutInfo.add(hmLockOutDetails)

        hmMemberServciesByBan[MPSDefs.DB_MEMBERLOCKOUT] = alLockoutInfo

        HashMap<String, Object> hmVoipInstace = new HashMap<String, Object>()

        hmVoipInstace['instance_id'] = 'tid13977'
        hmVoipInstace['group_status_name'] = 'Enabled'
        hmVoipInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<String, Object>()

        hmVoipInstaceMain['tid13977'] = hmVoipInstace
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED

        HashMap<String, Object> hmServices = new HashMap<String, Object>()
        hmServices['HSIA'] = hmVoipInstaceMain

        hmMemberServciesByBan['services'] = hmServices

        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap)>> hmProvisionResponse	

        HashMap<String, Object> hmTITANInstace = new HashMap<String, Object>()

        hmTITANInstace['instance_id'] = 'tid13977'
        hmTITANInstace['group_status_name'] = 'Enabled'
        hmTITANInstace['sor_invariant_id'] = 'LS3CMP0012520'

        HashMap<String, Object> hmTITANInstaceMain = new HashMap<String, Object>()

        hmTITANInstaceMain['tid13977'] = hmTITANInstace
        hmTITANInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED

        HashMap<String, Object> hmTitanServices = new HashMap<String, Object>()

        hmTitanServices['TITAN'] = hmTITANInstaceMain

        HashMap<String, Object> hmAssociatedMember = new HashMap<String, Object>()
        List<HashMap<String, Object>> alAssociatedMember = new ArrayList<HashMap<String, Object>>()

        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember['sor_invariant_id'] = '1234566'
        hmAssociatedMember[MPSDefs.DB_SLID_MEMBER_NUM] = '1234566'
        hmAssociatedMember[MPSDefs.SERVICES] = hmTitanServices

        alAssociatedMember.add(hmAssociatedMember)

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                'Success')
        hmAssocResponse['associatedMembers'] = alAssociatedMember

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap)>> hmMemberServciesByBan

        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap)>> hmAssocResponse

        hmLockOutResponse=CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        ArrayList alActiveLocks = CommonUtil.arrayList
        HashMap hmEachLock= CommonUtil.hashMap
        hmEachLock[MPSDefs.DB_LOCKOUT_NAME] = 'Test'
        alActiveLocks.add(hmEachLock)
        hmLockOutResponse[CommonDefs.ACTIVE_LOCKS] = alActiveLocks

        oLockoutHelper.queryLockout(_ as HashMap)>> hmLockOutResponse

		HashMap<String, Object> hmProofingEncryption_HResponse = CommonErrorMap
				.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')

		hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Handle currently locked out with a Test lock.'

    }


    // ===========================================================================================
    // NEW TESTS — Uncovered branches in VerifyExistingMemberEligibilityHelper
    // ===========================================================================================

    // ----- Bulk Billing Account (VEMEH_27) -----

    def "verify bulk billing owner returns ERR_BULK"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'

        HashMap<String, Object> hmVoipInstaceMain = new HashMap<>()
        hmVoipInstaceMain[MPSDefs.SERVICE_STATUS] = MPSDefs.TERMINATED
        HashMap<String, Object> hmServices = new HashMap<>()
        hmServices['HSIA'] = hmVoipInstaceMain
        hmMemberServciesByBan['services'] = hmServices

        // Setup hmMemByHandle for handle/domain query — parent, age valid, no lockout
        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = 'O'

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >>> [hmMemberServciesByBan, hmMemByHandle]

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo == 'Member has BULK billing account'
    }

    def "verify bulk billing member returns ERR_BULK"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmSvcs = new HashMap<>()
        hmSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = 'M'

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >>> [hmMemberServciesByBan, hmMemByHandle]

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo == 'Member has BULK billing account'
    }

    // ----- portal.att.net domain (VEMEH_28) -----

    def "verify portal att net domain returns ERR_INVALID_DATA"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        hmInput[CommonDefs.DOMAIN] = 'portal.att.net'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmSvcs = new HashMap<>()
        hmSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >>> [hmMemberServciesByBan, hmMemByHandle]

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo == 'portal.att.net IDs are NOT allowed for LS Registration'
    }

    // ----- SOR=LS, suspended access service (VEMEH_30) -----

    def "verify LS SOR suspended access service returns ERR_NOT_ENABLE"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'HSIA'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null

        HashMap<String, Object> hsiaService = new HashMap<>()
        hsiaService[MPSDefs.SERVICE_STATUS] = MPSDefs.SUSPENDED
        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap['HSIA'] = hsiaService
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >>> [hmMemberServciesByBan, hmMemByHandle]

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo.contains('suspended') && stAppInfo.contains('SOR=LS')
    }

    // ----- SOR=LS, active HSIA with different BAN (VEMEH_31) -----

    def "verify LS SOR active HSIA different BAN returns ERR_ACTIVE_SERVICE"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '999999999'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null

        HashMap<String, Object> hsiaService = new HashMap<>()
        hsiaService[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap['HSIA'] = hsiaService
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >>> [hmMemberServciesByBan, hmMemByHandle]

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo.contains('active LS service')
    }

    // ----- SOR=LS, active IPTV with different BAN (VEMEH_32) -----

    def "verify LS SOR active IPTV different BAN returns ERR_ACTIVE_SERVICE"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '999999999'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null

        HashMap<String, Object> iptvService = new HashMap<>()
        iptvService[MPSDefs.SERVICE_STATUS] = MPSDefs.SUSPENDED
        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.IPTV_SERVICE] = iptvService
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >>> [hmMemberServciesByBan, hmMemByHandle]

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo.contains('active LS service')
    }

    // ----- SOR=LS, active VOIP with different BAN (VEMEH_33) -----

    def "verify LS SOR active VOIP different BAN returns ERR_ACTIVE_SERVICE"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '999999999'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null

        HashMap<String, Object> voipService = new HashMap<>()
        voipService[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.VOIP_SERVICE] = voipService
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >>> [hmMemberServciesByBan, hmMemByHandle]

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo.contains('active LS service')
    }

    // ----- SOR=LS, already registered — HSIA enabled same BAN (VEMEH_34) -----

    def "verify LS SOR already registered HSIA enabled returns ERR_ALREADY_REGD"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null

        HashMap<String, Object> hsiaService = new HashMap<>()
        hsiaService[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap['HSIA'] = hsiaService
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >>> [hmMemberServciesByBan, hmMemByHandle]

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo.contains('active LS service')
    }

    // ----- SBCIPTV with enabled IPTV (VEMEH_35) -----

    def "verify SBCIPTV member with enabled IPTV returns ERR_ALREADY_REGD"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'SBCIPTV_user1'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        HashMap<String, Object> iptvBanSvc = new HashMap<>()
        iptvBanSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        hmBanSvcs[MPSDefs.IPTV_SERVICE] = iptvBanSvc
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null

        HashMap<String, Object> iptvSvc = new HashMap<>()
        iptvSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.IPTV_SERVICE] = iptvSvc
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >>> [hmMemberServciesByBan, hmMemByHandle]

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo.contains('SBCIPTV')
    }

    // ----- SOR!=LS, suspended access service (VEMEH_36) -----

    def "verify non-LS SOR suspended access service returns ERR_NOT_ENABLE"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'ACE'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'HSIA'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null

        HashMap<String, Object> hsiaService = new HashMap<>()
        hsiaService[MPSDefs.SERVICE_STATUS] = MPSDefs.SUSPENDED
        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap['HSIA'] = hsiaService
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >>> [hmMemberServciesByBan, hmMemByHandle]

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo.contains('suspended') && stAppInfo.contains('SOR!=LS')
    }

    // ----- SOR!=LS, missing LSRegBlockSORs config (VEMEH_37) -----

    def "verify non-LS SOR missing LSRegBlockSORs config returns ERR_CONFIG"() {
        given:
        ReflectionTestUtils.setField(testObj, 'propLSRegBlockSORs', '')
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'ACE'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemByHandle

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo.contains('Missing config parameter')
    }

    // ----- SOR!=LS, member SOR in blocked list (VEMEH_38) -----

    def "verify non-LS SOR member SOR blocked returns ERR_NOT_ELIGIBLE"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'WN'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemByHandle

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo.contains('blocked SORs')
    }

    // ----- SOR!=LS, service SOR in blocked list (VEMEH_39) -----

    def "verify non-LS SOR service SOR blocked returns ERR_NOT_ELIGIBLE"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'ACE'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null

        HashMap<String, Object> hsiaService = new HashMap<>()
        hsiaService[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        hsiaService[MPSDefs.DB_SOR_NAME] = 'WN'
        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        portalSvc[MPSDefs.DB_SOR_NAME] = 'ACE'
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap['HSIA'] = hsiaService
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >>> [hmMemberServciesByBan, hmMemByHandle]

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo.contains('blocked SORs')
    }

    // ----- Member services by BAN REC_NOT_FOUND (VEMEH_15) -----

    def "verify member services by BAN rec not found returns ERR_BAN_NOT_FOUND"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, 'Record not found')
        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemberServciesByBan

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = hmResult == null ? null : (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        hmResult == null
    }

    // ----- Member services by handle REC_NOT_FOUND (VEMEH_23) -----

    def "verify member services by handle rec not found returns ERR_USER_NOT_FOUND"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        HashMap<String, Object> hmHandleNotFound = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, 'Handle not found')

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >>> [hmMemberServciesByBan, hmHandleNotFound]
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = hmResult == null ? null : (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        hmResult == null
    }

    // ----- Provisioned services non-success status (VEMEH_09) -----

    def "verify provisioned services error status returns error"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, 'DB error')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = hmResult == null ? null : (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        hmResult == null
    }

    // ----- checkAgeEligibility — eligible (age >= 18) -----

    def "verify checkAgeEligibility returns true for eligible age"() {
        expect:
        VerifyExistingMemberEligibilityHelper.checkAgeEligibility('01011990', '18') == true
    }

    // ----- checkAgeEligibility — not eligible (age < 18) -----

    def "verify checkAgeEligibility returns false for underage"() {
        expect:
        VerifyExistingMemberEligibilityHelper.checkAgeEligibility('01012020', '18') == false
    }

    // ----- checkAgeEligibility — parse exception -----

    def "verify checkAgeEligibility throws exception for invalid date"() {
        when:
        VerifyExistingMemberEligibilityHelper.checkAgeEligibility('INVALID', '18')

        then:
        0 * _
        thrown(Exception)
    }

    // ----- parseToArray — basic parsing -----

    def "verify parseToArray splits pipe-delimited string"() {
        when:
        List<String> result = VerifyExistingMemberEligibilityHelper.parseToArray('A|B|C', '|')

        then:
        0 * _
        result == ['A', 'B', 'C']
    }

    def "verify parseToArray trims whitespace"() {
        when:
        List<String> result = VerifyExistingMemberEligibilityHelper.parseToArray(' A | B | C ', '|')

        then:
        0 * _
        result == ['A', 'B', 'C']
    }

    def "verify parseToArray single value"() {
        when:
        List<String> result = VerifyExistingMemberEligibilityHelper.parseToArray('ONLY', '|')

        then:
        0 * _
        result == ['ONLY']
    }

    // ----- isAgeValid — null DOB (no encrypted, no plain) returns true -----

    def "verify null DOB makes age valid by default"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null
        hmMemByHandle[MPSDefs.DB_SLID_MEMBER_NUM] = null
        // No encrypted or plain birthdate
        hmMemByHandle.remove('birthdate_venc')
        hmMemByHandle.remove(MPSDefs.DB_BIRTHDATE_ENCRYPTED)
        hmMemByHandle.remove(MPSDefs.DB_BIRTHDATE)

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        portalSvc[MPSDefs.PORTAL_PROVIDER] = 'AT&T YAHOO'
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemByHandle

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        subAccountsDBHelperObj.getAllSubInfo(_ as HashMap) >> hmSubResult

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]

        then:
        0 * _
        stAppStatusMsg == 'SUCCESS'
    }

    // ----- isAgeValid — decryption returns null (VEMEH_IAV_3) -----

    def "verify isAgeValid decryption returns null triggers age invalid"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemByHandle

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> null

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo == 'Age passed in input is not valid for Registration.'
    }

    // ----- isAgeValid — decryption error status (VEMEH_IAV_4) -----

    def "verify isAgeValid decryption error status triggers age invalid"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemByHandle

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmDecryptError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, 'Decryption failed')
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmDecryptError

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo == 'Age passed in input is not valid for Registration.'
    }

    // ----- isAgeValid — blank decrypted DOB (VEMEH_IAV_5) -----

    def "verify isAgeValid blank decrypted DOB triggers age invalid"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemByHandle

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmDecryptResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmDecryptResp[MPSDefs.DB_BIRTHDATE_VENC] = null
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmDecryptResp

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo == 'Age passed in input is not valid for Registration.'
    }

    // ----- Portal provider ATT_NAP on parent (VEMEH_46) -----

    def "verify parent portal provider ATT NAP returns ERR_PORTAL_NAP_YAHOO"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null
        hmMemByHandle[MPSDefs.DB_SLID_MEMBER_NUM] = null

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        portalSvc[MPSDefs.PORTAL_PROVIDER] = CommonDefs.PORTAL_PROVIDER_ATT_NAP
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemByHandle

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        subAccountsDBHelperObj.getAllSubInfo(_ as HashMap) >> hmSubResult

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo.contains('Portal Provider')
    }

    // ----- Portal provider ATT_YAHOO with ATT_NAP subs (VEMEH_47) -----

    def "verify parent ATT YAHOO portal with ATT NAP sub returns ERR_PORTAL_NAP_YAHOO"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null
        hmMemByHandle[MPSDefs.DB_SLID_MEMBER_NUM] = null

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        portalSvc[MPSDefs.PORTAL_PROVIDER] = CommonDefs.PORTAL_PROVIDER_ATT_YAHOO
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemByHandle

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        // Sub accounts with ATT_NAP portal provider
        subAccountsDBHelperObj.getAllSubInfo(_ as HashMap) >> hmSubResult

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo.contains('Portal Provider') || stAppInfo.contains('portal provider')
    }

    // ----- Sub accounts enabled >= 10 (VEMEH_44.4) -----

    def "verify sub accounts enabled limit exceeded returns ERR_SUB_LIMIT_EXCEEDED"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null
        hmMemByHandle[MPSDefs.DB_SLID_MEMBER_NUM] = null

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        portalSvc[MPSDefs.PORTAL_PROVIDER] = 'AT&T YAHOO'
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemByHandle

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        // Build 10 enabled sub accounts (agg_service_status=0 means enabled)
        ArrayList<HashMap<String, Object>> tenEnabledSubs = new ArrayList<>()
        for (int i = 0; i < 10; i++) {
            HashMap<String, Object> subItem = new HashMap<>()
            subItem[MPSDefs.DB_AGG_SERVICE_STATUS] = MPSDefs.DB_AGG_SERVICE_STATUS_ENABLE
            subItem[MPSDefs.DB_MEMBER_STATE] = 'INUSE'
            HashMap<String, Object> subSvcMap = new HashMap<>()
            HashMap<String, Object> subPortal = new HashMap<>()
            subPortal[MPSDefs.PORTAL_PROVIDER] = 'AT&T YAHOO'
            subSvcMap[MPSDefs.PORTAL_SERVICE] = subPortal
            subItem[MPSDefs.SERVICES] = subSvcMap
            tenEnabledSubs.add(subItem)
        }
        HashMap<String, Object> subResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        subResult['subaccounts'] = tenEnabledSubs
        subAccountsDBHelperObj.getAllSubInfo(_ as HashMap) >> subResult

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo.contains('enabled subs') || stAppInfo.contains('TEN')
    }

    // ----- Sub accounts total (enabled + suspended) >= 20 (VEMEH_44.6) -----

    def "verify sub accounts total limit exceeded returns ERR_SUB_LIMIT_EXCEEDED"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null
        hmMemByHandle[MPSDefs.DB_SLID_MEMBER_NUM] = null

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        portalSvc[MPSDefs.PORTAL_PROVIDER] = 'AT&T YAHOO'
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemByHandle

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        // Build 9 enabled + 11 suspended = 20 total sub accounts
        ArrayList<HashMap<String, Object>> twentySubs = new ArrayList<>()
        for (int i = 0; i < 9; i++) {
            HashMap<String, Object> subItem = new HashMap<>()
            subItem[MPSDefs.DB_AGG_SERVICE_STATUS] = MPSDefs.DB_AGG_SERVICE_STATUS_ENABLE
            subItem[MPSDefs.DB_MEMBER_STATE] = 'INUSE'
            HashMap<String, Object> subSvcMap = new HashMap<>()
            HashMap<String, Object> subPortal = new HashMap<>()
            subPortal[MPSDefs.PORTAL_PROVIDER] = 'AT&T YAHOO'
            subSvcMap[MPSDefs.PORTAL_SERVICE] = subPortal
            subItem[MPSDefs.SERVICES] = subSvcMap
            twentySubs.add(subItem)
        }
        for (int i = 0; i < 11; i++) {
            HashMap<String, Object> subItem = new HashMap<>()
            subItem[MPSDefs.DB_MEMBER_STATE] = 'INUSE'
            subItem[MPSDefs.DB_AGG_SERVICE_STATUS] = 'X'
            HashMap<String, Object> subSvcMap = new HashMap<>()
            HashMap<String, Object> subPortal = new HashMap<>()
            subPortal[MPSDefs.PORTAL_PROVIDER] = 'AT&T YAHOO'
            subSvcMap[MPSDefs.PORTAL_SERVICE] = subPortal
            subItem[MPSDefs.SERVICES] = subSvcMap
            twentySubs.add(subItem)
        }
        HashMap<String, Object> subResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        subResult['subaccounts'] = twentySubs
        subAccountsDBHelperObj.getAllSubInfo(_ as HashMap) >> subResult

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo.contains('enabled subs') || stAppInfo.contains('20')
    }

    // ----- Sub accounts error status code (VEMEH_44) -----

    def "verify sub accounts error status code returns error"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null
        hmMemByHandle[MPSDefs.DB_SLID_MEMBER_NUM] = null

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        portalSvc[MPSDefs.PORTAL_PROVIDER] = 'AT&T YAHOO'
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemByHandle

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        HashMap<String, Object> subErrResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, 'Sub accounts DB error')
        subAccountsDBHelperObj.getAllSubInfo(_ as HashMap) >> subErrResult

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo == 'SUCCESS'
    }

    // ----- isMemberIdLockedOut — no lockout data (null alLockoutInfo) -----

    def "verify no lockout data returns success"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null
        hmMemByHandle[MPSDefs.DB_SLID_MEMBER_NUM] = null
        hmMemByHandle[MPSDefs.DB_MEMBERLOCKOUT] = null

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        portalSvc[MPSDefs.PORTAL_PROVIDER] = 'AT&T YAHOO'
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemByHandle

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        subAccountsDBHelperObj.getAllSubInfo(_ as HashMap) >> hmSubResult

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]

        then:
        0 * _
        stAppStatusMsg == 'SUCCESS'
    }

    // ----- Member services by handle null returns ERR_SYS_APPL (VEMEH_21) -----

    def "verify member services by handle null returns ERR_SYS_APPL"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >>> [hmMemberServciesByBan, null]
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo == 'Null or empty response GetMemberServicesDBHelper'
    }

    // ----- Uverse service sets memberIdForce=true (prevents suspended access error) -----

    def "verify Uverse service sets memberIdForce preventing suspended access error"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        // Uverse service with non-terminated status sets memberIdForce=true
        HashMap<String, Object> uverseSvc = new HashMap<>()
        uverseSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        hmBanSvcs[MPSDefs.UVERSE_SERVICE] = uverseSvc
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'HSIA'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null
        hmMemByHandle[MPSDefs.DB_SLID_MEMBER_NUM] = null

        // HSIA is suspended but memberIdForce should skip this check
        HashMap<String, Object> hsiaService = new HashMap<>()
        hsiaService[MPSDefs.SERVICE_STATUS] = MPSDefs.SUSPENDED
        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        portalSvc[MPSDefs.PORTAL_PROVIDER] = 'AT&T YAHOO'
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap['HSIA'] = hsiaService
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemByHandle

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        subAccountsDBHelperObj.getAllSubInfo(_ as HashMap) >> hmSubResult

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        // Should NOT get 'suspended' error — memberIdForce bypasses it
        !stAppInfo.contains('suspended HSIA service (SOR=LS)')
    }

    // ----- SBCIPTV member name skips memberIdForce in activeLSServiceExist check -----

    def "verify SBCIPTV member name skips memberIdForce check"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'SBCIPTV_user1'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'

        // Build active LS services for ban — should NOT trigger memberIdForce because member starts with SBCIPTV
        HashMap<String, Object> hsiaMain = new HashMap<>()
        hsiaMain[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = hsiaMain
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null
        hmMemByHandle[MPSDefs.DB_SLID_MEMBER_NUM] = null

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        portalSvc[MPSDefs.PORTAL_PROVIDER] = 'AT&T YAHOO'
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemByHandle

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        subAccountsDBHelperObj.getAllSubInfo(_ as HashMap) >> hmSubResult

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]

        then:
        0 * _
        // Should NOT get ERR_MEMBER_ID_FORCE because SBCIPTV member is skipped
        stAppStatusMsg == 'SUCCESS'
    }

    // ----- General exception handling (catch block) -----

    def "verify general exception is caught and returns exception map"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> { throw new RuntimeException('Unexpected DB error') }

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo != null
    }

    // ----- NullPointerException handling (specific catch branch) -----

    def "verify NullPointerException is caught with specific logging"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> { throw new NullPointerException('null ref') }

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo != null
    }

    // ----- Missing ResidentialAccountSubTypes config (VEMEH_40) -----

    def "verify missing ResidentialAccountSubTypes config returns ERR_CONFIG"() {
        given:
        ReflectionTestUtils.setField(testObj, 'propResidentialAccountSubTypes', '')
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        hmMemByHandle[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmMemByHandle[MPSDefs.DB_SOR_NAME] = 'LS'
        hmMemByHandle[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        hmMemByHandle[MPSDefs.DB_BAN] = '001146267'
        hmMemByHandle['birthdate_venc'] = 'kUi}q|uPPKNB.u_'
        hmMemByHandle[MPSDefs.DB_BULK_BILLING_IND] = null
        hmMemByHandle['delete_request_date'] = null
        hmMemByHandle[MPSDefs.DB_SLID_MEMBER_NUM] = '12345666'

        HashMap<String, Object> portalSvc = new HashMap<>()
        portalSvc[MPSDefs.SERVICE_STATUS] = MPSDefs.ENABLED
        portalSvc[MPSDefs.PORTAL_PROVIDER] = 'AT&T YAHOO'
        HashMap<String, Object> svcMap = new HashMap<>()
        svcMap[MPSDefs.PORTAL_SERVICE] = portalSvc
        hmMemByHandle[MPSDefs.SERVICES] = svcMap

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemByHandle

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        HashMap<String, Object> hmProofingResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmProofingResp[MPSDefs.DB_BIRTHDATE_VENC] = '11112000'
        proofingEncryptionHelperObj.getDecryptedValues(_ as HashMap) >> hmProofingResp

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        stAppInfo.contains('ResidentialAccountSubTypes')
    }

    // ----- Member services by BAN error status (non-success, non-REC_NOT_FOUND) (VEMEH_14) -----

    def "verify member services by BAN error status returns error"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, 'Member services DB error')
        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >> hmMemberServciesByBan

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = hmResult == null ? null : (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        hmResult == null
    }

    // ----- Member services by handle error status (non-success, non-REC_NOT_FOUND) (VEMEH_22) -----

    def "verify member services by handle error status returns error"() {
        given:
        hmInput[CommonDefs.BAN] = '001146267'
        accountInfoDBHelperObj.getAccountInfo(_ as String) >> hmaccountInfoHash

        hmProvisionResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        getProvisionedServicesDBHelperObj.getProvisionedServices(_ as HashMap) >> hmProvisionResponse

        hmMemberServciesByBan = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmMemberServciesByBan[MPSDefs.DB_MEMBER_NAME] = 'qay_atto0444'
        hmMemberServciesByBan[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmMemberServciesByBan[MPSDefs.DB_BAN] = '001146267'
        HashMap<String, Object> hmBanSvcs = new HashMap<>()
        hmBanSvcs['HSIA'] = new HashMap<>()
        hmMemberServciesByBan['services'] = hmBanSvcs

        HashMap<String, Object> hmHandleError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, 'Handle services DB error')

        HashMap<String, Object> hmAssocResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAssocResponse['associatedMembers'] = new ArrayList<>()

        getMemberServicesDBHelperObj.getMemberServices(_ as HashMap) >>> [hmMemberServciesByBan, hmHandleError]
        getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> hmAssocResponse

        hmResult = testObj.verifyExistingMemberEligibility(hmInput)

        when:
        stAppInfo = hmResult == null ? null : (String) hmResult[CommonDefs.COMMON_APP_INFO]

        then:
        0 * _
        hmResult == null
    }


}
