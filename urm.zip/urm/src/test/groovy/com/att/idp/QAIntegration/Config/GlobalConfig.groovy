package com.att.idp.QAIntegration.Config

import com.att.idp.QAIntegration.Utils.Utility
import groovy.util.logging.Slf4j
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.yaml.snakeyaml.Yaml

import java.util.regex.Pattern

@Slf4j
class GlobalConfig {

    private static final String CONFIG_RESOURCE = "/CONFIG/userregistration-global-config.yaml"
    private static final Map<String, Object> GLOBAL_CONFIG = loadGlobalConfig()

    static final String DEFAULT_ENV   = GLOBAL_CONFIG.defaultEnv   as String ?: "TEST3"
    static final String CONTENT_TYPE  = GLOBAL_CONFIG.contentType  as String ?: "application/json"
    static final String ACCEPT        = GLOBAL_CONFIG.accept       as String ?: "application/json"

    static final Map<String, String> ENVIRONMENTS = (GLOBAL_CONFIG.environments as Map<String, String>) ?: [:]
    private static final Map<String, Pattern> ENV_HINT_PATTERNS = buildHintPatterns(GLOBAL_CONFIG.envHints as Map)
    private static final Map<String, String> EMAIL_CONFIG = (GLOBAL_CONFIG.email as Map<String, String>) ?: [:]
    private static final Map<String, List<String>> TEST_CASE_FILTER = (GLOBAL_CONFIG.testCases as Map<String, List<String>>) ?: [:]

    /**
     * All API endpoint paths loaded from CONFIG/userregistration-global-config.yaml.
     * Usage: GlobalConfig.Endpoints.HEARTBEAT
     */
    static class Endpoints {
        private static final Map<String, String> EP = (GLOBAL_CONFIG.endpoints as Map<String, String>) ?: [:]
        static final String HEARTBEAT = EP.get("heartbeat") ?: "/msapi/actuator/heartbeat"
        // AutoReg endpoints
        static final String AUTOGEN_TEMP_ACCESS_ID = EP.get("autogenTempAccessId") ?: "/msapi/idgraphuserregistrationms/v1/autoreg/tempAccessId"
        static final String PRE_ACCOUNT_REG = EP.get("preAccountReg") ?: "/msapi/idgraphuserregistrationms/v1/autoreg/preAccountReg"
        // LsReg endpoints
        static final String QUERY_BY_IP_ELIGIBILITY = EP.get("queryByIPEligibility") ?: "/msapi/idgraphuserregistrationms/v1/lsreg/queryByIPEligibility"
        static final String VERIFY_EXISTING_MEMBER_ELIGIBILITY = EP.get("verifyExistingMemberEligibility") ?: "/msapi/idgraphuserregistrationms/v1/lsreg/verifyExistingMemberEligibility"
        static final String REGISTER_LS_USER = EP.get("registerLSUser") ?: "/msapi/idgraphuserregistrationms/v1/lsreg/registerUser"
        // SyncUserProfile endpoints
        static final String SYNC_USER_PROFILE = EP.get("syncUserProfile") ?: "/msapi/idgraphuserregistrationms/v1/userprofile/sync"
        static final String VALIDATE_AND_SYNC_G2 = EP.get("validateAndSyncG2") ?: "/msapi/idgraphuserregistrationms/v1/userprofile/activate/uban"
        static final String REPROVISION_UVERSE = EP.get("reprovisionUverse") ?: "/msapi/idgraphuserregistrationms/v1/userprofile/reprovision/uban"
        // UnifiedTOS endpoints
        static final String QUERY_UNIFIED_TOS = EP.get("queryUnifiedTOS") ?: "/msapi/idgraphuserregistrationms/v1/unifiedTOS/query"
        static final String UPDATE_UNIFIED_TOS = EP.get("updateUnifiedTOS") ?: "/msapi/idgraphuserregistrationms/v1/unifiedTOS/update"
        // EmailAppPassword endpoints
        static final String LIST_EMAIL_APP_PASSWORD = EP.get("listEmailAppPassword") ?: "/msapi/idgraphuserregistrationms/v1/emailapppassword"
        static final String CREATE_EMAIL_APP_PASSWORD = EP.get("createEmailAppPassword") ?: "/msapi/idgraphuserregistrationms/v1/emailapppassword"
        static final String DELETE_EMAIL_APP_PASSWORD = EP.get("deleteEmailAppPassword") ?: "/msapi/idgraphuserregistrationms/v1/emailapppassword"
        // WirelessAutoReg endpoint
        static final String WIRELESS_AUTO_REG = EP.get("wirelessAutoReg") ?: "/msapi/idgraphuserregistrationms/v1/orchestration/wireless"
        // RetriggerQAR endpoint
        static final String RETRIGGER_QAR = EP.get("retriggerQAR") ?: "/msapi/idgraphuserregistrationms/v1/account/qar/retrigger"
    }

    private static String  CACHED_ENV       = null
    private static Map     CACHED_TEST_DATA = null
    private static boolean LOGGED_PARAMS    = false

    private static Map<String, Object> loadGlobalConfig() {
        Logger initLog = LoggerFactory.getLogger(GlobalConfig.class)
        InputStream is = null
        try {
            is = GlobalConfig.class.getResourceAsStream(CONFIG_RESOURCE)
            if (is != null) {
                Map loaded = new Yaml().load(is) as Map ?: [:]
                initLog.info("GlobalConfig loaded from classpath:{}", CONFIG_RESOURCE)
                return loaded
            }
            File fallback = new File("src/test/resources${CONFIG_RESOURCE}")
            if (fallback.exists()) {
                Map loaded = new Yaml().load(fallback.text) as Map ?: [:]
                initLog.info("GlobalConfig loaded from file: {}", fallback.absolutePath)
                return loaded
            }
            initLog.warn("userregistration-global-config.yaml not found — using empty defaults")
            return [:]
        } catch (Exception e) {
            initLog.error("Failed to load userregistration-global-config.yaml: {}", e.message, e)
            return [:]
        } finally {
            try { is?.close() } catch (Exception ignored) {}
        }
    }

    private static Map<String, Pattern> buildHintPatterns(Map raw) {
        if (!raw) return [:]
        Map<String, Pattern> patterns = [:]
        raw.each { k, v -> patterns[k as String] = Pattern.compile(v as String) }
        return patterns
    }

    static Map<String, String> getEmailConfig() { EMAIL_CONFIG }

    static synchronized String getCurrentTestEnv() {
        if (CACHED_ENV != null) return CACHED_ENV
        CACHED_ENV = determineEnv()
        return CACHED_ENV
    }

    static String getBaseUrl() {
        String explicit = System.getProperty("BASE_URL")?.trim()
        if (explicit?.toLowerCase(Locale.US)?.startsWith("http")) {
            // Sanitize URL: remove any trailing arguments that may have been incorrectly appended
            // e.g., "https://example.com  -DINTEGRATION_TEST_ENV=dev" → "https://example.com"
            return sanitizeUrl(explicit)
        }
        String envKey = normalizeEnvName(explicit ?: getCurrentTestEnv()) ?: DEFAULT_ENV
        return ENVIRONMENTS[envKey] ?: ENVIRONMENTS[DEFAULT_ENV]
    }

    /**
     * Sanitize URL by removing any trailing whitespace or incorrectly appended arguments.
     * Handles cases like: "https://example.com  -DINTEGRATION_TEST_ENV=dev"
     */
    private static String sanitizeUrl(String url) {
        if (!url) return url
        String trimmed = url.trim()
        // Strip anything after the first whitespace or -D flag that follows the URL
        def match = (trimmed =~ /^(https?:\/\/\S+)/)
        if (match.find()) {
            String sanitized = match.group(1)
            if (sanitized != trimmed) {
                log.warn("BASE_URL contained extra characters — sanitized '{}' to '{}'", trimmed, sanitized)
            }
            return sanitized
        }
        return trimmed
    }

    static String getAuthorization() {
        String token = System.getProperty("AUTHORIZATION")?.trim()
        if (token) {
            log.info("Authorization sourced from -DAUTHORIZATION system property")
        } else {
            token = Utility.getAuthorizationFromSecretCache()?.trim()
        }
        if (!token) return null
        if (token.toLowerCase(Locale.US).startsWith("basic ") ||
            token.toLowerCase(Locale.US).startsWith("bearer ")) {
            return token
        }
        return "Basic ${token}"
    }

    static String getDataFileDirectory() {
        "src/test/resources/QATestData/${getCurrentTestEnv()}/"
    }

    static synchronized Map getTestData() {
        if (CACHED_TEST_DATA == null) {
            String dir    = getDataFileDirectory()
            File yamlFile = new File(dir + "TestData.yaml")
            if (yamlFile.exists()) {
                CACHED_TEST_DATA = new Yaml().load(yamlFile.text) as Map ?: [:]
                log.info("Test data loaded from: {}", yamlFile.absolutePath)
            } else {
                log.warn("Test data YAML not found at: {}. Using empty defaults.", yamlFile.absolutePath)
                CACHED_TEST_DATA = [:]
            }
        }
        return new LinkedHashMap(CACHED_TEST_DATA)
    }

    /**
     * Check if a test case is enabled for the current environment.
     */
    static boolean isTestCaseEnabled(String testCaseName) {
        String env = getCurrentTestEnv()
        List<String> enabledTests = TEST_CASE_FILTER.get(env)
        
        if (enabledTests == null || enabledTests.isEmpty()) {
            log.info("No test case filter configured for env {} — test '{}' will run (all tests enabled)", env, testCaseName)
            return true
        }
        
        boolean enabled = enabledTests.contains(testCaseName)
        if (!enabled) {
            log.info("Test case '{}' is NOT in the filter list for env {} — test will be skipped", testCaseName, env)
        }
        return enabled
    }

    private static String determineEnv() {
        if (!LOGGED_PARAMS) {
            log.info("=" * 70)
            log.info("QG7 INTEGRATION TEST — PARAMETERS")
            log.info("  BASE_URL                 = {}", System.getProperty("BASE_URL") ?: "NOT SET")
            log.info("  INTEGRATION_TEST_ENV     = {}", System.getProperty("INTEGRATION_TEST_ENV") ?: "NOT SET")
            log.info("  INTEGRATION_TEST_CLUSTER = {}", System.getProperty("INTEGRATION_TEST_CLUSTER") ?: "NOT SET")
            log.info("  defaultEnv (YAML)        = {}", DEFAULT_ENV)
            log.info("=" * 70)
            LOGGED_PARAMS = true
        }

        String baseUrl = System.getProperty("BASE_URL")?.trim()
        if (baseUrl) {
            String inferred = normalizeEnvName(baseUrl)
            if (inferred) {
                log.info("Env inferred from BASE_URL '{}': {}", baseUrl, inferred)
                return inferred
            }
        }

        String integTestEnv = System.getProperty("INTEGRATION_TEST_ENV")?.trim()
        if (integTestEnv) {
            String inferred = normalizeEnvName(integTestEnv)
            if (inferred) {
                log.info("Env inferred from INTEGRATION_TEST_ENV '{}': {}", integTestEnv, inferred)
                return inferred
            }
            return integTestEnv.toUpperCase(Locale.US)
        }

        String cluster = System.getProperty("INTEGRATION_TEST_CLUSTER")?.trim()
        if (cluster) {
            String inferred = normalizeEnvName(cluster)
            if (inferred) {
                log.info("Env inferred from INTEGRATION_TEST_CLUSTER '{}': {}", cluster, inferred)
                return inferred
            }
        }

        log.info("Falling back to defaultEnv from YAML: {}", DEFAULT_ENV)
        return DEFAULT_ENV
    }

    private static String normalizeEnvName(String candidate) {
        if (!candidate) return null
        String trimmed = candidate.trim()
        String upper   = trimmed.toUpperCase(Locale.US)
        if (ENVIRONMENTS.containsKey(upper)) return upper
        String byUrl = ENVIRONMENTS.find { k, v -> v.equalsIgnoreCase(trimmed) }?.key
        if (byUrl) return byUrl
        return ENV_HINT_PATTERNS.find { k, p -> p.matcher(trimmed).find() }?.key
    }
}
