package com.att.idp.idgraphuserregistrationms.resource.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.request.validator.WirelessAutoRegRequestValidator
import com.att.idp.idgraphuserregistrationms.resource.request.WirelessAutoRegRequest
import com.att.idp.idgraphuserregistrationms.resource.response.WirelessAutoRegResponse
import com.att.idp.idgraphuserregistrationms.service.WirelessAutoRegService
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.Response
import java.sql.SQLException

class WirelessAutoRegResourceImplTest extends Specification {
	
	def wirelessAutoRegResourceImplObj=new WirelessAutoRegResourceImpl()

	WirelessAutoRegRequestValidator wirelessAutoRegReqValObj = Mock(WirelessAutoRegRequestValidator)

	WirelessAutoRegService wirelessAutoRegSvcObj = Mock(WirelessAutoRegService)

	HttpHeaders httpHeaders = Mock(HttpHeaders)

	WirelessAutoRegRequest wirelessAutoRegReq = Mock(WirelessAutoRegRequest)

	private WirelessAutoRegResponse responseObj = null
	
	def setup() {
		wirelessAutoRegResourceImplObj.wirelessAutoRegRequestValidator = wirelessAutoRegReqValObj
		wirelessAutoRegResourceImplObj.wirelessAutoRegService = wirelessAutoRegSvcObj
		
	}


	def "test wireless auto reg success"() throws Exception {

		given:
		responseObj = new WirelessAutoRegResponse()
		responseObj.appCategoryCode = '0'
		wirelessAutoRegSvcObj.wirelessAutoReg(_ as WirelessAutoRegRequest, _) >> responseObj
		when:
		Response response = wirelessAutoRegResourceImplObj.wirelessAutoReg(wirelessAutoRegReq, httpHeaders)
		then:
		response.status == 200
	}


	def "test wireless auto reg error"() throws Exception {
		
		// error from request validator
		given:
		responseObj = new WirelessAutoRegResponse()
		responseObj.appCategoryCode = '2'
		wirelessAutoRegReqValObj.wirelessAutoRegRequestValidator(_ as HttpHeaders, _ as WirelessAutoRegRequest) >> responseObj
		when:
		Response response = wirelessAutoRegResourceImplObj.wirelessAutoReg(wirelessAutoRegReq, httpHeaders)
		then:
		response.status == 500

		// error from service
		when:
		responseObj.appCategoryCode = '3'
		response = wirelessAutoRegResourceImplObj.wirelessAutoReg(wirelessAutoRegReq, httpHeaders)
		then:
		response.status == 400
	}


	def "test wireless auto reg data exception"() throws Exception {

		given:
		InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
		when:wirelessAutoRegSvcObj.wirelessAutoReg(_ as WirelessAutoRegRequest, _) >> { throw ex }
		wirelessAutoRegResourceImplObj.wirelessAutoReg(wirelessAutoRegReq, httpHeaders)
        then:
        thrown(InvalidInputDataException.class)
	}


	def "test wireless auto reg exception"() throws Exception {

		given:
		NullPointerException ex = new NullPointerException('NullPointerException thrown')
		when:wirelessAutoRegSvcObj.wirelessAutoReg(_ as WirelessAutoRegRequest, _) >> { throw ex }
		Response response = wirelessAutoRegResourceImplObj.wirelessAutoReg(wirelessAutoRegReq, httpHeaders)
		then:
		response.status == 500
	}
	def "test wireless auto reg SQL exception"() throws Exception {

		given:
		SQLException ex = new SQLException('SQLException thrown')
		when:wirelessAutoRegSvcObj.wirelessAutoReg(_ , _) >> { throw ex }
		Response response = wirelessAutoRegResourceImplObj.wirelessAutoReg(wirelessAutoRegReq, httpHeaders)
		then:
		response.status == 500
	}
}
