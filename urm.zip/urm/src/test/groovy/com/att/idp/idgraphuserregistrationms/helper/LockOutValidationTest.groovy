package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetLockOutsDBHelper
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension
import spock.lang.Specification

import static org.assertj.core.api.Assertions.assertThatThrownBy
import static org.mockito.Mockito.when


class LockOutValidationTest extends Specification {
	
	def lockOutValidation = new LockOutValidation()
	
	GetLockOutsDBHelper getLockOutDBHMock = Mock(GetLockOutsDBHelper)
	
	 def setup() {
        
        lockOutValidation.getLockOuts_H=getLockOutDBHMock
        }

	def "test get lock outs exception"() throws Exception {
		
		// when the result is empty
		expect:
		assertThatThrownBy(() -> lockOutValidation.lockOuts)

	}


	def "test get lock outs by lock out name exception"() throws Exception {
		expect:
		assertThatThrownBy(() -> lockOutValidation.getLockOutsByLockOutName('lockout_one'))
	}


	def "test get lock out name by id exception"() throws Exception {
		expect:
		assertThatThrownBy(() -> lockOutValidation.getLockOutNameById('lockout_id'))
	}


	def "test get lock out id by name exception"() throws Exception {
		expect:
		assertThatThrownBy(() -> lockOutValidation.getLockOutIdByName('lockout_name1'))
	}


	def "test get lock outs by lock out id exception"() throws Exception {
		expect:
		assertThatThrownBy(() -> lockOutValidation.getLockOutsByLockOutId('1'))
	}
	def "test get lock outs by lock out name"() throws Exception {
		given:
		HashMap<String, ArrayList<HashMap<String, String>>> dbLockOutsHashMap = new HashMap<>()
		ArrayList<HashMap<String, String>> lockOutList = new ArrayList<>()
		HashMap<String, String> lockOutDetails = new HashMap<>()
		lockOutDetails.put("lockout_name", "lockout_one")
		lockOutList.add(lockOutDetails)
		dbLockOutsHashMap.put("1", lockOutList)
		getLockOutDBHMock.getLockOuts()>>dbLockOutsHashMap
		when:
		def result = lockOutValidation.getLockOutsByLockOutName("lockout_one")

		then:
		assert result == lockOutList
	}


	def "test get lock out name by id"() {
		given:
		String lockOutId = "1"
		HashMap<String, ArrayList<HashMap<String, String>>> dbLockOutsHashMap = new HashMap<>()
		ArrayList<HashMap<String, String>> lockOutList = new ArrayList<>()
		HashMap<String, String> lockOutDetails = new HashMap<>()
		lockOutDetails.put("lockout_name", "lockout_one")
		lockOutList.add(lockOutDetails)
		dbLockOutsHashMap.put(lockOutId, lockOutList)

		getLockOutDBHMock.getLockOuts()>>dbLockOutsHashMap

		when:
		String result = lockOutValidation.getLockOutNameById(lockOutId)

		then:
		result == "lockout_one"
	}

	def "test get lock out id by name"() {
		given:
		String lockOutName = "lockout_one"
		String lockOutId = "1"
		HashMap<String, ArrayList<HashMap<String, String>>> dbLockOutsHashMap = new HashMap<>()
		ArrayList<HashMap<String, String>> lockOutList = new ArrayList<>()
		HashMap<String, String> lockOutDetails = new HashMap<>()
		lockOutDetails.put("lockout_name", lockOutName)
		lockOutList.add(lockOutDetails)
		dbLockOutsHashMap.put(lockOutId, lockOutList)

		getLockOutDBHMock.getLockOuts() >> dbLockOutsHashMap

		when:
		String result = lockOutValidation.getLockOutIdByName(lockOutName)

		then:
		result == lockOutId
	}


}
