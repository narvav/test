package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraph.extclient.yahoo.model.CreateApplicationPasswordResponse
import com.att.idp.idgraph.extclient.yahoo.model.DeleteApplicationPasswordResponse
import com.att.idp.idgraph.extclient.yahoo.service.YahooService
import com.att.mpsys.common.utils.CommonDefs
import com.fasterxml.jackson.databind.node.ObjectNode
import spock.lang.Specification

class YahooSMKHelperTest extends Specification {

    YahooService mockYahooService
    YahooSMKHelper helper

    void setup() {
        mockYahooService = Mock(YahooService)
        helper = new YahooSMKHelper(mockYahooService)
    }


    def "handleYahooCreateResponse should return error when response is null"() {
        given: "Null response"
        CreateApplicationPasswordResponse response = null

        when: "handleYahooCreateResponse is invoked"
        HashMap result = helper.handleYahooCreateResponse(response, "testMethod")

        then: "Error map is returned with system application error"
        result != null
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == "2"
        0 * _
    }

    def "handleYahooCreateResponse should return error when result code is not success"() {
        given: "Response with non-success result code"
        CreateApplicationPasswordResponse response = new CreateApplicationPasswordResponse()
        response.setResultCode("FAILURE")
        response.setAppInfo("Service error")

        when: "handleYahooCreateResponse is invoked"
        HashMap result = helper.handleYahooCreateResponse(response, "testMethod")

        then: "Error map is returned with the result code"
        result != null
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == "3"
        0 * _
    }

    def "handleYahooCreateResponse should return success with password when result code is success"() {
        given: "Successful response with password"
        CreateApplicationPasswordResponse response = new CreateApplicationPasswordResponse()
        response.setResultCode("SUCCESS")
        response.setApplicationPassword("testPassword123")

        when: "handleYahooCreateResponse is invoked"
        HashMap result = helper.handleYahooCreateResponse(response, "testMethod")

        then: "Success map is returned with password"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == "0"
        result.get("ApplicationPassword") == "testPassword123"
        0 * _
    }

    def "handleYahooCreateResponse should return error when password is null"() {
        given: "Successful response but password is null"
        CreateApplicationPasswordResponse response = new CreateApplicationPasswordResponse()
        response.setResultCode("SUCCESS")
        response.setApplicationPassword(null)

        when: "handleYahooCreateResponse is invoked"
        HashMap result = helper.handleYahooCreateResponse(response, "testMethod")

        then: "Error map is returned for invalid data"
        result != null
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == "3"
        0 * _
    }

    def "handleYahooDeleteResponse should return error when response is null"() {
        given: "Null response"
        DeleteApplicationPasswordResponse response = null

        when: "handleYahooDeleteResponse is invoked"
        HashMap result = helper.handleYahooDeleteResponse(response, "testMethod")

        then: "Error map is returned with system application error"
        result != null
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == "2"
        0 * _
    }

    def "handleYahooDeleteResponse should return error when result code is not success"() {
        given: "Response with non-success result code"
        DeleteApplicationPasswordResponse response = new DeleteApplicationPasswordResponse()
        response.setResultCode("FAILURE")
        response.setAppInfo("Service error")

        when: "handleYahooDeleteResponse is invoked"
        HashMap result = helper.handleYahooDeleteResponse(response, "testMethod")

        then: "Error map is returned with the result code"
        result != null
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == "3"
        0 * _
    }

    def "handleYahooDeleteResponse should return success when result code is success"() {
        given: "Successful response"
        DeleteApplicationPasswordResponse response = new DeleteApplicationPasswordResponse()
        response.setResultCode("SUCCESS")

        when: "handleYahooDeleteResponse is invoked"
        HashMap result = helper.handleYahooDeleteResponse(response, "testMethod")

        then: "Success map is returned"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == "0"
        0 * _
    }

    def "toObjectNode should convert map to ObjectNode"() {
        given: "A map with test data"
        Map<String, Object> inputMap = new HashMap<>()
        inputMap.put("key1", "value1")
        inputMap.put("key2", "value2")
        inputMap.put("key3", 123)

        when: "toObjectNode is invoked"
        ObjectNode result = helper.toObjectNode(inputMap)

        then: "ObjectNode is created with correct values"
        result != null
        result.get("key1").asText() == "value1"
        result.get("key2").asText() == "value2"
        result.get("key3").asInt() == 123
        0 * _
    }

    def "enc should encode string for HTML"() {
        given: "A test string"
        String input = "<script>alert('test')</script>"

        when: "enc is invoked"
        String result = helper.enc(input)

        then: "String is HTML encoded"
        result != null
        result.contains("&lt;")
        result.contains("&gt;")
        0 * _
    }
}
