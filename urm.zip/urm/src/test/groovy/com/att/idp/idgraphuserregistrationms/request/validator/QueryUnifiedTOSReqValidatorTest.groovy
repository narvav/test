package com.att.idp.idgraphuserregistrationms.request.validator

import com.att.idp.idgraphuserregistrationms.resource.request.QueryUnifiedTOSRequest
import com.att.idp.idgraphuserregistrationms.resource.response.QueryUnifiedTOSResponse
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap

class QueryUnifiedTOSReqValidatorTest extends Specification {

	def queryUnifiedTOSReqValidatorObject=new QueryUnifiedTOSRequestValidator()
	 QueryUnifiedTOSRequest queryUnifiedTOSRequestObj = null
	 QueryUnifiedTOSResponse queryUnifiedTOSResponse = null

	 HttpHeaders requestHeader = null
	 MultivaluedHashMap requestHeaders =null
	 private Map<String, String> headers = new HashMap<>()


	def setup() throws Exception {
		queryUnifiedTOSRequestObj = new QueryUnifiedTOSRequest()
		requestHeader= Mock(HttpHeaders)

		queryUnifiedTOSRequestObj.agentId = '1234'
		queryUnifiedTOSRequestObj.ban = '1234567'
		queryUnifiedTOSRequestObj.callingSystemId = 'IDP'

		ReflectionTestUtils.setField(queryUnifiedTOSReqValidatorObject, 'propQueryUnifiedTOSValidAgentCSIds', 'IDP|DATAMGT|CSRIDP')
		ReflectionTestUtils.setField(queryUnifiedTOSReqValidatorObject, 'validAgentCSIds',
				'IDP|DATAMGT|OCE|CSRIDP|ILM|DPL|OPUS|DATATEAM')
	}

	def "query unified tos null request test"() throws Exception {
		given:
		queryUnifiedTOSRequestObj = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'

		when:
		QueryUnifiedTOSResponse queryUnifiedTOSResponse = queryUnifiedTOSReqValidatorObject.queryUnifiedTOSReqValidator(requestHeader, queryUnifiedTOSRequestObj)
		then:
		queryUnifiedTOSResponse.appInfo == 'Input Request Parameter is NULL / Empty.'

	}
	def "query unifiedtos req validator success without trace id test"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		when:
		QueryUnifiedTOSResponse response = queryUnifiedTOSReqValidatorObject.queryUnifiedTOSReqValidator(requestHeader, queryUnifiedTOSRequestObj)
		then:
		response.appInfo == 'Missing or Invalid IdpTraceId'
	}
	def "query unified tos requestunknownattribues"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		Map<String,Object> allUnknownAttributes =new HashMap<>()
		queryUnifiedTOSRequestObj.setUnknownAttributes(allUnknownAttributes)
		allUnknownAttributes.put("test","test")
		when:
		QueryUnifiedTOSResponse responseObj = queryUnifiedTOSReqValidatorObject.queryUnifiedTOSReqValidator(requestHeader, queryUnifiedTOSRequestObj)
		then:
		responseObj.appInfo == 'Invalid Attributes passed in QueryUnifiedTOSRequest : {test=test}'

	}

	def "query unifiedtos req validator success test"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		QueryUnifiedTOSResponse queryUnifiedTOSResponse = queryUnifiedTOSReqValidatorObject.queryUnifiedTOSReqValidator(requestHeader, queryUnifiedTOSRequestObj)
		then:
		queryUnifiedTOSResponse == null

	}

	def "query unified tos helper empty  csi case"() throws Exception {
		given:
		requestHeader.getHeaderString('idp-trace-id')>>''
		when:
		QueryUnifiedTOSResponse queryUnifiedTOSResponse = queryUnifiedTOSReqValidatorObject.queryUnifiedTOSReqValidator(requestHeader, queryUnifiedTOSRequestObj)
		then:
		queryUnifiedTOSResponse.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}
	def "query unified tos helper invalid csi case"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>'INVALID'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'

		when:
		QueryUnifiedTOSResponse queryUnifiedTOSResponse = queryUnifiedTOSReqValidatorObject.queryUnifiedTOSReqValidator(requestHeader, queryUnifiedTOSRequestObj)
		then:
		queryUnifiedTOSResponse.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}


	def "query unified tos helper null csi case"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>null
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'

		when:
		QueryUnifiedTOSResponse queryUnifiedTOSResponse = queryUnifiedTOSReqValidatorObject.queryUnifiedTOSReqValidator(requestHeader, queryUnifiedTOSRequestObj)
		then:
		queryUnifiedTOSResponse.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}

	def "query unified tos helper invalid is external call error case"() throws Exception {
		given:
		queryUnifiedTOSRequestObj.isExternalCall = 'S'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		QueryUnifiedTOSResponse queryUnifiedTOSResponse = queryUnifiedTOSReqValidatorObject.queryUnifiedTOSReqValidator(requestHeader, queryUnifiedTOSRequestObj)
		then:
		queryUnifiedTOSResponse.appInfo == 'IsExternalCall must be one of Y or N'
	}


	def "query unified tos helper errorfor empty ban"() throws Exception {
		given:
		queryUnifiedTOSRequestObj.ban = ' '
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		QueryUnifiedTOSResponse queryUnifiedTOSResponse = queryUnifiedTOSReqValidatorObject.queryUnifiedTOSReqValidator(requestHeader, queryUnifiedTOSRequestObj)
		then:
		queryUnifiedTOSResponse.appInfo == 'Input ban is null or empty'
	}

	def "query unified tos helper no agent id for agent csi error case"() throws Exception {
		given:
		queryUnifiedTOSRequestObj.callingSystemId = 'CSRIDP'
		queryUnifiedTOSRequestObj.agentId = null
		queryUnifiedTOSRequestObj.isExternalCall = 'N'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		QueryUnifiedTOSResponse queryUnifiedTOSResponse = queryUnifiedTOSReqValidatorObject.queryUnifiedTOSReqValidator(requestHeader, queryUnifiedTOSRequestObj)
		then:
		queryUnifiedTOSResponse.appInfo == 'AgentId is required for caller:IDP'
	}
	def "query unified tos helperRequestValidatorExceptionTest"() throws Exception {
		given:
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>> { throw ex }

		when:
		QueryUnifiedTOSResponse response = queryUnifiedTOSReqValidatorObject.queryUnifiedTOSReqValidator(requestHeader, queryUnifiedTOSRequestObj)

		then:
		thrown(RuntimeException.class)
	}
}
