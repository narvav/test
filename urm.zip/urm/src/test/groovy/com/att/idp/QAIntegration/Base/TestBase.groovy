package com.att.idp.QAIntegration.Base

import com.att.idp.QAIntegration.Config.GlobalConfig
import com.att.idp.QAIntegration.Report.QG7ExtentReportListener
import com.att.idp.QAIntegration.Report.QG7TestResultCollector
import com.att.idp.QAIntegration.Utils.Utility
import groovy.json.JsonOutput
import groovy.util.logging.Slf4j
import io.restassured.RestAssured
import io.restassured.http.ContentType
import io.restassured.response.Response
import io.restassured.specification.RequestSpecification
import spock.lang.Specification

@Slf4j
class TestBase extends Specification {

    private static final int MAX_LOG_LENGTH = 1500
    private static final ThreadLocal<String> currentTestName = new ThreadLocal<>()

    static String baseUrl
    static String authorization

    def setupSpec() {
        RestAssured.useRelaxedHTTPSValidation()

        authorization = Utility.getAuthorizationFromSecretCache()
        if (authorization) {
            log.info("Authorization retrieved from .secretscachefolder")
        } else {
            log.warn("Authorization not found in secrets cache — GlobalConfig will attempt fallback")
        }

        baseUrl = sanitizeBaseUrl(GlobalConfig.getBaseUrl())
        log.info("TestBase.setupSpec() — env={}, baseUrl={}", GlobalConfig.getCurrentTestEnv(), baseUrl)
    }

    static void setTestName(String name) {
        currentTestName.set(name)
    }

    static Response sendRequest(
            String endpoint,
            String method,
            String requestBody = null,
            Map<String, String> extraHeaders = [:],
            Map<String, String> queryParams = [:]) {

        String resolvedBaseUrl  = sanitizeBaseUrl(GlobalConfig.getBaseUrl())
        String resolvedAuth     = GlobalConfig.getAuthorization()
        String resolvedPath     = resolveEndpointForBaseUrl(resolvedBaseUrl, endpoint)

        RestAssured.baseURI  = resolvedBaseUrl
        RestAssured.basePath = resolvedPath

        Map<String, String> headers = [
                "Content-Type" : GlobalConfig.CONTENT_TYPE,
                "Accept"       : GlobalConfig.ACCEPT,
                "Authorization": resolvedAuth
        ]
        if (extraHeaders) {
            headers.putAll(extraHeaders)
        }

        RequestSpecification request = RestAssured.given()
                .contentType(ContentType.JSON)
                .headers(headers)
                .relaxedHTTPSValidation()
                .body(requestBody != null ? requestBody : Collections.emptyMap())
                .queryParams(queryParams ?: Collections.emptyMap())

        Response response = request.request(method)

        try {
            logToExtentReport(resolvedBaseUrl + resolvedPath, headers, requestBody, response, queryParams, method)
        } catch (Exception e) {
            log.debug("ExtentReport logging skipped: {}", e.message)
        }

        // Track 5xx errors for the email report
        int sc = response.statusCode()
        if (sc >= 500 && sc < 600) {
            try {
                QG7TestResultCollector.getInstance().recordServerError(
                        currentTestName.get() ?: "Unknown",
                        resolvedBaseUrl + resolvedPath,
                        sc
                )
            } catch (Exception e) {
                log.debug("5xx tracking skipped: {}", e.message)
            }
        }

        return response
    }

    static void logStep(String stepDescription) {
        log.info("STEP: {}", stepDescription)
        try {
            QG7ExtentReportListener.getCurrent()?.info(
                    "<b style='color:#117A65;font-family:Arial'>STEP:</b> " +
                    "<span style='font-family:Arial'>${stepDescription}</span>")
        } catch (Exception e) {
            log.debug("ExtentReport step logging skipped: {}", e.message)
        }
    }

    static void logCustomMessage(String message) {
        log.info("{}", message)
        try {
            QG7ExtentReportListener.getCurrent()?.info(message)
        } catch (Exception e) {
            log.debug("ExtentReport message logging skipped: {}", e.message)
        }
    }

    static void logApiResponseToExtentReport(Response response) {
        if (response == null) {
            log.warn("Response is null — nothing to log")
            return
        }
        try {
            StringBuilder html = new StringBuilder()
            html.append("<div style='font-family:Arial,sans-serif;max-width:900px;margin:10px auto;background:#E8F8F5;border:1px solid #1ABC9C;border-radius:8px;padding:15px'>")
            html.append("<h3 style='color:#117A65'>API Response</h3>")
            html.append("<p><b>Status Code:</b> ").append(response.statusCode).append("</p>")
            html.append("<pre style='white-space:pre-wrap;word-wrap:break-word;color:#0E6251'>")
                    .append(truncate(response.body.asString(), MAX_LOG_LENGTH))
                    .append("</pre></div>")
            QG7ExtentReportListener.getCurrent()?.info(html.toString())
        } catch (Exception e) {
            log.debug("ExtentReport response logging skipped: {}", e.message)
        }
    }

    private static String sanitizeBaseUrl(String url) {
        if (!url) return url
        String trimmed = url.trim()
        def match = (trimmed =~ /^(https?:\/\/\S+)/)
        if (match.find()) {
            return match.group(1)
        }
        return trimmed
    }

    private static String resolveEndpointForBaseUrl(String url, String endpoint) {
        if (!endpoint) return endpoint
        if (url != null && (url ==~ /(?i)^https?:\/\/.*-(blue|green)\/?$/)) {
            return endpoint.replaceFirst('^/msapi/idgraph(?=/|$)', '/msapi')
        }
        return endpoint
    }

    private static void logToExtentReport(
            String uri,
            Map<String, String> headers,
            String requestBody,
            Response response,
            Map<String, String> queryParams,
            String method) {

        String[] segments = uri.split("/")
        String apiName = segments.length >= 2 ? "/${segments[-2]}/${segments[-1]}" : uri

        StringBuilder html = new StringBuilder()
        html.append("<div style='font-family:Arial,sans-serif;max-width:900px;margin:10px auto;border:2px solid #2F80ED;border-radius:8px;padding:15px;background:#f0f8ff'>")
        html.append("<h2 style='color:#2F80ED;margin-bottom:8px'>API: ").append(apiName).append("</h2>")
        html.append("<p><b style='color:#B03A2E'>Method:</b> <span style='color:#fff;background:#B03A2E;padding:2px 8px;border-radius:4px'>").append(method).append("</span></p>")
        html.append("<p><b style='color:#104E8B'>URI:</b> <span style='color:#333'>").append(uri).append("</span></p>")

        if (queryParams) {
            html.append("<div style='background:#F9E79F;padding:10px;border-radius:6px;margin-bottom:10px'>")
                    .append("<h3 style='color:#B7950B;margin:0 0 8px 0'>Query Parameters</h3>")
            queryParams.each { k, v -> html.append("<div><b>").append(k).append("</b>: ").append(v).append("</div>") }
            html.append("</div>")
        }

        html.append("<div style='background:#D6EAF8;padding:10px;border-radius:6px;margin-bottom:10px'>")
                .append("<h3 style='color:#1B4F72;margin:0 0 8px 0'>Request Headers</h3>")
        headers.each { k, v ->
            html.append("<div><b style='color:#154360'>").append(k)
                    .append("</b>: <span style='color:#1C2833'>").append(v).append("</span></div>")
        }
        html.append("</div>")

        html.append("<div style='background:#EBF5FB;padding:10px;border-radius:6px;margin-bottom:10px'>")
                .append("<h3 style='color:#21618C;margin:0 0 8px 0'>Request Body</h3>")
                .append("<pre style='white-space:pre-wrap;word-wrap:break-word;font-size:13px;color:#0B5345'>")
                .append(truncate(prettyPrintJson(requestBody), MAX_LOG_LENGTH))
                .append("</pre></div>")

        html.append("<p><b style='color:#117A65'>Response Status:</b> <span style='color:#0E6251'>")
                .append(response.statusCode).append("</span></p>")
        html.append("<div style='background:#D1F2EB;padding:10px;border-radius:6px;margin-top:10px'>")
                .append("<h3 style='color:#138D75;margin:0 0 8px 0'>Response Body</h3>")
                .append("<pre style='white-space:pre-wrap;word-wrap:break-word;font-size:13px;color:#0B5345'>")
                .append(truncate(prettyPrintJson(response.body?.asPrettyString()), MAX_LOG_LENGTH))
                .append("</pre></div></div>")

        QG7ExtentReportListener.getCurrent()?.info(html.toString())
    }

    private static String prettyPrintJson(String json) {
        if (!json?.trim()) return ""
        try { return JsonOutput.prettyPrint(json) } catch (Exception e) { return json }
    }

    private static String truncate(String input, int maxLength) {
        if (!input) return ""
        input.length() <= maxLength ? input : input.substring(0, maxLength) + "\n... (truncated)"
    }
}
