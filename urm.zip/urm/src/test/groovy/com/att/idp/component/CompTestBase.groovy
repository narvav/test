package com.att.idp.component

import com.att.ajsc.common.utility.SystemPropertiesLoader
import com.att.idp.cgclienthelpers.integration.CGRestClient
import com.att.idp.idgraph.extclient.db.service.TworkitemService
import com.att.idp.idgraph.extclient.g2.service.G2SoapClientHandler
import com.att.idp.idgraph.extclient.haloc.service.HaloCService
import com.att.idp.idgraph.extclient.yahoo.service.YahooService
import com.att.idp.idgraphuserregistrationms.Application
import com.att.idp.idgraphuserregistrationms.client.MPSReconnectWrapperSoapHandler
import com.att.idp.idgraphuserregistrationms.client.MPSRegisterUserSoapHandler
import com.att.idp.idgraphuserregistrationms.client.MPSSyncDestinationSoapHandler
import com.att.idp.idgraphuserregistrationms.helper.ConsolidatedProfileHelper
import com.att.idp.idgraphuserregistrationms.helper.G2GetBANByIPHelper
import com.att.idp.idgraphuserregistrationms.helper.HaloSyncHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.AccountAutoRegDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.DBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetAllInfoDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetAssociatedMembersDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetInfoByMaskDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetProvisionedServicesDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetSlidInfoDBHelper
import com.att.idp.idgraphuserregistrationms.helper.voltage.DecryptUtil
import com.att.idp.idgraphuserregistrationms.helper.voltage.EncryptUtil
import com.att.idp.idgraphuserregistrationms.helper.voltage.ProofingEncryptionHelper
import com.att.idp.idgraphuserregistrationms.queue.message.helpers.RetriggerQARQueueHelper
import com.att.idp.idgraphuserregistrationms.queue.message.helpers.UpdateTOSQueueHelper
import com.att.idp.idgraphuserregistrationms.utils.RILCheckAndEncryptPasswordHelper
import com.att.idp.idgraphuserregistrationms.integration.MPSYSInternalRestClient
import com.att.idp.idgraph.commons.integration.CLMRestClient
import com.att.idp.voltage.decrypt.api.VoltageDecryptorAutoConfiguration
import com.att.idp.voltage.encrypt.api.VoltageEncryptorAutoConfiguration
import com.att.idp.voltage.health.readiness.VoltageReadinessIndicator
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.fasterxml.jackson.core.type.TypeReference
import com.fasterxml.jackson.databind.ObjectMapper
import com.azure.spring.cloud.appconfiguration.config.AppConfigurationRefresh
import io.restassured.RestAssured
import io.restassured.http.ContentType
import io.restassured.specification.RequestSpecification
import org.junit.jupiter.api.Timeout
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.web.server.LocalServerPort
import org.springframework.scheduling.TaskScheduler
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.test.context.ContextConfiguration
import spock.lang.Shared
import org.springframework.test.context.TestPropertySource
import spock.lang.Specification
import java.util.concurrent.TimeUnit

@ContextConfiguration(classes = Application.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = Application.class)
@TestPropertySource(properties = [
		'API_CLIENT_REST_DEFAULT_USERTYPES_GUEST_USER=ct-guest',
		'API_CLIENT_REST_DEFAULT_USERTYPES_GUEST_PASSWORD=ct-guest-pass',
		'API_CLIENT_REST_DEFAULT_USERTYPES_REGISTERED_USER=ct-registered',
		'API_CLIENT_REST_DEFAULT_USERTYPES_REGISTERED_PASSWORD=ct-registered-pass',
		'management.readiness.health.enabled=false',
		'ixp.library-enabled=false',
		'spring.task.scheduling.enabled=false',
		'spring.main.lazy-initialization=true',
		'spring.cloud.azure.appconfiguration.enabled=false',
		'spring.cloud.azure.appconfiguration.refresh.enabled=false',
		'spring.cache.type=none',
		'spring.autoconfigure.exclude=org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration,org.springframework.boot.autoconfigure.data.redis.RedisClientAutoConfiguration'
])
@Timeout(value = 30L, unit = TimeUnit.SECONDS)
abstract class CompTestBase extends Specification {
	@SpringBean
	protected G2SoapClientHandler g2SoapClientHandler= Mock()

	@SpringBean
	protected TworkitemService tworkitemService= Mock()

	@SpringBean
	protected GetMemberServicesDBHelper getMemberServicesDBHelper= Mock()

	@SpringBean
	protected FeatureManagerHelper featureManager= Mock()

	@SpringBean
	protected HaloCService haloCService = Mock()

	@SpringBean
	protected ConsolidatedProfileHelper consolidatedProfileHelper = Mock()

	@SpringBean
	protected GetInfoByMaskDBHelper getInfoByMaskDBHelper = Mock()


	@SpringBean
	protected HaloSyncHelper haloSyncHelper = Mock()


	@SpringBean
	protected RILCheckAndEncryptPasswordHelper rilPwdHelper = Mock()

	@SpringBean
	protected DBHelper oDBHelper=Mock()

	@SpringBean
	protected MPSReconnectWrapperSoapHandler oMPSReconnectWrapperSoapHandler = Mock();

	@SpringBean
	protected AccountAutoRegDBHelper accountAutoRegDBHelperObj=Mock()

	@SpringBean
	protected GetAllInfoDBHelper getAllInfo=Mock()

	@SpringBean
	protected G2GetBANByIPHelper g2GetBANByIP=Mock()

	@SpringBean
	protected MPSRegisterUserSoapHandler oMPSRegisterUserSoapHandler = Mock();

	@SpringBean
	protected GetAssociatedMembersDBHelper getAssociatedMembersDBHelperObj = Mock()

	@SpringBean
	protected RetriggerQARQueueHelper retriggerQARQueueHelper = Mock()


	@SpringBean
	protected JdbcTemplate jdbcTemplate=Mock()


	@SpringBean
	protected UpdateTOSQueueHelper updateTOSQueueHelper = Mock()

	@SpringBean
	protected GetProvisionedServicesDBHelper getProvisionedServicesDBHelper = Mock()

	@SpringBean
	protected VoltageEncryptorAutoConfiguration voltageEncryptorAutoConfiguration = Mock()

	@SpringBean
	protected VoltageDecryptorAutoConfiguration voltageDecryptorAutoConfiguration = Mock()

	@SpringBean
	protected VoltageReadinessIndicator voltageReadinessIndicator = Mock()

	@SpringBean
	protected AppConfigurationRefresh appConfigurationRefresh = Mock()

	@SpringBean
	protected TaskScheduler taskScheduler = Mock()

	@SpringBean
	protected EncryptUtil encryptUtil = Mock()

	@SpringBean
	protected DecryptUtil decryptUtil = Mock()

	@SpringBean
	protected MPSYSInternalRestClient internalIDPRestClient = Mock()

	@SpringBean ProofingEncryptionHelper proofingEncryptionHelper = Mock()

	@SpringBean
	protected CLMRestClient clmRestClient = Mock()



	@SpringBean
	MPSSyncDestinationSoapHandler mpsSyncDestinationSoapHandler = Mock()

	@SpringBean
	YahooService yahooService = Mock()


	@SpringBean
	GetSlidInfoDBHelper getSlidInfoDBHelper = Mock()

	@Value('${server.servlet.context-path}')
	protected String contextPath

	@Value('${api.schemaVersion}')
	protected String apiVersion

	@Value('${spring.application.name}')
	protected String appPath

	@LocalServerPort
	protected int randomServerPort

	@Value('${apiclient.rest.default.userTypes.guest.username}')
	protected String guestUsername

	@Value('${apiclient.rest.default.userTypes.guest.password}')
	protected String guestPassword

	@Value('${apiclient.rest.default.userTypes.registered.username}')
	protected String registeredUsername

	@Value('${apiclient.rest.default.userTypes.registered.password}')
	protected String registeredPassword

	@Shared
	private boolean restAssuredBaseUriInitialized = false

	static {
		SystemPropertiesLoader.addSystemProperties()
	}


	def setup() throws Exception {
		if (!restAssuredBaseUriInitialized) {
			RestAssured.baseURI = 'http://localhost:' + randomServerPort +
					contextPath + '/' + appPath.toLowerCase() + '/' + apiVersion
			restAssuredBaseUriInitialized = true
		}
	}

	/*
	 * Base spec with guest user
	 */
	protected RequestSpecification givenBaseSpec() {
		return RestAssured.given()
				.relaxedHTTPSValidation()
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON)
				.auth().basic(guestUsername, guestPassword)
	}

	/*
	 * Base spec for registered user
	 */
	protected RequestSpecification givenRegisterdBaseSpec() {
		return RestAssured.given()
				.relaxedHTTPSValidation()
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON)
				.auth()
				.basic(registeredUsername, registeredPassword)
	}

	public static Map<String, Object> readJsonFileToMap(String filePath) throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		try (InputStream inputStream = CompTestBase.class.getClassLoader().getResourceAsStream(filePath)) {			if (inputStream == null) {
			throw new IOException("File not found: " + filePath);
		}
			return objectMapper.readValue(inputStream, new TypeReference<Map<String, Object>>() {});
		}
	}

	static List readJsonFileToList(String filePath) throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		try (InputStream inputStream = CompTestBase.class.getClassLoader().getResourceAsStream(filePath)) {
			if (inputStream == null) {
				throw new IOException("File not found: " + filePath);
			}
			return objectMapper.readValue(inputStream, new TypeReference<List>() {});
		}
	}
}