package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import com.att.idp.idgraphuserregistrationms.exceptions.MPSException
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.spockframework.spring.SpringBean
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import spock.lang.Specification
/**
 * 
 * @author sp7569
 *
 */
class AccountAutoRegDBHelperTest extends Specification {

	JdbcTemplate jdbcTemplate = Mock(JdbcTemplate)
    ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)

    def testObj = new AccountAutoRegDBHelper()

    DBHelper dBHelper = Mock(DBHelper)


    Logger logger = null
    HashMap hmDBInput = null
    String stAppStatusMsg = null
    String stAppInfo=null
    List alQueryResponse = CommonUtil.arrayList
    HashMap<String, String> hmQueryResponse = CommonUtil.hashMap
    List<Object> objectList = CommonUtil.arrayList
    HashMap<Object, Object> hmResult = CommonUtil.hashMap


    private String sAccountAutoRegQuery = 'SELECT member_num AS memberNum from accountautoreg where sor_id = ? and sor_invariant_id = ?'

    def setup() throws Exception {
        testObj.jdbcTemplate=jdbcTemplate
        testObj.errorMetricHandler=errorMetricHandler
        testObj.dBHelper=dBHelper
		logger = LoggerFactory.getLogger('AccountAutoRegDBHelper')
        //System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')
        hmQueryResponse[MPSDefs.DB_MEMBER_NUM] = '1302477816'
        hmQueryResponse[CommonDefs.SOR_ID] = '13'
        hmQueryResponse[CommonDefs.SOR_INVARIANT_ID] = '578293788030'
        hmQueryResponse[MPSDefs.DB_CREATE_DATE] = '2023-11-16 13:39:17.0'
        hmQueryResponse[MPSDefs.DB_LAST_MODIFIED] = '2023-11-16 14:52:16.0'
        hmQueryResponse[MPSDefs.DB_LAST_MODIFIED_BY] = 'OPUS'
        alQueryResponse.add(hmQueryResponse)
    }

    def "query account auto reg success case"() {
        given:
        objectList.add('13')
        objectList.add('1234567')
        hmQueryResponse[CommonDefs.SOR_ID] = '13'
        hmQueryResponse[CommonDefs.SOR_INVARIANT_ID] = '1234567'
        jdbcTemplate.queryForList(new String(sAccountAutoRegQuery),	_) >> alQueryResponse
        hmResult = testObj.queryAccountAutoReg(hmQueryResponse)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'SUCCESS'
    }
	
    def "query account auto reg error case"() {
        given:
        objectList.add('13')
        objectList.add('1234567')
        hmQueryResponse.remove(CommonDefs.SOR_ID, '13')
        hmQueryResponse.remove(CommonDefs.SOR_INVARIANT_ID, '1234567')
        hmResult = testObj.queryAccountAutoReg(hmQueryResponse)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
    }

    def "query account auto reg no record found success case"() {
        given:
        objectList.add('11')
        objectList.add('1234567')
        hmQueryResponse[CommonDefs.SOR_ID] = '11'
        hmQueryResponse[CommonDefs.SOR_INVARIANT_ID] = '1234567'
        jdbcTemplate.queryForList(new String(sAccountAutoRegQuery),	_) >> alQueryResponse
        hmResult = testObj.queryAccountAutoReg(hmQueryResponse)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'SUCCESS'
    }

    def "update account auto reg e r r e m p t y"() {
        given:
        HashMap<String, String> hmEmpty = null
        hmResult = testObj.updateAccountAutoReg(hmEmpty)
        when:
        stAppInfo=(String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppInfo == 'ERR_EMPTY'
    }

    def "update account auto reg for invalid sor i d"() throws MPSException {
        given:
        hmQueryResponse.remove(CommonDefs.SOR_ID)
        hmResult = testObj.updateAccountAutoReg(hmQueryResponse)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
    }

    def "update account auto reg for invalid sor inv id"() throws MPSException {
        given:
        hmQueryResponse.remove(CommonDefs.SOR_INVARIANT_ID)
        hmResult = testObj.updateAccountAutoReg(hmQueryResponse)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'
    }

    def "update account auto reg for invalid guid"() {
        given:
        hmQueryResponse.remove(CommonDefs.GUID)
        hmResult = testObj.updateAccountAutoReg(hmQueryResponse)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'

    }

    def "update account auto reg for invalid sor invariant list"() {
        given:
        hmQueryResponse.remove(CommonDefs.SOR_INVARIANT_ID_LIST)
        hmResult = testObj.updateAccountAutoReg(hmQueryResponse)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_INVALID_DATA'

    }

    def "query account auto reg with null sor invariant id"() {
        given:
        HashMap<String, String> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.SOR_ID, '13')
        hmInput.put(CommonDefs.SOR_INVARIANT_ID, null)

        when:
        HashMap hmResult = testObj.queryAccountAutoReg(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == '100'
    }

    def "query account auto reg with valid global unique id"() {
        given:
        HashMap<String, String> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.SOR_ID, '13')
        hmInput.put(CommonDefs.SOR_INVARIANT_ID, '1234567')
        List<Map<String, Object>> queryResponse = new ArrayList<>()
        Map<String, Object> responseMap = new HashMap<>()
        responseMap.put("MEMBERNUM", "1302477816")
        queryResponse.add(responseMap)
        jdbcTemplate.queryForList(new String(sAccountAutoRegQuery), _) >> queryResponse

        when:
        HashMap hmResult = testObj.queryAccountAutoReg(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
        hmResult[CommonDefs.GUID] == '1302477816'
    }

    def "query account auto reg exception handling"() {
        given:
        HashMap<String, String> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.SOR_ID, '13')
        hmInput.put(CommonDefs.SOR_INVARIANT_ID, '1234567')
        jdbcTemplate.queryForList(_, _) >> new RuntimeException("Database error")

        when:
        HashMap hmResult = testObj.queryAccountAutoReg(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_DB'
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == '304'
    }

    def "update account auto reg with null or empty sor invariant id list"() {
        given:
        HashMap<String, Object> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.SOR_INVARIANT_ID_LIST, null)
        hmInput.put(CommonDefs.GUID, "12324")
        when:
        HashMap hmResult = testObj.updateAccountAutoReg(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == '100'
    }

    def "update account auto reg success case"() {
        given:
        HashMap<String, Object> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.GUID, "12324")
        List<HashMap> alSorInvariantIdList = new ArrayList<>()
        HashMap<String, String> sorInvariantIdMap = new HashMap<>()
        sorInvariantIdMap.put(CommonDefs.SOR_INVARIANT_ID, "1234567")
        sorInvariantIdMap.put(CommonDefs.KEY_SOR_NAME, "SOR_NAME")
        alSorInvariantIdList.add(sorInvariantIdMap)
        hmInput.put(CommonDefs.SOR_INVARIANT_ID_LIST, alSorInvariantIdList)
        dBHelper.getSorId(_ as String) >> 1
        jdbcTemplate.queryForObject(_ , _ ,_) >> 1
        jdbcTemplate.update(_, _) >> 1

        when:
        HashMap hmResult = testObj.updateAccountAutoReg(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] =='SUCCESS'
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == '0'
    }

    def "update account auto reg exception handling"() {
        given:
        HashMap<String, Object> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.GUID, "12324")
        List<HashMap> alSorInvariantIdList = new ArrayList<>()
        HashMap<String, String> sorInvariantIdMap = new HashMap<>()
        sorInvariantIdMap.put(CommonDefs.SOR_INVARIANT_ID, "1234567")
        sorInvariantIdMap.put(CommonDefs.KEY_SOR_NAME, "SOR_NAME")
        alSorInvariantIdList.add(sorInvariantIdMap)
        hmInput.put(CommonDefs.SOR_INVARIANT_ID_LIST, alSorInvariantIdList)
        dBHelper.getSorId(_ as String) >> 1
        jdbcTemplate.queryForObject(_, _, _) >> 1
        jdbcTemplate.update(_, _) >> new RuntimeException("Database error")

        when:
        HashMap hmResult = testObj.updateAccountAutoReg(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == '602'
    }

    def "update account auto reg with invalid sor name"() {
        given:
        HashMap<String, Object> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.GUID, "12324")
        List<HashMap> alSorInvariantIdList = new ArrayList<>()
        HashMap<String, String> sorInvariantIdMap = new HashMap<>()
        sorInvariantIdMap.put(CommonDefs.SOR_INVARIANT_ID, "1234567")
        sorInvariantIdMap.put(CommonDefs.KEY_SOR_NAME, "INVALID_SOR_NAME")
        alSorInvariantIdList.add(sorInvariantIdMap)
        hmInput.put(CommonDefs.SOR_INVARIANT_ID_LIST, alSorInvariantIdList)
        dBHelper.getSorId(_ as String) >> -1

        when:
        HashMap hmResult = testObj.updateAccountAutoReg(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == '100'
    }
}