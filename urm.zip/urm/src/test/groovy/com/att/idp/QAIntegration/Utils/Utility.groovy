package com.att.idp.QAIntegration.Utils

import com.att.idp.secrets.utils.SecretsCacheReader
import groovy.util.logging.Slf4j

import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.ThreadLocalRandom

@Slf4j
class Utility {
    static String clusterName = ApplicationConstants.clusterName
    private static String secretValue = null

    static String getBasicAuthHeader(String username, String password) {
        String credentials = "${username}:${password}"
        String encoded = Base64.encoder.encodeToString(credentials.bytes)
        return "Basic ${encoded}"
    }

    static String getCurrentDateTime() {
        def now = ZonedDateTime.now(ZoneId.of("America/Chicago"))
        def formatter = DateTimeFormatter.ofPattern("MM_dd_yyyy_HH_mm_ss")
        return now.format(formatter)
    }

    static String getRandomTraceId() {
        return "qg7-${UUID.randomUUID().toString().take(8)}-${System.currentTimeMillis()}"
    }

    static String randomUserId() {
        return "qg7_user_${randomAlphaNumeric(10)}@test.com"
    }

    static String randomEmail() {
        return "qg7_${randomAlphaNumeric(8)}@yopmail.com"
    }

    static String randomAlphaNumeric(int length) {
        String chars = "abcdefghijklmnopqrstuvwxyz0123456789"
        StringBuilder sb = new StringBuilder()
        for (int i = 0; i < length; i++) {
            sb.append(chars.charAt(ThreadLocalRandom.current().nextInt(chars.length())))
        }
        return sb.toString()
    }

    static String randomNumeric(int length) {
        String chars = "0123456789"
        StringBuilder sb = new StringBuilder()
        for (int i = 0; i < length; i++) {
            sb.append(chars.charAt(ThreadLocalRandom.current().nextInt(chars.length())))
        }
        return sb.toString()
    }

    static String randomGuid() {
        return UUID.randomUUID().toString().toUpperCase()
    }

    static String randomIpAddress() {
        return "${ThreadLocalRandom.current().nextInt(1, 255)}.${ThreadLocalRandom.current().nextInt(0, 255)}.${ThreadLocalRandom.current().nextInt(0, 255)}.${ThreadLocalRandom.current().nextInt(1, 255)}"
    }

    static String randomBan() {
        return randomNumeric(9)
    }

    static synchronized String getAuthorizationFromSecretCache() {
        if (secretValue != null) {
            return secretValue
        }
        SecretsCacheReader secret = new SecretsCacheReader()
        
        // PROD environments
        if (ApplicationConstants.env?.contains("prodgraph1eus2")) {
            secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PROD_GRAPH_EAST_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
        } else if(ApplicationConstants.env?.contains("prodgraph1wus2")) {
            secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PROD_GRAPH_WEST_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
        } else if (ApplicationConstants.env?.contains("prodgraph1scus")) {
            secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PROD_GRAPH_SC_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
        } else if (ApplicationConstants.env?.contains("prodgraph1cnryeus2")) {
            secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PROD_GRAPH_CANARY_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
        } 
        // STAGE environments
        else if (ApplicationConstants.env?.contains("graph1eus2-stage") || ApplicationConstants.env?.contains("stagegraph1eus2")) {
            secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.STAGE_EAST_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
        } else if (ApplicationConstants.env?.contains("graph1wus2-stage") || ApplicationConstants.env?.contains("stagegraph1wus2")) {
            secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.STAGE_WEST_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
        }
        // PERF environments
        else if (ApplicationConstants.env?.contains("graph1eus2-perf2")) {
            secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PERF_GRAPH_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
            if (!secretValue?.trim()) {
                secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PERF_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
            }
        }
        // DEV environments
        else if (ApplicationConstants.env?.contains("graph1eus2-dev")) {
            secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.DEV_GRAPH_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
            if (!secretValue?.trim()) {
                secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.DEV_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
            }
        }
        // TEST environments
        else if (ApplicationConstants.env?.contains("graph1eus2-test")) {
            secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_GRAPH_EAST_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
            if (!secretValue?.trim()) {
                secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_2_5_6_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
            }
            if (!secretValue?.trim()) {
                secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_3_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
            }
        }
        // Fallback
        else {
            secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_3_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
        }
        return secretValue
    }
}
