package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import spock.lang.Specification
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs

class GetMemberRolesDBHelperTest extends Specification {

    JdbcTemplate jdbcTemplate = Mock(JdbcTemplate)
    ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)

    def testObj = new GetMemberRolesDBHelper()

    private List<Object> objectList = null
    private HashMap<String, Object> hmDbInput = CommonUtil.hashMap
    private HashMap<String, Object> hmQueryResponse = CommonUtil.hashMap
    private List alQueryResponse = CommonUtil.arrayList
    private List alEmptyQueryResponse = CommonUtil.arrayList
    private Logger logger = null

    private static final String queryMemberServiceRolesSql = '''SELECT msr.member_num, msr.service_id, ser.service_name, msr.role_id, srole.role_name, "
			+ " msr.sor_id, sor.sor_name,  msr.sor_invariant_id, msr.status as role_status_code, "
			+ " stat.status_name as role_status_name, TO_CHAR(msr.create_date, '" + dateFormat
			+ "') AS create_date, TO_CHAR(msr.last_modified, '" + dateFormat
			+ "') AS last_modified, msr.last_modified_by AS last_modified_by "
			+ " FROM memberservicerole msr, service ser, servicerole srole, status stat," + " systemofrecord sor"
			+ " WHERE msr.service_id = ser.service_id AND srole.role_id = msr.role_id "
			+ " AND msr.sor_id = sor.sor_id AND msr.status = stat.status_code (+) "
			+ " AND msr.service_id = srole.service_id AND msr.member_num = ?'''

    private static final String queryMemberServiceRolesBySorInvariantIdSql = '''SELECT msr.member_num, msr.service_id, ser.service_name, msr.role_id, srole.role_name, '
			+ " msr.sor_id, sor.sor_name,  msr.sor_invariant_id, msr.status as role_status_code, "
			+ " stat.status_name as role_status_name, TO_CHAR(msr.create_date, '" + dateFormat
			+ "') AS create_date, TO_CHAR(msr.last_modified, '" + dateFormat
			+ "') AS last_modified, msr.last_modified_by AS last_modified_by "
			+ " FROM memberservicerole msr, service ser, servicerole srole, status stat," + " systemofrecord sor"
			+ " WHERE msr.service_id = ser.service_id AND srole.role_id = msr.role_id "
			+ " AND msr.sor_id = sor.sor_id AND msr.status = stat.status_code (+) "
			+ " AND msr.service_id = srole.service_id AND msr.sor_id = ? AND msr.sor_invariant_id = ?'''

    def setup() {
        testObj.jdbcTemplate = jdbcTemplate
        testObj.errorMetricHandler = errorMetricHandler
        logger = LoggerFactory.getLogger('AddAssociation')
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '854726571'
        hmDbInput[MPSDefs.DB_SOR_ID] = '528415851'
        hmDbInput[MPSDefs.DB_SOR_INVARIANT_ID] = '6284121'
        hmQueryResponse[MPSDefs.DB_MEMBER_NUM] = '854726571'
        hmQueryResponse[MPSDefs.DB_SERVICE_ID] = '5424515'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = 'DSL'
        hmQueryResponse[MPSDefs.DB_ROLE_ID] = '5214'
        hmQueryResponse[MPSDefs.DB_ROLE_NAME] = 'owner'
        hmQueryResponse[MPSDefs.DB_SOR_ID] = '528415851'
        hmQueryResponse[MPSDefs.DB_SOR_NAME] = 'MO'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID] = '6284121'
        hmQueryResponse['role_status_code'] = '1'
        hmQueryResponse['role_status_name'] = 'enabled'
        hmQueryResponse[MPSDefs.DB_CREATE_DATE] = '12122016'
        hmQueryResponse[MPSDefs.DB_LAST_MODIFIED] = '12122017'
        hmQueryResponse[MPSDefs.DB_LAST_MODIFIED_BY] = 'DATAMGT'

        alQueryResponse.add(hmQueryResponse)
    }

    def "associate service no member num error"() {
        given:
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = null
        HashMap hmResult = testObj.getMemberServiceRoles(hmDbInput)
        String stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        String stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]
        then:
        stAppStatusMsg == 'ERR_EMPTY'
        stAppInfo == '101'
    }

    def "associate service success"() {
        given:
        objectList = new ArrayList<Object>()
        objectList.add('854726571')
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        HashMap hmResult = testObj.getMemberServiceRoles(hmDbInput)
        String stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        String stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]
        then:
        stAppStatusMsg == 'SUCCESS'
        stAppInfo == '0'
    }

    def "associate service null response exception"() {
        given:
        objectList = new ArrayList<Object>()
        objectList.add('854726571')
        jdbcTemplate.queryForList(_,_) >> null
        HashMap hmResult = testObj.getMemberServiceRoles(hmDbInput)
        when:
        String stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_SYS_APPL'
    }

    def "associate service no record found error"() {
        given:
        objectList = new ArrayList<Object>()
        objectList.add('854726571')
        jdbcTemplate.queryForList(_,_) >> alEmptyQueryResponse
        HashMap hmResult = testObj.getMemberServiceRoles(hmDbInput)
        when:
        String stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'REC_NOT_FOUND'
    }

}
