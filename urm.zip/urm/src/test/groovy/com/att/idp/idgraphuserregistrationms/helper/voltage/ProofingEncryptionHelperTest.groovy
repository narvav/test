package com.att.idp.idgraphuserregistrationms.helper.voltage

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import com.att.mpsys.common.utils.PropertyManager
import spock.lang.Specification
import org.slf4j.Logger
import org.slf4j.LoggerFactory

class ProofingEncryptionHelperTest extends Specification {

    def proofingEncryption_H

    VoltageEncryptionHelper voltageHelper = Mock(VoltageEncryptionHelper)

    public static final Logger logger = LoggerFactory.getLogger('ProofingEncryption_H')
    HashMap<String, Object> hmEncInput = null
    HashMap<String, Object> hmDecInput = null
    HashMap<String, Object> hmEachInnerValue = null
    HashMap<String, Object> hmServices = null
    HashMap<String, Object> hmEachServices = null

    def setup() {
        PropertyManager.setProperty("MSCONFIG", "voltageEncryptFields","passcode|wsPasscode|securityAnswer|wsSecurityAnswer|security_answer|dateOfBirth|birthdate_venc|security_answer_venc|passcode_venc|dsl_net_password|issuser_password|wirelineuser_passcode|securitycode_passcode|md5_password_venc|enc_password_venc|sha1_password_venc|des3_password_venc|ssha_password_venc|security_answer_1_venc|security_answer_2_venc|generatedPassword|dialEnrollPassword|yahoo_app_pwd|gen_password_venc");
        PropertyManager.setProperty("MSCONFIG", "voltageDecryptFields","birthdate_venc|security_answer_venc|passcode_venc|password_venc|dsl_net_password|md5_password_venc|enc_password_venc|sha1_password_venc|des3_password_venc|ssha_password_venc|security_answer_1_venc|security_answer_2_venc|gen_password_venc");
        PropertyManager.setProperty("MSCONFIG", "voltagePCIEncryptFields","ccNumber");
        PropertyManager.setProperty("MSCONFIG", "voltagePCIDecryptFields","");
        PropertyManager.setProperty("MSCONFIG", "voltageSSNEncryptFields","");
        PropertyManager.setProperty("MSCONFIG", "voltageSSNDecryptFields","fedTaxId");
        PropertyManager.setProperty("MSCONFIG", "voltageGenStringEncryptFields","CBR|CTNCBR");
        PropertyManager.setProperty("MSCONFIG", "voltageGenStringDecryptFields","CBR|CTNCBR");
        PropertyManager.setProperty("MSCONFIG", "voltageDOBDecryptFields","vc_dateOfBirth");
        PropertyManager.setProperty("MSCONFIG", "oneWayEncryptFields","online1SecurityAnswer|online2SecurityAnswer|wsOnline1SecurityAnswer|wsOnline2SecurityAnswer");
        PropertyManager.setProperty("MSCONFIG", "twoWayEncryptFields","passcode|wsPasscode|securityAnswer|wsSecurityAnswer");
        PropertyManager.setProperty("MSCONFIG", "SPI_ENCRYPTION_TYPE","V");

        proofingEncryption_H = new ProofingEncryptionHelper()
        proofingEncryption_H.voltageHelper = voltageHelper
        hmEncInput = new HashMap<String, Object>()
        hmEncInput['userID'] = 'qay_ribgt'
        hmEncInput['passcode'] = '67365'
        hmEncInput['voltage_dsl_net_password'] = 'A5EC5&$47D'
        hmEncInput['online1SecurityAnswer'] = 'developer'
        hmEncInput['sorInvariantId'] = '1673687503'

        hmDecInput = new HashMap<String, Object>()
        hmDecInput[MPSDefs.DB_DSL_NET_ENCR_TYPE] = 'A'
        hmDecInput[MPSDefs.DB_DSL_NET_PASSWORD] = '6d76f53543e7e4f21533e72f6a8bef36'
        hmDecInput['sorInvariantId'] = '6d76f53543e7e4f21533e72f6a8bef36'
        hmServices = new HashMap()
        hmEachServices = new HashMap<String, Object>()
        hmEachInnerValue = new HashMap()
        hmEachInnerValue['sor_invariant_id'] = '6d76f53543e7e4f21533e72f6a8bef36'
        hmEachServices['instanceID'] = hmEachInnerValue
        hmEachServices['aes_password'] = '6d76f53543e7e4f21533e72f6a8bef36'
        hmServices['MOSUB'] = hmEachServices
        hmServices['ISS'] = hmEachServices
        hmDecInput[MPSDefs.SERVICES] = hmServices

        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')
    }

    def "test get encrypted values null input"() {
        given:
        hmEncInput = null
        when:
        HashMap<String, Object> hmResult = proofingEncryption_H.getEncryptedValues(hmEncInput)
        then:
        hmResult == null
    }

    def "test get encrypted values null response from voltage helper"() {
        given:
        voltageHelper.getEFPEEncryptedValues(hmEncInput) >> null
        when:
        HashMap<String, Object> hmResult = proofingEncryption_H.getEncryptedValues(hmEncInput)
        then:
        hmResult['appInfo'] == 'VoltageEncryption_H.getEFPEDecryptedValues return null / empty'
    }

    def "test get encrypted values error from voltage helper"() {
        given:
        HashMap<String, Object> voltageResult = new HashMap<String, Object>()
        voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '118'
        voltageHelper.getEFPEEncryptedValues(hmEncInput) >> voltageResult
        when:
        HashMap<String, Object> hmResult = proofingEncryption_H.getEncryptedValues(hmEncInput)
        then:
        hmResult['appStatusCode'] == '118'
    }

    def "test get encrypted values exception from generate sha1 value"() {
        given:
        HashMap<String, Object> voltageResult = new HashMap<String, Object>()
        voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
        hmEncInput['online1SecurityAnswer'] = null
        voltageHelper.getEFPEEncryptedValues(hmEncInput) >> voltageResult
        when:
        HashMap<String, Object> hmResult = proofingEncryption_H.getEncryptedValues(hmEncInput)
        then:
        hmResult['appInfo'] == 'generateSHA1Value failed for field=online1SecurityAnswer'
    }

    def "test get encrypted values exception fromgenerate aes 256 value"() {
        given:
        HashMap<String, Object> voltageResult = new HashMap<String, Object>()
        voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
        hmEncInput['sorInvariantId'] = null
        voltageHelper.getEFPEEncryptedValues(hmEncInput) >> voltageResult
        //when:
        HashMap<String, Object> hmResult = proofingEncryption_H.getEncryptedValues(hmEncInput)
        //then:
        //hmResult['appInfo'] == 'generateAES256Value failed for field=sorInvariantId'
    }

    def "test get encrypted values exception"() {
        given:
        voltageHelper.getEFPEEncryptedValues(hmEncInput) >> { throw NullPointerException }
        when:
        HashMap<String, Object> hmResult = proofingEncryption_H.getEncryptedValues(hmEncInput)
        then:
        hmResult['appStatusMsg'] == 'ERR_SYS_APPL'
    }

    def "test get decrypted values null input"() {
        given:
        hmDecInput = null
        when:
        HashMap<String, Object> hmResult = proofingEncryption_H.getDecryptedValues(hmDecInput)
        then:
        hmResult['appInfo'] == ' hmInput is NULL '
    }

    def "test get decrypted values exception from get clear text from aes case1"() {
        given:
        hmDecInput[MPSDefs.DB_DSL_NET_PASSWORD] = '4f21533e72f6a8bef36'
        when:
        HashMap<String, Object> hmResult = proofingEncryption_H.getDecryptedValues(hmDecInput)
        then:
        hmResult['appInfo'] == 'generatedClearText failed for field=dsl_net_password'
    }

    def "test get decrypted values error from voltage helper"() {
        given:
        hmDecInput.put(MPSDefs.DB_DSL_NET_ENCR_TYPE, "C")
        HashMap<String, Object> voltageResult = new HashMap<>()
        voltageResult.put(CommonDefs.COMMON_APP_STATUS_CODE, "118")
        voltageHelper.getEFPEDecryptedValues(hmDecInput) >> voltageResult

        when:
        HashMap<String, Object> hmResult = proofingEncryption_H.getDecryptedValues(hmDecInput)

        then:
        hmResult.get("appStatusCode") == "118"
    }

    def "test replace all"() {
        given:
        hmDecInput = null
        when:
        String strResult = proofingEncryption_H.replaceAll(null, ' ', ' ')
        then:
        strResult == null

        when:
        strResult = proofingEncryption_H.replaceAll('online1SecurityAnswer', null, ' ')
        then:
        strResult == 'online1SecurityAnswer'

        when:
        strResult = proofingEncryption_H.replaceAll('online1SecurityAnswer', 'Answer', null)
        then:
        strResult == 'online1Security'

        when:
        strResult = proofingEncryption_H.replaceAll('online1SecurityAnswer', 'Answer', 'Question')
        then:
        strResult == 'online1SecurityQuestion'
    }
}