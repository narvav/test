package com.att.idp.idgraphuserregistrationms.resource.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.request.validator.QueryByIPEligibilityReqValidator
import com.att.idp.idgraphuserregistrationms.request.validator.RegisterLSUserRequestValidator
import com.att.idp.idgraphuserregistrationms.request.validator.VerifyExistingMemberEligibilityRequestValidator
import com.att.idp.idgraphuserregistrationms.resource.request.PreAccountRegRequest
import com.att.idp.idgraphuserregistrationms.resource.request.QueryByIPEligibilityRequest
import com.att.idp.idgraphuserregistrationms.resource.request.RegisterLSUserRequest
import com.att.idp.idgraphuserregistrationms.resource.request.VerifyExistingMemberEligibilityRequest
import com.att.idp.idgraphuserregistrationms.resource.response.QueryByIPEligibilityResponse
import com.att.idp.idgraphuserregistrationms.resource.response.RegisterLSUserResponse
import com.att.idp.idgraphuserregistrationms.resource.response.VerifyExistingMemberEligibilityResponse
import com.att.idp.idgraphuserregistrationms.service.QueryByIPEligibilityService
import com.att.idp.idgraphuserregistrationms.service.RegisterLSUserService
import com.att.idp.idgraphuserregistrationms.service.impl.VerifyExistingMemberEligibilityServiceImpl
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.Response
import java.sql.SQLException


class LsRegResourceImplTest extends Specification {
	
	def lsRegResourceImplObj=new LsRegResourceImpl()

	QueryByIPEligibilityReqValidator queryByIPEligReqValidatorObj=Mock(QueryByIPEligibilityReqValidator)

	QueryByIPEligibilityService queryByIPEligibilityServiceObj=Mock(QueryByIPEligibilityService)

	VerifyExistingMemberEligibilityRequestValidator verifyEMERequestvalidatorObj=Mock(VerifyExistingMemberEligibilityRequestValidator)

	VerifyExistingMemberEligibilityServiceImpl verifyEMEServiceImplObj=Mock(VerifyExistingMemberEligibilityServiceImpl)

	HttpHeaders httpHeaders=Mock(HttpHeaders)

	QueryByIPEligibilityRequest queryByIPEligReqObj=Mock(QueryByIPEligibilityRequest)

	private QueryByIPEligibilityResponse queryByIPEligibResObj = null

	RegisterLSUserRequestValidator registerLSUserReqValidator=Mock(RegisterLSUserRequestValidator)

	RegisterLSUserService registerLSUserService=Mock(RegisterLSUserService)
	
	def setup() {
		lsRegResourceImplObj.queryByIPEligReqValidator = queryByIPEligReqValidatorObj
		lsRegResourceImplObj.queryByIPEligibilityService = queryByIPEligibilityServiceObj
		
		lsRegResourceImplObj.verifyEMERequestvalidatorObj = verifyEMERequestvalidatorObj
		lsRegResourceImplObj.verifyEMEServiceImplObj = verifyEMEServiceImplObj
		
		lsRegResourceImplObj.registerLSUserReqValidator = registerLSUserReqValidator
		lsRegResourceImplObj.registerLSUserService = registerLSUserService
	}


	def "test query by i p eligibility success"() throws Exception {
		given:
		queryByIPEligibResObj = new QueryByIPEligibilityResponse()
		queryByIPEligibResObj.appCategoryCode = '0'
		queryByIPEligReqValidatorObj.queryByIPEligibilityReqValidator(_ as HttpHeaders, _ as QueryByIPEligibilityRequest)>>null
		queryByIPEligibilityServiceObj.queryByIPEligibility(_ as QueryByIPEligibilityRequest, _)>>queryByIPEligibResObj
		when:
		Response response = lsRegResourceImplObj.queryByIPEligibility(queryByIPEligReqObj, httpHeaders)
		then:
		response.status == 200
	}


	def "test query by i p eligibility error"() throws Exception {
		
		// error from request validator
		given:
		queryByIPEligibResObj = new QueryByIPEligibilityResponse()
		queryByIPEligibResObj.appCategoryCode = '2'
		queryByIPEligibilityServiceObj.queryByIPEligibility(_ as QueryByIPEligibilityRequest, _)>>queryByIPEligibResObj
		when:
		Response response = lsRegResourceImplObj.queryByIPEligibility(queryByIPEligReqObj, httpHeaders)
		then:
		response.status == 500

		// error from service
		when:
		queryByIPEligibResObj.appCategoryCode = '3'
		response = lsRegResourceImplObj.queryByIPEligibility(queryByIPEligReqObj, httpHeaders)
		then:
		response.status == 400
	}


	def "test query by i p elig data exception"() throws Exception {

		given:
		InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
		
		when:queryByIPEligibilityServiceObj.queryByIPEligibility(_ as QueryByIPEligibilityRequest, _) >> { throw ex }
		lsRegResourceImplObj.queryByIPEligibility(queryByIPEligReqObj, httpHeaders)
        then:
        thrown(InvalidInputDataException.class)
	}


	def "test query by i p elig exception"() throws Exception {

		given:
		NullPointerException ex = new NullPointerException('NullPointerException thrown')
		when:queryByIPEligibilityServiceObj.queryByIPEligibility(_ as QueryByIPEligibilityRequest, _) >> { throw ex }
		and:
		Response response = lsRegResourceImplObj.queryByIPEligibility(queryByIPEligReqObj, httpHeaders)
		then:
		response.status == 500
	}


	def "test register l s user success"() throws Exception {
		given:
		RegisterLSUserResponse registerLSUSerResponse = new RegisterLSUserResponse()
		registerLSUSerResponse.appCategoryCode = '0'
		registerLSUserReqValidator.registerLSUserReqValidator(_ as HttpHeaders, _ as RegisterLSUserRequest)>>null
		registerLSUserService.registerLSUser(_ as RegisterLSUserRequest, _)>>registerLSUSerResponse
		when:
		Response response = lsRegResourceImplObj.registerLSUser(new RegisterLSUserRequest(), httpHeaders)
		then:
		response.status == 200
	}


	def "test register l s user error"() throws Exception {
		
		// error from request validator
		given:
		RegisterLSUserResponse registerLSUSerResponse = new RegisterLSUserResponse()
		registerLSUSerResponse.appCategoryCode = '2'
		registerLSUserReqValidator.registerLSUserReqValidator(_ as HttpHeaders, _ as RegisterLSUserRequest)>>registerLSUSerResponse
		when:
		Response response = lsRegResourceImplObj.registerLSUser(new RegisterLSUserRequest(), httpHeaders)
		then:
		response.status == 500

		// error from service
		when:
		registerLSUSerResponse.appCategoryCode = '3'
		response = lsRegResourceImplObj.registerLSUser(new RegisterLSUserRequest(), httpHeaders)
		then:
		response.status == 400
	}


	def "test register l s user data exception"() throws Exception {

		given:
		InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
		when:registerLSUserService.registerLSUser(_ as RegisterLSUserRequest, _) >> { throw ex }
		InvalidInputDataException excep = lsRegResourceImplObj.registerLSUser(new RegisterLSUserRequest(), httpHeaders) as InvalidInputDataException
        then:
        thrown(InvalidInputDataException.class)

	}


	def "test register l s user exception"() throws Exception {

		given:
		NullPointerException ex = new NullPointerException('NullPointerException thrown')
		when:registerLSUserService.registerLSUser(_ as RegisterLSUserRequest, _) >> { throw ex }
		and:
		Response response = lsRegResourceImplObj.registerLSUser(new RegisterLSUserRequest(), httpHeaders)
		then:
		response.status == 500
	}


	def "test v e m e success"() throws Exception {
		given:
		VerifyExistingMemberEligibilityResponse verifyExistingMemberEligibilityResponse = new VerifyExistingMemberEligibilityResponse()
		verifyExistingMemberEligibilityResponse.appCategoryCode = '0'
		verifyEMERequestvalidatorObj.verifyExistingMemberEligibilityReqValidator(_ as HttpHeaders, _ as VerifyExistingMemberEligibilityRequest)>>null
		verifyEMEServiceImplObj.verifyExistingMemberEligibility(_ as VerifyExistingMemberEligibilityRequest, _)>>verifyExistingMemberEligibilityResponse
		when:
		Response response = lsRegResourceImplObj.verifyExistingMemberEligibility(new VerifyExistingMemberEligibilityRequest(), httpHeaders)
		then:
		response.status == 200
	}


	def "test v e m e error"() throws Exception {
		
		// error from request validator
		given:
		VerifyExistingMemberEligibilityResponse verifyExistingMemberEligibilityResponse = new VerifyExistingMemberEligibilityResponse()
		verifyExistingMemberEligibilityResponse.appCategoryCode = '2'
		verifyEMERequestvalidatorObj.verifyExistingMemberEligibilityReqValidator(_ as HttpHeaders, _ as VerifyExistingMemberEligibilityRequest)>>verifyExistingMemberEligibilityResponse
		when:
		Response response = lsRegResourceImplObj.verifyExistingMemberEligibility(new VerifyExistingMemberEligibilityRequest(), httpHeaders)
		then:
		response.status == 500

		// error from service
		when:
		verifyExistingMemberEligibilityResponse.appCategoryCode = '3'
		response = lsRegResourceImplObj.verifyExistingMemberEligibility(new VerifyExistingMemberEligibilityRequest(), httpHeaders)
		then:
		response.status == 400
	}


	def "test v e m e data exception"() throws Exception {

		given:
		InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
		when:verifyEMEServiceImplObj.verifyExistingMemberEligibility(_ as VerifyExistingMemberEligibilityRequest, _) >> { throw ex }
		InvalidInputDataException excep = lsRegResourceImplObj.verifyExistingMemberEligibility(new VerifyExistingMemberEligibilityRequest(), httpHeaders) as InvalidInputDataException
        then:
		thrown(InvalidInputDataException.class)

	}


	def "test v e m e exception"() throws Exception {

		given:
		NullPointerException ex = new NullPointerException('NullPointerException thrown')
		when:verifyEMEServiceImplObj.verifyExistingMemberEligibility(_ as VerifyExistingMemberEligibilityRequest, _) >> { throw ex }
		and:
		Response response = lsRegResourceImplObj.verifyExistingMemberEligibility(new VerifyExistingMemberEligibilityRequest(), httpHeaders)
		then:
		response.status == 500
	}
	def "test pre account reg sql exception"() throws Exception {

		given:
		SQLException ex = new SQLException('SQLException thrown')
		when:verifyEMEServiceImplObj.verifyExistingMemberEligibility(_ as VerifyExistingMemberEligibilityRequest, _) >> { throw ex }
		Response response = lsRegResourceImplObj.verifyExistingMemberEligibility(new VerifyExistingMemberEligibilityRequest(), httpHeaders)
		then:
		response.status == 500
	}
}
