package com.att.idp.idgraphuserregistrationms.queue.message.helpers

import com.att.idp.idgraphuserregistrationms.queue.message.sender.JMSQueueSender
import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.mpsys.common.utils.CommonDefs
import org.springframework.test.context.junit.jupiter.SpringExtension
import spock.lang.Specification

class ValidateAndSyncG2QueueHelperTest extends Specification {

    def validateAndSyncG2QueueHelper = new ValidateAndSyncG2QueueHelper()

    JMSQueueSender oJMSQueueSender = Mock(JMSQueueSender)


    def setup() {
    validateAndSyncG2QueueHelper.oJMSQueueSender = oJMSQueueSender
    }


    def "make async call returns expected result when account info is not empty and w d m t o s is y"() {
        given:
        SyncUserProfileRequest validateAndSyncG2Request = new SyncUserProfileRequest()
        validateAndSyncG2Request.idpTraceId = 'traceId'
        validateAndSyncG2Request.transactionName = 'transactionName'
        validateAndSyncG2Request.callingSystemId = 'callingSystemId'
        validateAndSyncG2Request.ban = 'ban'

        HashMap<String, Object> accountInfo = new HashMap<>()
        accountInfo[CommonDefs.WDM_TOS] = CommonDefs.IND_Y
        ArrayList<Object> accountInfoList = new ArrayList<>()
        accountInfoList.add(accountInfo)

        HashMap<String, Object> expectedResponse = new HashMap<>()
        oJMSQueueSender.send(_ as Map<String, Object>) >> expectedResponse

        when:
        Map<String, Object> result = validateAndSyncG2QueueHelper.makeAsyncCall(validateAndSyncG2Request, accountInfoList)

        then:
        result == expectedResponse
//        when:
//        verify(oJMSQueueSender, times(1)).send(org.mockito.ArgumentMatchers.any())
    }


    def "make async call returns empty result when account info is empty"() {
        // Given
        given:
        SyncUserProfileRequest validateAndSyncG2Request = new SyncUserProfileRequest()
        ArrayList<Object> accountInfoList = new ArrayList<>()
        validateAndSyncG2Request.idpTraceId = 'traceId'

        when:
        Map<String, Object> result = validateAndSyncG2QueueHelper.makeAsyncCall(validateAndSyncG2Request, accountInfoList)

        then:
        result.isEmpty()
    }


    def "make async call returns empty result when w d m t o s is not y"() {
        // Given
        given:
        SyncUserProfileRequest validateAndSyncG2Request = new SyncUserProfileRequest()
        HashMap<String, Object> accountInfo = new HashMap<>()
        validateAndSyncG2Request.idpTraceId = 'traceId'
        accountInfo[CommonDefs.WDM_TOS] = 'N'
        ArrayList<Object> accountInfoList = new ArrayList<>()
        accountInfoList.add(accountInfo)

        when:
        Map<String, Object> result = validateAndSyncG2QueueHelper.makeAsyncCall(validateAndSyncG2Request, accountInfoList)

        then:
        result.isEmpty()
    }
}
