package com.att.idp.idgraphuserregistrationms.metrics

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics
import org.springframework.stereotype.Component
import spock.lang.Specification

import java.lang.reflect.Method

class ErrorMetricHandlerTest extends Specification {

    ErrorMetricHandler errorMetricHandler = new ErrorMetricHandler()

    def "ErrorMetricHandler is annotated with @Component"() {
        when:
        boolean hasComponent = errorMetricHandler.class.isAnnotationPresent(Component)

        then:
        hasComponent
        0 * _
    }

    def "recordDbErrorMetric is annotated with @TimedMetrics with correct name"() {
        when:
        Method method = ErrorMetricHandler.getDeclaredMethod('recordDbErrorMetric')
        TimedMetrics annotation = method.getAnnotation(TimedMetrics)

        then:
        annotation != null
        annotation.name() == 'IDGRAPH_USERREGMS_DB_ERR'
        0 * _
    }

    def "recordDbErrorMetric is annotated with correct description"() {
        when:
        Method method = ErrorMetricHandler.getDeclaredMethod('recordDbErrorMetric')
        TimedMetrics annotation = method.getAnnotation(TimedMetrics)

        then:
        annotation.description() == 'Oracle DB error in IDGraphUserRegistrationMs'
        0 * _
    }

    def "recordDbErrorMetric is annotated with correct constantTags"() {
        when:
        Method method = ErrorMetricHandler.getDeclaredMethod('recordDbErrorMetric')
        TimedMetrics annotation = method.getAnnotation(TimedMetrics)

        then:
        annotation.constantTags().contains('database=mpsys')
        annotation.constantTags().contains('container=oracle')
        0 * _
    }

    def "recordDbErrorMetric can be called without throwing"() {
        when:
        errorMetricHandler.recordDbErrorMetric()

        then:
        noExceptionThrown()
        0 * _
    }
}
