#!/bin/bash

# Sigalit Benish
# Parse e2e tests results

usage() {
  echo "Usage: "
  echo "---------------------------------------------------------------------------"
  echo "$0 TEST_DIRECTORY TEST_DIRECTORY [...]"
  echo ""
  echo "TEST_DIRECTORY     Pass relevant test dorectories as arguments"
  echo "---------------------------------------------------------------------------"
}

TOTAL_FAILED_TESTS=0
TOTAL_PASSED_TESTS=0
TOTAL_TOTAL_TESTS=0
TOTAL_SKIPPED_TESTS=0

MAIN_DIR=`pwd`

if [ $# == 0 ]; then
  usage
  exit 0
else
  for DIRECTORY in "$@"; do
    cd ${MAIN_DIR}/${DIRECTORY} || return
    echo "${DIRECTORY}"
    XML_FILES=`find . -name "*.xml"`
    for FILE in ${XML_FILES}; do
          echo "Prasing ${FILE} results"
		  # FAILED
          FAILED_TESTS=`cat ${FILE} | head -2 | tail -1 | grep -o 'failures=\"[0-9]*"' | awk -F'=' '{print $2}' | awk -F'"' '{print $2}'`
		  ERROR_TESTS=`cat ${FILE} | head -2 | tail -1 | grep -o 'errors=\"[0-9]*"' | awk -F'=' '{print $2}' | awk -F'"' '{print $2}'`
		  FLAKY_ERROR_COUNT=$((`cat ${FILE} | grep -c flakyError`/2)) # Remove flakyError runs from total failed tests count
		  FLAKY_FAILURE_COUNT=$((`cat ${FILE} | grep -c flakyFailure`/2)) # Remove flakyFailure runs from total failed tests count
		  RERUN_FAILURE_COUNT=$((`cat ${FILE} | grep -c rerunFailure`/2)) # Remove rerunFailure runs from total failed tests count
		  FAILED_TESTS=$((FAILED_TESTS+ERROR_TESTS-FLAKY_ERROR_COUNT-FLAKY_FAILURE_COUNT-RERUN_FAILURE_COUNT))
          TOTAL_FAILED_TESTS=$((TOTAL_FAILED_TESTS+FAILED_TESTS))
		  echo "Failed=${TOTAL_FAILED_TESTS}" 
		  # SKIPPED
          SKIPPED_TESTS=`cat ${FILE} | head -2 | tail -1 | grep -o 'skipped=\"[0-9]*"' | awk -F'=' '{print $2}' | awk -F'"' '{print $2}'`
          TOTAL_SKIPPED_TESTS=$((TOTAL_SKIPPED_TESTS+SKIPPED_TESTS))
		  echo "Skipped=${TOTAL_SKIPPED_TESTS}"
		  # TOTAL
		  TOTAL_TESTS=`cat ${FILE} | head -2 | tail -1 | grep -o 'tests=\"[0-9]*"' | awk -F'=' '{print $2}' | awk -F'"' '{print $2}'`
		  TOTAL_TESTS=$((TOTAL_TESTS-SKIPPED_TESTS-FLAKY_ERROR_COUNT-FLAKY_FAILURE_COUNT-RERUN_FAILURE_COUNT)) # Count total tests without skipped and flaky
          TOTAL_TOTAL_TESTS=$((TOTAL_TOTAL_TESTS+TOTAL_TESTS))
		  echo "Total=${TOTAL_TOTAL_TESTS}"
		  # PASSED
          PASSED_TESTS=$((TOTAL_TESTS-FAILED_TESTS))
          TOTAL_PASSED_TESTS=$((TOTAL_PASSED_TESTS+PASSED_TESTS))
		  echo "Success=${TOTAL_PASSED_TESTS}"
     done
  done
   
  echo "Writing to properties file...."
  cd ${MAIN_DIR}
  echo "total=${TOTAL_TOTAL_TESTS}" > automation_test_results.properties
  echo "skipped=${TOTAL_SKIPPED_TESTS}" >> automation_test_results.properties
  echo "failed=${TOTAL_FAILED_TESTS}" >> automation_test_results.properties
  echo "success=${TOTAL_PASSED_TESTS}" >> automation_test_results.properties
fi